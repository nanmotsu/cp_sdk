/**
 * @file YAML・基本設定の取得と更新をHTTPで提供する。
 */

import { readJson, sendJson } from "../../common/api/http.mjs";

/** 文書設定のルートを登録する。 */
export function configRoutes(documents) {
    return [
        ["GET", "/documents/:id/config", async (_request, response, { id }) => sendJson(response, 200, await documents.config(id))],
        ["PATCH", "/documents/:id/config", async (request, response, { id }) => {
            const { changes, revision } = await readJson(request);
            return sendJson(response, 200, await documents.patchBasicSettings(id, changes, revision));
        }],
        ["PUT", "/documents/:id/config", async (request, response, { id }) => {
            const { yaml, revision } = await readJson(request);
            return sendJson(response, 200, await documents.putConfig(id, yaml, revision));
        }],
    ];
}
