/** @file 素材と指示を図版作成エージェントに送り、登録結果を図版一覧へつなぐ。 */

import { useState } from 'react';
import type { ClipboardEvent, FormEvent } from 'react';
import { errorMessage } from '../api';
import type { FigureGenerationResult, FigureMaterialInput } from '../api';
import type { JobState } from '../useJob';
import { allowedImageTypes, loadFigureImage, maxImages, maxUploadBytes } from './FigureEditor';
import { JobFeedback } from './Feedback';

/** 実行条件と、依頼・登録済み図版への移動操作。 */
interface Props {
  disabled: boolean;
  job: JobState<FigureGenerationResult>;
  canRequest: boolean;
  imageModelUnsupported: boolean;
  onRequest: (images: FigureMaterialInput[], instruction: string) => Promise<void>;
  onOpenFigures: () => void;
}

/** 添付画像の選択、図版作成の依頼、登録結果の表示を扱う。 */
export default function FigureRequest({ disabled, job, canRequest, imageModelUnsupported, onRequest, onOpenFigures }: Props) {
  const [materials, setMaterials] = useState<FigureMaterialInput[]>([]);
  const [instruction, setInstruction] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const locked = disabled || loading || job.busy;
  const visionNeeded = materials.length > 0 && imageModelUnsupported;
  const result = job.job?.status === 'succeeded' ? job.job.result : undefined;

  /** 素材を添付に追加する。アプリに送る前に形式と容量を確認する。 */
  async function addFiles(files: File[]) {
    if (locked || !files.length) return;
    setError('');
    if (materials.length + files.length > maxImages) {
      setError(`添付できる画像は${maxImages}枚までです。`);
      return;
    }
    const attachedBytes = materials.reduce((sum, item) => sum + item.base64.length * 3 / 4
      - (item.base64.endsWith('==') ? 2 : item.base64.endsWith('=') ? 1 : 0), 0);
    if (attachedBytes + files.reduce((sum, file) => sum + file.size, 0) > maxUploadBytes) {
      setError('画像素材の合計を20 MiB以下にしてください。');
      return;
    }
    setLoading(true);
    try {
      const additions = await Promise.all(files.map(loadFigureImage));
      setMaterials(current => [...current, ...additions.map(({ name, upload }) => ({ ...upload, name }))]);
    } catch (exception) {
      setError(errorMessage(exception));
    } finally {
      setLoading(false);
    }
  }

  /** クリップボードの画像を、ファイルからの添付と同じ形式へ渡す。 */
  function paste(event: ClipboardEvent<HTMLDivElement>) {
    if (locked) return;
    const images = Array.from(event.clipboardData.items).flatMap(item => {
      const file = item.type.startsWith('image/') && item.getAsFile();
      return file ? [file] : [];
    });
    const files = images.length ? images : Array.from(event.clipboardData.files).filter(file => file.type.startsWith('image/'));
    if (!files.length) return;
    event.preventDefault();
    void addFiles(files);
  }

  /** 依頼に必要な入力がそろったときだけ図版ジョブを開始する。 */
  function requestFigure(event: FormEvent) {
    event.preventDefault();
    if (locked || !canRequest || visionNeeded || !instruction.trim()) return;
    setError('');
    void onRequest(materials, instruction.trim());
  }

  return <form className="stack" onSubmit={requestFigure}>
    <p className="muted">Copilotに画像パーツの生成や素材の配置を依頼できます。完成した図版は「図版」タブで編集できます。画像生成にはCopilotのAIクレジットを使います。</p>
    <div className="stack local-image-picker">
      <label>手元の画像素材を添付
        <input type="file" accept={allowedImageTypes.join(',')} multiple disabled={locked} onChange={event => {
          void addFiles(Array.from(event.currentTarget.files ?? []));
          event.currentTarget.value = '';
        }} />
      </label>
      <div className="image-paste-target" tabIndex={locked ? -1 : 0} role="group" aria-label="スクリーンショットを貼り付け" onPaste={paste}>
        <span>スクリーンショットを貼り付け</span><span className="muted">ここを選んで Ctrl+V</span>
      </div>
    </div>
    {materials.length > 0 && <div className="candidate-grid" role="group" aria-label="添付した画像素材">
      {materials.map(material => <figure className="candidate" key={material.id}>
        <img alt={material.name} src={`data:${material.mime};base64,${material.base64}`} />
        <figcaption>
          <span>{material.name}</span>
          <button type="button" disabled={locked} aria-label={`${material.name}を添付から外す`}
            onClick={() => setMaterials(current => current.filter(item => item.id !== material.id))}>外す</button>
        </figcaption>
      </figure>)}
    </div>}
    <label>図版への指示<textarea value={instruction} rows={3} maxLength={8000} disabled={locked}
      onChange={event => setInstruction(event.target.value)}
      placeholder="スクリーンショットを左に置き、右には説明用のイラストを生成して、違いを矢印で示して。" /></label>
    {visionNeeded && <p className="muted">添付画像を使うには、画像入力に対応するモデルを選んでください。</p>}
    <div className="form-actions">
      <button className="primary" type="submit" disabled={locked || !canRequest || visionNeeded || !instruction.trim()}>図版作成を依頼</button>
    </div>
    {error && <p className="error" role="alert">{error}</p>}
    <JobFeedback state={job} />
    {result && <section className="job-result stack" aria-label="図版作成の結果">
      <p>「{result.figure.name}」を図版一覧に登録しました。</p>
      <div className="form-actions"><button type="button" onClick={onOpenFigures}>図版タブで確認</button></div>
    </section>}
  </form>;
}
