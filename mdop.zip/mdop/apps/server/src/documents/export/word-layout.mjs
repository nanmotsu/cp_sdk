/**
 * @file Word向けのレイアウトにHTMLを整え、DOCX変換器へ渡した後に生成されたXMLを補正する。
 */

import { createServer } from "node:http";
import { randomUUID } from "node:crypto";
import JSZip from "jszip";
import { escapeHtml } from "../shared/markup.mjs";

/** DOCX変換器が画像を取得できるよう、変換中だけ埋め込み画像をローカルHTTPで配信する。 */
export async function serveImagesViaHttp(html) {
    const imageStore = new Map();
    const token = randomUUID();

    // data: URI を収集してプレースホルダーに置換（port はまだ未定）
    const placeholderHtml = html.replace(/src="data:([^;]+);base64,([^"]+)"/g, (_, mime, base64) => {
        const id = imageStore.size;
        const subtype = mime.split("/")[1] || "png";
        const ext = subtype === "jpeg" ? "jpg" : subtype;
        const path = `/${token}/${id}.${ext}`;
        imageStore.set(path, { mime, buffer: Buffer.from(base64, "base64") });
        return `src="__IMG_SERVER_${token}__${path}"`;
    });

    if (imageStore.size === 0) {
        // 画像がなければサーバー不要
        return { html, cleanup: async () => { } };
    }

    const server = createServer((req, res) => {
        const image = imageStore.get(req.url);
        if (req.method === "GET" && image) {
            res.writeHead(200, { "Content-Type": image.mime, "Content-Length": image.buffer.length });
            res.end(image.buffer);
            return;
        }
        res.writeHead(404);
        res.end();
    });

    await new Promise((resolve, reject) => {
        server.once("error", reject);
        server.listen(0, "127.0.0.1", resolve);
    });
    const port = server.address().port;

    const finalHtml = placeholderHtml.replaceAll(`__IMG_SERVER_${token}__`, `http://127.0.0.1:${port}`);
    const cleanup = () => new Promise(r => server.close(r));
    return { html: finalHtml, cleanup };
}

/** 長さをピクセルへ換算する。割合は用紙の本文幅または画像の高さを基準にする。 */
function figureLengthInPixels(value, basis) {
    const relative = /^(\d+(?:\.\d+)?)(%|em|rem)$/i.exec(value ?? "");
    if (relative) return Number(relative[1]) * (relative[2] === "%" ? basis / 100 : 16);
    const twips = cssLengthToTwips(value, null);
    return twips === null ? undefined : twips / 15;
}

/** Wordへ渡すPNGのIHDRを読み、縦横比を保った掲載幅を求める。 */
function fittedFigureWidth(tag, width, height, contentWidth) {
    const source = /\ssrc="data:image\/png;base64,([A-Za-z0-9+/]{32})/i.exec(tag)?.[1];
    const header = Buffer.from(source ?? "", "base64");
    const hasDimensions = header.length === 24 && header.subarray(0, 8).toString("hex") === "89504e470d0a1a0a"
        && header.toString("ascii", 12, 16) === "IHDR";
    const maxWidth = Math.min(contentWidth, figureLengthInPixels(width, contentWidth) ?? contentWidth);
    if (!hasDimensions) return maxWidth;
    const imageWidth = header.readUInt32BE(16);
    const imageHeight = header.readUInt32BE(20);
    const maxHeight = figureLengthInPixels(height, imageHeight);
    return imageHeight && imageWidth && maxHeight !== undefined ? Math.min(maxWidth, maxHeight * imageWidth / imageHeight) : maxWidth;
}

/** 本文HTMLを、Word変換器で扱いやすいブロックとスタイルへ整える。 */
export function buildWordHtml(processedBodyHtml, title, contentWidth) {
    return `<!DOCTYPE html>
    <html lang="ja">
    <head>
      <meta charset="UTF-8">
      <title>${escapeHtml(title)}</title>
    </head>
    <body>
    ${processedBodyHtml
            // dsl.mjs の figure-body / mermaid-block ラッパーは Word では素の div に正規化
            .replace(/<div class="figure-body"([^>]*)>/g, '<div$1>')
            .replace(/<div class="mermaid-block"([^>]*)>/g, '<div$1>')
            // figure 全体を Word 互換ブロックに変換（本文 + キャプション）
            .replace(/<figure([^>]*)>([\s\S]*?)<\/figure>/gi, (_, figAttrs, inner) => {
                const alignMatch = String(figAttrs || "").match(/text-align\s*:\s*(left|center|right)/i);
                const align = alignMatch ? alignMatch[1].toLowerCase() : "center";
    
                const captionMatch = inner.match(/<figcaption>([\s\S]*?)<\/figcaption>/i);
                const caption = captionMatch ? captionMatch[1].trim() : "";
                const body = inner.replace(/<figcaption>[\s\S]*?<\/figcaption>/i, "").trim();
    
                const bodyBlock = body
                    ? `<div style="text-align:${align};">${body}</div>`
                    : "";
                const capBlock = caption
                    ? `<p style="text-align:center;"><em>${caption}</em></p>`
                    : "";
                return bodyBlock + capBlock;
            })
            // 縦横比を保つ図版は、Word変換器が元画像から高さを求めるよう幅だけを渡す。
            .replace(/<img([^>]*?)style="max-width:100%(?:;([^"]*))?"([^>]*?)>/gi, (tag, before, rest, after) => {
                const widthMatch = rest?.match(/width:([^;]+)/);
                const heightMatch = rest?.match(/height:([^;]+)/);
                if (rest?.split(";").includes("object-fit:contain")) {
                    const fittedWidth = fittedFigureWidth(tag, widthMatch?.[1], heightMatch?.[1], contentWidth);
                    if (!fittedWidth) return "";
                    return `<img${before}style="width:${fittedWidth.toFixed(3)}px;height:auto"${after}>`;
                }
                const widthStyle = widthMatch ? `width:${widthMatch[1]}` : 'width:100%';
                const heightStyle = heightMatch ? `;height:${heightMatch[1]}` : '';
                return `<img${before}style="${widthStyle}${heightStyle}"${after}>`;
            })
            // コードブロック: 1行1<p>形式に変換（html-to-docx は <pre> 内改行を保持しないため）
            .replace(/<pre[^>]*><code[^>]*>([\s\S]*?)<\/code><\/pre>/g, (_, content) => {
                const monoStyle = "font-family:'Courier New','Consolas',monospace;font-size:9pt;margin:0;padding:2pt 0;";
                const lines = content.split('\n');
                while (lines.length && !lines[0].trim()) lines.shift();
                while (lines.length && !lines[lines.length - 1].trim()) lines.pop();
                if (!lines.length) return '';
                return lines.map(l => `<p style="${monoStyle}">${l || '&#160;'}</p>`).join('\n');
            })
            // テーブル: <table> に border スタイルを強制付与
            .replace(/<table(?![^>]*border)[^>]*?>/gi, m => {
                if (m.includes('style=')) {
                    return m.replace(/style="([^"]*)"/, (s, s1) => `style="${s1};border:0.6pt solid #999;border-collapse:collapse;margin-left:0;margin-right:auto;"`);
                } else {
                    return m.replace(/<table/, '<table style="border:0.6pt solid #999;border-collapse:collapse;margin-left:0;margin-right:auto;"');
                }
            })
            // テーブルセル: 下 padding を除去し、全体を詰める
            .replace(/<(td|th)([^>]*)>/gi, (_, tag, attrs) => {
                if (/\bstyle="/i.test(attrs)) {
                    return `<${tag}${attrs.replace(/\bstyle="([^"]*)"/i, (_m, s) => ` style="${s};padding-top:0;padding-bottom:0;border:0.6pt solid #999;"`)}>`;
                }
                return `<${tag}${attrs} style="padding-top:0;padding-bottom:0;border:0.6pt solid #999;">`;
            })
            // Word 変換ライブラリが caption を取り込まないため、表の直前の段落に変換する
            .replace(/(<table\b[^>]*>)\s*<caption\b[^>]*>([\s\S]*?)<\/caption>/gi, '<p class="table-caption">$2</p>$1')
            .replace(/<p class="table-caption">/g, '<p class="table-caption" style="text-align:center;margin:0 0 4pt 0;">')
            // DSL warning ブロック: 左ボーダー + 背景色
            .replace(/<div class="warning">/g, '<div style="color:#e67e00;background:#fff8f0;border-left:4px solid #e67e00;padding:6pt;">')
            // DSL center ブロック
            .replace(/<div class="center">/g, '<div style="text-align:center;">')
            // DSL right ブロック
            .replace(/<div class="right">/g, '<div style="text-align:right;">')
            // DSL large ブロック
            .replace(/<div class="large">/g, '<div style="font-size:18pt;">')
            // DSL red ブロック
            .replace(/<div class="red">/g, '<div style="color:#cc0000;">')
            // ページ区切り: page-break クラスの div を Word 改ページへ
            .replace(/<div class="page-break"><\/div>/g, '<div style="page-break-before:always;"></div>')
        }
    </body>
    </html>`;
}

/** CSSの長さをWordの単位であるtwipへ変換する。 */
export function cssLengthToTwips(value, fallback) {
    const text = String(value ?? "").trim().toLowerCase();
    const match = text.match(/^([0-9]+(?:\.[0-9]+)?)\s*(mm|cm|in|pt|px)?$/);
    if (!match) return fallback;

    const amount = Number(match[1]);
    const unit = match[2] || "px";
    const twipsPerUnit = { mm: 56.6929, cm: 566.929, in: 1440, pt: 20, px: 15 };
    return Math.round(amount * (twipsPerUnit[unit] || twipsPerUnit.px));
}

/** Wordの互換モードを設定ファイルのXMLへ追加または更新する。 */
function injectCompatibilityModeToSettingsXml(settingsXml) {
    if (!settingsXml || !settingsXml.includes("<w:settings")) return settingsXml;

    const compatModeTag = '<w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/>';

    if (/<w:compat\b[^>]*>[\s\S]*?<\/w:compat>/i.test(settingsXml)) {
        // 既存の compat ブロック内に compatibilityMode があれば上書き、なければ追記
        return settingsXml.replace(/<w:compat\b[^>]*>([\s\S]*?)<\/w:compat>/i, (all, inner) => {
            if (/w:name="compatibilityMode"/i.test(inner)) {
                const replacedInner = inner.replace(
                    /<w:compatSetting\b[^>]*w:name="compatibilityMode"[^>]*\/?>/i,
                    compatModeTag
                );
                return `<w:compat>${replacedInner}</w:compat>`;
            }
            return `<w:compat>${inner}${compatModeTag}</w:compat>`;
        });
    }

    return settingsXml.replace(/<\/w:settings>\s*$/i, `  <w:compat>${compatModeTag}</w:compat>\n</w:settings>`);
}

// ── OOXML 修正: w:sectPr を w:body の最後に移動 ───────────────────────
/** DOCXのZIPを開き、セクション情報と互換モードのXMLを補正して再圧縮する。 */
export async function repairDocx(docxBuffer) {

    const zip = await JSZip.loadAsync(docxBuffer);
    const entry = zip.file("word/document.xml");
    if (!entry) return docxBuffer;

    let xml = await entry.async("string");

    // w:body 直下先頭にある w:sectPr を末尾の </w:body> 直前に移動
    const bodyOpenIdx = xml.indexOf("<w:body>");
    if (bodyOpenIdx === -1) return docxBuffer;

    const sectPrStartIdx = xml.indexOf("<w:sectPr>", bodyOpenIdx);
    if (sectPrStartIdx === -1) return docxBuffer;

    // sectPr が body の最初の子（間に空白のみ）であることを確認
    const betweenBodyAndSectPr = xml.slice(bodyOpenIdx + "<w:body>".length, sectPrStartIdx);
    if (betweenBodyAndSectPr.trim() !== "") return docxBuffer;

    const sectPrEndIdx = xml.indexOf("</w:sectPr>", sectPrStartIdx) + "</w:sectPr>".length;
    const sectPrText = xml.slice(sectPrStartIdx, sectPrEndIdx);

    // sectPr とその前後の空白を除去
    xml = xml.slice(0, bodyOpenIdx + "<w:body>".length) + xml.slice(sectPrEndIdx);

    // </w:body> 直前に挿入
    const bodyCloseIdx = xml.lastIndexOf("</w:body>");
    xml = xml.slice(0, bodyCloseIdx) + sectPrText + xml.slice(bodyCloseIdx);

    zip.file("word/document.xml", xml);

    const settingsEntry = zip.file("word/settings.xml");
    if (settingsEntry) {
        const settingsXml = await settingsEntry.async("string");
        const patchedSettingsXml = injectCompatibilityModeToSettingsXml(settingsXml);
        zip.file("word/settings.xml", patchedSettingsXml);
    }

    return zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE", compressionOptions: { level: 6 } });
}
