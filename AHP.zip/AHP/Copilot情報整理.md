
## 論理の流れ
1. 失敗時の再実行をしたい
2. AHPが正式リリースされたことを発見。これ使えそう
3. ただvscodeとの実行との差異は？最近でてきたcopilotハーネスもつかってんで
4. localはつかえないが、そもそもlocaって3か月後に死ぬやん
5. じゃあ、プロトコルをつかいまっせ。クライアントをつくりまーす（localサーバー立てて、webUI配置実行）
6. パイプライン1個を検証をして結果を得る

## エビデンスまとめ

### AHP
チェンジログ
 https://github.com/microsoft/agent-host-protocol/blob/main/CHANGELOG.md
 ここをみれば、 [1.0.0] — 2026-10-02    [1.1.0] — 2026-11-12が分かる。



### VSCODE
AIエージェントを理解する
https://code.visualstudio.com/docs/agents/concepts/agents#_agent-loop
エージェントループについて書かれている
HOSTがハーネスの実現させるものの一部となっている感じ（分かりやすい図）
エージェントハーネスは、エージェントループを調整するランタイム（概念？）です。セッションを管理し、言語モデルをツールに接続します

エージェントハーネスを理解する
https://code.visualstudio.com/docs/agents/concepts/agent-harnesses
概念的なものがかかれている？
エージェントハーネスを選択してくださいにつながる
**Agent harness（エージェントハーネス）は一般的な技術概念で、Copilot harnessはその具体的な実装の一つです。**

|比較|Agent harness|Copilot harness|
|---|---|---|
|意味|一般的な概念|GitHub Copilotの実装|
|開発主体|実装によって異なる|GitHub / Microsoft|
|Agent Loop|各実装による|Copilot Runtime|
|使用するSDK|任意|Copilot SDK|
|Agent Host|必須ではない|VS CodeではAgent Host上で動作|

| Agent harness（総称） | 実装                      | 実行場所           |
| ----------------- | ----------------------- | -------------- |
| Local harness     | VS Code独自の実装            | Extension Host |
| Copilot harness   | Copilot SDK / 共通Runtime | Agent Host     |
| Claude harness    | Claude Agent SDK        | Agent Host     |
| Codex harness     | Codex系の実装               | 対応する実行環境       |

![[Pasted image 20261115231807.png]]

![[Pasted image 20261115231902.png]]


ローカルハーネスからコパイロットハーネスへ移動
https://code.visualstudio.com/docs/agents/run/move-to-copilot#understand-what-changes
ローカルが2027年2月に死ぬ

エージェントハーネスを選択してください
https://code.visualstudio.com/docs/agents/run/agent-harnesses
ここにも、ローカルが2027年2月に死ぬことがかかれており（https://code.visualstudio.com/docs/agents/concepts/agent-host#_local-and-existing-extension-host-sessions   ここに密接に統合されている。ウィンドウが所有）
新は Agent Hostにリンクしている
（GitHub Copilot製品全体共通ののCopilot SDK（https://github.com/github/copilot-sdk?utm_source=chatgpt.com#architecture）を使用）
https://code.visualstudio.com/docs/agents/concepts/agent-host#_session-lifetime-and-client-dependencies
＝
エージェントホストアーキテクチャ
https://code.visualstudio.com/docs/agents/concepts/agent-host
エージェントホストのアーキテクチャ。sdkをつかいまっせってこと
一番下にローカルは既存のものとかかれている。
＝
さらにプロトコルが書いてる
https://microsoft.github.io/agent-host-protocol/

エージェントホスト紹介
https://code.visualstudio.com/blogs/2026/08/26/agent-host-architecture#how-the-pieces-fit
開発した理由などがある


--- 


Visual Studio Code 1.135
https://code.visualstudio.com/updates/v1_135#agent-host
エージェントホストがつかえるようになった
_2026年8月26日_

Visual Studio Code 1.143
https://code.visualstudio.com/updates/v1_143#copilot-harness-as-the-default
Copilot ハーネスがデフォルト


Visual Studio Code 1.146
https://code.visualstudio.com/updates/v1_146#copilot-harness-and-deprecation-of-the-local-harness
ローカルハーネスの廃止
2026年11月11日

---

VSではいつ対応した？
- **2025年5月 — Visual Studio 2022 17.14**
    
    Agent modeがプレビューとして登場。Visual Studio独自のCopilot Chat統合で、ファイル編集、ツール実行、エラーを受けた再試行などが可能になりました。
    
    [Visual Studio Blog](https://devblogs.microsoft.com/visualstudio/agent-mode-has-arrived-in-preview-for-visual-studio/)
    
- **2026年7月28日 — Visual Studio 2026**
    
    Copilot SDKを利用した新しい **Agent (Preview)** が登場。従来のAgent modeとは異なる実行基盤を使う選択肢が追加されました。
    
    [Visual Studio Blog](https://devblogs.microsoft.com/visualstudio/visual-studio-july-update-meet-the-new-agent-powered-by-copilot-sdk)
    
- **Visual Studio 2026 18.11**
    
    SDKベースの新Copilot Chatを、設定で有効にできるようになりました。AskとAgentの両方が共通SDK基盤を利用します。
    
    [Microsoft Learn](https://learn.microsoft.com/en-us/visualstudio/ide/copilot-agent-mode?view=visualstudio)
    
- **2026年11月10日 — Visual Studio 2026 18.12**
    
    Copilot SDKを使用した新Copilot Chatが、対象アカウントで既定になりました。Ask・Agentを含むチャット全体が新基盤に移行しています。
     同じ技術です！とかかれている。
    
    [Visual Studio Blog+1](https://devblogs.microsoft.com/visualstudio/copilot-in-visual-studio-just-got-a-major-upgrade/?utm_source=chatgpt.com)


|項目|VS Code（現行Copilot）|Visual Studio 2026 18.12|
|---|---|---|
|Copilot SDK利用|確認済み|確認済み|
|共通Copilot harness|確認済み|確認済み|
|Node.js版SDK利用|公開ソースで確認|**未確認**|
|Agent Host利用|確認済み|**未確認**|
|AHPによる画面接続|確認済み|**未確認**|
|IDE専用ツール|VS Code固有|Visual Studio固有|


## 結論
Local harnessでは、VS CodeのCopilot Chat拡張機能が独自のAgent Loopを実装していた。

Copilot harnessでは、Agent HostがCopilot SDKを介して共通Runtimeを利用する構造に変更された。

このため、両者の違いは単なるモデルの変更ではなく、エージェントの実行制御、セッション管理、プロセス構造の変更である。

また、現行のVS Code Copilot harnessがエージェントホストを用いて実現していることが分かった。

```
> Agent harnessは、Agent Loopを制御するRuntimeである。
> 
> Agent Hostは、複数のHarnessを接続・実行し、セッションやクライアントとの通信を管理する専用プロセスである。
> 
> VS CodeのCopilot harnessでは、Agent Host内のAdapterがNode.js Copilot SDKを利用し、SDKが別プロセスのCopilot Runtimeを管理する。
> 
> 一方、Node.js SDKを直接利用する場合は、Agent Hostを経由せず、Copilot RuntimeによるAgent Loopを利用できる。

**したがって、「HostがHarnessを包含する」よりも、「HostがHarnessを起動・管理する」という表現が正確です。**
```

旧ハーネスの構成は
![[Pasted image 20261115230748.png]]

![[Pasted image 20261115232502.png]]
![[Pasted image 20261115232517.png]]
## chatの取り方
以下は×


```
chatUri = await waitForReady(sub.snapshot);
```

chatUri = await waitForDefaultChat(sub.snapshot);

## Agentハーネスという言葉
|時期|組織・人物|内容|
|---|---|---|
|2025年9月29日|Anthropic|Claude Codeを動かす仕組みを _agent harness_ と呼び、Claude Agent SDKを紹介|
|2025年10月25日|LangChain創業者 Harrison Chase|Framework、Runtime、Harnessの違いを整理。自分が考案した用語ではないと明記|
|2026年2月11日|OpenAI|Harness Engineeringの実践例を公開|
|2026年|Microsoft / VS Code|Agent harnessを公式のアーキテクチャ概念として文書化|

|実装形式|Agent harnessは存在する？|外部SDK|
|---|---|---|
|VS Code旧Local harness|する|Copilot SDKは使用しない|
|GitHub Copilot harness|する|Copilot SDKあり|
|Claude Code|する|Claude Agent SDKあり|
|独自のPythonエージェント|する|自分でAgent Loopを実装すれば不要|
|SDK非公開のAIエージェント製品|する|公開されているとは限らない|