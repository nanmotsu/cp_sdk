/** @file Markdown表を編集できるセルとして表示し、選択位置と入力を親へ伝える。 */

import { useMemo } from 'react';
import type { ClipboardEvent, ReactNode } from 'react';
import { editorHtml } from '../editor/blocks';
import type { MarkdownTable, TableCell } from '../editor/tables';

interface Props {
  table: MarkdownTable;
  selected?: TableCell;
  disabled: boolean;
  caption?: ReactNode;
  fontSize?: string;
  columnWidths: string[];
  resolveImage: (src: string) => string | undefined;
  onFocus: (cell: TableCell, element: HTMLTableCellElement) => void;
  onInput: (cell: TableCell, element: HTMLTableCellElement, inputType: string) => void;
  onPaste: (event: ClipboardEvent<HTMLTableCellElement>) => void;
}

/** 見出しを保持し、最後の列は削除できないGFM表の編集面。 */
export default function VisualTable({ table, selected, disabled, caption, fontSize, columnWidths, resolveImage,
  onFocus, onInput, onPaste }: Props) {
  const html = useMemo(() => table.html.map(row => row.map(cell => ({ __html: editorHtml(cell, resolveImage) }))), [table, resolveImage]);
  const columns = table.align.length;

  function renderRow(values: { __html: string }[], row: number) {
    const Cell = row === 0 ? 'th' : 'td';
    return <tr key={row}>{values.map((value, column) => <Cell key={column}
      scope={row === 0 ? 'col' : undefined} data-table-row={row} data-table-column={column}
      data-selected={selected?.row === row && selected.column === column ? '' : undefined}
      aria-label={row === 0 ? `見出し行、列 ${column + 1}` : `データ行 ${row}、列 ${column + 1}`}
      style={{ textAlign: table.align[column] ?? undefined }}
      tabIndex={disabled ? undefined : 0} contentEditable={!disabled} suppressContentEditableWarning
      dangerouslySetInnerHTML={value}
      onFocus={event => onFocus({ row, column }, event.currentTarget)}
      onInput={event => onInput({ row, column }, event.currentTarget, (event.nativeEvent as InputEvent).inputType)}
      onClick={event => { if ((event.target as Element).closest('a')) event.preventDefault(); }}
      onPaste={onPaste} />)}</tr>;
  }

  return <div className="visual-table-scroll">
    <table className={columnWidths.length ? 'visual-table-fixed' : undefined} style={{ fontSize, minWidth: `${columns * 5}rem` }}>
      {caption && <caption>{caption}</caption>}
      {columnWidths.length > 0 && <colgroup>{Array.from({ length: columns }, (_, index) =>
        <col key={index} style={{ width: columnWidths[index] }} />)}</colgroup>}
      <thead>{renderRow(html[0], 0)}</thead>
      <tbody>{html.slice(1).map((row, index) => renderRow(row, index + 1))}</tbody>
    </table>
  </div>;
}

