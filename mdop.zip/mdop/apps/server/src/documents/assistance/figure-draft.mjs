/**
 * @file Copilotへ画像素材の配置を依頼し、応答から独立して編集できる画像レイヤーと注釈を作る。
 */

import { randomUUID } from "node:crypto";
import { parseFigureAnnotations, FIGURE_LAYER_LIMIT } from "../figures/store.mjs";
import { normalizeFigureSvg } from "../shared/svg.mjs";
import { ApiError } from "../../common/api/errors.mjs";

/** 図版の構成規約を持つ、リポジトリ内のVS Codeカスタムエージェント。 */
/** 専用エージェントに、現在の対象文書・素材情報・利用者の指示を渡す。 */
export function figureDraftPrompt(instruction, materials, document) {
    return [
        "添付と利用者の指示から、エージェント定義の形式で編集可能な図版を1点設計してください。",
        "新しい写真・イラストなどの画像パーツが必要なら画像生成ツールを使い、生成結果を generated 番号で指定してください。",
        `今回の対象文書（図版の登録先）:\n${JSON.stringify(document)}`,
        materials.length
            ? `添付素材（番号／名前／元寸法）:\n${JSON.stringify(materials.map(({ name, width, height }, index) => ({ source: index + 1, name, width, height })))}`
            : "添付素材はありません。",
        `利用者の依頼:\n${instruction}`,
    ].join("\n\n");
}

/** 応答の配置とSVGを検査し、ローカルの素材IDと保存前の部品に対応付ける。 */
export function parseFigureDraft(reply, materials, generatedMaterials = []) {
    const text = reply.trim();
    const fenced = /^(`{3,})json[ \t]*\r?\n([\s\S]*?)\r?\n\1$/i.exec(text);
    const invalid = message => new ApiError(422, "INVALID_FIGURE_DRAFT", message ?? "Copilotの応答を編集可能な図版案として読み込めませんでした。");
    let draft;
    try {
        draft = JSON.parse(fenced?.[2] ?? text);
    } catch {
        throw invalid();
    }
    const { format, name, width, height, images, annotations } = draft ?? {};
    if (format !== "md-operator-figure-v1") {
        throw invalid("図版作成エージェントの応答形式を確認できませんでした。VS Codeで専用エージェントが認識されているか確認してください。");
    }
    if (typeof name !== "string" || !name.trim() || Buffer.byteLength(name.trim()) > 512 || /[\r\n]/.test(name.trim())
        || !Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1 || width > 100000 || height > 100000
        || width * height > 40_000_000 || !Array.isArray(images) || images.length > FIGURE_LAYER_LIMIT
        || !Array.isArray(annotations) || annotations.length > 300 || (!images.length && !annotations.length)) {
        throw invalid();
    }
    const seen = new Set();
    const usedGenerated = new Set();
    const layers = images.map((layer, index) => {
        const { source, generated, svg, name, x, y, width: w, height: h } = layer ?? {};
        if (![x, y, w, h].every(Number.isFinite) || x < 0 || y < 0 || w <= 0 || h <= 0 || x + w > width || y + h > height) {
            throw invalid(`図版案の画像 ${index + 1} の位置と大きさを確認できませんでした。`);
        }
        const placement = { x, y, width: w, height: h };
        if (source !== undefined) {
            const material = Number.isInteger(source) && materials[source - 1];
            if (!material || seen.has(source) || generated !== undefined || svg !== undefined) throw invalid("図版案が参照した画像素材を確認できませんでした。");
            seen.add(source);
            return { ...placement, id: material.id, name: material.name, sourceId: material.id };
        }
        if (generated !== undefined) {
            const image = Number.isInteger(generated) && generatedMaterials[generated - 1];
            if (!image || usedGenerated.has(generated) || svg !== undefined) {
                throw invalid("図版案が参照した生成画像を確認できませんでした。画像生成ツールの結果を確認してください。");
            }
            usedGenerated.add(generated);
            return { ...placement, id: image.id, name: typeof name === 'string' && name.trim() ? name.trim() : image.name,
                sourceId: image.id };
        }
        if (typeof name !== "string" || !name.trim() || Buffer.byteLength(name) > 512
            || typeof svg !== "string" || Buffer.byteLength(svg) > 256 * 1024) throw invalid();
        try {
            return { ...placement, id: randomUUID(), name: name.trim(), svg: normalizeFigureSvg(svg) };
        } catch {
            throw invalid(`生成した画像パーツ「${name}」のSVGを読み込めませんでした。`);
        }
    });
    if (seen.size !== materials.length) throw invalid("図版案にすべての添付素材が配置されていることを確認できませんでした。");
    let shapes;
    try {
        shapes = parseFigureAnnotations(annotations.map(item => ({ ...item, id: randomUUID() })));
    } catch {
        throw invalid("図版案の枠・矢印・文字を読み込めませんでした。");
    }
    return { name: name.trim(), width, height, images: layers, annotations: shapes };
}
