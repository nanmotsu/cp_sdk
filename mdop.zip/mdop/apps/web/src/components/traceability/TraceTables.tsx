import type { Degree, Detail, Item, ItemTable, Mapping } from './api';

export function ItemEditor({ side, table, onChange, disabled }: {
  side: 'source' | 'target'; table: ItemTable; onChange: (table: ItemTable) => void; disabled: boolean;
}) {
  const label = side === 'source' ? '元項目' : '先項目';
  function change(id: string, key: keyof Item, value: string) {
    onChange({ ...table, items: table.items.map(item => item.id === id ? { ...item, [key]: value } : item) });
  }
  return <section className="trace-table-section">
    <div className="trace-table-heading"><h2>{label}表</h2><button type="button" disabled={disabled} onClick={() => onChange({ ...table,
      items: [...table.items, { id: crypto.randomUUID(), content: '', location: '', notes: '' }],
    })}>＋ {label}を追加</button></div>
    <div className="trace-table-scroll"><table className="trace-table" aria-label={label + '表'}>
      <thead><tr><th>ID</th><th>内容</th><th>位置</th><th>特記事項</th><th>操作</th></tr></thead>
      <tbody>{table.items.map(item => <tr key={item.id}>
        <td className="trace-id" title={item.id}>{item.id}</td>
        {(['content', 'location', 'notes'] as const).map((key, index) => <td key={key}><textarea rows={3} value={item[key] ?? ''}
          disabled={disabled} aria-label={`${item.id} ${['内容', '位置', '特記事項'][index]}`} onChange={event => change(item.id, key, event.target.value)} /></td>)}
        <td><button type="button" disabled={disabled} onClick={() => {
          if (window.confirm(`「${item.content || item.id}」を項目表から削除しますか？`)) onChange({ ...table, items: table.items.filter(entry => entry.id !== item.id) });
        }}>削除</button></td>
      </tr>)}</tbody>
    </table></div>
    {!table.items.length && <p className="trace-empty">項目がありません。「追加」またはCopilotの新規生成で作成できます。</p>}
    <details className="trace-scope"><summary>資料の読取範囲</summary>
      <label>読取済みの範囲<textarea rows={3} value={table.scope.read.join('\n')} disabled={disabled} placeholder="シート・節・ファイル等を1行ずつ入力"
        onChange={event => onChange({ ...table, scope: { ...table.scope, read: event.target.value.split('\n') } })} /></label>
      <label>未読の範囲と理由<textarea rows={3} value={table.scope.unread.join('\n')} disabled={disabled}
        onChange={event => onChange({ ...table, scope: { ...table.scope, unread: event.target.value.split('\n') } })} /></label>
    </details>
  </section>;
}

export function MatrixEditor({ detail, onChange, onDeleteOrphan, disabled }: {
  detail: Detail; onChange: (rows: Mapping[]) => void; onDeleteOrphan: (id: string) => void; disabled: boolean;
}) {
  const sources = detail.source.items;
  const targetById = new Map(detail.target.items.map(item => [item.id, item]));
  const mappingBySource = new Map(detail.mappings.rows.map(row => [row.sourceId, row]));
  const sourceIds = new Set(sources.map(item => item.id));
  const orphans = detail.mappings.rows.filter(row => !sourceIds.has(row.sourceId));
  const degrees: Degree[] = ['全', 'ほぼ', '一部', '未', '判定不能'];
  const counts = Object.fromEntries([...degrees, '判定未作成'].map(degree => [degree, 0]));
  sources.forEach(item => counts[mappingBySource.get(item.id)?.degree ?? '判定未作成']++);
  function change(sourceId: string, patch: Partial<Mapping>) {
    const existing = mappingBySource.get(sourceId);
    const row: Mapping = { id: crypto.randomUUID(), sourceId, targetIds: [], degree: '判定不能', detail: '', ...existing, ...patch };
    onChange(existing ? detail.mappings.rows.map(entry => entry.sourceId === sourceId ? row : entry) : [...detail.mappings.rows, row]);
  }
  return <section className="trace-table-section">
    <div className="trace-table-heading"><h2>判定表</h2><span>元項目 {sources.length}件</span></div>
    <div className="trace-counts" aria-label="判定の件数">{Object.entries(counts).map(([degree, count]) => <span key={degree}>{degree} <strong>{count}</strong></span>)}</div>
    <div className="trace-table-scroll"><table className="trace-table trace-matrix" aria-label="判定表">
      <thead><tr><th>元項目</th><th>対応する先項目</th><th>対応度</th><th>対応の詳細・残る条件</th><th>特記事項</th></tr></thead>
      <tbody>{sources.map(source => {
        const row = mappingBySource.get(source.id);
        const missing = row?.targetIds.filter(id => !targetById.has(id)) ?? [];
        return <tr key={source.id}>
          <td className="trace-source-cell"><strong>{source.content}</strong><span>{source.location}</span><code>{source.id}</code>{source.notes && <p>{source.notes}</p>}</td>
          <td><select multiple size={Math.max(3, Math.min(7, detail.target.items.length + missing.length))} disabled={disabled}
            aria-label={`${source.id} 対応する先項目`} value={row?.targetIds ?? []} onChange={event => change(source.id, {
              targetIds: [...event.target.selectedOptions].map(option => option.value),
            })}>
            {missing.map(id => <option key={id} value={id}>参照先なし ({id})</option>)}
            {detail.target.items.map(item => <option key={item.id} value={item.id}>{item.content} — {item.location}</option>)}
          </select>
          <div className="trace-target-details">{row?.targetIds.map(id => { const item = targetById.get(id); return <details key={id}>
            <summary>{item?.content || '参照先なし'}</summary><p>{item?.location || id}</p>{item?.notes && <p>{item.notes}</p>}
          </details>; })}</div></td>
          <td><select aria-label={`${source.id} 対応度`} value={row?.degree ?? ''} disabled={disabled} onChange={event => {
            if (event.target.value) change(source.id, { degree: event.target.value as Degree });
          }}><option value="" disabled>判定未作成</option>{degrees.map(degree => <option key={degree}>{degree}</option>)}</select>
            {!row && <span className="trace-row-status">判定未作成</span>}
            {missing.length > 0 && <span className="trace-row-status error">参照先なし</span>}
          </td>
          <td><textarea rows={4} value={row?.detail ?? ''} disabled={disabled} aria-label={`${source.id} 対応の詳細`}
            onChange={event => change(source.id, { detail: event.target.value })} /></td>
          <td><textarea rows={4} value={row?.notes ?? ''} disabled={disabled} aria-label={`${source.id} 判定の特記事項`}
            onChange={event => change(source.id, { notes: event.target.value })} /></td>
        </tr>;
      })}</tbody>
    </table></div>
    {!sources.length && <p className="trace-empty">元項目が0件です。</p>}
    {orphans.length > 0 && <section className="trace-orphans" aria-label="元項目なしの判定行"><h3>元項目なし</h3>
      {orphans.map(row => <div key={row.id}><code>{row.id}</code><span>元ID {row.sourceId} ／ {row.degree} ／ {row.detail}</span>
        <button type="button" disabled={disabled} onClick={() => {
          if (window.confirm('元項目がないこの判定行を削除しますか？ 保存時に全体履歴を残します。')) onDeleteOrphan(row.id);
        }}>この行を削除</button></div>)}
    </section>}
  </section>;
}
