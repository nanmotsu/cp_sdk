/**
 * @file AHP接続の切断と、ホストから渡されたエラー詳細を扱う。
 */

import { ApiError } from '../api/errors.mjs';

/** 外部エラーの最初の行を、画面に表示できる長さに整える。 */
export function shortDetail(value) {
    const message = typeof value === 'string' ? value : value?.message;
    return message ? ` ${message.split(/\r?\n/)[0].slice(0, 300)}` : '';
}

/** ターンの途中でAgent Hostとの接続が切れた場合に使う例外を作る。 */
export function disconnected() {
    return new ApiError(503, 'AHP_DISCONNECTED', 'Agent Hostとの接続が切れました。VS Codeの状態を確認して再実行してください。');
}
