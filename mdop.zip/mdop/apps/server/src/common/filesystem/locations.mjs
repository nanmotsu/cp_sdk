/**
 * @file サーバーの既定の作業場所と配信ファイルを、起動時のカレントディレクトリと独立に指定する。
 */

import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

export const workspaceRoot = resolve(fileURLToPath(new URL("../../../../../", import.meta.url)));
export const documentsDirectory = resolve(workspaceRoot, "documents");
export const webDirectory = resolve(workspaceRoot, "apps/web/dist");
export const openApiPath = resolve(workspaceRoot, "packages/api-contracts/openapi.yaml");
