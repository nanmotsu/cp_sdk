/**
 * @file 設定フォームの変更を、対象項目だけに限定して文書のYAMLへ反映する。
 */

import { isDeepStrictEqual } from "node:util";
import { isMap, parseDocument } from "yaml";
import { badRequest } from "../../common/api/errors.mjs";
import { CONFIG_LIMIT } from "./files.mjs";
import { parseConfig, requireConfig } from "./yaml.mjs";

const fields = {
    title: "string",
    subtitle: "string",
    titlePage: "boolean",
    paper: "string",
    orientation: ["portrait", "landscape"],
    toc: "boolean",
    tocDepth: "number",
    revisionHistoryVisibility: { preview: "boolean", pdf: "boolean", docx: "boolean" },
    headerFooter: { enabled: "boolean", header: { right: "string" } },
};

/** 受信した差分を許可項目の定義で検査し、ネストした値をパスと値の組に展開する。 */
function changedFields(value, schema = fields, path = []) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        throw badRequest(`${path.join(".") || "changes"} はキーと値の対応で指定してください。`);
    }
    return Object.entries(value).flatMap(([key, entry]) => {
        const field = [...path, key];
        if (!Object.hasOwn(schema, key)) throw badRequest(`基本設定の対象外です: ${field.join(".")}`);
        const rule = schema[key];
        if (typeof rule === "object" && !Array.isArray(rule)) return changedFields(entry, rule, field);
        if (Array.isArray(rule) ? !rule.includes(entry) : typeof entry !== rule) {
            throw badRequest(`${field.join(".")} の値の形式を確認してください。`);
        }
        return [[field, entry]];
    });
}

/** ネストしたパスに値を設定した新しいオブジェクトを作る。保存後の検証に使う期待値を組み立てる。 */
function withSetting(config, [key, ...nested], value) {
    return { ...config, [key]: nested.length ? withSetting(config?.[key], nested, value) : value };
}

/** コメントを保持しながらYAML構文木の指定項目を更新する。再解析結果を比較し、共有参照などで意図した値と異なれば保存を止める。 */
export function editBasicSettings(current, changes) {
    const prior = requireConfig(current);
    const updates = changedFields(changes);
    if (changes.headerFooter?.enabled === true || changes.headerFooter?.header?.right !== undefined) {
        const header = prior.headerFooter?.header;
        if (header?.left === undefined) updates.push([["headerFooter", "header", "left"], "{{documentFolder}}"]);
        if (header?.rightColor === undefined) updates.push([["headerFooter", "header", "rightColor"], "#c00000"]);
    }

    const changed = updates.filter(([path, value]) => path.reduce((entry, key) => entry?.[key], prior) !== value);
    if (!changed.length) return current.yaml;

    const document = parseDocument(current.yaml);
    if (document.errors.length || !isMap(document.contents)) {
        throw badRequest(`${current.path} のYAMLを確認してから設定を保存してください。`);
    }
    let expected = prior;
    try {
        for (const [path, value] of changed) {
            expected = withSetting(expected, path, value);
            document.setIn(path, value);
        }
    } catch {
        throw badRequest(`基本設定を保存できません。 ${current.path} の共有参照を含む項目はYAMLで変更してください。`);
    }
    const newline = /\r\n/.test(current.yaml) ? "\r\n" : "\n";
    const bom = current.yaml.startsWith("\uFEFF") ? "\uFEFF" : "";
    const source = bom + document.toString({ lineWidth: 0 }).replaceAll("\n", newline);
    if (Buffer.byteLength(source) > CONFIG_LIMIT) throw badRequest("config.yaml の上限は 256 KiB です。");
    const parsed = parseConfig(source);
    if (!parsed.config) throw badRequest("設定の値を確認してください。", parsed.diagnostics);
    if (!isDeepStrictEqual(parsed.config, expected)) {
        throw badRequest(`基本設定を保存できません。 ${current.path} の共有参照を含む項目はYAMLで変更してください。`);
    }
    return source;
}
