/**
 * @file 右側の文書プレビューを表示し、文書を開いた時点と手動更新の本文を描画する。
 */

import { useEffect, useState } from 'react';
import { api, errorMessage } from '../api';
import type { PreviewResult } from '../api';
import { Warnings } from './Feedback';

/** 描画に送った本文、その時点の設定と資産、要求ごとの版。 */
type PreviewRequest = { content: string; configVersion: number; assetVersion: number; version: number };

/** プレビューを生成する要求と現在の編集状態を分け、古い表示を更新できるようにする。 */
export default function PreviewPanel({ documentId, path, content, configVersion, assetVersion, hidden }: {
  documentId: string; path: string; content: string; configVersion: number; assetVersion: number; hidden: boolean;
}) {
  const [request, setRequest] = useState<PreviewRequest>(() => ({ content, configVersion, assetVersion, version: 0 }));
  const [preview, setPreview] = useState<{ result: PreviewResult; request: PreviewRequest } | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const stale = preview && (content !== preview.request.content
    || configVersion !== preview.request.configVersion || assetVersion !== preview.request.assetVersion);

  useEffect(() => {
    const controller = new AbortController();
    api.preview(documentId, path, request.content, controller.signal)
      .then(result => {
        if (!controller.signal.aborted) setPreview({ result, request });
      })
      .catch((exception: unknown) => {
        if (!controller.signal.aborted) setError(errorMessage(exception));
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    return () => controller.abort();
  }, [documentId, path, request]);

  /** 現在の編集中本文・設定・資産を次の描画要求へ取り込む。 */
  function refresh() {
    setLoading(true);
    setError('');
    setRequest(current => ({ content, configVersion, assetVersion, version: current.version + 1 }));
  }

  return <div className="preview-panel" hidden={hidden}>
    <div className="panel-meta">
      <span role="status">{loading ? '更新中…' : error ? 'プレビューを更新できませんでした'
        : stale ? '更新すると現在の編集内容が反映されます' : 'プレビュー表示中'}</span>
      <button type="button" disabled={loading} onClick={refresh}>プレビューを更新</button>
    </div>
    {error && <p className="error preview-error" role="alert">{error}</p>}
    <Warnings warnings={preview?.result.warnings} />
    {preview && <iframe key={preview.request.version} title="文書プレビュー" sandbox="" referrerPolicy="no-referrer" srcDoc={preview.result.html} />}
  </div>;
}
