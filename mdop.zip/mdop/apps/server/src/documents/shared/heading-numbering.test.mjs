/**
 * @file 原本の見出しが出力と自動目次に反映されることと、図表の採番を検証する。
 */

import assert from "node:assert/strict";
import { resolve } from "node:path";
import test from "node:test";
import JSZip from "jszip";
import { renderDocx } from "../export/render.mjs";
import { renderPreview } from "../preview/render.mjs";
import { renderDocument } from "./rendering.mjs";

const documentRoot = resolve(".");
const input = {
    documentRoot,
    sourcePath: resolve(documentRoot, "index.md"),
    content: [
        "# Overview", "", "## 1.2.3 Release changes", "", "### Connection", "",
        "See {{ref:capacity}} and {{ref:flow}}.", "",
        ":::table id=capacity", "Capacity", "", "| Name | Value |", "| --- | --- |", "| Limit | 10 |", ":::", "",
        ":::figure id=flow", "~~~text", "Queued -> Running", "~~~", "Job transition", ":::", "",
        "## 7.4. Legacy edition", "", "## 1.3 Compatibility", "", "# Next section", "", "### Skipped middle level",
    ].join("\n"),
};

/** プレビュー、PDF用HTML、自動目次、Wordの見出しには原本の文字を使う。 */
test("rendered headings and the automatic table of contents use Markdown heading text", async () => {
    const config = { headingNumbering: true };
    const preview = await renderPreview({ ...input, config });
    const pdf = await renderDocument({ ...input, config: { ...config, tocDepth: 2 } }, "pdf");
    for (const { html, warnings } of [preview, pdf]) {
        assert.deepEqual(warnings, []);
        assert.match(html, /<h1 id="toc-1">Overview<\/h1>/);
        assert.match(html, /<h2 id="toc-2">1\.2\.3 Release changes<\/h2>/);
        assert.match(html, /<h3 id="toc-3">Connection<\/h3>/);
        assert.match(html, /<h2 id="toc-4">7\.4\. Legacy edition<\/h2>/);
        assert.match(html, /href="#toc-4">7\.4\. Legacy edition<\/a>/);
        assert.match(html, /<h2 id="toc-5">1\.3 Compatibility<\/h2>/);
    }
    assert.match(preview.html, /href="#toc-3">Connection<\/a>/);
    assert.doesNotMatch(pdf.html, /href="#toc-3">/);
    const { buffer, warnings } = await renderDocx({ ...input, config });
    assert.deepEqual(warnings, [
        "Word変換は補助機能です。改ページ、複雑なレイアウト、独自記法は変換後に確認してください。",
    ]);
    const zip = await JSZip.loadAsync(buffer);
    const xml = await zip.file("word/document.xml").async("string");
    assert.match(xml, />Overview</);
    assert.match(xml, />1\.2\.3 Release changes</);
    assert.match(xml, />Connection</);
    assert.match(xml, />7\.4\. Legacy edition</);
});

/** 図表のキャプションと参照には設定に従って章内番号を付ける。 */
test("figure and table references use chapter numbering independently of written heading numbers", async () => {
    const shown = await renderPreview({ ...input, config: { headingNumbering: true } });
    assert.match(shown.html, /See 表1\.1 and 図1\.1\./);
    assert.match(shown.html, /表1\.1 Capacity/);
    assert.match(shown.html, /図1\.1 Job transition/);
    const hidden = await renderPreview({ ...input, config: { headingNumbering: false } });
    assert.match(hidden.html, /<h2 id="toc-4">7\.4\. Legacy edition<\/h2>/);
    assert.doesNotMatch(hidden.html, /表1\.1 Capacity|図1\.1 Job transition/);
});
