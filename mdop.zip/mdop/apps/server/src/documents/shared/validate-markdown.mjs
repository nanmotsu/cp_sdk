/**
 * @file AIが返した本文を採用前に点検し、Markdownと文書DSLの問題を行番号付きで伝える。
 */

import { Marked } from "marked";
import yaml from "js-yaml";
import { transformDSL } from "./dsl.mjs";
import { DEFAULT_DSL } from "./dsl-definition.mjs";
import { referencePattern, scanDocumentSyntax } from "./markdown-syntax.mjs";
import { checkMermaidSources, extractMermaidSources } from "./mermaid.mjs";

const marked = new Marked({ gfm: true, breaks: false });
const referenceId = /^[A-Za-z0-9._-]+$/;
const numberedBlocks = new Set(["figure", "table"]);
const inlineMarkup = /<!--(?:.*?-->|.*$)|(?<![\\`])(`+)(?!`).*?\1(?!`)/g;

/** 冒頭の区切りが設定用のYAMLフロントマターに該当するかを判定する。 */
function containsFrontmatter(source) {
    const fencedYaml = /^---[ \t]*\r?\n([\s\S]+?)^---[ \t]*(?:\r?\n|$)/m.exec(source);
    if (fencedYaml?.index !== 0) return false;
    try {
        const value = yaml.load(fencedYaml[1], { schema: yaml.JSON_SCHEMA });
        return value !== null && typeof value === "object" && !Array.isArray(value);
    } catch {
        return false;
    }
}

/** DSLの名前、ブロックの閉じ忘れ、図表参照を検査し、Mermaidの位置を記録する。 */
function collectSyntax(source, dsl, addError) {
    const definitions = new Set((dsl?.blocks ?? []).map(block => block.name));
    const blocks = [];
    const ids = new Map();
    const references = [];
    const diagramHints = [];
    let mermaidFence;

    for (const entry of scanDocumentSyntax(source)) {
        if (entry.kind === "fence-open" && entry.language === "mermaid") mermaidFence = entry;
        if (entry.kind === "fence-close" && mermaidFence) {
            diagramHints.push({
                line: mermaidFence.line, source: source.slice(mermaidFence.end, entry.start),
            });
            mermaidFence = undefined;
        }
        if (entry.kind === "dsl-open") {
            const { name, line } = entry;
            if (name === "revision-history") {
                addError("UNKNOWN_DSL", "改訂履歴は文書別の config.yaml に設定してください。", line);
            } else if (!definitions.has(name)) {
                addError("UNKNOWN_DSL", `この文書では :::${name} を使用できません。`, line);
            }
            if (blocks.length) {
                addError("NESTED_DSL", "DSLブロックは別のDSLブロックの内側に配置できません。", line);
            }
            blocks.push(entry);
        } else if (entry.kind === "dsl-close") {
            const block = blocks.pop();
            if (!block) {
                addError("UNEXPECTED_DSL_CLOSE", "対応する開始行が見つからない「:::」です。", entry.line);
            } else if (!blocks.length && definitions.has(block.name) && numberedBlocks.has(block.name)) {
                const id = block.attributes.id?.trim();
                if (id && !referenceId.test(id)) {
                    addError("INVALID_REFERENCE_ID", `図表ID「${id}」には半角英数字・ピリオド・ハイフン・アンダースコアを使ってください。`, block.line);
                } else if (id && ids.has(id)) {
                    addError("DUPLICATE_REFERENCE_ID", `図表ID「${id}」は ${ids.get(id)} 行目で使用済みです。`, block.line);
                } else if (id) {
                    ids.set(id, block.line);
                }
            }
        } else if (entry.kind === "text") {
            if (entry.text.startsWith(":::")) {
                addError("INVALID_DSL", "DSLの開始行は「:::ブロック名」、終了行は「:::」と記述してください。", entry.line);
            }
            if (entry.text.includes("ref:")) {
                for (const [, braces, brackets] of entry.text.replace(inlineMarkup, " ").matchAll(referencePattern)) {
                    references.push({ id: braces ?? brackets, line: entry.line });
                }
            }
        }
    }
    if (mermaidFence) addError("UNCLOSED_MERMAID_FENCE", "Mermaidのコードフェンスを閉じてください。", mermaidFence.line);
    for (const block of blocks) {
        addError("UNCLOSED_DSL", `:::${block.name} を「:::」で閉じてください。`, block.line);
    }
    for (const { id, line } of references) {
        if (!ids.has(id)) addError("UNRESOLVED_REFERENCE", `図表ID「${id}」の参照先が見つかりません。`, line);
    }
    return diagramHints;
}

/** 抽出した各Mermaidソースを描画器で検証し、図ごとの失敗理由を返す。 */
async function validateMermaid(sources, render, signal) {
    if (!render) return checkMermaidSources(sources, { signal });
    const results = [];
    for (const source of sources) {
        signal?.throwIfAborted();
        try {
            await render(source, { signal });
            results.push(null);
        } catch (error) {
            signal?.throwIfAborted();
            results.push(error.message || "描画できませんでした。");
        }
    }
    return results;
}

/** HTMLから抽出したMermaidと、元の行を対応付けるため表記をそろえる。 */
function normalizeDiagram(source) {
    return source.split(/\r?\n/).map(line => line.trim()).join("\n").trim();
}

/** 採用前の本文からフロントマター、DSL、参照、Mermaidの診断を集め、本文の行順で返す。 */
export async function validateGeneratedMarkdown(markdown, { dsl = DEFAULT_DSL, signal, renderMermaid } = {}) {
    signal?.throwIfAborted();
    const source = markdown.replace(/^\uFEFF/, "");
    const diagnostics = [];
    const addError = (code, message, line) => diagnostics.push({ severity: "error", code, message, line });
    if (containsFrontmatter(source)) {
        addError("FRONTMATTER", "文書設定は config.yaml に記述し、生成結果にはMarkdown本文を含めてください。", 1);
    }
    const hints = collectSyntax(source, dsl, addError);
    if (/(?:`{3,}|~{3,})[ \t]*mermaid\b/i.test(source)) {
        const html = transformDSL(source, text => marked.parse(text), { dslConfig: dsl });
        const sources = extractMermaidSources(html);
        if (sources.length) {
            try {
                const results = await validateMermaid(sources, renderMermaid, signal);
                for (const [index, message] of results.entries()) {
                    if (!message) continue;
                    const diagram = normalizeDiagram(sources[index]);
                    const hintIndex = hints.findIndex(hint => diagram.endsWith(normalizeDiagram(hint.source)));
                    const line = hintIndex >= 0 ? hints.splice(hintIndex, 1)[0].line : undefined;
                    addError("INVALID_MERMAID", `Mermaidの図を描画できません: ${message}`, line);
                }
            } catch {
                signal?.throwIfAborted();
                diagnostics.push({
                    severity: "warning", code: "MERMAID_CHECK_UNAVAILABLE",
                    message: "Mermaidを検証できませんでした。プレビューで図の表示を確認してください。",
                    line: hints[0]?.line,
                });
            }
        }
    }
    return diagnostics.sort((first, second) => (first.line ?? Infinity) - (second.line ?? Infinity));
}
