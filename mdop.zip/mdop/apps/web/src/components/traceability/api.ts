import { ApiError } from '../../api';
import type { CopilotSession } from '../../api';
import type {
  TraceabilityItem as Item, TraceabilityTable as ItemTable, TraceabilityMapping as Mapping,
} from '../../../../../packages/api-contracts/types';
export type {
  TraceabilityStage as Stage, TraceabilityMode as Mode, TraceabilityDegree as Degree,
  TraceabilityItem as Item, TraceabilityTable as ItemTable, TraceabilityMapping as Mapping,
} from '../../../../../packages/api-contracts/types';

export interface Config {
  id: string; name: string; sourceUri: string; targetUri: string; granularity: string;
  assessment: { status: string; reason: string }; fixedFiles: string[];
  copilotSession?: { sessionId?: string; id?: string; relationId?: string };
}
export interface Summary { id: string; name: string; updatedAt?: string; sourceUri?: string; targetUri?: string }
export interface ReviewSide { status: string; message?: string; baselineVersion?: string; changed?: boolean }
export interface MatrixRow { source: Item; mapping?: Mapping | null; missingTargetIds?: string[] }
export interface Detail {
  id: string; folderName?: string; config: Config; source: ItemTable; target: ItemTable;
  mappings: { rows: Mapping[]; inputVersion?: string }; revision: string;
  review: { source: ReviewSide; target: ReviewSide };
  matrix?: { rows: MatrixRow[]; orphans: Mapping[]; counts: Record<string, number>; total: number };
  version?: string;
}
export interface History { id: string; createdAt: string; reason: string; operation?: string; runId?: string; groupId?: string; startVersion?: string }
export interface DiffRow { file: string; id?: string; change: string; before?: unknown; after?: unknown; cells?: { column: string; before: unknown; after: unknown }[] }
export interface Diff { rows?: DiffRow[]; files?: { path: string; change: string }[]; fromVersion?: string; toVersion?: string }
export interface RunResult { id: string; version?: string; report?: string; message?: string; session?: CopilotSession; stages?: unknown[] }
export interface CreateInput { requestId: string; name: string; sourceUri: string; targetUri: string; granularity: string }

async function request<T>(path: string, method = 'GET', body?: unknown): Promise<T> {
  const response = await fetch('/api/v1/traceabilities' + path, {
    method, headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const result = await response.json().catch(() => undefined);
  if (!response.ok || result === undefined) {
    const error = result?.error;
    throw new ApiError(typeof error === 'string' ? error : error?.message || `取得に失敗しました (${response.status})`, response.status, error?.code, error?.details);
  }
  return result;
}
const route = (id: string) => '/' + encodeURIComponent(id);
export const traceApi = {
  list: () => request<{ traceabilities: Summary[] }>(''),
  get: (id: string, version?: string) => request<{ traceability: Detail }>(route(id) + (version ? '/history/' + encodeURIComponent(version) : '')),
  save: (id: string, detail: Detail, deleteMappingIds: string[]) => request<{ traceability: Detail }>(route(id), 'PUT', {
    revision: detail.revision, name: detail.config.name, source: detail.source, target: detail.target, mappings: detail.mappings,
    fixedFiles: detail.config.fixedFiles, deleteMappingIds,
  }),
  review: (id: string, revision: string, side: 'source' | 'target') => request<{ traceability: Detail }>(route(id) + '/review', 'POST', { revision, sides: [side] }),
  history: (id: string) => request<{ history: History[] }>(route(id) + '/history'),
  diff: (id: string, from: string, to?: string) => request<{ diff: Diff }>(route(id) + '/diff?from=' + encodeURIComponent(from) + (to ? '&to=' + encodeURIComponent(to) : '')),
  restore: (id: string, revision: string, version: string) => request<{ traceability: Detail }>(route(id) + '/restore', 'POST', { revision, version }),
  markdown: (id: string, version?: string) => '/api/v1/traceabilities' + route(id) + '/markdown' + (version ? '?version=' + encodeURIComponent(version) : ''),
};
