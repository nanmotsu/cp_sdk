/**
 * @file Reactの開発ビルドを構成し、開発サーバーのAPI要求をローカルのNode.jsサーバーへ転送する。
 */

import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react()],
  server: {
    host: '127.0.0.1',
    proxy: {
      '/api': `http://127.0.0.1:${process.env.MD_OPERATOR_PORT || 3355}`,
    },
  },
});
