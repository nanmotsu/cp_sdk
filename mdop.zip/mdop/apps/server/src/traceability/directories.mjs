import { readFile, readdir, realpath } from 'node:fs/promises';
import { badRequest, conflict, notFound } from '../common/api/errors.mjs';
import { ensureWorkspaceDirectory, pathParts, workspacePath } from '../common/filesystem/paths.mjs';

export function traceabilityName(value) {
  if (typeof value !== 'string' || !value.trim()) throw badRequest('トレーサビリティ名を入力してください。');
  const name = value.trim();
  if (name.startsWith('.') || pathParts(name).length !== 1) throw badRequest('名前には通常のフォルダ名を指定してください。');
  return name;
}

export async function traceabilityParent(root) {
  return ensureWorkspaceDirectory(await realpath(root), 'traceabilities');
}

export async function traceabilityIdentity(folder) {
  for (const file of ['traceability.json', 'backups/.transaction/previous/traceability.json', 'backups/.transaction/next/traceability.json']) {
    try { return JSON.parse(await readFile(await workspacePath(folder, file), 'utf8')); }
    catch (error) {
      if (error.code === 'ENOENT' || error.status === 404 || error instanceof SyntaxError) continue;
      throw error;
    }
  }
  return null;
}

/** フォルダ名と独立したメタ情報の ID で関係を探す。置換中断の退避版も検索する。 */
export async function findTraceabilityFolder(parent, id) {
  let found;
  for (const entry of await readdir(parent, { withFileTypes: true })) {
    if (!entry.isDirectory() || entry.name.startsWith('.')) continue;
    let folder;
    try { folder = await workspacePath(parent, entry.name, { directory: true }); }
    catch (error) { if (error.status === 404) continue; throw error; }
    const config = await traceabilityIdentity(folder);
    if (config?.id === id) {
      if (found) throw conflict('同じ UUID のトレーサビリティが複数あります。');
      found = folder;
    }
  }
  return found;
}

export async function resolveTraceabilityFolder(root, id) {
  if (pathParts(id).length !== 1) throw badRequest('関係 ID が不正です。');
  const folder = await findTraceabilityFolder(await traceabilityParent(root), id);
  if (!folder) throw notFound('トレーサビリティが見つかりません。');
  return folder;
}

/** 同じ名前の別件は連番のフォルダへ保存する。 */
export async function availableFolderName(parent, name, currentName) {
  const base = traceabilityName(name);
  const names = new Set((await readdir(parent)).filter(value => value !== currentName).map(value => value.toLowerCase()));
  let candidate = base;
  let index = 2;
  while (names.has(candidate.toLowerCase())) candidate = base + ' (' + index++ + ')';
  pathParts(candidate);
  return candidate;
}

export function folderMatchesName(folderName, name) {
  if (folderName === name) return true;
  if (!folderName.startsWith(name + ' (')) return false;
  return /^\([2-9]\d*\)$|^\(1\d+\)$/.test(folderName.slice(name.length + 1));
}
