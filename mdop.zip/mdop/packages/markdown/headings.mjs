/**
 * @file 原本の見出し番号と、図表の章に使う見出し階層を扱う。
 */

/** 設定の h1〜h3 を、採番に使う深さの順に並べる。 */
export function headingNumberLevels(levels = ["h1", "h2", "h3"]) {
    return [...new Set(levels.filter(level => /^h[1-3]$/.test(level)).map(level => Number(level[1])))].sort((a, b) => a - b);
}

/** 文書順に見出しを受け取り、設定で選ばれた階層の番号を返す。 */
export function createHeadingNumberer(levels = headingNumberLevels()) {
    const counters = levels.map(() => 0);
    return level => {
        const index = levels.indexOf(level);
        if (index < 0) return "";
        counters[index]++;
        counters.fill(0, index + 1);
        return counters.slice(0, index + 1).join(".") + ".";
    };
}

/** 見出し冒頭にある章番号に似た表記と、それに続く空白を取得する。 */
export function readWrittenHeadingNumber(text) {
    const match = /^([0-9]+(?:\.[0-9]+)+\.?|[0-9]+\.)[ \t]+(?=\S)/.exec(text);
    return match ? { number: match[1], length: match[0].length } : undefined;
}

