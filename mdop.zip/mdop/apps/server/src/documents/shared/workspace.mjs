/**
 * @file 文書の作業場所、書き込みのロック、復元状態を共有する。
 */

import { mkdir, realpath } from "node:fs/promises";
import { resolve } from "node:path";
import { badRequest, conflict } from "../../common/api/errors.mjs";
import { pathParts, workspacePath } from "../../common/filesystem/paths.mjs";
import { createBackups } from "../history/backups.mjs";

/** 文書名として使える単一のフォルダ名を検査する。 */
export function documentId(value) {
    if (pathParts(value).length !== 1 || value.startsWith(".") || value.toLowerCase() === "config.yaml") {
        throw badRequest("文書フォルダ名を指定してください。");
    }
    return value;
}

/** 文書ルートを準備し、各文書の書き込み処理を直列化するストアを返す。 */
export async function createDocumentWorkspace(documentsRoot) {
    await mkdir(resolve(documentsRoot), { recursive: true });
    const root = await realpath(documentsRoot);
    const locks = new Map();
    const backups = createBackups(root);
    const restores = new Map();

    /** 同じ文書の書き込みを順番に実行する。先行処理の失敗後も後続の書き込みを実行できる。 */
    function locked(id, action) {
        const key = id.toLowerCase();
        const current = (locks.get(key) ?? Promise.resolve()).then(action);
        const done = current.then(() => {}, () => {});
        locks.set(key, done);
        return current.finally(() => { if (locks.get(key) === done) locks.delete(key); });
    }

    /** 文書IDに対応する既存の文書フォルダを検査して返す。 */
    function documentRoot(id) {
        return workspacePath(root, documentId(id), { directory: true });
    }

    /** 文書を読み書きする前に、同じ文書の書き込みを待ち、中断された復元があれば巻き戻す。 */
    function access(id, action) {
        return locked(documentId(id), async () => {
            const folder = await documentRoot(id);
            await backups.recover(folder);
            return action(folder);
        });
    }

    /** ジョブの受け付け以降に復元が行われたかを判定するための番号。 */
    function restoreVersion(id) {
        return restores.get(documentId(id).toLowerCase()) ?? 0;
    }

    /** 復元より前に開始した処理による、復元後の文書への書き込みを止める。 */
    function checkRestoreVersion(id, expected) {
        if (restoreVersion(id) !== expected) throw conflict("処理中に文書が復元されました。現在の文書でやり直してください。");
    }

    /** 復元を記録し、開始済みのジョブが書き込み前に照合できるようにする。 */
    function markRestored(id) {
        restores.set(id.toLowerCase(), restoreVersion(id) + 1);
    }

    return { root, backups, locked, documentRoot, access, restoreVersion, checkRestoreVersion, markRestored };
}
