/**
 * @file 編集可能なSVGを許可された要素・属性・寸法に正規化する。
 */

import { parseDocument } from "htmlparser2";
import serialize from "dom-serializer";

const SVG_NAMESPACE = "http://www.w3.org/2000/svg";
const MAX_SOURCE_BYTES = 256 * 1024;
const MAX_SIDE = 1600;
const drawingTags = new Set("rect circle ellipse line polyline polygon path text".split(" "));
const definitionTags = new Set("defs linearGradient radialGradient clipPath marker".split(" "));
const allowedTags = new Set(["svg", "g", "title", "desc", "tspan", "stop", ...drawingTags, ...definitionTags]);
const editableClasses = new Set(["node", "edgeLabel", "actor", "cluster", "messageText"]);
const localReferenceProperties = new Set(["fill", "stroke", "clip-path", "marker-start", "marker-mid", "marker-end"]);
const presentation = new Set((
    "fill fill-opacity fill-rule stroke stroke-width stroke-linecap stroke-linejoin stroke-opacity " +
    "stroke-dasharray stroke-dashoffset stroke-miterlimit opacity text-anchor dominant-baseline alignment-baseline " +
    "font-family font-size font-weight font-style letter-spacing color stop-color stop-opacity clip-path clip-rule " +
    "marker-start marker-mid marker-end vector-effect visibility display"
).split(" "));
const geometry = new Set((
    "id viewBox preserveAspectRatio x y x1 y1 x2 y2 dx dy cx cy r rx ry fx fy fr width height d points transform " +
    "gradientUnits gradientTransform spreadMethod offset clipPathUnits markerUnits markerWidth markerHeight refX refY orient " +
    "aria-label data-figure-edit"
).split(" "));

/** SVG属性の値が描画に許容できる書式かを検査する。 */
function safeValue(property, value) {
    if (localReferenceProperties.has(property) && /^url\(\s*#[A-Za-z_][\w:.-]*\s*\)$/i.test(value)) return true;
    return !/[\\@;{}]/.test(value) && !/(?:url|image-set)\s*\(/i.test(value);
}

/** SVGの viewBox または寸法から編集・描画用の領域を決める。 */
function getCanvas(root) {
    const number = value => {
        const match = /^([\d.]+)(?:px)?$/i.exec(value?.trim() ?? "");
        const size = match ? Number(match[1]) : NaN;
        return Number.isFinite(size) && size > 0 && size <= 1e7 ? size : undefined;
    };
    const viewBox = root.attribs.viewBox?.trim().split(/[\s,]+/).map(Number);
    const validViewBox = viewBox?.length === 4 && viewBox.every(value => Number.isFinite(value) && Math.abs(value) <= 1e7)
        && viewBox[2] > 0 && viewBox[3] > 0;
    const width = number(root.attribs.width) ?? (validViewBox ? viewBox[2] : 1024);
    const height = number(root.attribs.height) ?? (validViewBox ? viewBox[3] : 640);
    const scale = Math.min(1, MAX_SIDE / Math.max(width, height));
    return {
        width: Math.max(1, Math.round(width * scale)),
        height: Math.max(1, Math.round(height * scale)),
        viewBox: (validViewBox ? viewBox : [0, 0, width, height]).join(" "),
    };
}

/** SVGのルート、描画領域、要素と属性を検証し、整形したSVGを返す。 */
function prepareSvg(source) {
    if (typeof source !== "string" || Buffer.byteLength(source, "utf8") > MAX_SOURCE_BYTES) {
        throw new Error("SVGのソースは256 KiB以内の文字列で指定してください。");
    }
    const xml = source.trim().replace(/^<\?xml\s[^?]*\?>\s*/i, "");
    if (!xml.startsWith("<svg") || /<!DOCTYPE|<!ENTITY|<\?/i.test(xml)) {
        throw new Error("SVGは外部定義を含まない単体の <svg> 画像として指定してください。");
    }
    const nodes = parseDocument(xml, { xmlMode: true }).children.filter(node =>
        node.type !== "comment" && (node.type !== "text" || node.data.trim()));
    const [root] = nodes;
    if (nodes.length !== 1 || root.type !== "tag" || root.name !== "svg"
        || (root.attribs.xmlns && root.attribs.xmlns !== SVG_NAMESPACE)) {
        throw new Error("SVGの最上位には <svg> を1つ指定してください。");
    }
    const canvas = getCanvas(root);
    let elements = 0;
    let drawings = 0;

    /** SVGツリーを再帰的に検査し、許可された要素・属性を描画用に残す。 */
    function clean(node, depth, definition) {
        if (node.type === "text") return node;
        if (node.type !== "tag" || !allowedTags.has(node.name)) return null;
        if (++elements > 2500 || depth > 32) throw new Error("SVGの要素数または階層が上限を超えています。");
        const insideDefinition = definition || definitionTags.has(node.name);
        if (!insideDefinition && drawingTags.has(node.name)) drawings++;
        const attributes = Object.create(null);
        for (const [property, value] of Object.entries(node.attribs)) {
            if ((presentation.has(property) || geometry.has(property)) && safeValue(property, value)) {
                attributes[property] = value;
            }
        }
        const classes = (node.attribs.class ?? "").split(/\s+/).filter(name => editableClasses.has(name));
        if (classes.length) attributes.class = classes.join(" ");
        for (const declaration of (node.attribs.style ?? "").split(";")) {
            const [rawProperty, ...rest] = declaration.split(":");
            const property = rawProperty.trim();
            const value = rest.join(":").trim();
            if (presentation.has(property) && safeValue(property, value)) attributes[property] = value;
        }
        if (insideDefinition) {
            for (const attribute of ["clip-path", "marker-start", "marker-mid", "marker-end"]) delete attributes[attribute];
        }
        node.attribs = attributes;
        node.children = node.children.map(child => clean(child, depth + 1, insideDefinition)).filter(Boolean);
        return node;
    }

    clean(root, 0, false);
    if (drawings === 0) throw new Error("SVGに描画できる図形や文字がありません。");
    root.attribs.xmlns = SVG_NAMESPACE;
    root.attribs.width = String(canvas.width);
    root.attribs.height = String(canvas.height);
    root.attribs.viewBox = canvas.viewBox;
    return serialize(root, { xmlMode: true });
}

/** 保存と編集に共通で使う正規化済みSVGを返す。 */
export function normalizeFigureSvg(source) {
    return prepareSvg(source);
}
