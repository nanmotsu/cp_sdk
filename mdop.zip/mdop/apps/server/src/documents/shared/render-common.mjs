/**
 * @file 文書設定を描画用に整え、図表番号、段落、番号付きリスト、前付け、印刷のCSSを生成する。
 */

import { basename, resolve } from "node:path";
import { escapeHtml, prepareMarkup } from "./markup.mjs";
import { resolveDslReferences } from "./references.mjs";

/** 採番対象の見出しレベルを数値順で取得する。 */
function getOrderedHeadingLevels(headingConfig) {
    return (headingConfig?.levels || ["h1", "h2", "h3"])
        .map(l => parseInt(String(l).replace("h", ""), 10))
        .filter(n => n >= 1 && n <= 3)
        .sort((a, b) => a - b);
}

/** 本文の図表参照を解決し、不正または未解決の参照を警告にまとめる。 */
export function resolveDslBodyWithWarnings(body, styleConfig, dslConfig) {
    const refResolved = resolveDslReferences(body, {
        headingConfig: styleConfig.heading,
        dslBlocks: dslConfig.blocks,
    });

    return {
        markdown: refResolved.markdown,
        warnings: refResolved.unknownRefs.length > 0
            ? [`未解決参照: ${refResolved.unknownRefs.join(", ")}`]
            : [],
    };
}

/** 見出しの進行に合わせて図と表の章内番号を管理し、キャプションへ付ける。 */
export function applyCaptionNumbersToHtml(html, headingCfg, dslCfg) {
    const orderedLevels = getOrderedHeadingLevels(headingCfg);
    const numberingEnabled = !!headingCfg?.numbering && orderedLevels.length > 0;
    if (!numberingEnabled) return html;

    const topLevel = orderedLevels[0];
    const headingCounters = {};
    for (const lv of orderedLevels) headingCounters[lv] = 0;

    let figureCounter = 0;
    let tableCounter = 0;
    let lastHeadingText = "";

    const blockMap = new Map((dslCfg?.blocks || []).map(b => [b.name, b]));
    const figPrefix = blockMap.get("figure")?.captionPrefix || "図";
    const figureClasses = new Set([...blockMap.values()].filter(block => block.captionPosition === "bottom").map(block => block.class));
    const tblPrefix = blockMap.get("table")?.captionPrefix || "表";

    const tokenRe = /<h([1-3])([^>]*)>([\s\S]*?)<\/h\1>|(<figure\b[^>]*>)([\s\S]*?)(<\/figure>)|(<p class="table-caption">)([\s\S]*?)(<\/p>)|(<table\b[^>]*>[\s\S]*?<\/table>)/gi;
    let lastTableCaptionEnd = -1;

    return html.replace(tokenRe, (...args) => {
        const [all, hLv, _hAttrs, hBody, figPre, figBody, figPost, tblPre, tblCap, tblPost, tableBlock, offsetRaw] = args;
        const offset = typeof offsetRaw === "number" ? offsetRaw : -1;

        if (hLv) {
            const level = parseInt(hLv, 10);
            if (!orderedLevels.includes(level)) return all;
            headingCounters[level]++;
            for (const lv of orderedLevels) {
                if (lv > level) headingCounters[lv] = 0;
            }
            const headingPlain = String(hBody ?? "")
                .replace(/<[^>]+>/g, " ")
                .replace(/\s+/g, " ")
                .trim()
                .replace(/^\d+(?:\.\d+)*\.\s*/, "");
            if (headingPlain) {
                lastHeadingText = headingPlain;
            }
            if (level === topLevel) {
                figureCounter = 0;
                tableCounter = 0;
            }
            lastTableCaptionEnd = -1;
            return all;
        }

        if (figPre) {
            lastTableCaptionEnd = -1;
            const caption = /(<figcaption\b[^>]*>)([\s\S]*?)(<\/figcaption>)/i;
            const classes = figPre.match(/\bclass="([^"]+)"/i)?.[1].split(/\s+/) ?? [];
            if (!caption.test(figBody) && !classes.some(name => figureClasses.has(name))) return all;
            const number = `${figPrefix}${headingCounters[topLevel] || 0}.${++figureCounter}`;
            const numbered = figBody.replace(caption, (tag, open, text, close) => {
                const captionCore = text.trim().replace(/^(図|表)\s*\d+(?:\.\d+)?\s*/, "");
                return captionCore ? `${open}${number} ${captionCore}${close}` : tag;
            });
            return `${figPre}${numbered}${figPost}`;
        }

        if (tblPre) {
            tableCounter++;
            const sectionNo = headingCounters[topLevel] || 0;
            const captionCore = String(tblCap ?? "").trim().replace(/^(図|表)\s*\d+(?:\.\d+)?\s*/, "");
            lastTableCaptionEnd = offset + all.length;
            return `${tblPre}${tblPrefix}${sectionNo}.${tableCounter} ${captionCore}${tblPost}`;
        }

        if (tableBlock) {
            const sectionNo = headingCounters[topLevel] || 0;
            const between = lastTableCaptionEnd >= 0 && offset >= 0
                ? html.slice(lastTableCaptionEnd, offset)
                : "";
            const pairedWithCaption = lastTableCaptionEnd >= 0 && /^\s*$/.test(between);
            lastTableCaptionEnd = -1;

            if (pairedWithCaption) return tableBlock;

            tableCounter++;
            const number = `${tblPrefix}${sectionNo}.${tableCounter}`;
            const firstCaption = /^(<table\b[^>]*>)(?:(\s*<caption\b[^>]*>)([\s\S]*?)(<\/caption>))?/i;
            return tableBlock.replace(firstCaption, (_opening, tableOpen, captionOpen, title, captionClose) => {
                const captionTitle = title?.trim().replace(/^(図|表)\s*\d+(?:\.\d+)?\s*/, "") || lastHeadingText || "表";
                return `${tableOpen}${captionOpen || '<caption class="table-caption">'}${number} ${captionTitle}${captionClose || "</caption>"}`;
            });
        }

        return all;
    });
}

/** HTMLタグの既存クラスを保持し、指定した表示クラスを追加する。 */
function appendClassNameToTag(tagText, className) {
    if (!className) return tagText;
    if (/\bclass\s*=\s*"/i.test(tagText)) {
        return tagText.replace(/\bclass\s*=\s*"([^"]*)"/i, (_m, cls) => `class="${cls} ${className}"`);
    }
    return tagText.replace(/^<ol\b/i, `<ol class="${className}"`);
}

/** リストの入れ子の深さを追い、その深さに対応する書式クラスを付ける。 */
export function applyOrderedListStyleClasses(html, listStyleConfig) {
    if (!listStyleConfig) return html;

    let depth = 0;
    return String(html ?? "").replace(/<\/?ol\b[^>]*>/gi, (tag) => {
        if (/^<\/ol/i.test(tag)) {
            depth = Math.max(0, depth - 1);
            return tag;
        }

        depth++;
        if (depth === 1 && listStyleConfig.level1) {
            return appendClassNameToTag(tag, `ol-style-l1-${escapeHtml(listStyleConfig.level1)}`);
        }
        if (depth === 2 && listStyleConfig.level2) {
            return appendClassNameToTag(tag, `ol-style-l2-${escapeHtml(listStyleConfig.level2)}`);
        }
        return tag;
    });
}

/** 括弧付きの番号を表示するCSSカウンターの規則を組み立てる。 */
function buildParenListCss(selector, counterName, markerExpr) {
    return [
        `${selector} {`,
        `    list-style: none;`,
        `    counter-reset: ${counterName};`,
        `    padding-left: 2.2em;`,
        `}`,
        `${selector} > li {`,
        `    counter-increment: ${counterName};`,
        `    position: relative;`,
        `}`,
        `${selector} > li::before {`,
        `    content: ${markerExpr};`,
        `    position: absolute;`,
        `    left: -2.2em;`,
        `    width: 2em;`,
        `    text-align: right;`,
        `}`,
    ].join("\n");
}

/** 深さごとに指定された番号付きリストのCSSを生成する。 */
export function generateOrderedListStyleCSS(listStyleConfig) {
    if (!listStyleConfig) return "";

    const blocks = [];

    const emitForLevel = (level, style, counterName) => {
        if (!style) return;
        const baseSelector = `ol.ol-style-${level}-${style}`;
        if (style === "decimal") {
            blocks.push(`${baseSelector} { list-style-type: decimal; }`);
            return;
        }
        if (style === "lower-alpha") {
            blocks.push(`${baseSelector} { list-style-type: lower-alpha; }`);
            return;
        }
        if (style === "upper-alpha") {
            blocks.push(`${baseSelector} { list-style-type: upper-alpha; }`);
            return;
        }
        if (style === "paren-decimal") {
            blocks.push(buildParenListCss(baseSelector, counterName, `"(" counter(${counterName}) ") "`));
            return;
        }
        if (style === "paren-lower-alpha") {
            blocks.push(buildParenListCss(baseSelector, counterName, `"(" counter(${counterName}, lower-alpha) ") "`));
            return;
        }
        if (style === "paren-upper-alpha") {
            blocks.push(buildParenListCss(baseSelector, counterName, `"(" counter(${counterName}, upper-alpha) ") "`));
        }
    };

    emitForLevel("l1", listStyleConfig.level1, "ol-l1-counter");
    emitForLevel("l2", listStyleConfig.level2, "ol-l2-counter");

    return blocks.join("\n\n");
}

/** 画像の相対パスを解決する基準ディレクトリを得る。 */
export function resolveAssetsBaseAbs(meta, srcDir) {
    const assetsBaseRaw = meta?.assetsBase ?? null;
    return assetsBaseRaw ? resolve(srcDir, String(assetsBaseRaw)) : srcDir;
}

/** 表紙の表示設定と、タイトル・副題・画像から表紙のHTMLを生成する。 */
export function buildTitlePage(meta) {
    if (meta?.titlePage === false) return "";
    if (!meta?.title && !meta?.cover) return "";
    const parts = ['<header class="title-page">'];
    if (meta?.title) parts.push(`  <p class="doc-title">${meta.title}</p>`);
    if (meta?.subtitle) parts.push(`  <p class="doc-subtitle">${meta.subtitle}</p>`);
    if (meta?.cover) parts.push(`  <img class="cover-image" src="${meta.cover}" alt="">`);
    parts.push("</header>");
    return parts.join("\n");
}

const labelPositions = ["left", "center", "right"];

/** 左・中央・右の各欄を並べ、文書フォルダ名プレースホルダーを展開する。 */
function headerFooterRow(section, documentRoot) {
    const folder = escapeHtml(basename(documentRoot));
    const slots = labelPositions.map(position => {
        const value = section?.[position] ?? "";
        const label = value.replaceAll("{{documentFolder}}", () => folder);
        const color = section?.[`${position}Color`];
        const colorStyle = /^#(?:[a-f\d]{3}|[a-f\d]{6})$/i.test(color ?? "") ? `color:${color};` : "";
        return `<span style="flex:1;min-width:0;text-align:${position};overflow-wrap:anywhere;${colorStyle}">${label}</span>`;
    });
    return `<div style="display:flex;align-items:center;">${slots.join("")}</div>`;
}

/** 有効なときに、プレビューの文書上部へ挿入できるヘッダーを作る。 */
export async function buildPreviewHeader(cfg, markupOptions) {
    const { enabled, fontSize = "9px", header } = cfg?.headerFooter ?? {};
    if (!enabled || !labelPositions.some(position => header?.[position])) return "";
    const row = headerFooterRow(header, markupOptions.documentRoot);
    return prepareMarkup(`<header class="document-page-header" style="font-size:${escapeHtml(fontSize)}">${row}</header>`, markupOptions);
}

/** PDF印刷用にヘッダーとフッターのテンプレートを準備する。 */
export async function buildHeaderFooterOptions(cfg, markupOptions) {
    const hf = cfg?.headerFooter ?? {};
    if (!hf.enabled) return {};

    const fontSize = hf.fontSize ?? "9px";
    const pl = cfg?.margin?.left ?? "10mm";
    const pr = cfg?.margin?.right ?? "10mm";

    const makeTemplate = async section => {
        const styleTag = `<style>* { font-size: ${fontSize} !important; margin: 0; padding: 0; }</style>`;
        const row = headerFooterRow(section, markupOptions.documentRoot);
        const body = `<div style="width:100%;box-sizing:border-box;padding:0 ${pr} 0 ${pl};">${row}</div>`;
        return styleTag + await prepareMarkup(body, markupOptions);
    };

    const headerTemplate = await makeTemplate(hf.header);
    const footerTemplate = await makeTemplate(hf.footer);
    return {
        displayHeaderFooter: true,
        headerTemplate,
        footerTemplate,
    };
}

/** 文書のスタイル・DSL・用紙設定を、HTMLが共通で使うCSS変数とルールへ展開する。 */
export function generateConfigCSS({ styleConfig, dslConfig, pageCfg }) {
    const { typography: t, colors: c, spacing: s } = styleConfig;
    const { margin: m, paper, orientation } = pageCfg;

    const tableDef = dslConfig.blocks.find((b) => b.name === "table");
    const tableBorderVal = tableDef?.showBorder === false ? "none" : `1px solid ${tableDef?.border || "#bdc3c7"}`;

    let blockCSS = "";
    for (const block of dslConfig.blocks) {
        if (block.styles) {
            const props = Object.entries(block.styles).map(([k, v]) => `    ${k}: ${v};`).join("\n");
            blockCSS += `.${block.class} {\n${props}\n}\n`;
        }
        if (block.captionStyles && block.captionPosition === "bottom") {
            const props = Object.entries(block.captionStyles).map(([k, v]) => `    ${k}: ${v};`).join("\n");
            blockCSS += `${block.element}.${block.class} figcaption {\n${props}\n}\n`;
        }
        if (block.captionStyles && block.captionPosition === "top") {
            const props = Object.entries(block.captionStyles).map(([k, v]) => `    ${k}: ${v};`).join("\n");
            blockCSS += `.${block.class} .table-caption {\n${props}\n}\n`;
        }
    }

    const tp = styleConfig.titlePage ?? {};
    const paperDimensions = {
        A4: { portrait: "297mm", landscape: "210mm" },
        A3: { portrait: "420mm", landscape: "297mm" },
        Letter: { portrait: "279mm", landscape: "216mm" },
        Legal: { portrait: "356mm", landscape: "216mm" },
    };
    const orient = orientation === "landscape" ? "landscape" : "portrait";
    const paperH = (paperDimensions[paper] ?? paperDimensions.A4)[orient];
    const contentH = `calc(${paperH} - ${m.top} - ${m.bottom})`;

    return [
        `:root {`,
        `    --h1-size:    ${t.fontSize.h1};`,
        `    --h2-size:    ${t.fontSize.h2};`,
        `    --h3-size:    ${t.fontSize.h3};`,
        `    --body-size:  ${t.fontSize.body};`,
        `    --small-size: ${t.fontSize.small || "13px"};`,
        `    --font-family: ${t.fontFamily};`,
        `    --body-line-height:    ${t.lineHeightBody ?? t.lineHeight ?? 1.8};`,
        `    --heading-line-height: ${t.lineHeightHeading ?? 1.3};`,
        `    --color-text:    ${c.text};`,
        `    --color-heading: ${c.heading};`,
        `    --color-heading-border: ${c.headingBorder};`,
        `    --color-subtle:  ${c.subtle};`,
        `    --color-link:    ${c.link};`,
        `    --color-code:    ${c.code};`,
        `    --color-code-bg: ${c.codeBg};`,
        `    --color-pre-bg:  ${c.preBg || "#f6f8fa"};`,
        `    --color-border:  ${tableDef?.border || "#bdc3c7"};`,
        `    --color-th-bg:   ${tableDef?.thBg || "#f0f0f0"};`,
        `    --table-cell-border: ${tableBorderVal};`,
        `    --table-cell-padding: ${tableDef?.cellPadding || "0.45em 0.8em"};`,
        `    --table-margin:       ${tableDef?.tableMargin || "1.5em 0"};`,
        `    --gap-paragraph:   ${s.paragraphGap};`,
        `    --gap-heading-top: ${s.headingTop};`,
        `    --gap-heading-bot: ${s.headingBottom};`,
        `    --toc-padding:      ${s.tocPadding ?? "2em 0"};`,
        `    --toc-item-padding: ${s.tocItemPadding ?? "0.3em 0"};`,
        `    --title-size:       ${tp.titleSize || "36px"};`,
        `    --subtitle-size:    ${tp.subtitleSize || "18px"};`,
        `    --cover-max-height: ${tp.coverMaxHeight || "360px"};`,
        `    --page-content-height: ${contentH};`,
        `}`,
        `@page {`,
        `    size: ${paper} ${orientation};`,
        `    margin: ${m.top} ${m.right} ${m.bottom} ${m.left};`,
        `}`,
        blockCSS,
    ].join("\n");
}

