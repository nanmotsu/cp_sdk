/**
 * @file 文書の表示・出力設定を検証し、更新時に照合するリビジョンを発行する。
 */

import { createHash } from "node:crypto";
import { badRequest } from "../../common/api/errors.mjs";
import { validateConfig } from "./schema.mjs";
import { loadYaml, readDocumentYaml } from "./files.mjs";

/** YAMLを検証済みの設定へ変換する。不正な入力は設定を null とし、利用できる場合は行番号を含めて診断を返す。 */
export function parseConfig(source) {
    try {
        const config = loadYaml(source);
        const diagnostics = validateConfig(config);
        return { config: diagnostics.length === 0 ? config : null, diagnostics };
    } catch (error) {
        const line = error.mark ? `${error.mark.line + 1}行目: ` : "";
        return { config: null, diagnostics: [`${line}${error.reason ?? error.message}`] };
    }
}

/** 設定元、読み取り結果と内容から、同時編集検出に使う識別子を計算する。 */
function configRevision(source, text, state = "read") {
    return createHash("sha256").update(source).update("\0").update(state).update("\0").update(text).digest("hex");
}

/** 文書別ファイルを優先し、不在なら共通ファイルを選ぶ。選んだファイルの解析結果、設定元、リビジョンを返す。 */
export async function loadDocumentConfig(documentsRoot, documentRoot) {
    const { source, path, yaml: text, state, signature, diagnostics } = await readDocumentYaml(documentsRoot, documentRoot, "config.yaml");
    const revision = configRevision(source, signature, state);
    if (state !== "read") return { source, path, yaml: text, config: null, diagnostics, revision };
    return { source, path, yaml: text, revision, ...parseConfig(text) };
}

/** 検証済み設定を取り出す。設定を使う操作では診断付きの400エラーに統一する。 */
export function requireConfig(value) {
    if (!value.config) throw badRequest(`${value.path} の設定を確認してください。`, value.diagnostics);
    return value.config;
}

