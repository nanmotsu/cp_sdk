import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';
import { createTraceability, beginTraceability, resolveTraceabilityFolder } from '../apps/server/src/traceability/store.mjs';

const writeJson = (file, value) => writeFile(file, JSON.stringify(value));
const readJson = async file => JSON.parse(await readFile(file, 'utf8'));

test('①は同じ依頼の再送をまとめ、改めて確定した作成だけを別件にする', async t => {
  const root = await mkdtemp(join(tmpdir(), 'mdop-create-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const input = { requestId: randomUUID(), name: '同名', sourceUri: 'file:///a', targetUri: 'file:///b', granularity: '節単位' };
  let analyses = 0;
  const analyze = ctx => {
    analyses++;
    return { ...ctx, candidate: { status: '関連あり', reason: '同じ製品' } };
  };
  const [first, concurrent] = await Promise.all([
    createTraceability(root, input, analyze), createTraceability(root, input, analyze),
  ]);
  assert.deepEqual(first, concurrent);
  const replay = await createTraceability(root, input, analyze);
  assert.deepEqual(replay, first);
  await assert.rejects(createTraceability(root, { ...input, targetUri: 'file:///c' }, analyze), /内容が異なります/);
  assert.equal(analyses, 1);
  const second = await createTraceability(root, { ...input, requestId: randomUUID() }, analyze);
  assert.notEqual(second.id, first.id);
  assert.equal(analyses, 2);
  assert.deepEqual((await readdir(join(root, 'traceabilities'))).sort(), [first.folderName, second.folderName].sort());
  assert.deepEqual(await readdir(join(await resolveTraceabilityFolder(root, first.id), 'backups')), [first.version]);
});

test('ツールは選択した関係と実行を照合し、④の部分修正でも他の行と入力版を保持する', async t => {
  const root = await mkdtemp(join(tmpdir(), 'mdop-traceability-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const input = {
    name: '要件と仕様', sourceUri: 'file:///requirements.md', targetUri: 'file:///spec.md', granularity: '要件ごと',
  };
  const assessment = { status: '関連が薄い', reason: '共通する主題が少ない' };
  const analyze = context => ({ ...context, candidate: assessment });
  await assert.rejects(createTraceability(root, input, ctx => ({ ...analyze(ctx), id: '別件' })), /一致しません/);
  const created = await createTraceability(root, input, analyze);
  const duplicate = await createTraceability(root, input, analyze);
  assert.notEqual(created.id, duplicate.id);
  const parent = join(root, 'traceabilities');
  const folder = await resolveTraceabilityFolder(root, created.id);
  const initial = await readJson(join(folder, 'traceability.json'));
  assert.equal(initial.id, created.id);
  assert.deepEqual(initial.assessment, assessment);
  assert.deepEqual(await readJson(join(await resolveTraceabilityFolder(root, duplicate.id), 'mappings.json')), { rows: [] });
  assert.deepEqual(await readJson(join(folder, 'backups', created.version, 'tree', 'traceability.json')), initial);
  const save = (file, value) => writeJson(join(folder, file), value);
  const begin = (operation, mode) => beginTraceability(root, created.id, operation, mode);
  const commit = (run, candidate) => run.save({ ...run.context, candidate });
  const table = (...ids) => ({
    items: ids.map(id => ({ id, content: id, location: id })),
    scope: { read: ['登録シート'], unread: ['取消シート：読取不可'] },
  });
  await assert.rejects(begin('related', 'generate'), /新規作成時のみ/);
  await assert.rejects(begin('related', 'revise'), /新規作成時のみ/);
  await save('source-items.json', table('A', 'B'));
  await save('target-items.json', table('T1', 'T2'));
  await save('mappings.json', { rows: [] });

  const generated = await begin('map', 'generate');
  assert.equal(generated.context.sourceUri, input.sourceUri);
  assert.equal(generated.context.targetUri, input.targetUri);
  const extraction = await begin('source', 'revise');
  await commit(extraction, table('A', 'B'));
  const A = { id: 'M1', sourceId: 'A', targetIds: ['T1'], degree: '全', detail: '登録' };
  const B = { id: 'M2', sourceId: 'B', targetIds: ['T2'], degree: '全', detail: '検索' };
  const other = await beginTraceability(root, duplicate.id, 'map');
  await assert.rejects(other.save({ ...generated.context, candidate: [A, B] }), /一致しません/);
  await assert.rejects(generated.save({ ...extraction.context, candidate: [A, B] }), /一致しません/);
  await assert.rejects(generated.save({ ...generated.context, mode: 'revise', candidate: [A, B] }), /一致しません/);
  await commit(generated, [A, B]);
  assert.deepEqual(await readJson(join(await resolveTraceabilityFolder(root, duplicate.id), 'mappings.json')), { rows: [] });
  assert.deepEqual((await readJson(join(folder, 'traceability.json'))).assessment.status, '関連が薄い');
  assert.deepEqual((await readdir(folder)).sort(), ['backups', 'mappings.json', 'source-items.json', 'target-items.json', 'traceability.json']);
  const stale = await begin('map', 'generate');
  await save('source-items.json', table('A', 'B', 'C'));
  await assert.rejects(commit(stale, [A, B]), /開始後/);
  const staleTarget = await begin('map', 'generate');
  await save('target-items.json', table('T2'));
  await assert.rejects(commit(staleTarget, [A, B]), /開始後/);
  assert.deepEqual(await readJson(join(generated.context.inputTree, 'target-items.json')), table('T1', 'T2'));
  const revised = await begin('map', 'revise');
  const edited = { ...B, notes: '根拠の位置を確認' };
  await commit(revised, [edited]);
  const current = await readJson(join(folder, 'mappings.json'));
  assert.deepEqual(current.rows, [A, edited]);
  assert.equal(current.inputVersion, generated.context.runId);

  const bad = await begin('map', 'revise');
  await assert.rejects(commit(bad, [{ ...edited, targetIds: ['T1'] }]), /先 ID/);
  const full = await begin('map', 'generate');
  await assert.rejects(commit(full, [A, B]), /判定数/);
  const C = { id: 'M3', sourceId: 'C', targetIds: [], degree: '判定不能', detail: '取消シートが未読' };
  await assert.rejects(commit(full, [A, B, C]), /先 ID/);
  assert.deepEqual(await readJson(join(folder, 'mappings.json')), current);
  await save('target-items.json', { items: [], scope: { read: [], unread: ['全シート読取不可'] } });
  const unread = await begin('map', 'revise');
  await assert.rejects(commit(unread, [{ ...C, degree: '未' }]), /調査済み/);
  await commit(unread, [C]);
  assert.deepEqual((await readJson(join(folder, 'mappings.json'))).rows, [A, edited, C]);
  assert.deepEqual(await readJson(join(await resolveTraceabilityFolder(root, duplicate.id), 'source-items.json')), { items: [], scope: { read: [], unread: [] } });
});
