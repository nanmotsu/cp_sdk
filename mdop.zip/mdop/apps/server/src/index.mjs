/**
 * @file サーバーの機能と依存を組み立て、ローカルで配信する。
 */

import { once } from "node:events";
import { createServer } from "node:http";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { sendFile } from "./common/api/http.mjs";
import { createRequestListener, createRouter } from "./common/api/router.mjs";
import { serveWeb } from "./common/api/web.mjs";
import { documentsDirectory, openApiPath, webDirectory } from "./common/filesystem/locations.mjs";
import { createJobQueue } from "./common/jobs/queue.mjs";
import { jobRoutes } from "./common/jobs/routes.mjs";
import { createGitHubCopilot } from "./copilot/github/index.mjs";
import { copilotRoutes } from "./copilot/routes.mjs";
import { createDocumentStore } from "./documents/index.mjs";
import { createAssistance } from "./documents/assistance/index.mjs";
import { assistanceJobs } from "./documents/assistance/jobs.mjs";
import { assistanceRoutes } from "./documents/assistance/routes.mjs";
import { configRoutes } from "./documents/config/routes.mjs";
import { exportJobs } from "./documents/export/jobs.mjs";
import { figureRoutes } from "./documents/figures/routes.mjs";
import { createFigureStore } from "./documents/figures/store.mjs";
import { historyRoutes } from "./documents/history/routes.mjs";
import { markdownRoutes } from "./documents/markdown/routes.mjs";
import { previewRoutes } from "./documents/preview/routes.mjs";
import { ASSET_LIMIT } from "./documents/shared/input.mjs";

const uploads = { limit: Math.ceil(ASSET_LIMIT / 3) * 4 + 64 * 1024 };

/** 文書ストア、エージェント、ジョブキューをHTTPへ接続する。 */
export async function createAppServer({ documentsRoot = documentsDirectory, webRoot = webDirectory,
    agent = createGitHubCopilot(),
} = {}) {
    const documents = await createDocumentStore(documentsRoot);
    const figures = createFigureStore(documents.documentRoot);
    const jobs = createJobQueue();
    const assistance = createAssistance({ agent });
    const handlers = new Map(Object.entries({
        ...exportJobs(documents, jobs),
        ...assistanceJobs(documents, figures, jobs, assistance),
    }));
    const api = createRouter([
        ["GET", "/openapi", (request, response) => sendFile(request, response, openApiPath, "application/yaml; charset=utf-8")],
        ...markdownRoutes(documents),
        ...configRoutes(documents),
        ...historyRoutes(documents, uploads),
        ...figureRoutes(documents, figures, uploads),
        ...previewRoutes(documents),
        ...assistanceRoutes(documents),
        ...copilotRoutes(agent),
        ...jobRoutes(jobs, handlers, uploads),
    ]);
    const server = createServer(createRequestListener(api, (request, response, segments) => serveWeb(request, response, webRoot, segments)));
    server.on("close", () => jobs.dispose());
    return server;
}

/** 既定または指定のポートをループバックで開き、待ち受け開始後にサーバーを返す。 */
export async function startServer({ port = Number(process.env.MD_OPERATOR_PORT ?? 3355),
    documentsRoot = documentsDirectory,
} = {}) {
    const server = await createAppServer({ documentsRoot });
    const listening = once(server, "listening");
    server.listen(port, "127.0.0.1");
    await listening;
    console.log(`md-operator: http://127.0.0.1:${server.address().port}`);
    return server;
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
    await startServer();
}
