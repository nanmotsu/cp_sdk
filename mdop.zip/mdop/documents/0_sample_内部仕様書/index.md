# 1. システム構成


## 1.1. 起動と責務

### 1.1.1. ローカル実行の構成

MD Operatorは、ブラウザーの編集画面とNode.jsのローカルAPIで構成する。配布時は同じNode.jsのプロセスが `apps/web/dist/` と `/api/v1` を配信し、`127.0.0.1:3355` で待ち受ける。開発時はViteでGUIを起動し、APIへのリクエストをNode.jsへ転送する。

:::figure id=architecture width=100% height=600px
```mermaid
flowchart TD
    UI["React GUI"] --> API["Node.js HTTP API"]
    API --> Docs["原本・設定・履歴"]
    API --> Trace["トレーサビリティ・全体履歴"]
    Trace --> TraceDisk["traceabilities 配下のJSON・添付資料"]
    Queue --> TraceAssist["トレーサビリティのAI依頼"]
    TraceAssist --> Trace
    TraceAssist --> Copilot
    API --> Figures["図版・素材"]
    API --> Render["プレビュー"]
    API --> Queue["共通ジョブキュー"]
    Queue --> Export["PDF・Word変換"]
    Queue --> Assist["文書のAI支援"]
    Docs --> Disk["documents 配下のファイル"]
    Figures --> Disk
    Export --> Disk
    Assist --> Docs
    Assist --> Figures
    Assist --> Copilot["GitHub Copilot実装"]
    Copilot --> AHP["共通のAHP通信"]
    AHP --> Host["VS Code Agent Host"]
```
ローカルプロセスの責務とデータの経路
:::

### 1.1.2. 実装の配置

実装の依存関係は `apps/server/src/index.mjs` で組み立てる。HTTPの共通ルーターが、各機能から登録されたメソッドとパスを振り分ける。ジョブは共通のキューが状態と中断を管理し、ジョブ種別ごとの入力と保存条件は文書機能が決める。テストでは `createAppServer` に一時文書ルートや模擬エージェントを渡し、本番と同じルートを検証する。

:::table id=modules
主要な実装の配置と責務

| 配置 | 実装する責務 |
| --- | --- |
| `apps/web/src/App.tsx`、`components/` | 文書の選択、編集画面、右側の各パネル。 |
| `apps/web/src/workspace.ts`、`editor/` | Zustandによる文書の作業状態、Markdownブロック・見出し・本文差分の処理。 |
| `apps/web/src/api.ts`、`useJob.ts` | API呼び出し、ジョブの取得・中断、エラーの画面表示。 |
| `apps/server/src/index.mjs` | 起動、機能ごとのルート・ジョブの登録、依存の組み立て。 |
| `apps/server/src/documents/markdown/`、`config/`、`history/` | 原本の読み書き、文書設定、版の保存・比較・復元。 |
| `apps/server/src/documents/figures/`、`preview/`、`export/` | 図版と素材の管理、表示、PDF・Wordの変換。 |
| `apps/server/src/documents/assistance/`、`shared/` | 参照資料の抽出、AIへの依頼と採用前の検証。文書共通のロック・DSL・描画処理。 |
| `apps/server/src/copilot/` | 生成エージェントの契約と、GitHub Copilotのセッションや専用エージェントの選択。 |
| `apps/server/src/traceability/` | 関係データの保存、元・先項目からの判定表、変更通知、全体履歴、資料展開、Copilot依頼。 |
| `apps/server/src/common/` | HTTPの共通処理、ジョブキュー、安全なファイル操作、AHPの接続とプロトコル処理。 |
| `packages/api-contracts/` | OpenAPIの契約とGUIが参照するTypeScriptの型。 |
:::

## 1.2. 外部依存

### 1.2.1. アプリで使うライブラリ

文書変換、図版の描画、AI支援、GUIには以下の直接依存を使う。ライブラリ名には `package-lock.json` の固定バージョンを併記する。ライセンス欄はその版のパッケージ宣言に基づき、同梱のライセンス文書や公式リポジトリで照合した。


:::table id=runtime_dependencies
アプリが直接使用するライブラリ

| ライブラリ名 | 何を実現するか | ライセンス | 特記事項 |
| --- | --- | --- | --- |
| **Marked** `12.0.2` | Markdownの解析とHTML化 | MIT | サーバーのレンダリング・生成文法チェックと、GUIのブロック・見出し抽出に使う。同梱の `LICENSE.md` にはMarkdown由来の通知も収録される。 |
| **Turndown** `7.2.4` | HTMLからMarkdownへの変換 | MIT | Word取り込みで得たHTMLと、ビジュアル編集したブロックをMarkdownへ戻す。 |
| **turndown-plugin-gfm** `1.0.2` | GFMの表や取り消し線を含むMarkdownへの変換 | MIT | TurndownにGFM用の変換規則を追加する。Word取り込みとビジュアル編集で共用する。 |
| **html-to-docx** `1.8.0` | HTMLからWordへの出力 | MIT | サーバーで整えたHTMLを `.docx` に変換する。アプリ側でWord用のレイアウトを組み立て、出力後のXMLも補正する。 |
| **Mammoth** `1.12.3` | WordからHTMLへの変換と画像の抽出 | BSD-2-Clause | `.docx` から見出しや段落などを取り出す。取り込んだ画像はアプリが文書の資産として保存する。 |
| **JSZip** `3.10.2` | Wordファイル内のZIPとXMLの更新 | MIT OR GPL-3.0-or-later | 出力した `.docx` を展開し、セクション情報の位置と互換モードを補正して再圧縮する。ライセンスは二択。 |
| **Mermaid** `12.3.0` | Mermaidコードから図の描画 | MIT | ブラウザー上で同梱バンドルを実行してSVGを描画する。Word出力ではPNGに変換して埋め込む。 |
| **Puppeteer** `24.43.1` | ブラウザー制御によるPDF出力と画像処理 | Apache-2.0 | Chrome系ブラウザーで印刷用HTMLをPDF化する。Mermaidの描画、図版の合成、送信用画像の縮小にも使う。 |
| **htmlparser2** `10.1.0` | HTMLとSVGを構文木へ変換 | MIT | アプリが画像リンクや許可する要素・属性を検査、整形するための構文木を作る。 |
| **dom-serializer** `2.0.0` | 編集した構文木からHTML・SVGを再生成 | MIT | プレビュー用HTMLや、図版用に整形したSVGを書き戻す。 |
| **ws** `8.21.3` | VS Code Agent HostとのWebSocket通信 | MIT | AHPのJSON-RPCを送受信する。リクエストやセッションを管理するAHPクライアントはアプリ側で実装する。 |
| **js-yaml** `4.3.2` | YAMLの読み込みと書き出し | MIT | 文書設定や図版メタデータの読み込み、図版メタデータの書き出し、AI応答中のフロントマターの検出に使う。 |
| **yaml** `2.9.1` | YAMLの一部を構文木で編集 | ISC | 基本設定を保存するとき、他の項目とコメントを保持するために使う。 |
| **React** `19.3.1` | GUIのコンポーネントと状態に応じた表示 | MIT | 文書一覧、編集欄、右側の操作パネルなどをコンポーネントで実装する。 |
| **React DOM** `19.3.1` | ReactのGUIをブラウザーのDOMに描画 | MIT | `react-dom/client` の `createRoot` でアプリの表示を開始する。 |
| **Zustand** `5.1.0` | GUI全体の文書状態を管理 | MIT | 選択中の原本、編集内容、保存済み内容、読み込み・保存状態を共有する。 |
:::

ライセンス本文は、たとえば [JSZipのデュアルライセンス](https://stuk.github.io/jszip/)、[Mammothのライセンス](https://github.com/mwilliamson/mammoth.js/blob/master/LICENSE)、[Puppeteerのライセンス](https://github.com/puppeteer/puppeteer/blob/main/LICENSE)、[yamlのライセンス](https://github.com/eemeli/yaml/blob/main/LICENSE) で確認できる。

### 1.2.2. 開発・ビルドで使うパッケージ

GUIの開発とビルドには `apps/web/package.json` の `devDependencies` を使う。

:::table id=build_dependencies
開発・ビルドの直接依存

| ライブラリ名 | 何を実現するか | ライセンス | 特記事項 |
| --- | --- | --- | --- |
| **TypeScript** `6.0.3` | GUIコードと共有API型の型検査 | Apache-2.0 | ビルド時に `tsc --noEmit` を実行する。 |
| **Vite** `7.3.8` | 開発サーバーとGUIのビルド | MIT | 開発時にローカルAPIへのリクエストを転送し、配信用ファイルを `apps/web/dist/` に生成する。配布パッケージの `LICENSE.md` には同梱コードの通知も記載される。 |
| **@vitejs/plugin-react** `5.2.0` | ViteへのReactビルド統合 | MIT | JSX・TSXの変換と、開発時のFast Refreshを提供する。 |
| **@types/react** `19.3.0` | ReactのTypeScript型定義 | MIT | コンポーネント、フック、イベントなどの型検査に使う。 |
| **@types/react-dom** `19.3.0` | React DOMのTypeScript型定義 | MIT | `createRoot` など、DOM描画用APIの型検査に使う。 |
:::

### 1.2.3. 実行環境と外部サービス

AI支援の推論は、VS CodeのAgent Hostを介してGitHub Copilotが行う。AHPは接続に使う通信仕様で、アプリは `ws` を使って仕様に沿ったメッセージを送る。Copilotの利用にはGitHubの製品条件が適用される。 [Agent Host Protocol仕様](https://microsoft.github.io/agent-host-protocol/) [GitHub Copilotの製品条件](https://docs.github.com/en/site-policy/github-terms/github-terms-for-additional-products-and-features#github-copilot)

PDFの印刷処理は、Puppeteerが起動したChrome系ブラウザーが行う。ブラウザーの利用条件とライセンスは、使用する実行ファイルの配布元で確認できる。 [Google Chromeの利用規約](https://www.google.com/chrome/terms/) [Chromiumのライセンス](https://chromium.googlesource.com/chromium/src/+/HEAD/LICENSE)

:::pagebreak
:::

# 2. 文書データ

## 2.1. ディスク上の構造

### 2.1.1. 文書フォルダと原本

文書の識別子は `documents/` 直下のフォルダ名である。新規作成は同名フォルダの有無を確認してから `index.md` を作る。原本の探索対象は文書フォルダ直下の有効な `.md` または `.markdown` の通常ファイルで、候補が複数ある場合は一覧に競合情報を返し、原本への操作を `409` で止める。

:::figure id=document_storage width=100%
```mermaid
flowchart TD
    Root["documents/"] --> Common["共通 config.yaml"]
    Root --> Folder["文書フォルダ"]
    Folder --> Source["原本 Markdown"]
    Folder --> Local["文書別 config.yaml"]
    Folder --> Assets["assets/"]
    Assets --> Figures["figures/ · 完成画像と配置"]
    Assets --> Parts["parts/ · 編集用の画像素材"]
    Folder --> Output["output/"]
    Folder --> Backups["backups/"]
    Backups --> Version["版 ID / document/ と metadata.json"]
```
文書フォルダの保存構造
:::

:::table id=storage_files
ファイルの作成元と掲載先

| 保存対象 | 作成・更新の契機 | 主な参照元 |
| --- | --- | --- |
| 原本Markdown | 文書の新規作成、本文の保存。 | ビジュアル・ソース、出力ジョブ。 |
| 文書別 `config.yaml` | 基本設定、YAML全体の更新。 | 文書設定、レンダリング、AI編集案のDSL。 |
| 文書別 `copilot.yaml` | YAMLを直接作成・編集。 | 本文編集のテンプレート一覧、Copilotに渡すプロンプト。 |
| `assets/figures/<UUID>/` | 画像の追加、Word取り込み、図版の採用・更新時に完成画像と配置を保存する。 | 本文の画像リンク、図版ライブラリ。 |
| `assets/parts/<UUID>/` | ラスタ図版の作成や素材追加時に、その図版の元画像と追加素材を保存する。 | 図版エディター、合成処理。 |
| `output/<原本名>.pdf`、`.docx` | 変換ジョブの完了。設定で配置先とファイル名を変更できる。 | ジョブ結果のダウンロードURL。 |
| `backups/<UUID>/` | 保存、Word取込、Copilotの編集案や図版の調整、復元前の退避。 | 履歴一覧、版の比較と復元。 |
:::

### 2.1.2. パスと書き込み

文書内のファイルへのアクセスは `workspacePath` を経由する。スラッシュ区切りの相対パスを検査し、空の要素、`..`、予約名などを拒否する。各階層を `lstat` で調べ、シンボリックリンクや用途と異なる種類のファイルを拒否する。参照資料の探索は別の実装が引き受ける。

原本・設定・図版・出力・履歴の更新は文書IDごとのロックで順番に処理する。既存ファイルの置き換えは同じディレクトリへ一時ファイルを書いてから名前を変更する。API内の操作を直列化するロックであり、外部エディターとの競合は取得時のリビジョン照合で検出する。

### 2.1.3. 版の保存と復元

文書の版は `backups/<UUID>/document/` に格納する。原本と付属ファイルを、空のフォルダも含めて複製する。日時・作成理由・原本パス・変換警告は隣にある `metadata.json` に記録する。共通設定が適用されていた場合は `shared-config.yaml` にその内容を保管する。版を構築するときは一時フォルダを使い、完成後の名前変更で一覧に公開する。

原本の保存はリビジョンの照合後、本文が変更されたときに版を作る。GUIは保存済みの本文と編集中の本文を比較し、一致する場合は保存要求を送らない。保存APIに同じ本文が届いた場合は、現在の原本を返す。

個別削除は文書のロック内で対象のUUIDを検証し、その版のディレクトリを履歴一覧から外してから消去する。消去が途中で中断された場合は、次の履歴一覧の取得時に消去を再試行する。

比較APIは相対パス、ファイルのSHA-256、共通設定のハッシュから差分と比較時点のリビジョンを返す。GUIは有効な編集中の本文を現在側に使い、Markdownの共通・追加・削除の行を表示する。復元APIは、比較後に文書フォルダが変更されていれば `409` を返す。

復元は現在の内容を別の版に退避してから、選んだ版のファイルに置き換える。作業フォルダ `backups/.restore/` に置き換え後と退避中のデータを持ち、入れ替えの段階を `phase` に記録する。途中で停止したときは、次の文書アクセス時にファイルを退避元へ戻す。復元する版で使われていた共通設定が変わった場合は、その版の設定を対象文書の `config.yaml` に書く。

:::figure id=backup_restore width=94% height=600px
```mermaid
flowchart TD
    Select["履歴から版を選ぶ"] --> Compare["本文とファイルを比較"]
    Compare --> Check{"文書フォルダの状態が一致するか"}
    Check -->|更新あり| Compare
    Check -->|一致| Preserve["現在を別の版に退避"]
    Preserve --> Restore["履歴を残して文書ファイルを入れ替える"]
    Restore -->|完了| Refresh["本文・設定・画像を再表示"]
    Restore -->|途中で停止| Rollback["退避中のファイルから巻き戻す"]
```
文書全体を復元する流れ
:::

## 2.2. 設定の解決

### 2.2.1. ファイル選択と組み込み値

文書設定はファイル単位で選択する。文書別 `config.yaml` が存在すれば、そのファイルを解析する。不在の場合は共通YAMLを解析する。選んだYAMLで省略した書式にはレンダラー内蔵のページ・スタイルの既定値を適用し、DSL定義を省略した場合は内蔵のDSLを使用する。

:::table id=config_source
設定やDSLを変更するときに読むコード

| ファイル | コードが定義する範囲 |
| --- | --- |
| `documents/config/schema.mjs` | `config.yaml` のキー、値の型と許容範囲。 |
| `documents/shared/settings.mjs` | 用紙と書式の組み込み値、文書設定の反映順。 |
| `documents/shared/dsl-definition.mjs` | 既定のブロック、`dsl.blocks` の項目、出力とGUIで共用する描画方式。 |
| `documents/shared/dsl.mjs`、`render-common.mjs` | DSL属性の処理、書式とブロック定義をHTML・CSSへ反映する処理。 |
:::

DSLの定義は通常の本文、区切り、図、表から描画方式を選ぶ。注意欄のようなブロックは既存の方式とCSSから定義できる。新しい振る舞いは、属性の解釈や描画の処理を追加して定義する。図表参照は `figure` と `table` のIDを処理する。

:::figure id=config_resolution width=90% height=600px
```mermaid
flowchart TD
    Start["文書設定を取得"] --> Local{"文書別 config.yaml があるか"}
    Local -->|ある| Doc["文書別ファイルを読む"]
    Local -->|ない| Shared["共通ファイルを読む"]
    Doc --> Check{"YAMLと設定値が有効か"}
    Shared --> Check
    Check -->|有効| Effective["選んだ設定と組み込み値を適用"]
    Check -->|無効| Error["診断を返す"]
```
設定ファイルの選択と検証
:::

### 2.2.2. 設定APIの更新範囲

設定のリビジョンは設定元、読み取り状態、YAMLの内容から計算する。GUIの部分更新は取得時のリビジョンと照合し、共通設定を利用中ならその内容を基に文書別YAMLを作る。部分更新は保持する設定値を再解析して確認し、YAMLの表記に整形が入る場合がある。

:::table id=config_writes
設定の参照と更新

| 操作 | 入力と更新範囲 |
| --- | --- |
| `GET /documents/{id}/config` | 選択元、パス、YAML、設定オブジェクト、診断、リビジョンを返す。 |
| `PATCH /documents/{id}/config` | `changes` と `revision` を受け、表紙、用紙、目次、改訂履歴、ヘッダーの基本項目を部分更新する。 |
| `PUT /documents/{id}/config` | 文書別YAML全体を置き換える。`revision` を指定した場合は一致を求める。 |
| `GET /documents/{id}/copilot-templates` | テンプレートの表示名とプロンプト、選択元、設定ファイルのパス、診断を返す。 |
:::

### 2.2.3. 改訂履歴と出力条件

改訂履歴の記録と掲載条件はYAMLの別項目で管理する。`revisionHistory` は版・日付・変更内容を保持する。`revisionHistoryVisibility.preview`、`.pdf`、`.docx` が掲載を決める。各キーは省略すると掲載する。PDFジョブの `includeRevisionHistory` は、その1回の出力に限り設定より優先する。

:::pagebreak
:::

# 3. ブラウザーとAPI

## 3.1. 編集状態

### 3.1.1. 編集中の本文と保存済み本文

編集中の本文と保存済み本文は、`workspace.ts` の `file.content` と `file.savedContent` で管理する。両者が異なる間は未保存と判断する。保存時は本文のスナップショットとSHA-256のリビジョンを送るため、保存開始後にユーザーが入力した内容も作業状態に残る。

:::figure id=save_sequence width=100%
```mermaid
sequenceDiagram
    participant GUI as ブラウザー
    participant API as 保存API
    participant Disk as 原本ファイル
    GUI->>API: 本文と取得時の revision
    API->>Disk: 文書ロック内で現在の原本を取得
    alt リビジョンが一致
        API->>Disk: 一時ファイルを原本へ置き換え
        API-->>GUI: 保存した本文と新しい revision
    else リビジョンが不一致
        API-->>GUI: 409 と現在の revision
    end
```
原本保存のリビジョン照合
:::

### 3.1.2. ビジュアル編集と見出し移動

ビジュアルとソースは同じMarkdown本文を参照する。ビジュアル編集は内容をブロックとして扱い、編集可能なブロックをMarkdownへ戻して周囲のソースと連結する。Mermaidなどのブロックはソース欄で変更できる。空段落は本文に文字を入力した時点で原本へ反映し、入力欄の段階でも削除できる。

文字装飾は、同じ編集欄の内側に始点と終点を持つ文字選択に適用する。ブラウザーの選択変更を監視してツールバーの使用可否を更新し、書式ショートカットも入力前に同じ条件で判定する。見出しを段落に戻すときは、見出しの内容を取り出し、先頭の番号や記号がリストや別の構文になる場合にエスケープする。前後に必要な空行を補い、一回の変更として履歴に登録する。

右クリックメニューは開いた時点のブロックとセルを保持し、対象に応じて見出し、表の行列、図のサイズの操作を出す。行列の追加や削除には、メニューを開いたセルの行番号と列番号を使う。サイズ変更の入力欄は、対象ブロックの幅と高さを初期値としてメニューの横に開く。

共通操作の追加メニューは横に開く。空段落、テーブルDSL、Mermaidコードフェンスは原本のその位置の直後へ挿入する。テーブルDSLは文書で有効な表のブロック名を使い、表題を省略しても開始行と閉じ行を生成する。共通の削除操作は確認を経て対象ブロックを編集中のMarkdownから取り除く。必要な区切りを補い、一回の編集として取り消し履歴に登録する。

文書ツリーの見出しは編集中の原本を解析して作る。見出しの表示は `tocDepth` を上限とし、省略時は3になる。原本行のドロップダウンは文書ごとに表示階層0〜3を保持する。0は見出し一覧を隠し、1〜3はツリーの根から指定階層まで展開する。子を持つ見出しの個別開閉は表示階層からの反転として文書ごとに保持し、ドロップダウンには **個別** と表示する。階層を再選択すると個別の反転を消去する。項目を選択すると記録した文字オフセットから編集位置へ移動する。

文書ツリーの表示幅は `SidebarResize` が境界のポインター操作と矢印キー操作を受け取り、`workspace-main` の `--sidebar-requested-width` に反映する。CSSの `clamp` は文書一覧の最小幅と、中央・右欄に必要な最小幅から求めた最大幅の間に収める。境界のダブルクリックで希望幅を解除し、画面幅に応じた初期幅へ戻す。文書ツリーと幅調整ハンドルはGridの同じ第一列・第一行に配置し、ツリーの高さが中央・右欄を次の行へ押し出さないようにする。左欄の **文書** の横のボタンで閉じると、Gridを二列に切り替えて中央の編集欄へ幅を渡す。再表示用のボタンは編集欄の左上に重ねる。文書ツリーは非表示のままマウントして、選択中の文書、作成フォーム、見出しの開閉状態を保持する。狭い画面では縦並びのまま左欄を隠し、編集欄と右欄の二段にする。

見出し番号の一括操作は、Markdown解析で見出しと判定したトップレベルの `#` 形式を対象とする。追加はレベル1〜6の順序を `packages/markdown/headings.mjs` で数え、先頭に番号らしい表記がある場合はその文字を使う。削除は末尾がドットの番号と直後の空白を取り除く。一括操作は一回の本文変更として取り消し履歴に記録する。

展開中のフォルダを閉じると、文書IDと原本の選択を解除する。移動時と同じ未保存確認を行い、承認された場合は中央と右の欄を待機表示に戻す。原本行の表示階層と子見出しの個別開閉状態は文書ツリーに保持するため、同じフォルダを開き直したときに再利用する。

### 3.1.3. 表とDSLのビジュアル編集

表の編集では、MarkedのGFM表から表示用HTMLと原本上の範囲を得る。セル入力は該当行に書き戻し、構造の変更は元の改行・セル記法と列揃えを使って組み立てる。DSL表では表題とブロック属性を引き継ぎ、列幅の指定と元の列数が揃っていればその並びも更新する。

図のサイズを変更すると、`:::figure` の属性か単体Mermaidのディレクティブへ書き戻す。`packages/markdown/layout.mjs` は、サイズ・図題・列幅の解釈をGUIと出力処理で共有する。ビジュアル・プレビュー・PDFでは、画像を幅と高さで指定した枠に `object-fit: contain` で収める。Word変換では、PNGの画像寸法と用紙の本文幅から掲載幅を求め、元画像の縦横比を使って高さを決める。注意欄やページ区切りなどは有効なDSL定義から描画し、詳細指定は各ブロックのソース欄で編集できる。

取り消しの履歴は、ビジュアル編集が送出する前の本文と選択位置を保持する。連続した文字入力はまとめ、行・列の操作やサイズ変更は個別に記録する。Ctrl+Zで戻した本文から表示を再構築し、セルやブロックの選択を戻す。

### 3.1.4. 表示用の二つのAPI

右側のプレビューは、文書を開いたときと利用者が更新を押したときの本文を送る。表示済みの本文、設定、画像と作業状態の版が異なる場合は更新可能と知らせる。表紙とMermaidの編集画面内表示は別のAPIを使用する。

:::table id=visual_requests
プレビューとビジュアル表示の契約

| 項目 | `POST /documents/{id}/preview` | `POST /documents/{id}/visual-elements` |
| --- | --- | --- |
| 入力 | 原本の `path` と表示する `content`。 | 原本の `path`、タイトル候補、Mermaidソースの配列。 |
| 出力 | 文書の `html` と警告。 | 表紙HTML、入力順のMermaid図またはエラー、DSLの表示用設定、警告。 |
| 画面での使い方 | サンドボックス付きiframeの `srcDoc`。 | 表紙とMermaidの描画、図表の採番条件、DSLブロックの種別とスタイル。 |
| 中断 | HTTP接続が閉じたときはレンダラー側の `AbortSignal` に伝える。 | 同左。 |
:::

## 3.2. HTTPの契約

### 3.2.1. 操作と結果の形式

HTTP APIの基点は `/api/v1` で、OpenAPI定義は `GET /openapi` で取得できる。更新要求の本文はJSONオブジェクトで、画像やWordのバイト列は必要に応じてBase64で渡す。HTTPエラーは `error.code`、`error.message`、任意の `error.details` を返す。

:::table id=http_groups
主なHTTP APIと状態の変更

| 基点からのパス | メソッド | 処理 |
| --- | --- | --- |
| `/documents` | `GET`、`POST` | 文書の一覧取得、原本つき文書フォルダの作成。 |
| `/documents/{id}/files` | `GET`、`POST`、`PUT` | 原本の取得・作成・保存。保存では文書全体の版を作る。 |
| `/documents/{id}/backups` | `GET` | 文書の版を新しい順に返す。 |
| `/documents/{id}/backups/{backupId}` | `GET` | 選んだ版と現在の本文、変更ファイルの一覧、比較時点のリビジョンを返す。 |
| `/documents/{id}/backups/{backupId}` | `DELETE` | 指定のバックアップを一件削除し、削除した版のIDを返す。 |
| `/documents/{id}/backups/{backupId}/restore` | `POST` | 現在の状態を退避し、選んだ版を復元する。 |
| `/documents/{id}/backups/{backupId}/figures` | `POST` | Copilotの版を複製し、調整後のSVGを保存する。 |
| `/documents/{id}/assets` | `GET`、`HEAD`、`POST` | 図版の完成画像の配信、画像一枚を素材とする図版の登録。PDFとWordはダウンロードとして返す。 |
| `/documents/{id}/figures` | `GET`、`POST` | 図版一覧、図版の作成。 |
| `/documents/{id}/figures/{figureId}` | `GET`、`PUT` | 図版の詳細、リビジョンを照合した編集と名前の変更。 |
| `/documents/{id}/parts` | `GET` | 文書内の図版に保存された画像素材を一覧にする。 |
| `/documents/{id}/figures/{figureId}/parts/{partId}` | `GET`、`HEAD` | 図版エディターで表示、再利用する画像素材を配信する。 |
| `/documents/{id}/figures/prepare-svg` | `POST` | SVGを検査して編集可能な形式へ整える。 |
| `/jobs`、`/jobs/{id}`、`/jobs/{id}/cancel` | `POST`、`GET`、`POST` | ジョブの受付、進捗・結果の取得、中断。 |
| `/sources/browse`、`/sources/inspect` | `POST` | ローカルの選択候補と、ファイル・シートの参照候補を取得する。 |
| `/integrations/status`、`/integrations/sessions` | `GET` | 接続状態、モデルとひな形、作業場所が一致するセッションの一覧。 |
:::

### 3.2.2. ローカル境界

ローカルHTTP境界はホストとブラウザーの出所を検証する。待ち受けはループバックで、許可する `Host` は `localhost`、`127.0.0.1`、`[::1]` と任意のポートになる。GET・HEAD以外ではクロスサイト要求とローカル以外のOriginを拒否する。

本文や表紙の画像リンクから開けるのは、登録した図版の完成画像である。プレビューでは資産URLへ、PDFとWordの出力では埋め込み用データへ変換する。素材の直接参照は画像の読み込み警告を返す。プレビューのiframeをサンドボックス化し、配信するSVGには追加のContent Security Policyを付ける。

:::pagebreak
:::

# 4. 変換とジョブ

## 4.1. ジョブの実行

### 4.1.1. 状態と中断

変換と生成のジョブはサーバーのメモリに保持する。既定の並列実行数は2、実行中と待機を合わせた上限は12である。終了済みを含む履歴は32件を目安に終了済みから整理し、サーバーを再起動すると失われる。GUIは受付結果に含まれるIDを使い、待機中または実行中のジョブをポーリングする。

:::figure id=job_states width=100%
```mermaid
flowchart LR
    Submit["POST 受付 202"] --> Wait["queued"]
    Wait --> Run["running"]
    Wait --> Cancel["canceled"]
    Run --> Done["succeeded"]
    Run --> Failed["failed"]
    Run --> Cancel
```
ジョブの状態遷移
:::

中断の要求は待機中または実行中のジョブに反映する。待機中ならキューから外し、実行中なら `AbortSignal` を処理へ伝える。PDF・Wordの保存はファイルの置き換え前にも中断を確認する。

### 4.1.2. ジョブ種別ごとの入出力

PDF・Word出力は受付時の原本と設定を使う。同じ出力先へ向かう処理が受付済みなら、新しい要求を `409` で拒否する。受付から保存までの間に文書全体が復元された場合は、受付時の内容から作った出力や編集案の保存を止める。

:::table id=job_types
ジョブ受付時の入力と完了時の状態

| 種別 | 主な入力 | 結果と保存副作用 |
| --- | --- | --- |
| `pdf` | 原本・設定、任意の `includeRevisionHistory`。 | PDFを保存し、パス・ダウンロードURL・警告を返す。 |
| `docx` | 原本・設定。 | DOCXを保存し、パス・ダウンロードURL・警告を返す。 |
| `docx-import` | DOCXファイル名とバイト列、対象原本。 | 抽出画像を図版にして、Markdownとともに履歴の版へ保存する。 |
| `generate` | 保存済み原本、ひな形、自然文の依頼、参照資料、任意のセッションとモデル。 | 検証済みの編集案と図版を履歴の版に保存し、版・編集案・出典・診断・セッション情報を返す。 |
| `compose-figure` | 画像素材の配列、図版の依頼、任意のセッションとモデル。 | 専用エージェントの応答を検証して図版を登録し、図版一覧の情報を返す。 |
:::

## 4.2. レンダリング

### 4.2.1. Markdownから出力への分岐

文書レンダラーはMarkdownの解析と図表の変換を共有する。DSLから図表キャプションを組み立て、図表番号と参照を反映し、見出しにアンカーを設定する。表のキャプションは既定で上中央、図のキャプションは下中央に配置する。組み込みの図のキャプションは、プレビューとPDFで下側に `1em` のマージンを取る。

見出し番号の保存先は原本Markdownである。レンダラーは原本から得た見出しのHTMLをプレビュー・PDF・Wordで使い、そのテキストを自動目次の項目名に使う。`tocDepth` は自動目次の掲載範囲を決める。図表の章内番号と参照には、`headingNumbering` と `heading.levels` を適用する。

:::figure id=render_pipeline width=100% height=600px
```mermaid
flowchart TD
    Input["本文と有効な設定"] --> Markup["Markdown・DSL・図表参照を解決"]
    Markup --> Heading["画像・見出しとアンカーを解決"]
    Heading --> Web["表紙・改訂履歴・目次とHTML"]
    Heading --> Word["改訂履歴・Word用の本文"]
    Web --> Preview["プレビュー用HTML"]
    Web --> PDF["Chromiumの印刷処理でPDF"]
    Word --> DOCX["Word用変換でDOCX"]
```
プレビュー・PDF・Wordのレンダリング経路
:::

### 4.2.2. 出力形式ごとの調整

出力形式によって前付けと画像の扱いを調整する。プレビューとPDFは表紙、改訂履歴、目次、本文の順で組み立てる。ヘッダーの `{{documentFolder}}` はフォルダ名へ置き換わり、プレビューでは文書上部、PDFではChromiumのページヘッダーに配置される。

:::table id=render_outputs
各形式のデータと変換方法

| 出力経路 | 利用する処理 | 確認する点 |
| --- | --- | --- |
| プレビュー | HTMLとスタイルに文書内画像の配信URLを使う。 | 未保存の本文を手動更新で確認できる。 |
| PDF | PuppeteerからChrome・Chromiumを起動し、用紙・向き・余白とヘッダー／フッターを指定する。 | ページ単位の配置、改訂履歴の掲載、画像とMermaid。 |
| Word出力 | 本文HTMLを `html-to-docx` とWord用のレイアウト処理で変換する。Mermaidを含む画像は必要に応じてラスタライズする。 | Word用の体裁を適用し、指定された改訂履歴を本文前に置く。 |
| Word取込 | MammothでDOCXをHTMLへ変換し、表の変換処理とTurndownでMarkdownを作る。 | 原本への採用前に差分と警告を確認する。Word独自の書式を含む往復変換には差異が生じる。 |
:::

:::pagebreak
:::

# 5. AIエージェント連携

## 5.1. 参照資料と指示

### 5.1.1. 資料の候補と採用範囲

参照資料は利用者が登録したファイルまたはフォルダのURIをAHPへ添付する。相対パスの起点はアプリのルートで、外部のローカルフォルダや対応するファイルも選べる。候補の確認と依頼に使う資料の登録はGUIで別の操作になり、依頼に送るのは登録した参照元である。サーバーはパスとファイルの種類を検証し、個別ファイルの選択時は指定したファイルがそのフォルダ内にあることを確認する。Excelブックの中身を解析しない。

:::table id=reference_limits
参照資料の単位と制約

| 参照元 | AHPへ渡す単位 | 主な制約 |
| --- | --- | --- |
| コード・テキストファイル | 選択したファイルの `file:` URI。 | 許可する拡張子を検査する。外部Markdownは参照元の対象外。 |
| フォルダ全体 | `scope: directory` を受け、フォルダの `file:` URIを `displayKind: directory` で1件添付する。 | 候補一覧の除外設定や500件上限による制限は参照範囲に適用されない。 |
| フォルダ内の選択ファイル | `files` の相対パスを検証し、各ファイルの `file:` URIを添付する。 | 候補一覧は依存関係・ビルド成果物や一部の認証情報を含むファイル名を除外し、最大500件を表示する。 |
| Excel | ブック全体の `file:` URI。 | シート名とセル範囲は `readingNote` でCopilotに伝える。 |
| 参照元全体 | 各資料のURI添付と出典名。 | 依頼全体で最大20添付。フォルダ全体は1添付。 |
| 資料ごとの読み方 | `readingNote` と対応する資料の出典を組にする。 | その資料の読み取り方として指示に含める。 |
:::

参照元の選択APIは実パスとディレクトリ直下の一覧をローカルGUIへ返す。待受先は `127.0.0.1` とし、APIはローカルのHostとOriginを検査する。選択されたファイルまたはフォルダのURIはAHPのメッセージへ含まれるため、VS CodeのAgent Hostが同じファイルシステムを参照できる環境で使う。

### 5.1.2. ひな形と文書の書き方

ひな形は `copilot.yaml` の `templates` に定義する。原本と同じフォルダにファイルがあれば一覧全体を採用し、不在なら `documents/copilot.yaml` を読む。空の一覧や不正なファイルも文書別を優先し、GUIで無効状態や診断を表示する。

:::table id=writing_templates
テンプレートの定義

| キー | 用途 |
| --- | --- |
| `id` | 文書内で一意の識別子。本文編集ジョブの `templateId` で指定する。 |
| `label` | ドロップダウンの表示名。表示順はファイル内の並び順に従う。 |
| `prompt` | テンプレート選択欄の下に読み取り専用で表示し、編集案を作成するときサーバーがCopilotへ渡す文面。 |
| `instructionOptionalWithSources` | `true` の場合、資料を登録したGUI依頼で依頼内容を省略できる。 |
:::

### 5.1.3. 編集案の生成と採用

本文編集は、AHPの各メッセージで `.github/agents/document-editor.agent.md` を専用エージェントとして指定する。エージェントの定義は、各段落の先頭に要点を置く書き方、変更範囲の扱い、図表参照、DSL、編集可能なSVG図版の出力形式を定める。GUIからの依頼ではエージェントが本文案を返し、サーバーが履歴の版を作る。VS Codeのチャットから原本を直接編集する依頼では、エージェントが既存の版形式に従って文書フォルダ全体を `backups/<UUID>/document/` に複製し、`metadata.json` と必要な共通設定を保存した後に原本を変更する。直接編集前の版には `reason: save` と `label: VS Code編集前` を記録する。

アプリはセッションを再利用するときも、本文の編集条件を依頼ごとに組み立てる。対象の文書ID、ワークスペースから見た相対フォルダ、原本の相対パスとファイル添付、今回の依頼、参照元のURI添付と読み方、その文書で有効なDSLの種類と書式例を渡す。参照元の内容はプロンプトに展開しない。テンプレートのプロンプトは、ジョブ受付時に対象文書の `copilot.yaml` と `templateId` から取得する。ブラウザーはテンプレート一覧APIから表示名とプロンプトを受け取り、選択中の内容を読み取り専用で表示する。プロンプトの登録はYAMLを直接編集して行う。

本文の編集依頼は保存済み原本を対象にする。GUIは未保存時に実行ボタンを無効にする。APIは送信されたリビジョンを原本と照合し、処理開始時にも原本の版を再確認する。AHPの `chat/turnStarted` には、原本と登録した参照資料の `file:` URIを `resource` 添付として渡す。原本の読み取り範囲は文書全体で、先頭から末尾までを0始まりの行番号と文字位置で表す。Copilotの読取・検索・実行ツールが承認を要する場合はVS Codeでの判断を待ち、コマンド実行の自動承認と書き込みツールはアプリの依頼から受け付けない。Excelなどの添付が読めない場合は専用の応答をサーバーがエラーに変換する。部分修正では、エージェントが依頼文に指定された見出しや段落を原本から探す。 [AHPのファイル添付](https://microsoft.github.io/agent-host-protocol/reference/chat.html#messageresourceattachment)

編集案を履歴に保存する前に、生成時の原本・設定のリビジョンと文法診断を確認する。応答から全体を囲むMarkdownコードフェンスや解釈できるYAMLフロントマターを取り除き、DSL、参照ID、Mermaid、提案された図版を検査する。エラーのない案は図版を版の中に保存し、本文の仮リンクを図版の相対パスへ変更する。

:::figure id=ai_draft width=100%
```mermaid
sequenceDiagram
    participant GUI as GUI
    participant API as 生成ジョブ
    participant Source as 資料
    participant AHP as Agent Host
    participant History as 文書の履歴
    GUI->>API: 依頼条件と原本のリビジョン
    API->>Source: 指定範囲を抽出
    API->>AHP: 本文編集エージェント・今回の条件・原本と参照資料のURI
    AHP-->>API: Markdownと図版
    API->>History: 検証済みの本文と図版を保存
    API-->>GUI: 履歴の版・出典・診断
    GUI->>History: 現在との差分を取得
    GUI->>History: 確認して復元
```
AI編集案の作成と採用
:::

## 5.2. VS Code Agent Host

### 5.2.1. 接続と作業場所

AHPの接続先は `common/ahp/client.mjs` が探索する。VS CodeのAgent Hostがローカルに登録した接続情報を読み、ローカルIPCまたはループバックのWebSocketを選ぶ。JSON-RPCでプロトコルを初期化し、セッションの仕様差は `sessions.mjs`、ターンの通知と応答の集約は `turn.mjs` で扱う。

文書のAI支援は `copilot/agent.mjs` の契約を使う。本文編集または図版作成の用途、今回の指示、ファイルと画像を渡す。`copilot/github/index.mjs` がGitHub Copilotを選び、用途に対応する `.github/agents/` の定義とAHP形式の添付に変換する。

作業場所はアプリのルートで固定する。GitHub Copilot実装は新規セッションをその作業場所で作成し、既存セッションの一覧からも同じ作業場所のものを返す。AHPへの接続は依頼ごとに閉じ、セッションはAgent Hostに残す。

### 5.2.2. モデルと実行条件

モデル欄の選択値はAgent Hostが公開するモデルIDを使う。指定があれば新規セッションの作成とターンの送信に反映し、省略時はAgent Hostの選択に従う。画像付きの依頼では、画像非対応と分かるモデルを送信前に拒否する。

既存セッションを再利用する前に、作業場所、Copilotプロバイダー、用途に応じたモード、手動承認、既定チャットの状態を検査する。新規の本文編集セッションはPlanモード、新規の図版作成セッションはInteractiveモードで作る。図版作成のターンでは `image_generation` ツールだけを実行でき、その結果に含まれる画像データを受け取る。ほかのツール要求、追加入力、認証要求を受けた場合は、このアプリが開始したターンを中断する。

:::figure id=ahp_connection width=100% height=600px
```mermaid
flowchart TD
    Start["依頼とセッション・モデル指定"] --> Connect["ローカル Agent Hostを探索して初期化"]
    Connect --> Selection{"既存セッションか"}
    Selection -->|新規| New["アプリのルートでセッションを作成"]
    Selection -->|既存| Old["セッションと既定チャットを取得"]
    New --> Check["作業場所・承認・チャット状態を検査"]
    Old --> Check
    Check --> Turn["選択モデルでターンを開始"]
    Turn --> Read["応答の断片を集約"]
    Read --> Close["接続を閉じてセッションを保持"]
```
Agent Host接続から応答の受信まで
:::

:::pagebreak
:::

# 6. 編集可能な図版

## 6.1. 生成と採用

### 6.1.1. 図版の入口とデータ

図版フォルダは一枚の画像も、複数素材の組み合わせも編集できる状態で保持する。本文編集案のSVGは図形単位で編集する。合成図版は、手元の画像、Copilotが生成したラスタ画像、生成SVG、注釈をそれぞれ編集する。ラスタ画像の編集単位は画像パーツ全体であり、位置、寸法、重なり順を変更する。

:::table id=figure_entry_points
図の入力形式と編集単位

| 入力経路 | 返すデータ | 採用後の編集 |
| --- | --- | --- |
| AI本文編集で図版を依頼 | 指定位置の仮参照とSVG図版案。 | SVGのグループや図形を図版エディターで選択する。 |
| 本文内のMermaid | Markdown中のMermaidコードフェンス。 | コードを変更して描画を更新する。 |
| 図版タブの新規作成 | キャンバスの寸法、画像素材の配置、枠・矢印・文字。 | 同じエディターで画像素材を追加し、各部品を編集する。 |
| Word取り込み | 書き出し画像と、元の画像一枚を配置した図版。 | 他の画像や、枠・矢印・文字を追加する。 |
| AI支援の図版作成 | 添付素材と、画像生成ツールによるラスタ画像、生成SVG、枠・矢印・文字を独立したレイヤーで配置する。 | 位置、寸法、画像の重なり順を調整する。 |
:::

本文への挿入は図版一覧が返した完成画像のパスを `:::figure` ブロックに書く。ビジュアルで右クリックから図版一覧を開いた場合は、一覧へ移動した後も指定したブロックの直後に挿入する。編集ブロックが再構成された場合は位置の選び直しを求める。挿入は一回の変更として取り消し履歴に登録する。ソースでは末尾にブロックを追加する。表示サイズの指定は本文側の `width` と `height` に保存するため、同じ図版を複数箇所で使う場合も個別に指定できる。外部ファイルからの取り込みは図版エディターで素材として処理する。

図題の初期値は、挿入時に図版一覧から受け取った名前である。図題は原本Markdownに保存し、掲載箇所ごとの右クリック操作で変更できる。図題がある場合は採番設定に従って図番号を表示する。図題が空の場合は、章内での出現順は数えた上でキャプションを省く。図版一覧での名前の変更は `asset.yaml` に保存し、以降の挿入に使う。

### 6.1.2. 専用エージェントで図版を登録する処理

図版作成では、Agent Hostが公開したエージェントから、リポジトリの `.github/agents/figure-composer.agent.md` と同じファイルを選ぶ。見つかったエージェントのURIを `chat/turnStarted.message.agent.uri` に指定する。定義ファイルに画像生成ツールの利用条件、応答形式と配置規約を置き、メッセージ本文に今回の文書ID、ワークスペース内の相対フォルダ、依頼、素材の名前・元寸法を渡す。添付画像は一枚ずつAHPの `embeddedResource` に入れ、必要に応じて送信用JPEGへ変換する。 [AHPのメッセージ仕様](https://microsoft.github.io/agent-host-protocol/reference/chat.html#message)

Copilotが `image_generation` を呼ぶと、AHPのツール完了イベントから生成画像を取り出す。画像がAHPのリソース参照で届いた場合は `resourceRead` で読み込む。図版案の `images[].generated` は今回のターンで生成に成功した画像の通し番号であり、`source` はGUIで添付した素材の番号である。サーバーは応答の形式識別子、両番号の参照、キャンバス内の配置、注釈と生成SVGを検証する。図版ストアは添付素材の元画像と生成画像を `assets/parts/` に保存し、完成画像と配置を `assets/figures/` に保存する。ジョブは図版一覧に渡す識別子を返す。本文への挿入は図版一覧から利用者が行う。

### 6.1.3. SVGの位置調整

SVG部品の位置は、標準SVGの `transform` に保存する。ポインターを `getScreenCTM()` の逆変換で `viewBox` の座標へ移し、移動量を部品の親座標へ換算する。親座標の平行移動を `translate(dx dy)` として既存の回転・拡大縮小に加える。

関連する枠とラベルは、共通の `<g>` に `id` と `aria-label` を付けると一緒に移動できる。別グループの接続線と図形は独立した部品として編集する。保存時は選択枠などを外し、サーバーでSVGの許可要素・属性、外部参照を検査してから登録する。

## 6.2. 保存と更新

### 6.2.1. SVGとラスタ図版のファイル

完成画像と配置は `assets/figures/<UUID>/` に保存する。ラスタ図版の元画像と追加素材は `assets/parts/<UUID>/` に保存し、配置情報と同じ図版IDで対応させる。Wordから抽出した画像は、一枚ずつ図版として取り込み版に登録する。図版の更新では本文が指すパスを保ったまま完成画像を差し替える。履歴の保存と復元は両方のフォルダを対象とする。

本文編集案のSVGは `md-operator-figure` コードフェンスから最大12点を抽出する。提案時には仮パスを使い、採用時に図版フォルダへ保存して本文の画像リンクを実パスへ置き換える。同じIDと内容で作成を再試行した場合、保存済みの図版を再利用できる。

:::table id=figure_files
図版と素材の保存ファイル

| ファイル | 対象 | 用途 |
| --- | --- | --- |
| `figures/<UUID>/asset.yaml` | 共通 | 図版名、種類、必要に応じて原本のMIMEタイプを記録する。 |
| `figures/<UUID>/image.svg` | SVG | 編集するSVG本体であり、Markdownの画像リンク先でもある。 |
| `figures/<UUID>/source.mmd` | SVG、任意 | 図案の元になったMermaidソースを保持する。 |
| `parts/<UUID>/original.<拡張子>` | 基準画像があるラスタ | 画像の取り込みなどで基準にした素材を保持する。 |
| `parts/<UUID>/layer-<ID>.<拡張子>` | ラスタ | 添付素材、Copilotの生成画像、生成SVGパーツを保持する。 |
| `figures/<UUID>/annotations.json` | ラスタ | 配置、素材名、注釈、対応する合成画像のハッシュを記録する。 |
| `figures/<UUID>/image.png` | ラスタ | 画像レイヤーと注釈を合成した、本文が参照するPNG。 |
:::

### 6.2.2. ラスタ図版の座標と復旧

ラスタ図版の編集座標は合成キャンバスのピクセル単位で保存する。最大16枚の画像の配置順、原本、幅・高さを保持し、注釈はすべての画像の上に重ねる。枠は幅と高さ、矢印は始点からの `dx` と `dy`、文字は内容・サイズ・太さを持つ。色や線幅も注釈の属性として保存する。

新規作成は基準画像がない状態で始まる。APIにはキャンバス寸法、画像の配置と素材、注釈を送る。注釈だけの図版は保存でき、後から画像素材を追加すると素材フォルダを作成する。

画像パーツの一覧では、キャンバスの配置済みレイヤーと、同じ文書に保存した素材をサムネイルで選べる。選んだ素材と外部画像は、全部を読み込めた時点で個別のレイヤーとして追加し、取り消し履歴を一件作る。採用時に新しい素材を図版のフォルダへ保存するため、再利用元の図版とは独立して編集できる。

ラスタ図版の更新は新旧の合成画像に対応する状態を区別する。既存の状態と合成画像の組を確保した後、`annotations.pending.json` と新しい `image.png` の順で更新し、最後に新しい状態を確定ファイルへ移す。途中で処理が途切れた場合も、読み込み時は画像ハッシュが一致する状態を採用する。

:::figure id=raster_save width=90% height=600px
```mermaid
flowchart TD
    Edit["画像レイヤーと注釈の編集"] --> Revision["図版の revision を照合"]
    Revision --> Render["原本から合成PNGと状態を生成"]
    Render --> Previous["旧画像に対応する状態を確保"]
    Previous --> Pending["新しい状態を pending に保存"]
    Pending --> Replace["合成PNGを置き換え"]
    Replace --> Accepted["新しい状態を確定"]
```
ラスタ図版の更新順序
:::

:::pagebreak
:::

# 7. 異常系と検証

## 7.1. 操作を中断する条件

### 7.1.1. 更新の競合と失敗

更新の競合は、扱うデータに応じて別のリビジョンを用いて検出する。原本は本文のハッシュ、設定は設定元とYAMLのハッシュを使う。図版は名前と表示画像をハッシュ化し、ラスタ図版では配置状態も含める。

:::table id=failures
代表的な異常系と保持する状態

| 条件 | 処理 |
| --- | --- |
| 原本・設定・図版のリビジョンが異なる | 更新APIは `409` を返し、既存ファイルを保持する。 |
| YAMLの解析または設定値の検証に失敗 | 設定取得は診断を返し、設定に依存するプレビューや変換はエラーを返す。 |
| 既存出力先へ同時に変換要求 | 後から受けた要求を `409` にし、実行中の要求を継続する。 |
| ジョブ受付上限 | `429` と `JOB_QUEUE_FULL` を返す。 |
| 参照元の不正な形式、読み取りの失敗 | 資料確認またはジョブの該当段階でエラーを返す。読み取り上限の切り詰めは警告を添える。 |
| Copilotの診断にエラーがある | 診断の行番号と内容をAI支援に表示する。履歴への保存は文法チェックの通過後に行う。 |
| DOCX取込で図版に変換できない画像がある | その画像の変換警告を履歴に記録する。 |
:::

## 7.2. 回帰検証

### 7.2.1. 確認するテストと画面

回帰テストは、設定ファイルの選択、更新競合、変換処理、図版と注釈の再読み込み、AHPの送受信を責務ごとに検証する。`npm test` で自動テストを実行する。Chromeが必要なテストを有効にするには `MD_OPERATOR_TEST_CHROME=1` を指定する。

:::table id=verification
実装変更と確認箇所

| 変更箇所 | 確認する内容 |
| --- | --- |
| 文書管理・API契約 | `tests/application.test.mjs` で作成、取得、保存、競合、APIの結果を確認する。APIを変更したらOpenAPIと共有型を照合する。 |
| YAML・ひな形 | `tests/application.test.mjs` で文書別ファイルの優先、プロンプトを含まない選択肢、独自IDによる生成、GUIでの再読み込みを確認する。 |
| AI・AHP連携 | `documents/assistance/assistance.test.mjs` で参照ファイルのURI添付と依頼条件を、`copilot/github/agent.test.mjs` でモデル、セッション、ツール承認、AHPへの送信を確認する。 |
| レンダリング・図版 | レンダラーと図版のテストに加え、Chromeを使って表紙、目次、Mermaid、PDF・Wordの出力を確認する。 |
| GUIの操作 | `npm run build` で型と配信成果物を確認し、編集モード、見出し移動、手動プレビューをブラウザーで確認する。 |
| トレーサビリティ | `tests/traceability*.test.mjs` でストア・API・ジョブを検証し、GUIはヘッドレスブラウザーを動かすテストコードで確認する。実資料の読み取りと判定の妥当性は人が実運用試験で確認する。 |
:::

# 8. トレーサビリティ

## 8.1. 関係と元・先の項目

関係の識別子はUUIDで、データは `traceabilities/<名前>/` に保存する。新規作成の①は元資料と先資料の関連性を調べ、調査結果と空の項目表を初版として保存する。作成依頼IDを関係IDに対応付け、同じ依頼の再送は初版から選択条件を照合して作成済みの関係を返す。別の作成依頼IDなら、同名・同資料でも別件になる。 保存先のフォルダ名は名前を使い、名前の変更時にフォルダも移動する。APIはメタ情報のUUIDから現在のフォルダを探す。同名の別件の保存先は連番で区別する。

②の元項目表と③の先項目表は独立している。両方とも `items` と `scope` を持ち、項目には `id`、`content`、`location`、任意の `notes` を保存する。scopeのreadとunreadは読取済み範囲と未読範囲・理由の文字列配列。④の判定表には元ID、複数の先ID、対応度、対応詳細、特記事項を持つ行と、一括判定の入力版IDを保存する。

## 8.2. ストアと全体履歴

`traceability/store.mjs` が作成・保存・固定・確認・Copilot候補の検証を行う。手保存は取得時のrevisionを照合する。変更前と結果の全体版を保存した後に現行を置換し、複数ファイルの置換途中はbackups内の一時的な処理情報から復旧する。`history.mjs` は通常ファイルと空フォルダを含めた全体コピー、マニフェスト、セル差分、復元を担当する。

全体版は `backups/<版ID>/tree/` と隣の `metadata.json` で構成する。treeには関係内のJSONと添付資料をまとめる。復元では選んだtreeにない現行ファイルも外し、復元前版を残す。外部URI先の原本は参照情報として保持する。

元項目起点の行と件数は `matrix.mjs` が計算し、同じ結果を画面と `markdown.mjs` の出力で使う。元項目が増えて判定行がなければ判定未作成として表示し、元項目なしの判定は別枠に置く。先項目の参照が欠けても保存済みIDと対応度を保持する。元項目なしの判定行は、人が削除対象のIDを指定した手保存で整理できる。

## 8.3. 確認通知

`review.mjs` は元・先の項目表を正規化したSHA-256を計算する。JSONのキー順・整形は比較結果に影響せず、文字列の内容と配列順は影響する。通知の起点は項目表だけで、①の調査結果やセッション管理項目は含まない。

人がまだ確認していない場合は④のinputVersionを比較元にし、人の確認後はreview-stateの各表の確認版を使う。確認要求には画面で読んだrevisionを渡す。入力版が変わっていれば保存しない。保存・再生成だけでは人の確認済み状態を進めない。

## 8.4. CopilotとAPI

`routes.mjs` は一覧・編集・履歴・確認・復元・Markdownを公開し、作成とCopilot実行は既存のジョブキューに登録する。`assistance.mjs` は関係ID、実行ID、操作と入力版を依頼時に固定し、同じ値を持つ候補だけをストアへ渡す。セッションは関係ごとの対応を記録し、他の関係との重複や失効を送信前に確認する。

`sources.mjs` は元URIを添付し、Office資料は読み取り用の本文をアプリ側で展開する。Wordの見出し・段落・表、Excelのシート・セルの位置を残す。上限やアクセス失敗で読めなかった範囲も依頼に含める。ツール経由のCopilotには読み取りと検索を許可し、編集と任意コマンドは拒否する。

Agent定義は `.github/agents/traceability/` に10件ある。①はgenerate/relatedのみ、②〜④はgenerate・revise・checkに分ける。VS Codeではツールが作ったセッションを開き、Agentを指定して自然文で直接依頼する。直接実行のファイル操作とバックアップは利用者の責任で行い、完了後は画面を手動で再読み込みする。
