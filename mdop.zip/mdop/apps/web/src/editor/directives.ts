/** @file ブロックのDSL属性やMermaidの表示設定を読み、指定箇所だけを原本上で更新する。 */

import { layoutLength, readMermaidLayout, splitFigureSource } from '../../../../packages/markdown/layout.mjs';
import type { TableAction } from './tables';

/** DSLの開始行・本文・閉じ行を元の文字位置で区切る。 */
export interface DslBlock {
  name: string;
  attributes: Record<string, string>;
  bodyStart: number;
  bodyEnd: number;
  attributeStart: number;
  attributeEnd: number;
}

const attributePattern = /([ \t]+)([\w-]+)=("[^"]*"|'[^']*'|[^\s]+)/g;

/** 閉じたDSLブロックを認識する。壊れた構文はソース欄で扱う。 */
export function readDslBlock(source: string): DslBlock | undefined {
  const opening = /^( {0,3}:::(\w[\w-]*))([^\r\n]*)(?:\r\n|\n|\r|$)/.exec(source);
  if (!opening) return undefined;
  const [, prefix, name, raw] = opening;
  const inlineClose = /:::[ \t]*$/.exec(raw);
  const closing = /(^|\r\n|\n|\r)[ \t]*:::[ \t]*(?:\r\n|\n|\r|$)[\s]*$/.exec(source);
  const bodyStart = opening[0].length;
  const bodyEnd = inlineClose ? bodyStart : closing && closing.index + closing[1].length;
  if (bodyEnd === null || bodyEnd < bodyStart) return undefined;
  const attributes = inlineClose ? raw.slice(0, inlineClose.index) : raw;
  return {
    name, bodyStart, bodyEnd, attributeStart: prefix.length, attributeEnd: prefix.length + attributes.length,
    attributes: Object.fromEntries(Array.from(attributes.matchAll(attributePattern), ([, , key, value]) =>
      [key, value.replace(/^['"]|['"]$/g, '')])),
  };
}

/** 図版名や入力された図題をDSLの一行に書ける文字列へ変換する。 */
export function encodeFigureCaption(value: string) {
  return value.replace(/[\r\n]+/g, ' ').trim()
    .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
    .replace(/^[!\x60~:]/, char => `&#${char.charCodeAt(0)};`);
}

/** 図の内容・属性を保ち、図題に使う行だけを更新する。 */
export function setFigureCaption(source: string, block: DslBlock, caption: string) {
  const body = source.slice(block.bodyStart, block.bodyEnd);
  const { captionLines } = splitFigureSource(body);
  const removedLines = new Set(captionLines);
  const ending = /\r\n|\r|\n/.exec(source)?.[0] ?? '\n';
  const lines = body.match(/[^\r\n]*(?:\r\n|\r|\n|$)/g)?.filter(Boolean) ?? [];
  let updated = lines.map((line, index) => {
    if (!removedLines.has(index)) return line;
    if (index !== captionLines[0] || !caption) return '';
    return caption + (/\r\n|\r|\n/.exec(line)?.[0] ?? ending);
  }).join('');
  if (!captionLines.length && caption) {
    if (updated.trim() && !/\r\n[ \t]*\r\n$|\n[ \t]*\n$|\r[ \t]*\r$/.test(updated)) updated += ending;
    updated += caption + ending;
  }
  return source.slice(0, block.bodyStart) + updated + source.slice(block.bodyEnd);
}

/** 対象属性を設定し、IDやその他の属性、本文と改行はそのまま残す。 */
export function setDslAttributes(source: string, block: DslBlock, changes: Record<string, string>) {
  const pending = new Map(Object.entries(changes));
  const attributes = source.slice(block.attributeStart, block.attributeEnd).replace(attributePattern,
    (match, whitespace: string, key: string, raw: string) => {
      if (!Object.hasOwn(changes, key)) return match;
      const value = pending.get(key);
      pending.delete(key);
      const quote = /^['"]/.test(raw) ? raw[0] : '';
      return value ? `${whitespace}${key}=${quote}${value}${quote}` : '';
    });
  const added = Array.from(pending, ([key, value]) => value ? ` ${key}=${value}` : '').join('');
  const trailing = /[ \t]*$/.exec(attributes)![0];
  return source.slice(0, block.attributeStart) + attributes.trimEnd() + added + trailing + source.slice(block.attributeEnd);
}

/** 表題の行と、GFM表が始まりうる本文の位置を分ける。 */
export function dslTableBody(source: string, block: DslBlock) {
  const first = /^([^\r\n]*)(?:\r\n|\n|\r|$)/.exec(source.slice(block.bodyStart, block.bodyEnd))!;
  if (first[1].trimStart().startsWith('|')) return { caption: '', start: block.bodyStart };
  return { caption: first[1].trim(), start: block.bodyStart + first[0].length };
}

/** 列追加・削除に対応する幅を、列数が揃っている設定に対して更新する。 */
export function resizeDslColumns(source: string, action: TableAction, columns: number) {
  const block = readDslBlock(source);
  if (!block || action.axis !== 'column') return source;
  const values = block.attributes.colRatio?.split(/[,:]/).map(value => value.trim());
  if (!values || values.length !== columns || !values.every(value => layoutLength(value) || value === 'auto' || /^\d+(?:\.\d+)?$/.test(value))) return source;
  const ratios = values.every(value => Number(value) > 0);
  const column = action.cell.column;
  if (action.kind === 'add') values.splice(column + 1, 0, ratios ? values[column] : 'auto');
  else values.splice(column, 1);
  return setDslAttributes(source, block, { colRatio: values.join(',') });
}

/** 単体のMermaidコードフェンスについて、コードの開始位置と開き行の書式を返す。 */
function mermaidOpening(source: string) {
  return /^ {0,3}(?:`{3,}|~{3,})[ \t]*mermaid(?:[ \t][^\r\n]*)?(\r\n|\n|\r)/i.exec(source);
}

/** 単体Mermaidの表示用ディレクティブを取得する。 */
export function standaloneMermaidSize(source: string) {
  const opening = mermaidOpening(source);
  if (!opening) return undefined;
  const { width, height } = readMermaidLayout(source.slice(opening[0].length));
  return { width: width ?? '', height: height ?? '' };
}

/** 幅と高さのディレクティブを更新する。文字サイズや図のコードは変更しない。 */
export function setMermaidSize(source: string, changes: Record<string, string>) {
  const opening = mermaidOpening(source);
  if (!opening) return source;
  const { code, directives } = readMermaidLayout(source.slice(opening[0].length));
  const retained = directives.filter(({ name }) => !Object.hasOwn(changes, name)).map(({ raw }) => raw);
  const added = Object.entries(changes).flatMap(([key, value]) => value ? [`%%${key}:${value}%%${opening[1]}`] : []);
  return opening[0] + [...retained, ...added].join('') + code;
}
