import { useEffect, useRef, useState } from 'react';
import { errorMessage } from '../../api';
import { useJob } from '../../useJob';
import { JobFeedback } from '../Feedback';
import { traceApi } from './api';
import type { Detail, Diff, History, Mode, RunResult, Stage } from './api';
import { ItemEditor, MatrixEditor } from './TraceTables';
import './traceability.css';

type Tab = 'map' | 'source' | 'target' | 'history';
const tabs: { id: Tab; label: string }[] = [
  { id: 'map', label: '判定表' }, { id: 'source', label: '元項目' }, { id: 'target', label: '先項目' }, { id: 'history', label: '履歴' },
];
const stageLabels = { source: '② 元項目分解', target: '③ 先項目分解', map: '④ 関係性判定' };
const files = { source: 'source-items.json', target: 'target-items.json', map: 'mappings.json' };
const clone = (value: Detail) => structuredClone(value);
const formatValue = (value: unknown) => value === undefined ? '—' : typeof value === 'string' ? value : JSON.stringify(value, null, 2);
function date(value?: string) { return value && !Number.isNaN(Date.parse(value)) ? new Date(value).toLocaleString('ja-JP') : ''; }

export default function TraceabilityEditor({ id, onBack }: { id: string; onBack: () => void }) {
  const [saved, setSaved] = useState<Detail>();
  const [draft, setDraft] = useState<Detail>();
  const [historical, setHistorical] = useState<Detail>();
  const [history, setHistory] = useState<History[]>([]);
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [difference, setDifference] = useState<Diff>();
  const [tab, setTab] = useState<Tab>('map');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [working, setWorking] = useState(false);
  const [deleteIds, setDeleteIds] = useState<string[]>([]);
  const [stage, setStage] = useState<Stage>('map');
  const [mode, setMode] = useState<Mode>('generate');
  const [throughEnd, setThroughEnd] = useState(false);
  const [instruction, setInstruction] = useState('');
  const [needsRefresh, setNeedsRefresh] = useState(false);
  const task = useJob<RunResult>();
  const handled = useRef('');
  const mounted = useRef(true);
  const dirty = Boolean(saved && draft && JSON.stringify(saved) !== JSON.stringify(draft));
  const blocked = working || task.busy || needsRefresh || Boolean(historical);
  const shown = historical || draft;

  function accept(detail: Detail) {
    setSaved(detail); setDraft(clone(detail)); setDeleteIds([]); setHistorical(undefined); setDifference(undefined);
  }
  async function reload(force = false) {
    if (dirty && !force && !window.confirm('未保存の編集を破棄して、保存済みの内容を再読み込みしますか？')) return;
    setWorking(true); setError('');
    try {
      const result = await traceApi.get(id);
      if (mounted.current) { accept(result.traceability); setNeedsRefresh(false); setNotice('保存済みの内容を読み込みました。'); }
    } catch (exception) { if (mounted.current) setError(errorMessage(exception)); }
    finally { if (mounted.current) setWorking(false); }
  }
  useEffect(() => {
    mounted.current = true;
    void reload(true);
    return () => { mounted.current = false; };
    // The relation ID is fixed for this component instance.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);
  useEffect(() => {
    if (!dirty) return;
    const leave = (event: BeforeUnloadEvent) => event.preventDefault();
    window.addEventListener('beforeunload', leave);
    return () => window.removeEventListener('beforeunload', leave);
  }, [dirty]);

  async function save() {
    if (!draft || blocked) return undefined;
    if (!dirty) return draft;
    setWorking(true); setError('');
    try {
      const clean = clone(draft);
      for (const side of ['source', 'target'] as const) {
        clean[side].scope.read = clean[side].scope.read.filter(value => value.trim());
        clean[side].scope.unread = clean[side].scope.unread.filter(value => value.trim());
      }
      const result = await traceApi.save(id, clean, deleteIds);
      accept(result.traceability); setNotice('関係全体の履歴を残して保存しました。');
      return result.traceability;
    } catch (exception) { setError(errorMessage(exception)); return undefined; }
    finally { setWorking(false); }
  }
  useEffect(() => {
    const shortcut = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
        event.preventDefault(); if (!window.document.querySelector('dialog[open]')) void save();
      }
    };
    window.addEventListener('keydown', shortcut);
    return () => window.removeEventListener('keydown', shortcut);
  });
  useEffect(() => {
    if (task.job && ['succeeded', 'failed', 'canceled'].includes(task.job.status) && task.job.id !== handled.current) {
      handled.current = task.job.id; setNeedsRefresh(true);
      setNotice(task.job.status === 'succeeded' ? 'Copilotの処理が完了しました。画面を再読み込みしてください。'
        : 'Copilotの処理が終了しました。途中までの結果が保存されている場合があります。画面を再読み込みして確認してください。');
    }
  }, [task.job]);

  async function run() {
    if (!draft || blocked) return;
    let current = draft;
    if (dirty) {
      if (!window.confirm('未保存の編集を保存してから、Copilotを実行しますか？')) return;
      const result = await save(); if (!result) return; current = result;
    }
    setNotice('');
    await task.start({ type: 'traceability-run', traceabilityId: id, stage, mode, instruction: instruction.trim(),
      throughEnd: mode === 'generate' && throughEnd, revision: current.revision });
  }
  async function loadHistory(start?: string) {
    setWorking(true); setError('');
    try {
      const result = await traceApi.history(id); setHistory(result.history); setTab('history');
      if (start) setFrom(start); else if (!from) setFrom(result.history[0]?.id || '');
      setDifference(undefined);
    } catch (exception) { setError(errorMessage(exception)); }
    finally { setWorking(false); }
  }
  async function compare() {
    if (!from) return;
    setWorking(true); setError('');
    try { setDifference((await traceApi.diff(id, from, to || undefined)).diff); }
    catch (exception) { setError(errorMessage(exception)); }
    finally { setWorking(false); }
  }
  async function inspectVersion(version: string) {
    if (dirty && !window.confirm('未保存の編集を保持したまま、読み取り専用の履歴を開きますか？')) return;
    setWorking(true); setError('');
    try { setHistorical((await traceApi.get(id, version)).traceability); setTab('map'); }
    catch (exception) { setError(errorMessage(exception)); }
    finally { setWorking(false); }
  }
  async function restore() {
    if (!saved || !historical?.version || !window.confirm('関係フォルダ全体をこの版に戻しますか？ 復元直前の全体履歴を残します。未保存の編集は破棄します。')) return;
    setWorking(true); setError('');
    try { accept((await traceApi.restore(id, saved.revision, historical.version)).traceability); setNotice('全体を復元しました。'); setNeedsRefresh(false); }
    catch (exception) { setError(errorMessage(exception)); }
    finally { setWorking(false); }
  }
  async function confirm(side: 'source' | 'target') {
    if (!saved || dirty || blocked) return;
    setWorking(true); setError('');
    try { accept((await traceApi.review(id, saved.revision, side)).traceability); setNotice('現在の項目表と判定表を確認した記録を保存しました。'); }
    catch (exception) { setError(errorMessage(exception)); }
    finally { setWorking(false); }
  }
  async function exportMarkdown() {
    if (!shown || working || task.busy || needsRefresh) return;
    if (dirty && !historical) {
      if (!window.confirm('未保存の編集を保存してからMarkdownを出力しますか？')) return;
      if (!await save()) return;
    }
    setError('');
    try {
      const response = await fetch(traceApi.markdown(id, historical?.version));
      if (!response.ok) throw new Error('Markdownの出力に失敗しました。');
      const url = URL.createObjectURL(await response.blob());
      const link = window.document.createElement('a');
      link.href = url; link.download = `${shown.config.name}.md`; link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (exception) { setError(errorMessage(exception)); }
  }
  function changeFixed(side: Stage, checked: boolean) {
    if (!draft) return;
    const fixed = draft.config.fixedFiles.filter(file => file !== files[side]);
    setDraft({ ...draft, config: { ...draft.config, fixedFiles: checked ? [...fixed, files[side]] : fixed } });
  }
  function back() {
    if (working) return;
    if (dirty && !window.confirm('未保存の編集を破棄して一覧に戻りますか？')) return;
    onBack();
  }
  return <div className="workspace-app trace-app">
    <header className="app-bar">
      <button type="button" className="back-button" onClick={back} disabled={working} aria-label="文書とトレーサビリティの一覧に戻る">← <span>一覧</span></button>
      <div className="branding"><span className="brand-icon" aria-hidden="true">M</span><h1>MD Operator</h1></div>
      <span className="header-location">{shown?.config.name || 'トレーサビリティ'}</span>
      <div className="app-actions"><span className="save-status">{working ? '処理中…' : historical ? '履歴を閲覧中' : dirty ? '未保存' : '保存済み'}</span>
        <button className="save-button" disabled={!dirty || blocked} onClick={() => void save()}>保存</button></div>
    </header>
    <main className="trace-workspace">
      {error && <p className="trace-notice error" role="alert">{error}</p>}
      {notice && <p className="trace-notice" role="status">{notice}</p>}
      {!shown ? <p role="status">読み込み中…</p> : <>
        <div className="trace-editor-heading"><div><label className="trace-name">トレーサビリティ名
          <input aria-label="トレーサビリティ名" maxLength={255} value={shown.config.name} disabled={blocked}
            onChange={event => setDraft({ ...shown, config: { ...shown.config, name: event.target.value } })} /></label>
          <code className="trace-relation-id">{id}</code></div>
          <div className="trace-actions"><button type="button" disabled={working || task.busy} onClick={() => void reload()}>画面を再読み込み</button>
            <button type="button" disabled={working || task.busy || needsRefresh} onClick={() => void exportMarkdown()}>Markdown出力</button></div>
        </div>
        {historical && <div className="trace-history-banner"><strong>履歴 {historical.version}</strong>
          <button type="button" disabled={working} onClick={() => setHistorical(undefined)}>編集画面に戻る</button><button type="button" disabled={working || task.busy} onClick={() => void restore()}>この版を全体復元</button>
        </div>}
        <details className="trace-context"><summary>資料と作成時の関係性調査</summary><dl><dt>元</dt><dd>{shown.config.sourceUri}</dd><dt>先</dt><dd>{shown.config.targetUri}</dd>
          <dt>粒度</dt><dd>{shown.config.granularity}</dd><dt>関係性</dt><dd>{shown.config.assessment.status} — {shown.config.assessment.reason}</dd></dl>
          {shown.mappings.inputVersion && <p><button type="button" disabled={working} onClick={() => void inspectVersion(shown.mappings.inputVersion!)}>④の判定に使った版を開く</button></p>}
          {shown.config.copilotSession && <p>この関係のCopilotセッション <code>{shown.config.copilotSession.sessionId || shown.config.copilotSession.id}</code></p>}
        </details>
        {!historical && <section className="trace-run" aria-label="Copilotの実行">
          <div className="trace-run-options"><label>段階<select value={stage} disabled={blocked} onChange={event => setStage(event.target.value as Stage)}>
            {Object.entries(stageLabels).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select></label>
            <label>操作<select value={mode} disabled={blocked} onChange={event => setMode(event.target.value as Mode)}><option value="generate">新規生成</option><option value="revise">修正・追記</option><option value="check">検査</option></select></label>
            {mode === 'generate' && <label className="check-label"><input type="checkbox" checked={throughEnd} disabled={blocked} onChange={event => setThroughEnd(event.target.checked)} />ここから④まで実行</label>}
            <button type="button" className="primary" disabled={blocked} onClick={() => void run()}>Copilotで実行</button>
          </div>
          <label>今回の指示（任意）<textarea rows={2} disabled={blocked} value={instruction} onChange={event => setInstruction(event.target.value)} placeholder="修正する項目や、検査で確認したい条件を入力" /></label>
          <JobFeedback state={task} />
          {task.job?.status === 'succeeded' && task.job.result?.report && <pre className="trace-report">{typeof task.job.result.report === 'string' ? task.job.result.report : JSON.stringify(task.job.result.report, null, 2)}</pre>}
        </section>}
        <nav className="trace-tabs" aria-label="トレーサビリティの表">
          {tabs.map(entry => <button key={entry.id} type="button" aria-pressed={tab === entry.id} disabled={working}
            onClick={() => entry.id === 'history' ? void loadHistory() : setTab(entry.id)}>{entry.label}</button>)}
        </nav>
        {tab !== 'history' && <>
          {tab === 'map' && <div className="trace-review" aria-label="判定の確認状態">{(['source', 'target'] as const).map(side => {
            const review = shown.review?.[side]; if (!review) return null;
            return <div key={side} className={'trace-review-item ' + review.status}>
              <span><strong>{side === 'source' ? '元項目表' : '先項目表'}</strong> {review.message || review.status}</span>
              <div>{review.baselineVersion && <button type="button" disabled={working} onClick={() => void loadHistory(review.baselineVersion)}>履歴差分</button>}
                {!historical && review.status !== 'confirmed' && <button type="button" disabled={dirty || blocked} onClick={() => void confirm(side)}>この組を確認済みにする（修正不要を含む）</button>}</div>
            </div>;
          })}</div>}
          <label className="trace-fixed check-label"><input type="checkbox" disabled={blocked} checked={shown.config.fixedFiles.includes(files[tab])}
            onChange={event => changeFixed(tab, event.target.checked)} />この表のJSONを固定する</label>
          {tab === 'map' ? <MatrixEditor detail={shown} disabled={blocked} onChange={rows => setDraft({ ...shown, mappings: { ...shown.mappings, rows } })}
            onDeleteOrphan={mappingId => { setDeleteIds(current => [...current, mappingId]); setDraft({ ...shown, mappings: { ...shown.mappings, rows: shown.mappings.rows.filter(row => row.id !== mappingId) } }); }} />
            : <ItemEditor side={tab} table={shown[tab]} disabled={blocked} onChange={value => setDraft({ ...shown, [tab]: value })} />}
        </>}
        {tab === 'history' && <section className="trace-history" aria-label="全体履歴と差分">
          <div className="trace-diff-options"><label>変更前<select value={from} onChange={event => setFrom(event.target.value)}><option value="">版を選択</option>{history.map(entry => <option key={entry.id} value={entry.id}>{date(entry.createdAt)} {entry.reason} {entry.id.slice(0, 8)}</option>)}</select></label>
            <label>変更後<select value={to} onChange={event => setTo(event.target.value)}><option value="">現在の保存版</option>{history.map(entry => <option key={entry.id} value={entry.id}>{date(entry.createdAt)} {entry.reason} {entry.id.slice(0, 8)}</option>)}</select></label>
            <button type="button" disabled={working || !from} onClick={() => void compare()}>差分を表示</button></div>
          {difference && <div className="trace-difference"><h3>変更前 {difference.fromVersion || from} → 変更後 {difference.toVersion || to || '現在の保存版'}</h3>
            {difference.files?.length === 0 && difference.rows?.length === 0 && <p>差分はありません。</p>}
            {difference.files?.map(file => <p key={file.path}><code>{file.path}</code> {file.change}</p>)}
            {difference.rows?.map((row, index) => <section key={index}><h4>{row.file} {row.id} — {row.change}</h4>
              {(row.cells || [{ column: '行', before: row.before, after: row.after }]).map(cell => <div className="trace-cell-diff" key={cell.column}><strong>{cell.column}</strong><pre>{formatValue(cell.before)}</pre><span aria-hidden="true">→</span><pre>{formatValue(cell.after)}</pre></div>)}
            </section>)}
          </div>}
          <ul className="trace-history-list">{history.map(entry => <li key={entry.id}><div><strong>{date(entry.createdAt)}</strong><span>{entry.reason} {entry.operation}</span><code>{entry.id}</code>{entry.runId && <small>実行 {entry.runId}</small>}{entry.groupId && <small>パイプライン実行 {entry.groupId}</small>}</div><div className="trace-actions">
            {entry.startVersion && <button type="button" disabled={working} onClick={() => void inspectVersion(entry.startVersion!)}>今回の実行前版を開く</button>}
            <button type="button" disabled={working} onClick={() => void inspectVersion(entry.id)}>この版を開く</button></div></li>)}</ul>
        </section>}
      </>}
    </main>
  </div>;
}
