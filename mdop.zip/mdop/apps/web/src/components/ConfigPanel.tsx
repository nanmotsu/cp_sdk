/**
 * @file 文書の基本設定をフォームで編集し、詳細設定のYAML例と保存時の競合を表示する。
 */

import { useEffect, useState } from 'react';
import type { FormEvent, ReactNode } from 'react';
import { ApiError, api, errorMessage } from '../api';
import type { BasicSettingsPatch, ConfigInfo } from '../api';
import { Warnings } from './Feedback';
import './ConfigPanel.css';

const paperSizes = ['A0', 'A1', 'A2', 'A3', 'A4', 'A5', 'A6', 'Letter', 'Legal', 'Tabloid', 'Ledger'];
const revisionTargets = { preview: 'プレビュー', pdf: 'PDF', docx: 'Word' } as const;
/** 改訂履歴の表示を個別に制御する出力先。 */
type RevisionTarget = keyof typeof revisionTargets;
const revisionKeys = Object.keys(revisionTargets) as RevisionTarget[];

/** フォームに表示するため既定値を補った基本設定。 */
interface BasicSettings {
  title: string;
  subtitle: string;
  titlePage: boolean;
  paper: string;
  orientation: 'portrait' | 'landscape';
  toc: boolean;
  tocDepth: number;
  revisionHistoryVisibility: Record<RevisionTarget, boolean>;
  headerEnabled: boolean;
  headerRight: string;
}

/** 設定値をネストしたフォーム項目として読み取れる形にそろえる。 */
function mapping(value: unknown): Record<string, unknown> {
  return value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};
}

/** 設定値が文字列の場合に入力欄へ移す。 */
function text(value: unknown) {
  return typeof value === 'string' ? value : '';
}

/** 有効なYAML設定から基本項目を取り出し、フォームで表示できる値にする。 */
function readBasicSettings(config: Record<string, unknown>): BasicSettings {
  const header = mapping(config.headerFooter);
  const visibility = mapping(config.revisionHistoryVisibility);
  const depth = Number(config.tocDepth);
  return {
    title: text(config.title),
    subtitle: text(config.subtitle),
    titlePage: config.titlePage !== false,
    paper: paperSizes.find(size => size.toLowerCase() === text(config.paper).toLowerCase()) ?? 'A4',
    orientation: config.orientation === 'landscape' ? 'landscape' : 'portrait',
    toc: config.toc !== false,
    tocDepth: [1, 2, 3].includes(depth) ? depth : 3,
    revisionHistoryVisibility: {
      preview: visibility.preview !== false,
      pdf: visibility.pdf !== false,
      docx: visibility.docx !== false,
    },
    headerEnabled: header.enabled === true,
    headerRight: text(mapping(header.header).right),
  };
}

/** 初期表示と異なる項目だけを、部分更新APIへ渡す形に組み立てる。 */
function changedSettings(base: BasicSettings, values: BasicSettings): BasicSettingsPatch {
  const revisionHistoryVisibility: Partial<Record<RevisionTarget, boolean>> = {};
  for (const key of revisionKeys) {
    if (values.revisionHistoryVisibility[key] !== base.revisionHistoryVisibility[key]) {
      revisionHistoryVisibility[key] = values.revisionHistoryVisibility[key];
    }
  }
  const headerChanged = values.headerEnabled !== base.headerEnabled;
  const headerTextChanged = values.headerRight !== base.headerRight;
  return {
    ...(values.title !== base.title && { title: values.title }),
    ...(values.subtitle !== base.subtitle && { subtitle: values.subtitle }),
    ...(values.titlePage !== base.titlePage && { titlePage: values.titlePage }),
    ...(values.paper !== base.paper && { paper: values.paper }),
    ...(values.orientation !== base.orientation && { orientation: values.orientation }),
    ...(values.toc !== base.toc && { toc: values.toc }),
    ...(values.tocDepth !== base.tocDepth && { tocDepth: values.tocDepth }),
    ...(Object.keys(revisionHistoryVisibility).length && { revisionHistoryVisibility }),
    ...((headerChanged || headerTextChanged) && { headerFooter: {
      ...(headerChanged && { enabled: values.headerEnabled }),
      ...(headerTextChanged && { header: { right: values.headerRight } }),
    } }),
  };
}

/** フォームの近くで詳細なYAML設定例を展開する。 */
function YamlExample({ title, children, example }: { title: string; children: ReactNode; example: string }) {
  return <details className="config-yaml-help">
    <summary>{title}</summary>
    <p className="muted">{children}</p>
    <pre><code>{example}</code></pre>
  </details>;
}

/** 文書の設定元と診断を示し、基本設定の部分更新を提供する。 */
export default function ConfigPanel({ documentId, configVersion, onSaved }: {
  documentId: string;
  configVersion: number;
  onSaved: () => void;
}) {
  const [info, setInfo] = useState<ConfigInfo | null>(null);
  const [edit, setEdit] = useState<{ values: BasicSettings; revision: string } | null>(null);
  const [error, setError] = useState('');
  const [conflict, setConflict] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const base = info?.config ? readBasicSettings(info.config) : null;
  const values = edit?.values ?? base;
  const changes = base && edit ? changedSettings(base, edit.values) : {};
  const changed = Object.keys(changes).length > 0;
  const stale = Boolean(edit && (conflict || edit.revision !== info?.revision));

  useEffect(() => {
    const controller = new AbortController();
    api.config(documentId, controller.signal).then((result) => {
      if (controller.signal.aborted) return;
      setInfo(result);
      setError('');
    }).catch((exception: unknown) => {
      if (!controller.signal.aborted) setError(errorMessage(exception));
    });
    return () => controller.abort();
  }, [documentId, configVersion]);

  /** フォームに入力された値を作業状態に保存する。 */
  function change<K extends keyof BasicSettings>(key: K, value: BasicSettings[K]) {
    if (!info || !base) return;
    setSaved(false);
    setError('');
    setEdit(current => ({
      values: { ...(current?.values ?? base), [key]: value },
      revision: current?.revision ?? info.revision,
    }));
  }

  /** 読み込み時のリビジョンと差分を送る。保存できたら他パネルへ設定変更を知らせる。 */
  async function save(event: FormEvent) {
    event.preventDefault();
    if (!base || !edit || stale || saving || !changed) return;
    setSaving(true);
    setSaved(false);
    setError('');
    try {
      setInfo(await api.saveBasicSettings(documentId, changes, edit.revision));
      setEdit(null);
      setSaved(true);
      onSaved();
    } catch (exception) {
      if (exception instanceof ApiError && exception.status === 409) setConflict(true);
      else setError(errorMessage(exception));
    } finally {
      setSaving(false);
    }
  }

  /** フォームの未保存状態を解除し、ディスク上の設定を取り直す。 */
  function reloadSettings() {
    setInfo(null);
    setEdit(null);
    setConflict(false);
    setError('');
    setSaved(false);
    onSaved();
  }

  const localPath = `documents/${documentId}/config.yaml`;
  return <div className="form-panel stack config-settings">
    {error && <p className="error" role="alert">{error}</p>}
    {!info && !error && <p className="muted" role="status">設定を読み込んでいます…</p>}
    {!info && error && <div className="form-actions"><button type="button" onClick={reloadSettings}>再読み込み</button></div>}
    {info && <>
      <p className="config-source">{info.source === 'shared' ? '共通設定' : '文書別設定'}
        <code>{info.source === 'shared' ? info.path : localPath}</code>
      </p>
      <Warnings warnings={info.diagnostics} />
      {!base && <>
        <p className="muted">設定ファイルをテキストエディターで修正してから、再読み込みしてください。</p>
        <div className="form-actions"><button type="button" onClick={reloadSettings}>設定を再読み込み</button></div>
      </>}
      {base && values && <form className="stack" onSubmit={save}>
        {info.source === 'shared'
          ? <>
            <p className="muted">フォームの変更を保存すると、共通設定をもとに文書別設定を作成します。</p>
            <p className="muted">この文書だけ詳細設定を変える場合は、共通設定を <code>{localPath}</code> にコピーして編集します。
              共通設定の編集は、その設定を使う文書すべてに反映します。</p>
          </>
          : <p className="muted">詳細設定は各項目のYAML例を参考に、<code>{localPath}</code> を編集します。</p>}
        {stale && <p className="error" role="alert">設定ファイルが変更されました。最新の設定を読み込んでから編集してください。</p>}
        <fieldset className="config-fields stack" disabled={saving}>
          <section className="config-group stack" aria-labelledby="config-cover-heading">
            <h3 id="config-cover-heading">表紙</h3>
            <label className="config-check"><input type="checkbox" name="titlePage" checked={values.titlePage}
              onChange={event => change('titlePage', event.target.checked)} />表紙を表示</label>
            <label>タイトル<input type="text" name="title" value={values.title} onChange={event => change('title', event.target.value)} /></label>
            <label>副題<input type="text" name="subtitle" value={values.subtitle} onChange={event => change('subtitle', event.target.value)} /></label>
            <YamlExample title="表紙画像・文字サイズのYAML例" example={"cover: assets/figures/<図版ID>/image.png\ntitlePageStyle:\n  titleSize: 36px\n  subtitleSize: 18px"}>
              表紙画像には、登録した図版の完成画像への相対パスを指定します。
            </YamlExample>
          </section>
          <section className="config-group stack" aria-labelledby="config-paper-heading">
            <h3 id="config-paper-heading">用紙と目次</h3>
            <div className="config-pair">
              <label>用紙サイズ<select name="paper" value={values.paper} onChange={event => change('paper', event.target.value)}>
                {paperSizes.map(size => <option key={size}>{size}</option>)}
              </select></label>
              <label>用紙の向き<select name="orientation" value={values.orientation}
                onChange={event => change('orientation', event.target.value === 'landscape' ? 'landscape' : 'portrait')}>
                <option value="portrait">縦</option>
                <option value="landscape">横</option>
              </select></label>
            </div>
            <label className="config-check"><input type="checkbox" name="toc" checked={values.toc}
              onChange={event => change('toc', event.target.checked)} />目次を表示</label>
            <label>見出しの深さ<select name="tocDepth" value={values.tocDepth} onChange={event => change('tocDepth', Number(event.target.value))}>
              <option value={1}>見出し1まで</option>
              <option value={2}>見出し2まで</option>
              <option value={3}>見出し3まで</option>
            </select></label>
            <p className="muted">左の見出し一覧にも反映します。</p>
            <YamlExample title="余白・目次の細かな調整のYAML例"
              example={"margin:\n  top: 10mm\n  left: 15mm\nheading:\n  levels: [h1, h2]\ntocManual: |-\n  - [概要](#toc-1)"}>
              余白は単位を付けて指定します。目次の項目を手書きする場合は <code>tocManual</code> に記述します。
            </YamlExample>
          </section>
          <section className="config-group stack" aria-labelledby="config-history-heading">
            <h3 id="config-history-heading">改訂履歴の表示</h3>
            <div className="config-revision-targets">
              {revisionKeys.map(target => <label className="config-check" key={target}>
                <input type="checkbox" name={`revisionHistoryVisibility.${target}`} checked={values.revisionHistoryVisibility[target]}
                  onChange={event => change('revisionHistoryVisibility', { ...values.revisionHistoryVisibility, [target]: event.target.checked })} />
                {revisionTargets[target]}
              </label>)}
            </div>
            <YamlExample title="改訂履歴を記録するYAML例"
              example={"revisionHistory:\n  - version: '1.0'\n    date: '2026-01-01'\n    description: 初版作成"}>
              版、日付、説明は <code>revisionHistory</code> に記録します。
            </YamlExample>
          </section>
          <section className="config-group stack" aria-labelledby="config-header-heading">
            <h3 id="config-header-heading">ヘッダーとフッター</h3>
            <label className="config-check"><input type="checkbox" name="headerFooter.enabled" checked={values.headerEnabled}
              onChange={event => change('headerEnabled', event.target.checked)} />ヘッダー・フッターを有効にする</label>
            <label>右上の文字<input type="text" name="headerFooter.header.right" value={values.headerRight}
              onChange={event => change('headerRight', event.target.value)} /></label>
            <YamlExample title="ヘッダーの位置・色・ページ番号のYAML例"
              example={"headerFooter:\n  enabled: true\n  fontSize: 9px\n  header:\n    left: '{{documentFolder}}'\n    right: レビュー中\n    rightColor: '#c00000'\n  footer:\n    center: '<span class=\"pageNumber\"></span> / <span class=\"totalPages\"></span>'"}>
              <code>{'{{documentFolder}}'}</code> は文書フォルダ名に置き換わります。ページ番号はPDFに表示します。
            </YamlExample>
          </section>
        </fieldset>
        <div className="form-actions">
          <button type="submit" className="primary" disabled={saving || stale || !changed}>
            {saving ? '保存中…' : 'この文書の設定として保存'}
          </button>
          <button type="button" disabled={saving} onClick={reloadSettings}>
            {changed || stale ? '編集を破棄して再読み込み' : '設定を再読み込み'}
          </button>
        </div>
        {saved && <p role="status" className="muted">設定を保存しました。</p>}
      </form>}
    </>}
  </div>;
}
