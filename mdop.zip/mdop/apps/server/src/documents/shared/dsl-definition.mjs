/**
 * @file 組み込みDSLの一覧、YAMLで指定できるブロック定義、描画方式の選択。
 * 記法の解析は markdown-syntax.mjs、HTML変換は dsl.mjs、図表番号と参照は references.mjs。
 *
 * 通常ブロックの幅は width、図の寸法・配置は width / height / align を受け付ける。
 * 表は fontSize と colRatio を解釈する。
 * figure と table の id は図表参照に使う。hide は出力前に処理される予約済みの記法。
 */

/**
 * @typedef {object} DslBlockDefinition
 * @property {string} name ::: に続くブロック名。
 * @property {string} element HTML要素名。
 * @property {string} class 出力要素のCSSクラス。
 * @property {boolean} [selfClosing] 本文のない区切りとして描画する。
 * @property {"top" | "bottom"} [captionPosition] 上なら表、下なら図の記法を使う。省略時は通常の本文。
 * @property {string} [captionPrefix] 採番に使う図表ラベルの接頭辞。
 * @property {string} [counter] CSSカウンター名の基礎になる識別子。
 * @property {{ width?: string, height?: string }} [defaults] 図の属性を省略したときの寸法。
 * @property {Record<string, string>} [styles] ブロックのCSS。
 * @property {Record<string, string>} [captionStyles] 図題・表題のCSS。
 * @property {boolean} [showBorder] 名前が table の定義における表の罫線の表示。
 * @property {string} [border] 名前が table の定義における表の罫線色。
 * @property {string} [thBg] 名前が table の定義における見出し行の背景色。
 * @property {string} [cellPadding] 名前が table の定義におけるセルの余白。
 * @property {string} [tableMargin] 名前が table の定義における表の余白。
 * @property {{ prefix?: string, description?: string, body?: string[] }} [snippet] 表示名とAIに渡す記法の例。
 */

/** @type {{ blocks: DslBlockDefinition[] }} */
export const DEFAULT_DSL = {
    blocks: [
        // 通常ブロック。色、配置、大きさといった装飾を指定できる。
        {
            name: "warning",
            element: "div",
            class: "warning",
            selfClosing: false,
            styles: {
                color: "#e67e00",
                background: "#fff8f0",
                "border-left": "4px solid #e67e00",
                padding: "0.2em 0.5em",
                margin: "0.5em 0",
                "border-radius": "0 4px 4px 0",
                "max-width": "100%"
            },
            snippet: {
                prefix: "warn",
                description: "警告ブロック",
                body: [
                    ":::warning",
                    "${1:内容}",
                    ":::"
                ]
            }
        },
        {
            name: "center",
            element: "div",
            class: "center",
            selfClosing: false,
            styles: {
                "text-align": "center"
            },
            snippet: {
                prefix: "center",
                description: "中央揃え",
                body: [
                    ":::center",
                    "${1:内容}",
                    ":::"
                ]
            }
        },
        {
            name: "right",
            element: "div",
            class: "right",
            selfClosing: false,
            styles: {
                "text-align": "right"
            },
            snippet: {
                prefix: "right",
                description: "右寄せ",
                body: [
                    ":::right",
                    "${1:内容}",
                    ":::"
                ]
            }
        },
        {
            name: "large",
            element: "div",
            class: "large",
            selfClosing: false,
            styles: {
                "font-size": "24px"
            },
            snippet: {
                prefix: "large",
                description: "大きい文字",
                body: [
                    ":::large",
                    "${1:内容}",
                    ":::"
                ]
            }
        },
        {
            name: "red",
            element: "div",
            class: "red",
            selfClosing: false,
            styles: {
                color: "#cc0000"
            },
            snippet: {
                prefix: "red",
                description: "赤文字",
                body: [
                    ":::red",
                    "${1:内容}",
                    ":::"
                ]
            }
        },
        // 本文を持たない区切り。印刷時は break-before のスタイルが改ページを指定する。
        {
            name: "pagebreak",
            element: "div",
            class: "page-break",
            selfClosing: true,
            styles: {
                "page-break-before": "always",
                "break-before": "page"
            },
            snippet: {
                prefix: "pb",
                description: "ページ区切り",
                body: [
                    ":::pagebreak",
                    ":::"
                ]
            }
        },
        // 図題は画像・Mermaid・コードなどの後ろに置く。
        {
            name: "figure",
            element: "figure",
            class: "figure",
            selfClosing: false,
            counter: "figure",
            captionPosition: "bottom",
            captionPrefix: "図",
            defaults: {
                width: "100%",
                height: "auto"
            },
            styles: {
                margin: "0 0",
                "text-align": "center"
            },
            captionStyles: {
                "font-size": "var(--small-size)",
                color: "#555",
                "margin-top": "0",
                "margin-bottom": "1em"
            },
            snippet: {
                prefix: "fig",
                description: "図（キャプション付き）",
                body: [
                    ":::figure ${4:width=80%}",
                    "![${1:alt}](${2:path})",
                    "",
                    "${3:キャプション}",
                    ":::"
                ]
            }
        },
        // 表題はMarkdown表の前に置く。
        {
            name: "table",
            element: "div",
            class: "table-wrapper",
            selfClosing: false,
            counter: "table",
            captionPosition: "top",
            captionPrefix: "表",
            showBorder: true,
            border: "#bdc3c7",
            thBg: "#f0f0f0",
            cellPadding: "0.45em 0.8em",
            tableMargin: "0 0",
            styles: {
                margin: "0 0"
            },
            captionStyles: {
                "font-size": "var(--small-size)",
                color: "#555",
                "margin-bottom": "0.5em",
                "font-weight": "bold",
                "text-align": "center"
            },
            snippet: {
                prefix: "tbl",
                description: "表（キャプション付き・fontSize/colRatio対応）",
                body: [
                    ":::table ${6:fontSize=13px} ${7:colRatio=2,3}",
                    "${1:表タイトル}",
                    "",
                    "| ${2:列1} | ${3:列2} |",
                    "| --- | --- |",
                    "| ${4:} | ${5:} |",
                    ":::"
                ]
            }
        }
    ]
};

/** HTML出力とビジュアル編集で共通のブロックの種類を求める。 */
export function resolveDslBlockKind(definition) {
    if (definition.selfClosing) return "separator";
    if (definition.captionPosition === "top") return "table";
    if (definition.captionPosition === "bottom") return "figure";
    return "text";
}

/** YAMLでブロックのプロパティを記述するオブジェクトか判断する。 */
const record = value => value && typeof value === "object" && !Array.isArray(value);

/** カスタムDSLのブロック名、要素、書式、採番に関する問題を診断一覧へ追加する。 */
export function validateDslDefinitions(config, diagnostics) {
    if (!Array.isArray(config.blocks)) {
        diagnostics.push("dsl.blocks は配列で指定してください。");
        return;
    }
    const names = new Set();
    for (const [index, block] of config.blocks.entries()) {
        const field = `dsl.blocks[${index}]`;
        if (!record(block) || typeof block.name !== "string" || !/^[a-z][\w-]*$/i.test(block.name)
            || typeof block.element !== "string" || !/^[a-z][\w-]*$/i.test(block.element)
            || typeof block.class !== "string" || !/^[a-z][\w-]*$/i.test(block.class)) {
            diagnostics.push(`${field} に name、element、class を指定してください。`);
            continue;
        }
        if (names.has(block.name)) diagnostics.push(`${field}.name が重複しています: ${block.name}`);
        names.add(block.name);
        for (const key of ["selfClosing", "showBorder"]) {
            if (key in block && typeof block[key] !== "boolean") diagnostics.push(`${field}.${key} は true または false で指定してください。`);
        }
        for (const key of ["styles", "captionStyles", "defaults", "snippet"]) {
            if (key in block && !record(block[key])) diagnostics.push(`${field}.${key} はキーと値の対応で指定してください。`);
        }
        if ("captionPosition" in block && !["top", "bottom"].includes(block.captionPosition)) {
            diagnostics.push(`${field}.captionPosition は top または bottom で指定してください。`);
        }
        if ("counter" in block && (typeof block.counter !== "string" || !/^[a-z][\w-]*$/i.test(block.counter))) {
            diagnostics.push(`${field}.counter はカウンター名で指定してください。`);
        }
    }
}
