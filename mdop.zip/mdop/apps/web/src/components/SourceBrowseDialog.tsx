/**
 * @file AI支援の参照元にする端末上のファイルやフォルダを選ぶダイアログ。
 */

import { useEffect, useRef, useState } from 'react';
import { api, errorMessage } from '../api';
import type { SourceFolderContents } from '../api';
import './source-browser.css';

/** フォルダを移動し、参照元候補を選択画面へ返す。 */
export default function SourceBrowseDialog({ onChoose, onClose }: {
  onChoose: (path: string) => void;
  onClose: () => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const request = useRef<AbortController | null>(null);
  const [folder, setFolder] = useState<SourceFolderContents | null>(null);
  const [location, setLocation] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  /** パスを指定してフォルダの項目を読み込む。更新前の読み込みを中断し、現在の結果だけを反映する。 */
  async function open(path?: string) {
    request.current?.abort();
    const controller = new AbortController();
    request.current = controller;
    setLoading(true);
    setError('');
    try {
      const next = await api.browseSourceFolder(path, controller.signal);
      if (controller.signal.aborted) return;
      setFolder(next);
      setLocation(next.path);
    } catch (exception) {
      if (!controller.signal.aborted) setError(errorMessage(exception));
    } finally {
      if (!controller.signal.aborted) setLoading(false);
    }
  }

  useEffect(() => {
    dialog.current?.showModal();
    void open();
    return () => request.current?.abort();
  }, []);

  return <dialog className="source-browser" ref={dialog} aria-labelledby="source-browser-title"
    onCancel={event => { event.preventDefault(); onClose(); }}>
    <div className="source-browser-body stack">
      <div className="subsection-head">
        <h3 id="source-browser-title">参照元のファイル・フォルダを選ぶ</h3>
        <button type="button" onClick={onClose}>閉じる</button>
      </div>
      <form className="field-row" onSubmit={event => { event.preventDefault(); void open(location.trim()); }}>
        <input aria-label="開くフォルダのパス" value={location} disabled={loading} onChange={event => setLocation(event.target.value)} />
        <button type="submit" disabled={!location.trim() || loading}>開く</button>
      </form>
      <div className="form-actions">
        <button type="button" disabled={loading || !folder?.parent} onClick={() => void open(folder?.parent ?? undefined)}>親フォルダへ</button>
        <button type="button" disabled={loading} onClick={() => void open()}>アプリのルートへ</button>
        <button type="button" className="primary" disabled={loading || !folder} onClick={() => {
          if (folder) onChoose(folder.path);
        }}>このフォルダを選択</button>
      </div>
      {folder && <code className="source-browser-path">{folder.path}</code>}
      {loading && <p className="muted" role="status">フォルダを読み込んでいます…</p>}
      {error && <p className="error" role="alert">{error}</p>}
      {folder?.truncated && <p className="muted">一覧の一部を表示しています。必要なフォルダのパスを直接開けます。</p>}
      {folder && !loading && <ul className="source-browser-list" aria-label="フォルダの内容">
        {folder.entries.map(entry => <li key={entry.path}>
          <button type="button" aria-label={entry.kind === 'folder' ? `${entry.name} を開く` : `${entry.name} を選択`}
            onClick={() => entry.kind === 'folder' ? void open(entry.path) : onChoose(entry.path)}>
            <span className="source-browser-kind" aria-hidden="true">{entry.kind === 'folder' ? 'フォルダ' : 'ファイル'}</span>
            {entry.name}
          </button>
        </li>)}
      </ul>}
      {folder && !loading && !folder.entries.length && <p className="muted">このフォルダには選択できる項目がありません。</p>}
    </div>
  </dialog>;
}
