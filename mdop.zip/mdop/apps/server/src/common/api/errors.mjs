/**
 * @file HTTP応答へ変換できるアプリのエラー型と、主要な状態コードの生成処理。
 */

/** HTTP状態、機械判定用コード、画面用メッセージをひとつの例外に保持する。 */
export class ApiError extends Error {
    /** 応答に載せる追加情報を含め、アプリで扱うエラーの内容を設定する。 */
    constructor(status, code, message, details) {
        super(message);
        this.name = "ApiError";
        this.status = status;
        this.code = code;
        this.details = details;
    }
}

/** 入力や形式の検証失敗を表す400エラーを作る。 */
export function badRequest(message, details) {
    return new ApiError(400, "INVALID_REQUEST", message, details);
}

/** 要求された対象が存在しないことを表す404エラーを作る。 */
export function notFound(message) {
    return new ApiError(404, "NOT_FOUND", message);
}

/** データの更新競合や同時処理を表す409エラーを作る。 */
export function conflict(message, details) {
    return new ApiError(409, "CONFLICT", message, details);
}
