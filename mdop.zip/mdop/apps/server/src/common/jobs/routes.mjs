/**
 * @file 種別ごとの仕事を登録し、ジョブの進捗取得と中断を提供する。
 */

import { badRequest } from "../api/errors.mjs";
import { readJson, sendJson } from "../api/http.mjs";

/** 各種別が用意した登録処理を、共通のジョブAPIから呼び出す。 */
export function jobRoutes(jobs, handlers, uploads) {
    return [
        ["POST", "/jobs", async (request, response) => {
            const input = await readJson(request, uploads);
            const handler = handlers.get(input.type);
            if (!handler) throw badRequest(`type は ${[...handlers.keys()].join("、")} のいずれかを指定してください。`);
            return sendJson(response, 202, { job: await handler(input) });
        }],
        ["GET", "/jobs/:id", (_request, response, { id }) => sendJson(response, 200, { job: jobs.get(id) })],
        ["POST", "/jobs/:id/cancel", (_request, response, { id }) => sendJson(response, 200, { job: jobs.cancel(id) })],
    ];
}
