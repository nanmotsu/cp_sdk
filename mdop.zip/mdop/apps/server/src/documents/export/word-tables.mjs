/**
 * @file Word取り込み時のHTML表を、原本で編集できるMarkdown表へ変換する。
 */

/** セルの内容で使われるHTML文字参照を文字に戻す。 */
function decodeHtmlEntities(text) {
    return String(text)
        .replace(/&nbsp;/g, " ")
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'");
}

/** セルのテキストや改行などをMarkdown表の1セルに収まる表記へ変換する。 */
function normalizeCellHtml(cellHtml) {
    const withBreaks = String(cellHtml)
        .replace(/<\/p>\s*<p[^>]*>/gi, "<br>")
        .replace(/<\/div>\s*<div[^>]*>/gi, "<br>");

    const withoutContainers = withBreaks
        .replace(/<\/?p[^>]*>/gi, "")
        .replace(/<\/?div[^>]*>/gi, "");

    const keepBreaks = withoutContainers.replace(/<br\s*\/?>/gi, "__MD_TBL_BR__");
    const noTags = keepBreaks.replace(/<[^>]+>/g, "");

    return decodeHtmlEntities(noTags)
        .replace(/\|/g, "\\|")
        .replace(/\s*__MD_TBL_BR__\s*/g, "<br>")
        .replace(/[ \t]+/g, " ")
        .trim();
}

/** HTML表の行と列を読み、見出しとデータのMarkdown表を作る。 */
function htmlTableToMarkdown(tableHtml) {
    const rows = [];
    const trRegex = /<tr\b[^>]*>([\s\S]*?)<\/tr>/gi;
    let trMatch;

    while ((trMatch = trRegex.exec(tableHtml)) !== null) {
        const rowHtml = trMatch[1];
        const cells = [];
        const cellRegex = /<(td|th)\b[^>]*>([\s\S]*?)<\/\1>/gi;
        let cellMatch;

        while ((cellMatch = cellRegex.exec(rowHtml)) !== null) {
            cells.push(normalizeCellHtml(cellMatch[2]));
        }

        if (cells.length > 0) rows.push(cells);
    }

    if (rows.length === 0) return tableHtml;

    const colCount = Math.max(...rows.map(r => r.length));
    const paddedRows = rows.map(row => {
        const r = [...row];
        while (r.length < colCount) r.push("");
        return r;
    });

    const header = paddedRows[0];
    const bodyRows = paddedRows.slice(1);
    const headerLine = `| ${header.join(" | ")} |`;
    const separatorLine = `| ${Array(colCount).fill("---").join(" | ")} |`;
    const bodyLines = bodyRows.map(row => `| ${row.join(" | ")} |`);

    return [headerLine, separatorLine, ...bodyLines].join("\n");
}

/** 文書中のHTML表を、解析できた範囲でMarkdown表へ置き換える。 */
export function replaceHtmlTablesWithMarkdown(markdown) {
    return String(markdown).replace(/<table\b[\s\S]*?<\/table>/gi, tableHtml => {
        const converted = htmlTableToMarkdown(tableHtml);
        return `\n${converted}\n`;
    });
}
