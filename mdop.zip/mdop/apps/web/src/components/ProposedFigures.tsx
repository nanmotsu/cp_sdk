/**
 * @file 生成された本文案に含まれるSVG候補を確認し、採用前のレイアウトを調整する。
 */

import { useState } from 'react';
import type { GenerationResult } from '../api';
import FigureEditor from './FigureEditor';

/** 個別のSVG図版案を表示し、編集内容を親へ渡す。 */
type ProposedFigure = NonNullable<GenerationResult['figures']>[number];

/** 本文案に紐づく図版候補を表示し、編集後のSVGを候補のIDに対応付ける。 */
export default function ProposedFigures({ figures, values, disabled, onEdit }: {
  figures: ProposedFigure[];
  values: Record<string, string>;
  disabled: boolean;
  onEdit: (id: string, svg: string) => void;
}) {
  const [editing, setEditing] = useState<ProposedFigure | null>(null);
  return <section className="stack" aria-label="編集案の図版">
    <h4>編集案の図版</h4>
    <div className="candidate-grid">
      {figures.map((figure) => <figure className="candidate" key={figure.id}>
        <img alt={`提案図版: ${figure.name}`}
          src={`data:image/svg+xml;charset=utf-8,${encodeURIComponent(values[figure.id] ?? figure.svg)}`} />
        <figcaption>
          <span>{figure.name}</span>
          <button type="button" disabled={disabled} onClick={() => setEditing(figure)}>図版を編集</button>
        </figcaption>
      </figure>)}
    </div>
    {editing && <FigureEditor title={editing.name} value={{ kind: 'svg', svg: values[editing.id] ?? editing.svg }}
      applyLabel="編集案の図版に反映" onApply={(value) => {
        if (value.kind === 'svg') onEdit(editing.id, value.svg);
        setEditing(null);
      }} onClose={() => setEditing(null)} />}
  </section>;
}
