import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readFile, readdir, rename, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import test from 'node:test';
import { beginTraceability, createTraceability, createTraceabilityStore, resolveTraceabilityFolder } from '../apps/server/src/traceability/store.mjs';

async function fixture(t) {
  const root = await mkdtemp(join(tmpdir(), 'mdop-trace-name-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const input = { name: '仕様A', sourceUri: 'materials/source.md', targetUri: 'materials/target.md', granularity: '機能ごと' };
  const analyze = context => ({ ...context, candidate: { status: '関連あり', reason: '同じ機能' } });
  const created = await createTraceability(root, input, analyze);
  return { root, input, analyze, created, store: createTraceabilityStore(root) };
}

test('名前で保存し、改名後もUUID・資料・履歴・再送先を引き継ぐ', async t => {
  const { root, input, analyze, created, store } = await fixture(t);
  const parent = join(root, 'traceabilities');
  assert.deepEqual(await readdir(parent), ['仕様A']);
  const folder = await resolveTraceabilityFolder(root, created.id);
  await mkdir(join(folder, 'materials', '空'), { recursive: true });
  await writeFile(join(folder, 'materials', 'source.md'), '要件');
  await store.setSession(created.id, { relationId: created.id, sessionId: 'session-A' });
  const original = await store.get(created.id);
  const changed = await store.save(created.id, { revision: original.revision, name: '仕様B' });
  assert.equal(changed.id, created.id);
  assert.equal(changed.folderName, '仕様B');
  assert.equal(changed.config.name, '仕様B');
  assert.equal(changed.config.copilotSession.sessionId, 'session-A');
  assert.deepEqual(await readdir(parent), ['仕様B']);
  assert.equal(await readFile(join(parent, '仕様B', 'materials', 'source.md'), 'utf8'), '要件');
  const replay = await createTraceability(root, { ...input, requestId: created.id }, analyze);
  assert.equal(replay.id, created.id);
  assert.equal(replay.folderName, '仕様B');
  await assert.rejects(store.save(created.id, { revision: original.revision, name: '古い保存' }), /再読み込み/);
  const history = await store.history(created.id);
  const before = history.find(row => row.reason === 'before-save');
  assert.equal((await store.get(created.id, before.id)).config.name, '仕様A');
  const restored = await store.restore(created.id, before.id, { revision: changed.revision });
  assert.equal(restored.config.name, '仕様A');
  assert.equal(restored.folderName, '仕様A');
  assert.equal(await readFile(join(parent, '仕様A', 'materials', 'source.md'), 'utf8'), '要件');
  assert.ok((await store.history(created.id)).some(row => row.id === changed.savedVersion));
});

test('同名・同時作成と改名の衝突でも別件を上書きしない', async t => {
  const { root, input, analyze, created, store } = await fixture(t);
  const second = await createTraceability(root, input, analyze);
  assert.equal(second.folderName, '仕様A (2)');
  const [third, fourth] = await Promise.all([createTraceability(root, input, analyze), createTraceability(root, input, analyze)]);
  assert.notEqual(third.folderName, fourth.folderName);
  let current = await store.get(created.id);
  current = await store.save(created.id, { revision: current.revision, name: '別の仕様' });
  current = await store.save(created.id, { revision: current.revision, name: '仕様A' });
  assert.equal(current.folderName, '仕様A');
  assert.equal((await store.get(second.id)).folderName, '仕様A (2)');
  const all = await store.list();
  assert.equal(new Set(all.map(item => item.id)).size, 4);
  for (const name of ['', '../outside', 'a/b', 'a\\b', '.hidden', 'CON', '末尾.']) {
    await assert.rejects(store.save(created.id, { revision: current.revision, name }));
  }
  assert.equal((await store.get(created.id)).revision, current.revision);
});

test('改名中のAI結果を古いフォルダへ保存せず、UUID形式の既存フォルダも開ける', async t => {
  const { root, created, store } = await fixture(t);
  const pending = await beginTraceability(root, created.id, 'map');
  const initial = await store.get(created.id);
  const changed = await store.save(created.id, { revision: initial.revision, name: '変更後' });
  await assert.rejects(pending.save({ ...pending.context, candidate: [] }), /開始後/);
  assert.deepEqual((await store.get(created.id)).mappings.rows, []);
  const folder = await resolveTraceabilityFolder(root, created.id);
  const legacy = join(root, 'traceabilities', created.id);
  assert.equal(dirname(folder), dirname(legacy));
  await rename(folder, legacy);
  assert.equal((await store.get(created.id)).folderName, '変更後');
  assert.deepEqual(await readdir(join(root, 'traceabilities')), ['変更後']);
  assert.equal((await store.get(created.id)).config.id, changed.config.id);
});

test('設定JSONの置換が中断していてもUUIDを退避版から見つけて復旧する', async t => {
  const { root, created, store } = await fixture(t);
  const folder = await resolveTraceabilityFolder(root, created.id);
  const transaction = join(folder, 'backups', '.transaction');
  await mkdir(join(transaction, 'previous'), { recursive: true });
  await mkdir(join(transaction, 'next'));
  await writeFile(join(transaction, 'phase'), 'move-old');
  await rename(join(folder, 'traceability.json'), join(transaction, 'previous', 'traceability.json'));
  assert.equal((await store.get(created.id)).config.id, created.id);
  assert.equal((await store.list())[0].name, '仕様A');
});
