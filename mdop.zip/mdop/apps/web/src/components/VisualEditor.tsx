/**
 * @file Markdownを画面で直接編集するためのブロックエディター。変更していないMarkdownを保ち、図やDSLは専用の欄で編集する。
 */

import { useCallback, useEffect, useImperativeHandle, useMemo, useRef, useState } from 'react';
import type { ClipboardEvent, CSSProperties, DragEvent, FormEvent, KeyboardEvent, MouseEvent, Ref } from 'react';
import { isFigureImagePath } from '../../../../packages/markdown/figure-paths.mjs';
import { api, assetUrl, errorMessage } from '../api';
import type { VisualDiagram, VisualElements, VisualElementsInput } from '../api';
import { blockMarkdown, changeHeadingLevel, editBlockSource, editorHtml, headingAsParagraph, insertMarkdownBlock, markdownBlocks } from '../editor/blocks';
import type { MarkdownBlock } from '../editor/blocks';
import { dslTableBody, encodeFigureCaption, readDslBlock, resizeDslColumns, setDslAttributes, setFigureCaption, setMermaidSize } from '../editor/directives';
import { editTableCell, editTableStructure, readTable, tableCellMarkdown } from '../editor/tables';
import type { TableAction, TableCell } from '../editor/tables';
import { describeVisualBlocks } from '../editor/visualBlocks';
import { VisualHistory } from '../editor/visualHistory';
import type { EditorPosition } from '../editor/visualHistory';
import { Warnings } from './Feedback';
import { BlockSource, VisualBlockMenu } from './VisualBlockOptions';
import type { BlockMenuAction } from './VisualBlockOptions';
import VisualTable from './VisualTable';
import './VisualEditor.css';

/** 現在の原本、表示用の設定・資産の版と、編集結果を親へ伝える操作。 */
interface Props {
  ref?: Ref<VisualEditorHandle>;
  documentId: string;
  path: string;
  content: string;
  assetVersion: number;
  configVersion: number;
  disabled: boolean;
  onChange: (content: string) => void;
  onChooseFigure: () => void;
}

/** 文書一覧や図版パネルからビジュアル編集欄を操作する。 */
export interface VisualEditorHandle {
  revealHeading(offset: number): void;
  insertFigure(markdown: string): boolean;
  clearFigureTarget(): void;
  replaceHeadingNumbers(markdown: string): void;
}

/** Markdown内のローカル画像リンクを、現在の文書に対応する配信URLへ変換する。 */
function resolveImage(documentId: string, path: string, src: string, assetVersion: number) {
  if (/^(?:[a-z][\w+.-]*:|[/\\])/i.test(src)) return undefined;
  const base = `https://document.local/${path.split('/').map(encodeURIComponent).join('/')}`;
  try {
    const target = new URL(src, base);
    if (target.origin !== 'https://document.local') return undefined;
    const relative = decodeURIComponent(target.pathname.slice(1));
    if (!isFigureImagePath(relative)) return undefined;
    return assetUrl(documentId, relative, String(assetVersion));
  } catch {
    return undefined;
  }
}

const formatting = [
  { command: 'bold', label: '太字', text: 'B', requiresSelection: true },
  { command: 'italic', label: '斜体', text: 'I', requiresSelection: true },
  { command: 'strikeThrough', label: '取り消し線', text: 'S', requiresSelection: true },
  { command: 'insertUnorderedList', label: '箇条書き', text: '•', requiresSelection: false },
  { command: 'insertOrderedList', label: '番号付きリスト', text: '1.', requiresSelection: false },
];
const inlineFormatInputTypes = new Set(['formatBold', 'formatItalic', 'formatStrikeThrough']);

/** 両端が同じ編集欄に収まるブラウザーの選択範囲を取得する。 */
function editableRange(element: HTMLElement) {
  const selection = window.getSelection();
  if (!element.isContentEditable || !selection?.rangeCount) return undefined;
  const range = selection.getRangeAt(0);
  return element.contains(range.startContainer) && element.contains(range.endContainer) ? range : undefined;
}

/** カーソルや画像だけの範囲を文字装飾の対象から外す。 */
function hasSelectedText(range?: Range) {
  return Boolean(range && !range.collapsed && range.toString().length);
}

const exampleMermaid = ['```mermaid', 'flowchart LR', '    start["開始"] --> finish["終了"]', '```'];
/** 挿入後にフォーカスする位置を決める、追加ブロックの種類。 */
type InsertedBlock = 'text' | 'table' | 'mermaid' | 'source';

/** 本文の変更と、その直前に選択されていた編集位置。 */
interface EditorChange { position?: EditorPosition; target?: HTMLElement; inputType?: string }

/** メニューを開いたブロックと、画面上の表示位置。 */
interface BlockMenuPosition { index: number; x: number; y: number; cell?: TableCell }

/** 本文に使われている改行を優先し、新しいブロックに使う。 */
function preferredEnding(value: string) {
  return /\r\n|\n|\r/.exec(value)?.[0] ?? '\n';
}

/** 図題のHTMLや文字参照を、入力欄へ表示できるテキストに戻す。 */
function captionInputValue(caption: string) {
  const template = document.createElement('template');
  template.innerHTML = editorHtml(caption);
  return template.content.textContent ?? '';
}

/** 表紙のタイトル候補と、編集欄に表示するMermaidの入力を抽出する。 */
function visualElementsInput(blocks: MarkdownBlock[]): VisualElementsInput {
  const heading = blocks.find((block) => block.html?.startsWith('<h1'));
  const template = document.createElement('template');
  template.innerHTML = heading?.html ?? '';
  return {
    fallbackTitle: template.content.textContent?.trim() ?? '',
    diagrams: [...new Set(blocks.flatMap((block) => block.mermaid ?? []))],
  };
}

/** サーバーが返したMermaid図、描画待ち、または描画エラーを表示する。 */
function DiagramBlock({ diagram, height, align }: { diagram?: VisualDiagram; height?: string; align?: 'left' | 'right' | 'center' }) {
  if (!diagram) return <p className="muted" role="status">Mermaid図を描画しています…</p>;
  if ('error' in diagram) return <p className="error visual-mermaid-error" role="status">Mermaid図を表示できません。{diagram.error}</p>;
  return <img className="visual-mermaid-image" alt="Mermaid図"
    src={`data:image/svg+xml,${encodeURIComponent(diagram.svg)}`}
    style={{ width: diagram.width ?? undefined, maxHeight: diagram.maxHeight ?? height,
      marginLeft: align === 'left' ? 0 : undefined, marginRight: align === 'right' ? 0 : undefined }} />;
}

/** 編集できるHTMLブロックと保護対象の原本を表示し、変更をMarkdownへ戻す。 */
export default function VisualEditor({ ref, documentId, path, content, assetVersion, configVersion, disabled, onChange, onChooseFigure }: Props) {
  const [blocks, setBlocks] = useState(() => markdownBlocks(content));
  const [epoch, setEpoch] = useState(0);
  const [contentViewVersion, setContentViewVersion] = useState(0);
  const [visual, setVisual] = useState<(Omit<VisualElements, 'diagrams'> & { diagrams: Map<string, VisualDiagram> }) | null>(null);
  const [visualError, setVisualError] = useState('');
  const [selectedBlock, setSelectedBlock] = useState<number | null>(null);
  const [selectedCell, setSelectedCell] = useState<TableCell>();
  const [textSelected, setTextSelected] = useState(false);
  const [pendingSource, setPendingSource] = useState<ReadonlySet<number>>(() => new Set());
  const [history] = useState(() => new VisualHistory());
  const [blockMenu, setBlockMenu] = useState<BlockMenuPosition | null>(null);
  const workspace = useRef<HTMLDivElement>(null);
  const pane = useRef<HTMLDivElement>(null);
  const draft = useRef(blocks.map((block) => block.raw));
  const emitted = useRef(content);
  const focused = useRef<{ index: number; element: HTMLElement; cell?: TableCell; dslText?: boolean } | null>(null);
  const figureTarget = useRef<{ index: number; blocks: MarkdownBlock[] } | null>(null);
  const localImage = useCallback((src: string) => resolveImage(documentId, path, src, assetVersion), [documentId, path, assetVersion]);
  const renderedBlocks = useMemo(() => blocks.map((block) => ({
    __html: block.html ? editorHtml(block.html, localImage) : '',
  })), [blocks, localImage]);
  const presentations = useMemo(() => describeVisualBlocks(blocks, visual?.layout, localImage), [blocks, visual?.layout, localImage]);
  const tableDirective = visual?.layout ? visual.layout.blocks.find(block => block.kind === 'table' && block.name === 'table')
    ?? visual.layout.blocks.find(block => block.kind === 'table') : { name: 'table' };
  const menuFigure = blockMenu && !pendingSource.has(blockMenu.index) ? presentations[blockMenu.index] : undefined;
  const menuSize = menuFigure?.sizeOptions;
  const menuCaption = menuFigure?.figure?.body.trim() ? captionInputValue(menuFigure.figure.caption) : undefined;
  const renderInput = useMemo(() => JSON.stringify(visualElementsInput(blocks)), [blocks]);
  useImperativeHandle(ref, () => ({
    /** 原本の文字オフセットから編集ブロックを特定してフォーカスと表示位置を移す。 */
    revealHeading(offset) {
      let end = 0;
      const index = draft.current.findIndex(raw => {
        end += raw.length;
        return offset < end;
      });
      const block = pane.current?.querySelector<HTMLDivElement>(`[data-visual-block="${index}"]`);
      if (!block) return;
      block.scrollIntoView({ block: 'start', inline: 'nearest' });
      if (!block.isContentEditable) {
        block.querySelector('summary')?.focus({ preventScroll: true });
        return;
      }
      block.focus({ preventScroll: true });
      const range = document.createRange();
      range.selectNodeContents(block.querySelector('h1, h2, h3, h4, h5, h6') ?? block);
      range.collapse(true);
      window.getSelection()?.removeAllRanges();
      window.getSelection()?.addRange(range);
    },
    /** 右クリックから選んだ場合は元のブロックを使い、ブロックの再構成後は位置を選び直す。 */
    insertFigure(markdown) {
      const target = figureTarget.current;
      if (disabled || (target && target.blocks !== blocks)) return false;
      figureTarget.current = null;
      insertBlock(markdown, 'text', target?.index ?? selectedBlock);
      return true;
    },
    /** 図版パネルを離れたときは、右クリックで指定した挿入位置を解除する。 */
    clearFigureTarget() {
      figureTarget.current = null;
    },
    /** 文書全体の採番を取り消し履歴の一操作として反映する。 */
    replaceHeadingNumbers(markdown) {
      if (disabled) return;
      const previous = draft.current;
      const next = replaceBlocks(markdown, { position: selectedBlock === null ? undefined : { block: selectedBlock } });
      const firstChange = next.findIndex(({ raw }, index) => raw !== previous[index]);
      focusBlock(selectedBlock ?? firstChange, 'text');
    },
  }));

  useEffect(() => {
    const editor = workspace.current!;
    /** 選択が動くたびに文字装飾ボタンの使用可否を更新する。 */
    function trackSelection() {
      const element = focused.current?.element;
      setTextSelected(Boolean(element && hasSelectedText(editableRange(element))));
    }
    /** ブラウザーの書式ショートカットも文字を選択したときだけ適用する。 */
    function guardInlineFormat(event: InputEvent) {
      if (!inlineFormatInputTypes.has(event.inputType) || !(event.target instanceof HTMLElement)) return;
      if (!hasSelectedText(editableRange(event.target))) event.preventDefault();
    }
    document.addEventListener('selectionchange', trackSelection);
    editor.addEventListener('beforeinput', guardInlineFormat);
    return () => {
      document.removeEventListener('selectionchange', trackSelection);
      editor.removeEventListener('beforeinput', guardInlineFormat);
    };
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    const input: VisualElementsInput = JSON.parse(renderInput);
    setVisualError('');
    void api.visualElements(documentId, path, input, controller.signal).then((result) => {
      if (controller.signal.aborted) return;
      const diagrams = new Map(input.diagrams.map((source, index) => [source, result.diagrams[index]]));
      setVisual(previous => ({ ...result, diagrams, layout: previous && JSON.stringify(previous.layout) === JSON.stringify(result.layout)
        ? previous.layout : result.layout }));
    }).catch((error: unknown) => {
      if (!controller.signal.aborted) setVisualError(errorMessage(error));
    });
    return () => controller.abort();
  }, [documentId, path, renderInput, configVersion]);

  useEffect(() => {
    if (emitted.current === content) return;
    const next = markdownBlocks(content);
    emitted.current = content;
    draft.current = next.map((block) => block.raw);
    focused.current = null;
    setSelectedBlock(null);
    setSelectedCell(undefined);
    setTextSelected(false);
    setBlockMenu(null);
    setPendingSource(new Set());
    history.clear();
    setBlocks(next);
    setEpoch((value) => value + 1);
  }, [content, history]);

  /** 現在のブロック群を連結し、本文が変化した場合だけ親へ通知する。 */
  function publish(change?: EditorChange) {
    const next = draft.current.join('');
    if (next === emitted.current) return;
    if (change) history.remember({ markdown: emitted.current, position: change.position }, change.target, change.inputType);
    emitted.current = next;
    onChange(next);
  }

  /** 編集した要素をMarkdownへ戻す。新規段落の初回入力には、段落を分ける改行を補う。 */
  function update(index: number, element: HTMLElement, inputType?: string) {
    const lineEnding = preferredEnding(emitted.current);
    const newParagraph = blocks[index].raw === '';
    const markdown = blockMarkdown(element.innerHTML, newParagraph ? '' : draft.current[index], lineEnding);
    if (newParagraph && markdown.trim()) {
      const parts = draft.current.slice();
      parts.splice(index, 1);
      const before = parts.slice(0, index).join('');
      const after = parts.slice(index).join('');
      const inserted = insertMarkdownBlock(parts, index, markdown, lineEnding);
      const suffixLength = after.length || lineEnding.length;
      draft.current[index] = inserted.markdown.slice(before.length, inserted.markdown.length - suffixLength);
    } else {
      draft.current[index] = markdown;
    }
    publish({ position: { block: index }, target: inputType ? element : undefined, inputType });
  }

  /** 保護対象のソースを更新し、変更していない部分の元の改行を保持する。 */
  function updateSource(index: number, element: HTMLTextAreaElement, inputType: string) {
    const previous = draft.current[index];
    const lineEnding = /\r\n|\n|\r/.exec(previous)?.[0] ?? /\r\n|\n|\r/.exec(emitted.current)?.[0] ?? '\n';
    draft.current[index] = editBlockSource(previous, element.value, lineEnding);
    if (draft.current[index] === previous) return;
    setPendingSource(current => new Set(current).add(index));
    publish({ position: { block: index, source: true }, target: element, inputType });
  }

  /** 現在の編集済み本文を再解析し、Mermaidなどの表示の更新へつなげる。 */
  function refreshBlocks() {
    replaceBlocks(emitted.current);
    setContentViewVersion(version => version + 1);
  }

  /** 与えられた本文から編集ブロックを組み直し、選択状態と出力を更新する。 */
  function replaceBlocks(markdown: string, change?: EditorChange, emptyOffset?: number) {
    const next = markdownBlocks(markdown);
    if (emptyOffset !== undefined && next.every(block => block.raw)) {
      let position = 0;
      let end = 0;
      while (position < next.length && end < emptyOffset) {
        end += next[position].raw.length;
        position += 1;
      }
      next.splice(position, 0, { kind: 'editable', raw: '', html: '<p><br></p>' });
    }
    draft.current = next.map(block => block.raw);
    focused.current = null;
    setSelectedBlock(null);
    setSelectedCell(undefined);
    setTextSelected(false);
    setBlockMenu(null);
    setPendingSource(new Set());
    setBlocks(next);
    publish(change);
    return next;
  }

  /** 挿入位置や見出し操作に使うブロックと、編集要素を記録する。 */
  function selectBlock(index: number, element?: HTMLElement, cell?: TableCell, dslText = false) {
    focused.current = element ? { index, element, cell, dslText } : null;
    setSelectedBlock(index);
    setSelectedCell(cell);
    setTextSelected(Boolean(element && hasSelectedText(editableRange(element))));
  }

  /** 挿入したブロックの編集欄へ移動する。表は最初の見出しセル、Mermaidはソースを選ぶ。 */
  function focusBlock(index: number, kind: InsertedBlock, tableCell?: TableCell) {
    if (index < 0) return;
    requestAnimationFrame(() => {
      const block = pane.current?.querySelector<HTMLDivElement>(`[data-visual-block="${index}"]`);
      if (!block) return;
      if (kind === 'mermaid' || kind === 'source') {
        const details = block.querySelector<HTMLDetailsElement>('.visual-block-source');
        if (details) details.open = true;
        const source = details?.querySelector('textarea');
        if (source) { source.focus({ preventScroll: kind === 'source' }); return; }
      }
      const cell = kind === 'table' ? block.querySelector<HTMLElement>(
        `[data-table-row="${tableCell?.row ?? 0}"][data-table-column="${tableCell?.column ?? 0}"]`)
        ?? block.querySelector<HTMLElement>('[data-table-row="0"][data-table-column="0"]') : null;
      const element = cell ?? (block.isContentEditable ? block : block.querySelector<HTMLElement>('.visual-dsl-content[contenteditable="true"]'));
      if (!element) {
        block.focus({ preventScroll: true });
        selectBlock(index);
        return;
      }
      element.focus({ preventScroll: Boolean(tableCell) });
      selectBlock(index, element, cell ? { row: Number(cell.dataset.tableRow), column: Number(cell.dataset.tableColumn) } : undefined,
        element.classList.contains('visual-dsl-content'));
      const range = document.createRange();
      range.selectNodeContents(element);
      if (!cell || tableCell) range.collapse(false);
      window.getSelection()?.removeAllRanges();
      window.getSelection()?.addRange(range);
    });
  }

  /** 取り消した本文を再解析し、編集していたブロック・セルに戻る。 */
  function stepHistory(direction: 'undo' | 'redo') {
    if (disabled) return;
    const position = selectedBlock === null ? undefined : {
      block: selectedBlock, cell: selectedCell, source: document.activeElement instanceof HTMLTextAreaElement,
    };
    const next = history.step(direction, { markdown: emitted.current, position });
    if (!next) return;
    replaceBlocks(next.markdown);
    // contentEditableの直接入力はReactのHTML差分に現れないため、復元時は編集面を作り直す。
    setContentViewVersion(version => version + 1);
    const location = next.position ?? position;
    if (location) focusBlock(location.block, location.cell ? 'table' : location.source ? 'source' : 'text', location.cell);
  }

  /** サイズなどの未確定フォーム入力にはブラウザー標準の取り消しを残す。 */
  function historyShortcut(event: KeyboardEvent<HTMLDivElement>) {
    if (event.nativeEvent.isComposing || !(event.ctrlKey || event.metaKey) || event.altKey || disabled) return;
    if ((event.target as HTMLElement).closest('input, select')) return;
    const key = event.key.toLowerCase();
    const direction = key === 'z' ? (event.shiftKey ? 'redo' : 'undo') : key === 'y' ? 'redo' : undefined;
    if (!direction || !history[direction].length) return;
    event.preventDefault();
    stepHistory(direction);
  }

  /** 表の古い表示位置ではなく、原本の現在値から編集対象の範囲を取り直す。 */
  function currentTable(index: number) {
    const source = draft.current[index];
    const dsl = presentations[index].dsl ? readDslBlock(source) : undefined;
    return dsl ? readTable(source, dslTableBody(source, dsl).start, dsl.bodyEnd) : readTable(source);
  }

  /** セルで編集した内容をそのセルのMarkdownへ反映する。 */
  function updateCell(index: number, cell: TableCell, element: HTMLElement, inputType?: string) {
    const table = currentTable(index);
    if (!table || pendingSource.has(index)) return;
    draft.current[index] = editTableCell(draft.current[index], table, cell, tableCellMarkdown(element.innerHTML));
    publish({ position: { block: index, cell }, target: inputType ? element : undefined, inputType });
  }

  /** 表の構造と列幅の変更を、まとめて一回で取り消せるよう反映する。 */
  function changeTable(index: number, action: TableAction) {
    const table = currentTable(index);
    if (!table || pendingSource.has(index) || disabled) return;
    const source = draft.current[index];
    let next = editTableStructure(source, table, action);
    if (source === next) return;
    if (presentations[index].dsl) next = resizeDslColumns(next, action, table.align.length);
    const { row, column } = action.cell;
    const cell = {
      row: action.axis !== 'row' ? row : action.kind === 'add' ? row + 1 : Math.min(row, table.rows.length - 1),
      column: action.axis !== 'column' ? column : action.kind === 'add' ? column + 1 : Math.min(column, table.align.length - 2),
    };
    draft.current[index] = next;
    replaceBlocks(draft.current.join(''), { position: { block: index, cell: action.cell } });
    setSelectedBlock(index);
    setSelectedCell(cell);
    focusBlock(index, 'table', cell);
  }

  /** 図のサイズは既存のDSL属性またはMermaidのディレクティブとして保存する。 */
  function changeSize(index: number, changes: Record<string, string>) {
    if (pendingSource.has(index) || disabled || !Object.keys(changes).length) return false;
    const source = draft.current[index];
    const block = readDslBlock(source);
    return updateFigureSource(index, block ? setDslAttributes(source, block, changes) : setMermaidSize(source, changes));
  }

  /** 図題だけを変更し、空欄なら既存の図題を取り除く。 */
  function changeCaption(index: number, value: string) {
    if (pendingSource.has(index) || disabled) return false;
    const source = draft.current[index];
    const block = readDslBlock(source);
    return Boolean(block && updateFigureSource(index, setFigureCaption(source, block, encodeFigureCaption(value))));
  }

  /** 図版への変更を一度の取り消しで戻せるように記録する。 */
  function updateFigureSource(index: number, next: string) {
    if (next === draft.current[index]) return false;
    draft.current[index] = next;
    replaceBlocks(draft.current.join(''), { position: { block: index } });
    setSelectedBlock(index);
    focusBlock(index, 'text');
    return true;
  }

  /** 注意欄などの編集結果を適用し、開始行の属性と閉じ行を保つ。 */
  function updateDslText(index: number, element: HTMLElement, inputType?: string) {
    const source = draft.current[index];
    const block = readDslBlock(source);
    if (!block || pendingSource.has(index)) return;
    const ending = preferredEnding(source);
    const body = blockMarkdown(element.innerHTML, source.slice(block.bodyStart, block.bodyEnd) || ending, ending);
    draft.current[index] = source.slice(0, block.bodyStart) + body + source.slice(block.bodyEnd);
    publish({ position: { block: index }, target: inputType ? element : undefined, inputType });
  }

  /** 選択ブロックの見出しレベルを更新する。0の場合は前後の段落と区切って本文へ戻す。 */
  function heading(index: number, depth: number) {
    if (disabled || depth < 0 || depth > 6) return;
    const parts = [...draft.current];
    if (depth) {
      parts[index] = changeHeadingLevel(parts[index], depth);
      replaceBlocks(parts.join(''), { position: { block: index } });
      focusBlock(index, 'text');
      return;
    }
    const lineEnding = preferredEnding(emitted.current);
    const paragraph = headingAsParagraph(parts[index], lineEnding);
    if (!paragraph) return;
    parts[index] = paragraph.trailing;
    const insertion = insertMarkdownBlock(parts, index, paragraph.markdown, lineEnding);
    applyInsertion(insertion, 'text', index, !paragraph.markdown);
  }

  /** 指定したブロックの直後、または未指定なら末尾に新しいブロックを挿入する。 */
  function insertBlock(text: string, kind: InsertedBlock, anchor: number | null) {
    const ending = preferredEnding(emitted.current);
    const index = anchor === null ? draft.current.length : anchor + 1;
    const insertion = insertMarkdownBlock(draft.current, index, text, ending);
    applyInsertion(insertion, kind, anchor);
  }

  /** 変更を履歴に登録し、挿入したテキスト・セル・ソース欄にフォーカスする。 */
  function applyInsertion(insertion: ReturnType<typeof insertMarkdownBlock>, kind: InsertedBlock, anchor: number | null, empty = false) {
    const position = anchor === null ? undefined : { block: anchor };
    const next = replaceBlocks(insertion.markdown, { position }, empty ? insertion.start : undefined);
    let offset = insertion.start;
    const inserted = empty ? next.findIndex(block => !block.raw) : next.findIndex(block => {
      offset -= block.raw.length;
      return offset < 0;
    });
    focusBlock(inserted, kind);
  }

  /** 指定の列数とデータ行数でDSL表を作り、右クリックした位置に追加する。 */
  function insertTable(event: FormEvent<HTMLFormElement>, anchor: number) {
    event.preventDefault();
    if (!tableDirective || disabled) return;
    const data = new FormData(event.currentTarget);
    const columns = Number(data.get('columns'));
    const rows = Number(data.get('rows'));
    if (!Number.isInteger(columns) || !Number.isInteger(rows) || columns < 1 || columns > 20 || rows < 0 || rows > 30) return;
    const row = (cell: (index: number) => string) => `| ${Array.from({ length: columns }, (_, index) => cell(index)).join(' | ')} |`;
    const caption = String(data.get('caption') ?? '').trim();
    const text = caption.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
      .replace(/^[\x60~:|]/, character => `&#${character.charCodeAt(0)};`);
    const markdown = [
      `:::${tableDirective.name}`, ...(text ? [text, ''] : []),
      row(index => `見出し${index + 1}`), row(() => '---'), ...Array.from({ length: rows }, () => row(() => '')), ':::',
    ];
    insertBlock(markdown.join(preferredEnding(emitted.current)), 'table', anchor);
  }

  /** 貼り付け時はプレーンテキストを使い、外部のHTML書式を持ち込まないようにする。 */
  function paste(event: ClipboardEvent<HTMLElement>) {
    event.preventDefault();
    document.execCommand('insertText', false, event.clipboardData.getData('text/plain'));
  }

  /** 選択中の編集ブロックに太字やリストなどの書式を適用し、Markdownへ反映する。 */
  function format(command: string, requiresSelection: boolean) {
    const block = focused.current;
    const range = block && editableRange(block.element);
    if (disabled || !block || !range || (requiresSelection && !hasSelectedText(range)) || (block.cell && !requiresSelection)) return;
    if (document.activeElement !== block.element) {
      const retained = range.cloneRange();
      block.element.focus({ preventScroll: true });
      const selection = window.getSelection();
      selection?.removeAllRanges();
      selection?.addRange(retained);
    }
    const previous = block.element.innerHTML;
    document.execCommand(command);
    if (block.element.innerHTML !== previous) {
      if (block.cell) updateCell(block.index, block.cell, block.element);
      else if (block.dslText) updateDslText(block.index, block.element);
      else update(block.index, block.element);
    }
  }

  /** 選択位置の直後に段落入力欄を用意する。使える空欄があれば再利用する。 */
  function addParagraph(anchor: number) {
    if (emptyParagraph(anchor)) {
      setBlockMenu(null);
      focusBlock(anchor, 'text');
      return;
    }
    let following = anchor + 1;
    while (blocks[following]?.kind === 'space') following += 1;
    if (emptyParagraph(following)) {
      setBlockMenu(null);
      focusBlock(following, 'text');
      return;
    }
    const offset = draft.current.slice(0, anchor + 1).join('').length;
    const next = replaceBlocks(emitted.current, undefined, offset);
    setEpoch((value) => value + 1);
    focusBlock(next.findIndex(block => !block.raw), 'text');
  }

  /** 対象のブロックが空の段落として扱えるかを判定する。 */
  function emptyParagraph(index: number) {
    return Boolean(blocks[index]?.html?.startsWith('<p>') && !draft.current[index]?.trim());
  }

  /** 編集欄で削除操作を出せる空段落かを確認する。 */
  function canRemoveParagraph(index: number) {
    return emptyParagraph(index) && blocks.some((block, position) => position !== index && block.kind !== 'space');
  }

  /** 本文から一つのブロックを取り除き、隣り合うブロックの区切りと取り消し位置を保つ。 */
  function removeBlock(index: number, cell?: TableCell) {
    const before = draft.current.slice(0, index).join('');
    const after = draft.current.slice(index + 1).join('');
    const gap = (before.match(/[ \t\r\n]*$/)?.[0] ?? '') + (after.match(/^[ \t\r\n]*/)?.[0] ?? '');
    const breaks = gap.match(/\r\n|\r|\n/g)?.length ?? 0;
    const separator = !emptyParagraph(index) && before.trim() && after.trim()
      ? preferredEnding(emitted.current).repeat(Math.max(0, 2 - breaks)) : '';
    const boundary = before.length + separator.length;
    const next = replaceBlocks(before + separator + after, { position: { block: index, cell } });
    setEpoch(value => value + 1);
    let offset = 0;
    let nearest = 0;
    next.some((block, index) => {
      offset += block.raw.length;
      if (block.kind === 'space') return false;
      nearest = index;
      return offset > boundary;
    });
    focusBlock(nearest, 'text');
  }

  /** 空段落でのBackspaceまたはDeleteを、段落単位の削除として扱う。 */
  function deleteWhenEmpty(index: number, event: KeyboardEvent<HTMLDivElement>) {
    if (disabled || event.nativeEvent.isComposing || event.ctrlKey || event.metaKey || event.altKey
      || !['Backspace', 'Delete'].includes(event.key) || !canRemoveParagraph(index)) return;
    event.preventDefault();
    removeBlock(index);
  }

  /** 入力フォームの標準メニューを保ち、本文・図表では対象ブロックを特定する。 */
  function menuAnchor(target: EventTarget) {
    if (disabled || !(target instanceof Element) || target.closest('input, textarea, select, button, summary')) return undefined;
    const block = target.closest<HTMLElement>('[data-visual-block]');
    return block && pane.current?.contains(block) ? block : undefined;
  }

  /** 右クリックしたブロックとセルを、メニューを閉じるまで固定する。 */
  function openBlockMenu(block: HTMLElement, target: EventTarget, x: number, y: number) {
    const index = Number(block.dataset.visualBlock);
    const element = target instanceof Element ? target.closest<HTMLElement>('[data-table-row][data-table-column]') : null;
    const cell = element ? { row: Number(element.dataset.tableRow), column: Number(element.dataset.tableColumn) }
      : selectedBlock === index ? selectedCell : undefined;
    selectBlock(index, undefined, cell);
    setBlockMenu({ index, x, y, cell });
  }

  /** 本文を右クリックした場所に操作メニューを開く。 */
  function contextMenu(event: MouseEvent<HTMLDivElement>) {
    const block = menuAnchor(event.target);
    if (!block) return;
    event.preventDefault();
    openBlockMenu(block, event.target, event.clientX, event.clientY);
  }

  /** Shift+F10またはコンテキストメニューキーでも、同じ操作メニューを開く。 */
  function contextShortcut(event: KeyboardEvent<HTMLDivElement>) {
    if (event.key !== 'ContextMenu' && !(event.shiftKey && event.key === 'F10')) return;
    const block = menuAnchor(event.target);
    if (!block) return;
    event.preventDefault();
    const rect = (event.target instanceof Element ? event.target : block).getBoundingClientRect();
    openBlockMenu(block, event.target, rect.left + 12, rect.top + 12);
  }

  /** 対象ブロックで実行できる操作を、共通の追加・削除より先に表示する。 */
  function blockActions({ index, cell }: BlockMenuPosition): BlockMenuAction[] {
    const view = presentations[index];
    if (pendingSource.has(index)) return [];
    if (view.table && cell) {
      const commands: { label: string; kind: TableAction['kind']; axis: TableAction['axis']; available: boolean }[] = [
        { label: 'この行の下に行を追加', kind: 'add', axis: 'row', available: true },
        { label: 'この行を削除', kind: 'delete', axis: 'row', available: cell.row > 0 },
        { label: 'この列の右に列を追加', kind: 'add', axis: 'column', available: true },
        { label: 'この列を削除', kind: 'delete', axis: 'column', available: view.table.align.length > 1 },
      ];
      return commands.filter(command => command.available)
        .map(({ label, kind, axis }) => ({ label, run: () => changeTable(index, { kind, axis, cell }) }));
    }
    const { html, heading: token } = blocks[index];
    if (html?.startsWith('<p>')) return [{ label: '見出しにする', run: () => heading(index, 2) }];
    if (!html || !token) return [];
    const level = token.depth;
    return [
      ...(level > 1 ? [{ label: '見出しを昇格', run: () => heading(index, level - 1) }] : []),
      ...(level < 6 ? [{ label: '見出しを降格', run: () => heading(index, level + 1) }] : []),
      { label: '本文に戻す', run: () => heading(index, 0) },
    ];
  }

  /** メニューが閉じた後、必要に応じて右クリックした編集欄へ戻す。 */
  function closeBlockMenu({ index, cell }: BlockMenuPosition, restoreFocus: boolean) {
    setBlockMenu(null);
    if (restoreFocus) focusBlock(index, cell ? 'table' : 'text', cell);
  }

  /** 本文からブロックを消す直前に、利用者に確認する。 */
  function confirmBlockDeletion(menu: BlockMenuPosition) {
    if (window.confirm('このブロックを本文から削除しますか？')) removeBlock(menu.index, menu.cell);
    else closeBlockMenu(menu, true);
  }

  /** 外部のドラッグ内容によって編集中のDOMが直接変更されるのを止める。 */
  function preventDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
  }

  return (
    <div className="visual-workspace" ref={workspace} onKeyDown={historyShortcut}>
      <div className="visual-toolbar" aria-label="文字の書式">
        <button type="button" title="元に戻す（Ctrl+Z）" aria-label="ビジュアル編集を元に戻す"
          disabled={disabled || !history.undo.length} onClick={() => stepHistory('undo')}>↶</button>
        <button type="button" title="やり直す（Ctrl+Shift+Z）" aria-label="ビジュアル編集をやり直す"
          disabled={disabled || !history.redo.length} onClick={() => stepHistory('redo')}>↷</button>
        {formatting.map((item) => (
          <button key={item.command} type="button" className={`visual-format-${item.command}`} title={item.label} aria-label={item.label}
            disabled={disabled || (item.requiresSelection ? !textSelected : Boolean(selectedCell))}
            onMouseDown={(event) => event.preventDefault()} onClick={() => format(item.command, item.requiresSelection)}>
            {item.text}
          </button>
        ))}
      </div>
      {!disabled && blockMenu && <VisualBlockMenu key={`${blockMenu.index}:${blockMenu.x}:${blockMenu.y}`} x={blockMenu.x} y={blockMenu.y}
        actions={blockActions(blockMenu)}
        sizeOptions={menuSize && {
          ...menuSize,
          mermaid: Boolean(blocks[blockMenu.index].mermaid?.length),
          onApply: changes => {
            if (!changeSize(blockMenu.index, changes)) closeBlockMenu(blockMenu, true);
          },
        }}
        captionOptions={menuCaption === undefined ? undefined : {
          value: menuCaption,
          onApply: value => {
            if (value === menuCaption || !changeCaption(blockMenu.index, value)) closeBlockMenu(blockMenu, true);
          },
        }}
        canDelete={Boolean(draft.current[blockMenu.index]?.trim()) || canRemoveParagraph(blockMenu.index)}
        tableEnabled={Boolean(tableDirective)}
        onClose={restoreFocus => closeBlockMenu(blockMenu, restoreFocus)}
        onDelete={() => confirmBlockDeletion(blockMenu)}
        onParagraph={() => addParagraph(blockMenu.index)}
        onTable={event => insertTable(event, blockMenu.index)}
        onMermaid={() => insertBlock(exampleMermaid.join(preferredEnding(emitted.current)), 'mermaid', blockMenu.index)}
        onFigure={() => {
          figureTarget.current = { index: blockMenu.index, blocks };
          closeBlockMenu(blockMenu, false);
          onChooseFigure();
        }} />}
      <div className="visual-editor" key={epoch} ref={pane} onContextMenu={contextMenu} onKeyDown={contextShortcut}>
        {visualError && <p className="error" role="alert">表紙・Mermaid図を表示できません。{visualError}</p>}
        <Warnings warnings={visual?.warnings} />
        {visual?.cover && <iframe className={`visual-cover${visual.cover.hasImage ? ' visual-cover-with-image' : ''}`}
          title="表紙" sandbox="" referrerPolicy="no-referrer" srcDoc={visual.cover.html} />}
        {blocks.map((block, index) => {
          if (block.kind === 'space') return null;
          if (block.kind !== 'editable') {
            const view = presentations[index];
            const wrapper = view.dsl;
            const mermaid = Boolean(block.mermaid?.length);
            const locked = disabled || pendingSource.has(index);
            const caption = (view.number || view.caption) && <>{view.number && <span>{view.number} </span>}
              <span dangerouslySetInnerHTML={{ __html: view.caption }} /></>;
            const diagrams = block.mermaid?.map((source, diagramIndex) => <DiagramBlock key={diagramIndex}
              height={view.height} align={view.figure ? view.align : undefined}
              diagram={visual?.diagrams.get(source) ?? (visualError ? { error: 'ソースを確認してください。' } : undefined)} />);
            const selectContainer = (target: EventTarget) => {
              if (target instanceof Element && target.closest('[data-table-row], .visual-dsl-content[contenteditable]')) return;
              if (selectedBlock !== index) selectBlock(index);
            };
            return <div key={index} className={view.table || view.isHtmlTable ? 'visual-block visual-table-block'
              : mermaid ? 'visual-mermaid' : 'visual-protected-block'} data-visual-block={index} data-dsl-block={wrapper?.name} tabIndex={-1}
              onFocus={event => selectContainer(event.target)} onClick={event => selectContainer(event.target)}>
              {view.table ? <VisualTable key={contentViewVersion} table={view.table} caption={caption}
                disabled={locked} selected={selectedBlock === index ? selectedCell : undefined}
                fontSize={view.fontSize} columnWidths={view.columnWidths} resolveImage={localImage}
                onFocus={(cell, element) => selectBlock(index, element, cell)}
                onInput={(cell, element, inputType) => updateCell(index, cell, element, inputType)}
                onPaste={paste} />
                : view.figure ? <figure className="visual-figure-preview">
                  <div className="visual-figure-body" style={{ width: view.width, textAlign: view.align,
                    marginInlineStart: view.align === 'left' ? 0 : 'auto', marginInlineEnd: view.align === 'right' ? 0 : 'auto',
                    ...(view.height && { '--visual-figure-height': view.height }),
                  } as CSSProperties}>
                    {mermaid ? diagrams : <div className="visual-figure-content" dangerouslySetInnerHTML={view.html} />}
                  </div>
                  {caption && <figcaption>{caption}</figcaption>}
                </figure>
                : view.kind === 'separator' ? <div className="visual-dsl-separator" role="separator">{view.definition?.label ?? 'ページ区切り'}</div>
                : wrapper || view.isHtmlTable ? <>
                  {wrapper?.name === 'hide' && <p className="visual-hidden-label">出力に含まれない本文</p>}
                  {mermaid ? diagrams : <div key={contentViewVersion} className="visual-dsl-content" style={{ ...view.definition?.styles, maxWidth: view.width ?? view.definition?.styles.maxWidth }}
                    contentEditable={view.editable && !locked} suppressContentEditableWarning
                    role={view.editable ? 'textbox' : undefined} aria-label={view.editable ? view.definition?.label ?? wrapper?.name : undefined}
                    aria-multiline={view.editable ? true : undefined}
                    dangerouslySetInnerHTML={view.html}
                    onFocus={event => { if (view.editable) selectBlock(index, event.currentTarget, undefined, true); }}
                    onInput={event => updateDslText(index, event.currentTarget, (event.nativeEvent as InputEvent).inputType)}
                    onClick={event => { if ((event.target as Element).closest('a')) event.preventDefault(); }}
                    onPaste={view.editable ? paste : undefined} />}
                </>
                : mermaid ? diagrams : <pre className="visual-protected">{block.raw.trimEnd()}</pre>}
              <BlockSource source={draft.current[index]} mermaid={mermaid} disabled={disabled} pending={pendingSource.has(index)}
                onChange={(field, inputType) => updateSource(index, field, inputType)} onRefresh={refreshBlocks} />
            </div>;
          }
          return (
            <div key={`${index}:${contentViewVersion}`} className="visual-block" role="textbox" data-visual-block={index} aria-label={`本文ブロック ${index + 1}`}
              aria-multiline="true" aria-readonly={disabled} contentEditable={!disabled} suppressContentEditableWarning
              dangerouslySetInnerHTML={renderedBlocks[index]}
              onFocus={(event) => selectBlock(index, event.currentTarget)}
              onInput={event => update(index, event.currentTarget, (event.nativeEvent as InputEvent).inputType)}
              onKeyDown={(event) => deleteWhenEmpty(index, event)}
              onClick={(event) => { if ((event.target as HTMLElement).closest('a')) event.preventDefault(); }}
              onPaste={paste} onDrop={preventDrop} />
          );
        })}
      </div>
    </div>
  );
}
