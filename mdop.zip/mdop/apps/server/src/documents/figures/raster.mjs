/**
 * @file ラスタ図版のレイヤーと注釈を合成し、AIに渡す場合は元寸法と送信用画像を用意する。
 */

import { withBrowserPage } from "../shared/browser-page.mjs";
import { validateFigureMaterial } from "./formats.mjs";
import { escapeHtml } from "../shared/markup.mjs";

const supported = new Set(["image/png", "image/jpeg", "image/webp"]);
const maxPixels = 40_000_000;
const maxSourcePixels = 80_000_000;
const maxOutputSide = 4096;
const maxAttachmentBytes = 2 * 1024 * 1024;
const ink = "#d53343";

/** 検証済みの枠・矢印・文字をラスタ合成用のSVG要素へ変換する。 */
function annotationMarkup(annotation) {
    const { x, y } = annotation;
    const color = escapeHtml(annotation.color ?? ink);
    const strokeWidth = annotation.strokeWidth ?? 3;
    const stroke = `stroke="${color}" stroke-width="${strokeWidth}" stroke-linecap="round" stroke-linejoin="round" fill="none"`;
    if (annotation.type === "box") {
        return `<rect x="${x}" y="${y}" width="${annotation.width}" height="${annotation.height}" ${stroke}/>`;
    }
    if (annotation.type === "label") {
        const fontSize = annotation.fontSize ?? 24;
        const fontWeight = annotation.fontWeight ?? "normal";
        return `<text x="${x}" y="${y + fontSize}" fill="${color}" font-family="sans-serif" font-size="${fontSize}" font-weight="${fontWeight}">${escapeHtml(annotation.text)}</text>`;
    }
    const endX = x + annotation.dx;
    const endY = y + annotation.dy;
    const length = Math.hypot(annotation.dx, annotation.dy) || 1;
    const head = Math.min(Math.max(14, strokeWidth * 4), length / 3);
    const alongX = annotation.dx / length * head;
    const alongY = annotation.dy / length * head;
    const wing = side => `${endX - alongX - side * alongY / 2},${endY - alongY + side * alongX / 2}`;
    return `<path d="M ${x},${y} L ${endX},${endY} M ${wing(1)} L ${endX},${endY} L ${wing(-1)}" ${stroke}/>`;
}

const pageHeader = '<!doctype html><meta charset="utf-8">' +
    '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; img-src data:; style-src \'unsafe-inline\'">';

/** 対応形式の画像バイト列をブラウザー内で読み込めるデータURLにする。 */
function rasterDataUrl(original, mime) {
    return `data:${mime};base64,${validateFigureMaterial(original, mime).toString("base64")}`;
}

/** ブラウザーで画像を読み込み、描画に使う実際のピクセル寸法を取得する。 */
async function readRasterSize(page, url) {
    await page.setContent(`${pageHeader}<img src="${url}" alt="">`, { waitUntil: "load" });
    const { width, height } = await page.$eval("img", image => ({
        width: image.naturalWidth, height: image.naturalHeight,
    }));
    if (!width || !height || width * height > maxPixels) {
        throw new Error("画像を読み込めませんでした。画像形式とサイズを確認してください。");
    }
    return { width, height };
}

/** 描画ページを開き、基準画像があれば原寸を確認する。 */
async function withFigureRaster({ original, mime, signal }, operation) {
    signal?.throwIfAborted();
    const url = original && rasterDataUrl(original, mime);
    return withBrowserPage(async page => {
        const size = url ? await readRasterSize(page, url) : {};
        return operation({ page, url, ...size });
    }, { signal });
}

/** 注釈依頼用の画像を準備する。大きい画像は送信用に縮小し、応答座標のために元寸法も返す。 */
export function prepareFigureRasterAttachment({ original, mime, signal, maxBytes = maxAttachmentBytes }) {
    return withFigureRaster({ original, mime, signal }, async ({ page, width, height }) => {
        // The host can echo and retain user messages, so keep image payloads compact.
        if (supported.has(mime) && original.length <= maxBytes) return { width, height, bytes: original, mime };
        const encoded = await page.$eval("img", (image, limit) => {
            const scale = Math.min(1, 1600 / Math.max(image.naturalWidth, image.naturalHeight));
            const canvas = document.createElement("canvas");
            canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
            canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
            const context = canvas.getContext("2d");
            context.fillStyle = "#fff";
            context.fillRect(0, 0, canvas.width, canvas.height);
            context.drawImage(image, 0, 0, canvas.width, canvas.height);
            const jpeg = quality => canvas.toDataURL("image/jpeg", quality).split(",")[1];
            const preferred = jpeg(0.84);
            return preferred.length <= limit ? preferred : jpeg(0.66);
        }, Math.floor(maxBytes / 3) * 4);
        const bytes = Buffer.from(encoded, "base64");
        if (!bytes.length || bytes.length > maxBytes) throw new Error("この画像をCopilotの添付用に縮小できませんでした。");
        return { width, height, bytes, mime: "image/jpeg" };
    });
}

/** 画像を配置順に並べ、上に注釈を重ねて本文表示用のPNGへ変換する。 */
export function renderFigureRaster({ original, mime, annotations = [], composition, signal }) {
    return withFigureRaster({ original, mime, signal }, async ({ page, url, width: sourceWidth = 0, height: sourceHeight = 0 }) => {
        // Preserve the screenshot bytes until an annotation actually needs a composite.
        if (!composition && !annotations.length && mime === "image/png") return { buffer: original, width: sourceWidth, height: sourceHeight };
        const { width, height } = composition ?? { width: sourceWidth, height: sourceHeight };
        const layers = [];
        let pixels = sourceWidth * sourceHeight;
        for (const image of composition?.images ?? [{ original, mime, x: 0, y: 0, width, height }]) {
            signal?.throwIfAborted();
            const source = image.original === original ? url : rasterDataUrl(image.original, image.mime);
            if (image.original !== original) {
                const size = await readRasterSize(page, source);
                pixels += size.width * size.height;
                if (pixels > maxSourcePixels) throw new Error("図版に配置する画像の元サイズの合計が大きすぎます。");
            }
            layers.push(`<image href="${source}" x="${image.x}" y="${image.y}" width="${image.width}" height="${image.height}" preserveAspectRatio="none"/>`);
        }
        const scale = Math.min(1, maxOutputSide / Math.max(width, height));
        const canvasWidth = Math.max(1, Math.round(width * scale));
        const canvasHeight = Math.max(1, Math.round(height * scale));
        await page.setViewport({ width: canvasWidth, height: canvasHeight, deviceScaleFactor: 1 });
        await page.setContent(`${pageHeader}<body style="margin:0;overflow:hidden"><svg xmlns="http://www.w3.org/2000/svg"
viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" style="position:absolute;inset:0;width:100vw;height:100vh">
${layers.join("")}${annotations.map(annotationMarkup).join("")}</svg></body>`, { waitUntil: "load" });
        return { buffer: Buffer.from(await page.screenshot({ type: "png", omitBackground: true })), width, height };
    });
}
