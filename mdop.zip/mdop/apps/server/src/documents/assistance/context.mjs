/**
 * @file 本文と図版のAI支援に共通する入力上限と、依頼対象の文書情報を扱う。
 */

import { isAbsolute, relative, sep } from 'node:path';
import { ApiError } from '../../common/api/errors.mjs';
import { workspaceRoot } from '../../common/filesystem/locations.mjs';

/** 任意の入力を文字列にそろえ、上限を検査して前後の空白を除く。 */
export function boundedText(value, limit, label) {
    if (value === undefined) return '';
    if (typeof value !== 'string' || value.length > limit) {
        throw new ApiError(400, 'INVALID_GENERATION_INPUT', `${label}は${limit}文字以内で指定してください。`);
    }
    return value.trim();
}

/** 文書IDと、ワークスペース内にある場合の相対フォルダを依頼の対象として示す。 */
export function documentTarget(documentId, documentFolder) {
    const folder = relative(workspaceRoot, documentFolder);
    const segments = folder.split(sep);
    return { documentId, ...(!isAbsolute(folder) && segments[0] !== '..' && { workspaceFolder: segments.join('/') }) };
}
