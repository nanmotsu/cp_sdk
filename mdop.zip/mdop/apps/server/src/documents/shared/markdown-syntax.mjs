/**
 * @file 参照ID、DSL記法、コードフェンスを扱う共通の字句処理を提供する。
 */

/** 新旧の図表参照構文からIDを検出するためのパターン。 */
export const referencePattern = /\{\{ref:([A-Za-z0-9._-]+)\}\}|\[\[ref:([A-Za-z0-9._-]+)\]\]/g;

/** DSLの開始行に並ぶ属性からキーと値を取り出す。 */
export function parseDslAttributes(source) {
    const attributes = {};
    for (const [, key, value] of source.matchAll(/(\w+)=("[^"]*"|'[^']*'|[^\s]+)/g)) {
        attributes[key] = value.replace(/^['"]|['"]$/g, "");
    }
    return attributes;
}

/** 入力の行を順に調べ、本文・DSL・コードフェンスを行番号付きで識別する。 */
export function* scanDocumentSyntax(source) {
    let line = 0;
    let fence;
    let inComment = false;
    for (const { 0: raw, index } of source.matchAll(/[^\n]*(?:\n|$)/g)) {
        if (!raw) break;
        const location = { start: index, end: index + raw.length, line: ++line };
        const text = raw.trimEnd();
        const marker = /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(text);
        if (fence) {
            if (marker && marker[1][0] === fence[0] && marker[1].length >= fence.length && !marker[2]) {
                fence = undefined;
                yield { ...location, kind: "fence-close" };
            } else {
                yield { ...location, kind: "fence-body" };
            }
            continue;
        }
        if (inComment || /^ {0,3}<!--/.test(text)) {
            inComment = !text.includes("-->");
            continue;
        }
        if (marker) {
            fence = marker[1];
            yield { ...location, kind: "fence-open", language: marker[2].trim().split(/\s+/, 1)[0].toLowerCase() };
            continue;
        }
        const opening = /^:::(\w[\w-]*)(?:[ \t]+(.*))?$/.exec(text);
        if (opening) {
            yield { ...location, kind: "dsl-open", name: opening[1], attributes: parseDslAttributes(opening[2] ?? "") };
        } else {
            yield { ...location, kind: text === ":::" ? "dsl-close" : "text", text };
        }
        if (/<!--(?:(?!-->).)*$/.test(text)) inComment = true;
    }
}
