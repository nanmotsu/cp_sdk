/**
 * @file 文書別YAMLと共通設定を読み、設定変更を文書単位で保存する。
 */

import { badRequest, conflict } from "../../common/api/errors.mjs";
import { atomicWrite, workspacePath } from "../../common/filesystem/paths.mjs";
import { textInput } from "../shared/input.mjs";
import { CONFIG_LIMIT } from "./files.mjs";
import { loadDocumentConfig, parseConfig } from "./yaml.mjs";
import { editBasicSettings } from "./basic.mjs";

/** 設定取得時のハッシュを検査し、現在の設定と一致しなければ競合を返す。 */
function checkConfigRevision(expected, actual) {
    if (typeof expected !== "string" || !/^[a-f\d]{64}$/.test(expected)) {
        throw badRequest("設定取得時の revision を指定してください。");
    }
    if (expected !== actual) {
        throw conflict("設定が別の操作で更新されています。最新の内容を確認してください。", { revision: actual });
    }
}

/** 原本や履歴と同じ文書ロックで、設定を読み書きする。 */
export function createConfigStore({ root, access }) {
    /** 指定された有効なYAML全体を文書別設定として保存する。 */
    async function putConfig(id, source, expectedRevision) {
        textInput(source, "yaml", CONFIG_LIMIT);
        const parsed = parseConfig(source);
        if (!parsed.config) throw badRequest("config.yaml の設定を確認してください。", parsed.diagnostics);
        return access(id, async folder => {
            if (expectedRevision !== undefined) {
                checkConfigRevision(expectedRevision, (await loadDocumentConfig(root, folder)).revision);
            }
            await atomicWrite(await workspacePath(folder, "config.yaml", { mayBeMissing: true }), source);
            return loadDocumentConfig(root, folder);
        });
    }

    /** フォームから受け取った基本設定を部分更新する。変更がなければ既存の設定情報を返す。 */
    async function patchBasicSettings(id, changes, expectedRevision) {
        return access(id, async folder => {
            const current = await loadDocumentConfig(root, folder);
            checkConfigRevision(expectedRevision, current.revision);
            const source = editBasicSettings(current, changes);
            if (source === current.yaml) return current;
            await atomicWrite(await workspacePath(folder, "config.yaml", { mayBeMissing: true }), source);
            return loadDocumentConfig(root, folder);
        });
    }

    return { config: id => access(id, folder => loadDocumentConfig(root, folder)),
        putConfig, patchBasicSettings };
}
