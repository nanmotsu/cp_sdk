/**
 * @file Word出力用の体裁と画像処理を適用し、Word取り込みではMarkdown本文と抽出画像を返す。
 */

import { basename, extname } from "node:path";
import { randomUUID } from "node:crypto";
import HTMLtoDOCX from "html-to-docx";
import mammoth from "mammoth";
import TurndownService from "turndown";
import { gfm } from "turndown-plugin-gfm";
import { withBrowserPage } from "../shared/browser-page.mjs";
import { figureFormats } from "../figures/formats.mjs";
import { buildWordHtml, cssLengthToTwips, repairDocx, serveImagesViaHttp } from "./word-layout.mjs";
import { replaceHtmlTablesWithMarkdown } from "./word-tables.mjs";

const docxPaper = {
    a4: ["210mm", "297mm"],
    a3: ["297mm", "420mm"],
    a5: ["148mm", "210mm"],
    legal: ["8.5in", "14in"],
    letter: ["8.5in", "11in"],
    tabloid: ["11in", "17in"],
};
const fidelityNote = "Word変換は補助機能です。改ページ、複雑なレイアウト、独自記法は変換後に確認してください。";

/** Wordで扱いにくいSVG画像をラスタ化し、変換できない画像は警告する。 */
async function rasterizeWordImages(html, warnings, signal) {
    const vectorOrWebp = /src="(data:image\/(?:svg\+xml|webp|bmp);base64,[A-Za-z0-9+/=]+)"/gi;
    const images = [...html.matchAll(vectorOrWebp)];
    if (!images.length) return html;
    const sources = new Map();
    await withBrowserPage(async page => {
        for (const [, source] of images) {
            if (sources.has(source)) continue;
            try {
                await page.setContent(`<!doctype html><body style="margin:0"><img style="display:block;max-width:1600px;max-height:1600px" src="${source}" alt=""></body>`, { waitUntil: "load" });
                const image = await page.$("img");
                const png = await image.screenshot({ type: "png", omitBackground: true });
                sources.set(source, `src="data:image/png;base64,${Buffer.from(png).toString("base64")}"`);
            } catch (error) {
                signal?.throwIfAborted();
                warnings.push(`Word用に画像を変換できません: ${error.message}`);
                sources.set(source, "");
            }
        }
    }, { signal });
    return html.replace(vectorOrWebp, (_, source) => sources.get(source));
}

/** Word向けに整えたHTMLをDOCXへ変換し、出力後のXMLを補正して警告とバイト列を返す。 */
export async function writeWord({ title, page, bodyHtml, warnings }, signal) {
    const body = await rasterizeWordImages(bodyHtml, warnings, signal);
    const dimensions = docxPaper[String(page.paper).toLowerCase()];
    const pageSize = dimensions && { width: cssLengthToTwips(dimensions[0]), height: cssLengthToTwips(dimensions[1]) };
    const margins = {
        top: cssLengthToTwips(page.margin?.top, 567),
        right: cssLengthToTwips(page.margin?.right, 567),
        bottom: cssLengthToTwips(page.margin?.bottom, 850),
        left: cssLengthToTwips(page.margin?.left, 851),
        header: 0, footer: 0, gutter: 0,
    };
    // 明示していない用紙は、変換器の既定値であるLetterとして表示幅を求める。
    const pageWidth = page.orientation === "landscape" ? pageSize?.height ?? 15840 : pageSize?.width ?? 12240;
    const contentWidth = Math.max(0, (pageWidth - margins.left - margins.right) / 15);
    const html = buildWordHtml(body, title, contentWidth).replace(/<\/?(thead|tbody|tfoot)\b[^>]*>/gi, "");
    const images = await serveImagesViaHttp(html);
    try {
        signal?.throwIfAborted();
        const buffer = await HTMLtoDOCX(images.html, null, {
            orientation: page.orientation,
            ...(pageSize && { pageSize }),
            table: { row: { cantSplit: true } },
            footer: false,
            pageNumber: false,
            decodeUnicode: true,
            lang: { eastAsia: "ja-JP", val: "ja-JP" },
            font: "Yu Gothic UI",
            fontSize: 22,
            margins,
        });
        signal?.throwIfAborted();
        const repaired = await repairDocx(buffer);
        return { buffer: Buffer.from(repaired), warnings: [...warnings, fidelityNote] };
    } finally {
        await images.cleanup();
    }
}

/** DOCXの段落・表と対応画像を抽出し、Markdownと画像データ、変換警告を返す。 */
export async function importDocx({ buffer, name, signal }) {
    if (extname(name).toLowerCase() !== ".docx") throw new Error(".docx ファイルを選択してください");
    const assets = [];
    const warnings = [fidelityNote];
    let extractedSize = 0;
    const conversion = await mammoth.convertToHtml({ buffer: Buffer.from(buffer) }, {
        externalFileAccess: false,
        convertImage: mammoth.images.imgElement(async image => {
            signal?.throwIfAborted();
            const extension = Object.hasOwn(figureFormats, image.contentType) && figureFormats[image.contentType];
            if (!extension) {
                warnings.push(`Word内の未対応画像形式: ${image.contentType}`);
                return { alt: "変換できなかった画像" };
            }
            const data = await image.readAsBuffer();
            if (data.length > 12 * 1024 * 1024 || extractedSize + data.length > 48 * 1024 * 1024) {
                warnings.push("Word内の画像がサイズ上限を超えたため省略されました。");
                return { alt: "変換できなかった画像" };
            }
            extractedSize += data.length;
            const fileName = `Word画像 ${assets.length + 1}.${extension}`;
            const placeholder = `./__md_operator_word__/${randomUUID()}.${extension}`;
            assets.push({ name: fileName, mime: image.contentType, buffer: data, placeholder });
            return { src: placeholder };
        }),
    });
    signal?.throwIfAborted();
    warnings.push(...conversion.messages.map(message => `${message.type}: ${message.message}`));
    const converter = new TurndownService({
        headingStyle: "atx", codeBlockStyle: "fenced", bulletListMarker: "-", emDelimiter: "_",
    });
    converter.use(gfm);
    const markdown = converter.turndown(conversion.value).replace(/\u00a0/g, " ").replace(/\r\n/g, "\n");
    const body = replaceHtmlTablesWithMarkdown(markdown).replace(/\n{3,}/g, "\n\n").trim();
    const fileName = basename(name).replace(/--/g, "—").replace(/[<>\r\n]/g, "");
    return { content: `<!-- Wordから取り込み: ${fileName} -->\n\n${body}\n`, assets, warnings };
}
