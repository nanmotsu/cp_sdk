/**
 * @file copilot.yaml のテンプレートを読み、本文編集に使える項目に整える。
 */

import { badRequest } from "../../common/api/errors.mjs";
import { loadYaml, readDocumentYaml } from "../config/files.mjs";

/** ID、表示名、プロンプトと、参照元があるときの依頼省略設定を検証する。 */
function parseTemplates(yaml) {
    const data = loadYaml(yaml);
    if (!data || !Array.isArray(data.templates) || Object.keys(data).some(key => key !== "templates")) {
        throw new Error("最上位に templates の一覧を指定してください。");
    }
    const ids = new Set();
    return data.templates.map((entry, index) => {
        const path = `templates[${index + 1}]`;
        if (!entry || typeof entry !== "object" || Array.isArray(entry)) throw new Error(`${path} はキーと値で指定してください。`);
        const { id, label, prompt, instructionOptionalWithSources = false, ...other } = entry;
        if (typeof id !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}$/.test(id)) {
            throw new Error(`${path}.id は半角英数字・ハイフン・アンダースコアで指定してください（80文字以内）。`);
        }
        if (ids.has(id)) throw new Error(`テンプレートIDが重複しています。 ${id}`);
        if (typeof label !== "string" || !label.trim() || label.length > 120 || /[\r\n]/.test(label)) {
            throw new Error(`${path}.label は120文字以内の1行で指定してください。`);
        }
        if (typeof prompt !== "string" || !prompt.trim() || prompt.length > 12000) {
            throw new Error(`${path}.prompt は12000文字以内の文字列で指定してください。`);
        }
        if (typeof instructionOptionalWithSources !== "boolean" || Object.keys(other).length) {
            throw new Error(`${path} の項目を確認してください。instructionOptionalWithSources は true または false で指定できます。`);
        }
        ids.add(id);
        return { id, label: label.trim(), prompt: prompt.trim(), instructionOptionalWithSources };
    });
}

/** 文書別または共通の定義を読み、YAMLの不備を診断として返す。 */
export async function loadCopilotTemplates(documentsRoot, documentRoot) {
    const { source, path, yaml, diagnostics } = await readDocumentYaml(documentsRoot, documentRoot, "copilot.yaml");
    if (diagnostics.length) return { source, path, templates: [], diagnostics };
    try {
        return { source, path, templates: parseTemplates(yaml), diagnostics: [] };
    } catch (error) {
        const line = error.mark ? `${error.mark.line + 1}行目 ` : "";
        return { source, path, templates: [], diagnostics: [line + (error.reason ?? error.message)] };
    }
}

/** ジョブ開始時に、現在の文書で使えるテンプレートをIDで解決する。 */
export function requireCopilotTemplate(info, templateId) {
    if (info.diagnostics.length) throw badRequest(`${info.path} の設定を確認してください。`, info.diagnostics);
    const template = info.templates.find(({ id }) => id === templateId);
    if (!template) throw badRequest("現在の文書で使えるテンプレートを選び直してください。");
    return template;
}
