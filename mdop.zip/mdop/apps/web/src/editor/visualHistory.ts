/** @file ビジュアルの文字入力と構造編集を、同じ本文の取り消し履歴に記録する。 */

import type { TableCell } from './tables';

/** 履歴の復元後に戻るブロックまたはセル。 */
export interface EditorPosition { block: number; cell?: TableCell; source?: boolean }
export interface VisualSnapshot { markdown: string; position?: EditorPosition }

const maxEntries = 60;
const maxCharacters = 8 * 1024 * 1024;

export class VisualHistory {
  readonly undo: VisualSnapshot[] = [];
  readonly redo: VisualSnapshot[] = [];
  private lastInput?: { target: HTMLElement; inputType: string; when: number };

  /** 同じ入力欄への連続入力をひとまとめにし、構造編集は独立した履歴にする。 */
  remember(before: VisualSnapshot, target?: HTMLElement, inputType = '') {
    const when = performance.now();
    const last = this.lastInput;
    if (!target || last?.target !== target || last.inputType !== inputType || when - last.when > 850) {
      this.push(this.undo, before);
    }
    this.lastInput = target ? { target, inputType, when } : undefined;
    this.redo.length = 0;
  }

  /** 一つ前・後の本文を取り出し、反対向きの操作で戻れるよう現在値を交換する。 */
  step(direction: 'undo' | 'redo', current: VisualSnapshot) {
    const next = this[direction].pop();
    if (!next) return undefined;
    this.push(direction === 'undo' ? this.redo : this.undo, current);
    this.lastInput = undefined;
    return next;
  }

  /** 別の機能から原本が置換されたときは、古い本文を復元しないよう履歴を破棄する。 */
  clear() {
    this.undo.length = 0;
    this.redo.length = 0;
    this.lastInput = undefined;
  }

  private push(stack: VisualSnapshot[], snapshot: VisualSnapshot) {
    stack.push(snapshot);
    let size = 0;
    for (let index = stack.length - 1; index > 0; index -= 1) {
      size += stack[index].markdown.length;
      if (stack.length - index >= maxEntries || size + stack[index - 1].markdown.length > maxCharacters) {
        stack.splice(0, index);
        break;
      }
    }
  }
}
