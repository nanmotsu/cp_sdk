/**
 * @file 共通の文書描画結果からPDF・Wordの成果物を作る。
 */

import { withBrowserPage } from "../shared/browser-page.mjs";
import { buildHeaderFooterOptions } from "../shared/render-common.mjs";
import { renderDocument } from "../shared/rendering.mjs";
import { writeWord } from "./word.mjs";

/** 印刷用HTMLをChromeで開き、用紙・余白・ヘッダーの設定を適用してPDFを生成する。 */
export async function renderPdf(input) {
    const { html, page, warnings, markupOptions } = await renderDocument({ ...input, assetUrl: undefined }, "pdf");
    const headerFooterOptions = await buildHeaderFooterOptions(page, markupOptions);
    const buffer = await withBrowserPage(async browserPage => {
        await browserPage.setContent(html, { waitUntil: "load" });
        return browserPage.pdf({
            format: page.paper,
            landscape: page.orientation === "landscape",
            margin: page.margin,
            printBackground: true,
            ...headerFooterOptions,
        });
    }, { signal: input.signal });
    return { buffer: Buffer.from(buffer), warnings };
}

/** Word用の本文HTMLを組み立て、DOCXの体裁変換とバイト列生成へ渡す。 */
export async function renderDocx(input) {
    const state = await renderDocument({ ...input, assetUrl: undefined }, "docx");
    return writeWord(state, input.signal);
}
