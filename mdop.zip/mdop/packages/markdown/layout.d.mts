/** @file 図のサイズと列幅を読む共通処理の型。 */

export function layoutLength(value: unknown): string | undefined;
export function readMermaidLayout(source: string): {
  code: string;
  width: string | null;
  height: string | null;
  fontSize: string | null;
  directives: { name: string; raw: string }[];
};
export function parseColumnWidths(raw?: string): string[];
export function splitFigureSource(source: string): { body: string; caption: string; captionLines: number[] };
