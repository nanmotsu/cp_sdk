/**
 * @file エージェントの接続状態・モデル・セッションをGUIへ返す。
 */

import { sendJson } from "../common/api/http.mjs";
import { workspaceRoot } from "../common/filesystem/locations.mjs";

/** 統合APIにエージェントの状態とセッションを載せる。 */
export function copilotRoutes(agent) {
    return [
        ["GET", "/integrations/status", async (_request, response) =>
            sendJson(response, 200, { copilot: await agent.status(), workspace: workspaceRoot })],
        ["GET", "/integrations/sessions", async (_request, response) =>
            sendJson(response, 200, { workspace: workspaceRoot, sessions: await agent.listSessions() })],
    ];
}
