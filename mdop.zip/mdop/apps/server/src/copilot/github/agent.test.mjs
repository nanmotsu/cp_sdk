/**
 * @file 模擬Agent Hostを使い、GitHub Copilotのセッション、添付、専用エージェントを検証する。
 */

import assert from 'node:assert/strict';
import { once } from 'node:events';
import { realpath } from 'node:fs/promises';
import { join } from 'node:path';
import { test } from 'node:test';
import { pathToFileURL } from 'node:url';
import { WebSocketServer } from 'ws';
import { workspaceRoot } from '../../common/filesystem/locations.mjs';
import { connectCopilot, createGitHubCopilot } from './index.mjs';

/** ローカルWebSocketでAHPの要求とアクションに応答し、送信内容を検証できるよう記録する。 */
async function fakeHost(t, options = {}) {
    const server = new WebSocketServer({ host: '127.0.0.1', port: 0 });
    await once(server, 'listening');
    t.after(async () => {
        for (const socket of server.clients) socket.terminate();
        await new Promise((resolve) => server.close(resolve));
    });

    const messages = [];
    const chat = 'ahp-chat:/test-chat';
    const provider = 'copilotcli';
    const repository = await realpath(workspaceRoot);
    const directory = pathToFileURL(repository).href;
    const agentUri = `${directory}/.github/agents/figure-%63omposer.agent.md`;
    const documentAgentUri = `${directory}/.github/agents/document-%65ditor.agent.md`;
    const config = {
        mode: options.mode ?? 'plan', sandboxEnabled: 'on',
        ...(options.modernConfig ? { approvals: 'manual', target: 'workspace' }
            : options.standardConfig ? { approvalMode: 'manual', target: 'workspace', effectiveApprovalMode: 'manual' }
                : { autoApprove: 'default', isolation: 'folder', effectiveApprovalMode: 'default' }),
    };
    const properties = {
        mode: { enum: ['plan', 'interactive'] }, sandboxEnabled: { enum: ['on'] },
        ...(options.modernConfig ? { approvals: { enum: ['manual'] }, target: { enum: ['workspace', 'worktree'] } }
            : options.standardConfig ? { approvalMode: { enum: ['manual'] }, target: { enum: ['workspace', 'worktree'] } }
                : { autoApprove: { enum: ['default'] }, isolation: { enum: ['folder', 'worktree'] } }),
    };
    const existing = { resource: 'ahp-session:/existing', provider, status: 1, title: 'Existing session', workingDirectories: [directory], modifiedAt: '2026-11-21T00:00:00.000Z' };
    const created = [];
    let currentMode = config.mode;
    server.on('connection', (socket) => {
        let serverSeq = 0;
        let pendingToolTurn;
        let pendingImageTurn;
        const action = (channel, payload) => socket.send(JSON.stringify({
            jsonrpc: '2.0', method: 'action', params: { channel, serverSeq: ++serverSeq, action: payload },
        }));
        socket.on('message', (raw) => {
            const message = JSON.parse(raw.toString());
            messages.push(message);
            const { id, method, params } = message;
            const result = (value) => socket.send(JSON.stringify({ jsonrpc: '2.0', id, result: value }));
            if (method === 'initialize') result({ protocolVersion: options.protocolVersion ?? '1.2.0',
                snapshots: [{ resource: 'ahp-root://', state: { agents: [{ provider, models: options.models }] } }],
            });
            if (method === 'resolveSessionConfig') result({
                schema: { properties }, values: { ...config, mode: params.config.mode },
            });
            if (method === 'listSessions') result(params.cursor === 'p2' ? { items: [existing, ...created] } : {
                items: [
                    { ...existing, resource: 'ahp-session:/other-provider', provider: 'other' },
                    { ...existing, resource: 'ahp-session:/other-repository', workingDirectories: [pathToFileURL(join(repository, 'worktree')).href] },
                    { ...existing, resource: 'ahp-session:/archived', status: 65 },
                ], nextCursor: 'p2',
            });
            if (method === 'createSession') {
                created.push({ resource: params.channel, provider: params.provider, title: 'New session', workingDirectories: params.workingDirectories });
                currentMode = params.config.mode;
                result({});
            }
            if (method === 'disposeSession') result({});
            if (method === 'resourceRead' && options.generatedImage === 'resource') {
                result({ data: options.imageBytes.toString('base64'), encoding: 'base64', contentType: 'image/png' });
            }
            if (method === 'subscribe') result({ snapshot: { state: params.channel === chat ? {
                ...(options.chatState ?? {}),
            } : {
                provider, lifecycle: 'creating', defaultChat: chat, config: { values: { ...config, mode: currentMode } }, workingDirectories: [directory],
                customizations: [{ type: 'directory', children: [agentUri, documentAgentUri,
                    ...(options.traceability ? [`${directory}/.github/agents/traceability/generate/map.agent.md`] : []),
                ].map(uri => ({ type: 'agent', uri })) }],
            } } });
            if (method === 'dispatchAction' && params.action.type === 'session/titleChanged') {
                const session = created.find((item) => item.resource === params.channel);
                if (session) session.title = params.action.title;
            }
            if (method === 'dispatchAction' && params.action.type === 'chat/turnStarted') {
                const { turnId } = params.action;
                if (options.abort) {
                    options.abort();
                    return;
                }
                if (options.automaticTool) {
                    action(chat, { type: 'chat/toolCallReady', turnId, toolCallId: 'tool-1', confirmed: 'not-needed' });
                    return;
                }
                if (options.manualTool) {
                    action(chat, { type: 'chat/toolCallStart', turnId, toolCallId: 'tool-1', toolName: options.manualTool });
                    action(chat, { type: 'chat/toolCallReady', turnId, toolCallId: 'tool-1' });
                    setTimeout(() => {
                        action(chat, { type: 'chat/toolCallConfirmed', turnId, toolCallId: 'tool-1', approved: true, confirmed: 'user-action' });
                        action(chat, { type: 'chat/toolCallComplete', turnId, toolCallId: 'tool-1', result: { success: true } });
                        action(chat, { type: 'chat/responsePart', turnId, part: { id: 'md', kind: 'markdown', content: '# From attachment' } });
                        action(chat, { type: 'chat/turnComplete', turnId });
                    }, 10);
                    return;
                }
                if (options.autoExecuteTool) {
                    action(chat, { type: 'chat/toolCallStart', turnId, toolCallId: 'tool-1', toolName: 'execute' });
                    action(chat, { type: 'chat/toolCallReady', turnId, toolCallId: 'tool-1', confirmed: 'not-needed' });
                    return;
                }
                if (options.generatedImage) {
                    pendingImageTurn = turnId;
                    action(chat, { type: 'chat/toolCallStart', turnId, toolCallId: 'image-1', toolName: 'image_generation', displayName: 'Generate image' });
                    action(chat, { type: 'chat/toolCallReady', turnId, toolCallId: 'image-1' });
                    return;
                }
                action(chat, { type: 'chat/responsePart', turnId, part: { id: 'md', kind: 'markdown', content: '# Scope' } });
                pendingToolTurn = turnId;
                action(chat, { type: 'chat/toolCallReady', turnId, toolCallId: 'tool-1' });
            }
            if (method === 'dispatchAction' && params.action.type === 'chat/toolCallConfirmed' && params.action.turnId === pendingToolTurn) {
                const { turnId } = params.action;
                pendingToolTurn = undefined;
                action(chat, { type: 'chat/delta', turnId, partId: 'md', content: '\nGenerated draft' });
                action(chat, { type: 'chat/turnComplete', turnId });
            }
            if (method === 'dispatchAction' && params.action.type === 'chat/toolCallConfirmed' && params.action.turnId === pendingImageTurn) {
                const { turnId } = params.action;
                pendingImageTurn = undefined;
                const image = options.generatedImage === 'resource'
                    ? { type: 'resource', uri: 'ahp-session:/generated-image', contentType: 'image/png' }
                    : { type: 'embeddedResource', contentType: 'image/png', data: options.imageBytes.toString('base64') };
                action(chat, { type: 'chat/toolCallComplete', turnId, toolCallId: 'image-1',
                    result: { success: true, content: [image], structuredContent: { imageGeneration: { images: [{ contentIndex: 0 }] } } } });
                action(chat, { type: 'chat/responsePart', turnId, part: { id: 'md', kind: 'markdown', content: '{"generated":1}' } });
                action(chat, { type: 'chat/turnComplete', turnId });
            }
        });
    });
    const discover = async () => [{ url: `ws://127.0.0.1:${server.address().port}/`, type: 'editor' }];
    return { directory, agentUri, documentAgentUri, messages, existing,
        copilot: createGitHubCopilot({ connect: (options) => connectCopilot({ discover, ...options }) }) };
}

/** 再利用したセッションでも、図版のターンだけに専用エージェントのファイルURIを付ける。 */
test('AHP selects each workspace custom agent on its own message', { timeout: 8000 }, async (t) => {
    const { copilot, agentUri, documentAgentUri, existing, messages } = await fakeHost(t, { mode: 'interactive' });
    await copilot.complete({ purpose: 'compose-figure', prompt: 'Arrange the images', sessionId: existing.resource });
    await copilot.complete({ purpose: 'edit-document', prompt: 'Edit the document', sessionId: existing.resource });
    await copilot.complete({ purpose: 'compose-figure', prompt: 'Another request', sessionId: existing.resource });
    await copilot.complete({ purpose: 'compose-figure', prompt: 'Create a new figure' });
    const turns = messages.filter(({ params }) => params?.action?.type === 'chat/turnStarted')
        .map(({ params }) => params.action.message);
    assert.deepEqual(turns.map(message => message.agent), [{ uri: agentUri }, { uri: documentAgentUri }, { uri: agentUri }, { uri: agentUri }]);
});

/** 新規セッションが作業場所に紐付き、ツールを承認せずに応答を集約できることを検証する。 */
test('AHP creates a persistent repository session, denies tool calls, and streams Markdown', { timeout: 8000 }, async (t) => {
    const { directory, existing, messages, copilot } = await fakeHost(t);
    const { text, session } = await copilot.complete({ purpose: 'edit-document', prompt: 'Fictional test prompt', sessionTitle: 'Document draft' });
    assert.equal(text, '# Scope\nGenerated draft');
    const created = messages.find(({ method }) => method === 'createSession');
    assert.equal(created.params.provider, 'copilotcli');
    assert.deepEqual(created.params.config, { mode: 'plan', autoApprove: 'default', sandboxEnabled: 'on', isolation: 'folder' });
    assert.deepEqual(created.params.workingDirectories, [directory]);
    assert.equal(messages.find(({ params }) => params.action?.type === 'chat/toolCallConfirmed').params.action.approved, false);
    assert.equal(messages.some(({ method }) => method === 'disposeSession'), false);
    assert.deepEqual(session, { id: created.params.channel, title: 'Document draft' });
    assert.deepEqual(await copilot.listSessions(), [{ id: existing.resource, title: existing.title, modifiedAt: existing.modifiedAt }, session]);
});

/** 接続を開き直しても、同じ作業場所のセッションを再利用できることを検証する。 */
test('AHP reuses a catalog session in the repository across a new connection', { timeout: 8000 }, async (t) => {
    const { existing, messages, copilot } = await fakeHost(t);
    const [expected] = await copilot.listSessions();
    assert.deepEqual(expected, { id: existing.resource, title: existing.title, modifiedAt: existing.modifiedAt });
    const { text, session } = await copilot.complete({ purpose: 'edit-document', prompt: 'Fictional follow-up', sessionId: expected.id });
    assert.equal(text, '# Scope\nGenerated draft');
    assert.deepEqual(session, expected);
    assert.ok(messages.some(({ method, params }) => method === 'subscribe' && params.channel === expected.id));
    assert.equal(messages.some(({ method }) => ['createSession', 'disposeSession'].includes(method)), false);
    await assert.rejects(copilot.complete({ purpose: 'edit-document', prompt: 'Fictional follow-up', sessionId: 'ahp-session:/other-repository' }), { code: 'AHP_SESSION_NOT_FOUND' });
});

/** Agent Hostの標準名に従って手動承認と作業場所を設定することを検証する。 */
test('AHP accepts the standard approval and repository config names', { timeout: 8000 }, async (t) => {
    const { existing, messages, copilot } = await fakeHost(t, { standardConfig: true });
    await copilot.complete({ purpose: 'edit-document', prompt: 'Fictional test prompt' });
    assert.deepEqual(messages.find(({ method }) => method === 'createSession').params.config,
        { mode: 'plan', approvalMode: 'manual', sandboxEnabled: 'on', target: 'workspace' });
    assert.equal((await copilot.complete({ purpose: 'edit-document', prompt: 'Fictional follow-up', sessionId: existing.resource })).text, '# Scope\nGenerated draft');
});

/** 交渉したAHPバージョンに応じて、作業場所を対応するフィールドへ渡す。 */
test('AHP uses the workspace field for the negotiated protocol version', { timeout: 8000 }, async (t) => {
    const { directory, messages, copilot } = await fakeHost(t, { protocolVersion: '0.10.0' });
    await copilot.complete({ purpose: 'edit-document', prompt: 'Protocol compatibility check' });
    const created = messages.find(({ method }) => method === 'createSession');
    assert.equal(created.params.workingDirectory, directory);
    assert.equal(created.params.workingDirectories, undefined);
});

/** 有効なモデル一覧を返し、新規と既存の依頼に選択値を渡すことを検証する。 */
test('AHP lists available models and selects them on new and existing session requests', { timeout: 8000 }, async (t) => {
    const models = [
        { id: 'model-a', name: 'Model A', supportsVision: true, policyState: 'enabled' },
        { id: 'model-b', name: 'Model B' },
        { id: 'disabled', name: 'Disabled', policyState: 'disabled' },
    ];
    const { existing, messages, copilot } = await fakeHost(t, { models, chatState: { model: { id: 'model-a' } } });
    assert.deepEqual((await copilot.status()).models, [
        { id: 'model-a', name: 'Model A', supportsVision: true }, { id: 'model-b', name: 'Model B' },
    ]);
    await assert.rejects(copilot.complete({ purpose: 'edit-document', prompt: 'New draft', modelId: 'disabled' }), { code: 'AHP_MODEL_UNAVAILABLE' });
    assert.equal(messages.some(({ method }) => method === 'createSession'), false);
    await copilot.complete({ purpose: 'edit-document', prompt: 'New draft', modelId: 'model-a' });
    await copilot.complete({ purpose: 'edit-document', prompt: 'Follow-up', sessionId: existing.resource, modelId: 'model-b' });
    await copilot.complete({ purpose: 'edit-document', prompt: 'Default model', sessionId: existing.resource });
    const created = messages.filter(({ method }) => method === 'createSession');
    assert.equal(created.length, 1);
    assert.deepEqual(created[0].params.model, { id: 'model-a' });
    const turns = messages.filter(({ params }) => params?.action?.type === 'chat/turnStarted');
    assert.deepEqual(turns.map(({ params }) => params.action.message.model), [{ id: 'model-a' }, { id: 'model-b' }, undefined]);
});

/** 画像対応モデルに画像データが送り出され、画像非対応モデルでは依頼を止めることを検証する。 */
test('AHP sends embedded image bytes to an existing vision chat and blocks a text-only model', { timeout: 8000 }, async (t) => {
    const models = [{ id: 'text-only', supportsVision: false }, { id: 'vision', supportsVision: true }];
    const attachments = [{ kind: 'image', label: 'test.png', mime: 'image/png', bytes: Buffer.alloc(3) }];
    const embedded = { type: 'embeddedResource', displayKind: 'image', label: 'test.png', contentType: 'image/png', data: 'AAAA' };
    // Some hosts return retained history even when a client asks for a smaller snapshot.
    const earlier = { ...embedded, data: 'A'.repeat(2.5 * 1024 * 1024) };
    const turns = [{ message: { attachments: [earlier] } }, { message: { attachments: [earlier] } }];
    const vision = await fakeHost(t, { models, mode: 'interactive', chatState: { model: { id: 'vision' }, turns } });
    await vision.copilot.complete({ purpose: 'compose-figure', prompt: 'Test image', sessionId: vision.existing.resource, attachments });
    const sent = vision.messages.find(({ params }) => params.action?.type === 'chat/turnStarted').params.action.message;
    assert.deepEqual(sent, { text: 'Test image', origin: { kind: 'user' },
        agent: { uri: vision.agentUri }, attachments: [embedded] });
    assert.deepEqual(vision.messages.find(({ params }) => params?.channel === 'ahp-chat:/test-chat').params.view, { turns: 1 });

    const text = await fakeHost(t, { models, mode: 'interactive', chatState: { model: { id: 'text-only' } } });
    await assert.rejects(text.copilot.complete({ purpose: 'compose-figure', prompt: 'Test image', sessionId: text.existing.resource, attachments }),
        { code: 'AHP_IMAGE_MODEL_REQUIRED' });
    assert.equal(text.messages.some(({ params }) => params.action?.type === 'chat/turnStarted'), false);
    const range = { start: { line: 0, character: 0 }, end: { line: 2, character: 8 } };
    const uri = `${text.directory}/index.md`;
    const files = [
        { kind: 'file', role: 'document', label: 'index.md', uri, range },
        { kind: 'file', role: 'directory', label: 'reference/', uri: `${text.directory}/reference` },
    ];
    await text.copilot.complete({ purpose: 'edit-document', prompt: 'Test document', sessionId: text.existing.resource, attachments: files });
    assert.deepEqual(text.messages.find(({ params }) => params.action?.message?.text === 'Test document').params.action.message.attachments,
        [
            { type: 'resource', displayKind: 'document', label: 'index.md', uri, selection: { range } },
            { type: 'resource', displayKind: 'directory', label: 'reference/', uri: `${text.directory}/reference` },
        ]);
    await assert.rejects(vision.copilot.complete({ purpose: 'compose-figure', prompt: 'Test image', modelId: 'text-only', attachments }), { code: 'AHP_IMAGE_MODEL_REQUIRED' });
    assert.equal(vision.messages.some(({ method }) => method === 'createSession'), false);
    await text.copilot.complete({ purpose: 'compose-figure', prompt: 'Test image', sessionId: text.existing.resource, modelId: 'vision', attachments });
    const override = text.messages.find(({ params }) => params.action?.message?.text === 'Test image').params.action.message;
    assert.deepEqual(override.model, { id: 'vision' });
});

/** 図版エージェントが画像生成ツールを実行し、AHP結果の画像を受け取ることを検証する。 */
test('AHP imports generated images from embedded and resource tool results', { timeout: 8000 }, async (t) => {
    const imageBytes = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10, 1, 2, 3]);
    for (const generatedImage of ['embedded', 'resource']) {
        const { copilot, messages } = await fakeHost(t, { generatedImage, imageBytes, mode: 'interactive', modernConfig: true });
        const result = await copilot.complete({ purpose: 'compose-figure', prompt: 'Generate an illustration' });
        assert.equal(result.text, '{"generated":1}');
        assert.deepEqual(result.generatedImages, [{ mime: 'image/png', bytes: imageBytes }]);
        const created = messages.find(({ method }) => method === 'createSession');
        assert.equal(created.params.config.mode, 'interactive');
        assert.equal(created.params.config.approvals, 'manual');
        assert.equal(messages.find(({ params }) => params.action?.type === 'chat/toolCallConfirmed').params.action.approved, true);
        if (generatedImage === 'resource') assert.ok(messages.some(({ method }) => method === 'resourceRead'));
    }
});

/** 進行中の既存チャットや自動承認のチャットへ、新しい依頼や他のターンの中断を送らないことを検証する。 */
test('AHP refuses to send or cancel in a busy or auto-approved VS Code chat', { timeout: 8000 }, async (t) => {
    const unsafe = await fakeHost(t, { chatState: { config: { values: { autoApprove: 'bypass', effectiveApprovalMode: 'bypass' } } } });
    await assert.rejects(unsafe.copilot.complete({ purpose: 'edit-document', prompt: 'Fictional follow-up', sessionId: unsafe.existing.resource }), { code: 'AHP_APPROVAL_MODE' });
    assert.equal(unsafe.messages.some(({ method }) => method === 'dispatchAction'), false);
    const busy = await fakeHost(t, { chatState: { activeTurn: { id: 'in-vscode' } } });
    await assert.rejects(busy.copilot.complete({ purpose: 'edit-document', prompt: 'Fictional follow-up', sessionId: busy.existing.resource }), { code: 'AHP_SESSION_BUSY' });
    assert.equal(busy.messages.some(({ method }) => method === 'dispatchAction'), false);
});

/** 中断でアプリ自身のターンを止め、セッションは再利用できることを検証する。 */
test('cancelling an AHP job cancels its own turn and retains the session', { timeout: 8000 }, async (t) => {
    const abort = new AbortController();
    const { messages, copilot } = await fakeHost(t, { abort: () => abort.abort(new Error('Test cancelled')) });
    await assert.rejects(copilot.complete({ purpose: 'edit-document', prompt: 'Fictional test prompt', signal: abort.signal }), /Test cancelled/);
    await copilot.listSessions();
    const started = messages.find(({ params }) => params.action?.type === 'chat/turnStarted');
    const cancelled = messages.find(({ params }) => params.action?.type === 'chat/turnCancelled');
    assert.equal(cancelled?.params.action.turnId, started.params.action.turnId);
    assert.equal(messages.some(({ method }) => method === 'disposeSession'), false);
});

/** 自動承認されたツール要求を検出した場合に、セッションを保持したままターンを中断することを検証する。 */
test('an automatically confirmed Copilot tool ends the job and retains the session', { timeout: 8000 }, async (t) => {
    const { messages, copilot } = await fakeHost(t, { automaticTool: true });
    await assert.rejects(copilot.complete({ purpose: 'edit-document', prompt: 'Fictional test prompt' }), { code: 'AHP_TOOL_REQUEST' });
    await copilot.listSessions();
    assert.ok(messages.find(({ params }) => params.action?.type === 'chat/turnCancelled'));
    assert.equal(messages.some(({ method }) => method === 'disposeSession'), false);
});

/** 資料読取ツールの判断をVS Codeに残し、自動承認のコマンド実行を拒否する。 */
test('AHP waits for manual source tool approval and rejects automatic execution', { timeout: 8000 }, async (t) => {
    const manual = await fakeHost(t, { manualTool: 'run_in_terminal' });
    const result = await manual.copilot.complete({ purpose: 'edit-document', prompt: 'Read the attached Excel file' });
    assert.equal(result.text, '# From attachment');
    assert.equal(manual.messages.some(({ params }) => params?.action?.type === 'chat/toolCallConfirmed'), false);

    const automatic = await fakeHost(t, { autoExecuteTool: true });
    await assert.rejects(automatic.copilot.complete({ purpose: 'edit-document', prompt: 'Read the attached Excel file' }),
        { code: 'AHP_TOOL_REQUEST' });
});

test('traceability allows reading while refusing edits and terminal commands', { timeout: 8000 }, async t => {
    const reading = await fakeHost(t, { traceability: true, manualTool: 'read_file' });
    await reading.copilot.complete({ purpose: 'traceability-generate-map', prompt: 'Read the selected requirement' });
    assert.equal(reading.messages.some(({ params }) => params?.action?.type === 'chat/toolCallConfirmed'), false);
    for (const tool of ['edit_file', 'run_in_terminal']) {
        const denied = await fakeHost(t, { traceability: true, manualTool: tool });
        await denied.copilot.complete({ purpose: 'traceability-generate-map', prompt: 'Return candidates only' });
        assert.equal(denied.messages.find(({ params }) => params?.action?.type === 'chat/toolCallConfirmed')?.params.action.approved, false);
    }
});
