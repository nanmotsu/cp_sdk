/**
 * @file 文書の描画処理ごとに、ブラウザーの作成・中断・終了を管理する。
 */

import { launchBrowser } from "./browser.mjs";

/** 描画用ページに要求の制限とスクリプト設定を適用して処理を実行する。失敗・中断時もブラウザーを閉じる。 */
export async function withBrowserPage(run, { signal, scripts = false } = {}) {
    signal?.throwIfAborted();
    const browser = await launchBrowser();
    const stop = () => { void browser.close().catch(() => {}); };
    signal?.addEventListener("abort", stop, { once: true });
    try {
        signal?.throwIfAborted();
        const page = await browser.newPage();
        await page.setJavaScriptEnabled(scripts);
        await page.setRequestInterception(true);
        page.on("request", request => {
            const cycle = /^(?:data:|about:)/i.test(request.url()) ? request.continue() : request.abort();
            void cycle.catch(() => {});
        });
        const result = await run(page);
        signal?.throwIfAborted();
        return result;
    } finally {
        signal?.removeEventListener("abort", stop);
        await browser.close().catch(() => {});
    }
}
