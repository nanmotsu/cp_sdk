/**
 * @file ビルド済みGUIの入口と静的資産をローカルHTTPで配信する。
 */

import { extname } from "node:path";
import { statIfPresent, workspacePath } from "../filesystem/paths.mjs";
import { ApiError, notFound } from "./errors.mjs";
import { sendFile } from "./http.mjs";

const staticTypes = new Map([
    [".html", "text/html; charset=utf-8"], [".js", "text/javascript; charset=utf-8"], [".css", "text/css; charset=utf-8"],
    [".svg", "image/svg+xml"], [".png", "image/png"], [".ico", "image/x-icon"], [".woff2", "font/woff2"],
]);

/** 配信ビルドの静的資産またはGUIの入口HTMLを返す。 */
export async function serveWeb(request, response, webRoot, segments) {
    if (request.method !== "GET" && request.method !== "HEAD") throw notFound("ページが見つかりません。");
    const path = segments.join("/");
    const filename = path && extname(path) ? path : "index.html";
    const type = staticTypes.get(extname(filename));
    if (!type) throw notFound("ファイルが見つかりません。");
    const absolute = await workspacePath(webRoot, filename, { mayBeMissing: true });
    if (!await statIfPresent(absolute)) {
        if (filename !== "index.html") throw notFound("ファイルが見つかりません。");
        throw new ApiError(503, "WEB_BUILD_MISSING", "npm run build でGUIをビルドしてから起動してください。開発時は npm run dev:web を使用できます。");
    }
    return sendFile(request, response, absolute, type);
}
