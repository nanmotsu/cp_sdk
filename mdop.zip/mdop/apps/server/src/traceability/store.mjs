/** ツール実行時のトレーサビリティ保存処理。対象は依頼を開始した時点で固定する。 */
import { createHash, randomUUID } from 'node:crypto';
import { readFile, readdir, writeFile, mkdir, rename, rm, realpath } from 'node:fs/promises';
import { createServer } from 'node:net';
import { tmpdir } from 'node:os';
import { basename, dirname, join } from 'node:path';
import { isDeepStrictEqual } from 'node:util';
import { setTimeout as delay } from 'node:timers/promises';
import { pathParts, workspacePath, ensureWorkspaceDirectory, atomicWrite, statIfPresent } from '../common/filesystem/paths.mjs';
import { badRequest, conflict } from '../common/api/errors.mjs';
import { captureRelation, openRelationVersion, recoverRelation, relationHistory, relationRevision, replaceRelation, relationDiff } from './history.mjs';
import { businessHash, reviewStatus } from './review.mjs';
import { traceabilityMatrix } from './matrix.mjs';
import { traceabilityMarkdown } from './markdown.mjs';
import { availableFolderName, findTraceabilityFolder, folderMatchesName, resolveTraceabilityFolder, traceabilityIdentity, traceabilityName, traceabilityParent } from './directories.mjs';
export { resolveTraceabilityFolder } from './directories.mjs';

const files = ['traceability.json', 'source-items.json', 'target-items.json', 'mappings.json'];
const operations = { source: files[1], target: files[2], map: files[3] };
const pendingCreations = new Map();
const reservations = new Map();
const digest = value => createHash('sha256').update(value).digest('hex');
const nonempty = value => typeof value === 'string' && value.trim().length > 0;
function requireValue(ok, message) { if (!ok) throw badRequest(message); }

async function readState(folder) {
  const contents = {};
  for (const name of files) {
    contents[name] = await readFile(await workspacePath(folder, name), 'utf8');
    JSON.parse(contents[name]);
  }
  return contents;
}
async function snapshot(folder, state, reason, operation, mode, inputVersion, id = randomUUID(), options = {}) {
  return captureRelation(folder, state, { reason, operation, mode, runId: inputVersion ?? id,
    groupId: options.groupId ?? (reason === 'before-run' ? id : undefined),
    startVersion: options.startVersion ?? (reason === 'before-run' ? id : undefined) }, id);
}
export async function createTraceability(root, selection, analyze) {
  selection.signal?.throwIfAborted();
  const { sourceUri, targetUri, granularity } = selection;
  const name = traceabilityName(selection.name);
  requireValue([name, sourceUri, targetUri, granularity].every(nonempty), '表示名、元・先の URI、粒度を指定してください。');
  const id = selection.requestId ?? randomUUID();
  requireValue(typeof id === 'string' && /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(id), '作成依頼 ID が不正です。');
  const fields = { name, sourceUri, targetUri, granularity };
  const parent = await ensureWorkspaceDirectory(await realpath(root), 'traceabilities');
  const requestKey = join(parent, id);
  const pending = pendingCreations.get(requestKey);
  if (pending) {
    requireValue(isDeepStrictEqual(fields, pending.fields), '同じ作成依頼 ID の内容が異なります。');
    return pending.result;
  }
  const result = createOrReplay(parent, id, fields, analyze, selection.signal);
  pendingCreations.set(requestKey, { fields, result });
  try { return await result; } finally { pendingCreations.delete(requestKey); }
}

async function createdResult(folder, id, fields) {
  const path = await workspacePath(folder, 'backups/' + id + '/tree/traceability.json');
  const original = JSON.parse(await readFile(path, 'utf8'));
  requireValue(original.id === id && Object.entries(fields).every(([key, value]) => original[key] === value),
    '同じ作成依頼 ID の内容が異なります。');
  return { id, version: id, folderName: basename(folder) };
}

async function createOrReplay(parent, id, fields, analyze, signal) {
  const existing = await findTraceabilityFolder(parent, id);
  if (existing) return createdResult(existing, id, fields);
  const context = Object.freeze({ id, runId: randomUUID(), operation: 'related', mode: 'generate', ...fields });
  const response = await analyze(context);
  signal?.throwIfAborted();
  const assessment = candidateFor(context, response);
  requireValue(['関連あり','関連が薄い','判定不能'].includes(assessment?.status) && nonempty(assessment.reason), '関係性調査が不正です。');
  const config = { id, ...fields, assessment: { status: assessment.status, reason: assessment.reason }, fixedFiles: [] };
  if (response.copilotSession) config.copilotSession = response.copilotSession;
  const empty = { items: [], scope: { read: [], unread: [] } };
  const data = [config, empty, empty, { rows: [] }];
  const staging = join(parent, '.' + context.runId);
  await mkdir(staging);
  try {
    const state = {};
    for (const [i, file] of files.entries()) {
      state[file] = JSON.stringify(data[i], null, 2) + '\n';
      await writeFile(join(staging, file), state[file]);
    }
    const version = await snapshot(staging, state, 'created', 'related', 'generate', context.runId, id);
    signal?.throwIfAborted();
    const reservation = await reserveWorkspace(parent);
    try {
      const existing = await findTraceabilityFolder(parent, id);
      if (existing) return createdResult(existing, id, fields);
      const folderName = await availableFolderName(parent, fields.name);
      signal?.throwIfAborted();
      await rename(staging, join(parent, folderName));
      return { id, version, folderName };
    } finally { reservation.close(); }
  } finally {
    await rm(staging, { recursive: true, force: true });
  }
}
function checkItems(items) {
  requireValue(Array.isArray(items), '項目は配列で指定してください。');
  const ids = new Set();
  for (const item of items) {
    requireValue(item && nonempty(item.id) && !ids.has(item.id) && nonempty(item.content) && nonempty(item.location) && !Object.hasOwn(item, 'fixed'), '項目には ID・本文・位置を指定してください。固定は JSON ファイル単位です。');
    ids.add(item.id);
  }
  return ids;
}
function checkItemTable(table) {
  const scope = table?.scope;
  requireValue(Array.isArray(scope?.read) && scope.read.every(nonempty)
    && Array.isArray(scope.unread) && scope.unread.every(nonempty), '項目表には読取済み・未読の範囲を指定してください。');
  return checkItems(table.items);
}
function result(operation, candidate, state, mode, inputVersion) {
  const original = JSON.parse(state[operations[operation]]);
  if (operation !== 'map') {
    const ids = checkItemTable(candidate);
    if (mode === 'revise') {
      for (const old of original.items) requireValue(ids.has(old.id), '修正・追記では既存 ID を保持してください: ' + old.id);
    }
    return candidate;
  }
  const source = checkItemTable(JSON.parse(state[files[1]]));
  const targetTable = JSON.parse(state[files[2]]);
  const target = checkItemTable(targetTable);
  const partial = mode === 'revise';
  const rows = new Map(partial ? original.rows.map(row => [row.sourceId, row]) : []);
  requireValue(!partial || rows.size === original.rows.length, '既存の元 ID が重複しており、修正行を特定できません。');
  requireValue(Array.isArray(candidate) && (partial || candidate.length === source.size), '元項目の判定数が一致しません。');
  const touched = new Set();
  for (const row of candidate) {
    requireValue(row && nonempty(row.id) && nonempty(row.sourceId) && !touched.has(row.sourceId), '判定 ID が空か元 ID が重複しています。');
    touched.add(row.sourceId);
    const old = rows.get(row.sourceId);
    if (partial && isDeepStrictEqual(row, old)) continue;
    requireValue(source.has(row.sourceId), '不明な元 ID です。');
    requireValue(!old || old.id === row.id, '既存の判定 ID が変更されています。');
    requireValue(Array.isArray(row.targetIds) && row.targetIds.every(id => target.has(id))
      && new Set(row.targetIds).size === row.targetIds.length, '先 ID の配列を確認してください。');
    requireValue(['全','ほぼ','一部','未','判定不能'].includes(row.degree) && nonempty(row.detail), '判定と理由が必要です。');
    requireValue(row.degree === '判定不能' || (row.degree === '未' ? !row.targetIds.length : row.targetIds.length > 0), '対応度と先 ID の件数が矛盾します。');
    requireValue(row.degree !== '未' || targetTable.scope.read.length > 0, '未の判定には調査済みの範囲が必要です。');
    rows.set(row.sourceId, row);
  }
  const merged = [...rows.values()];
  requireValue(new Set(merged.map(row => row.id)).size === merged.length, '判定 ID が重複しています。');
  if (partial) return { ...original, rows: merged };
  return { inputVersion, rows: merged };
}

// OS の IPC エンドポイントで同じ関係への並行保存を防ぐ。関係フォルダには書き込まない。
async function reserveWorkspace(folder) {
  const windows = process.platform === 'win32';
  const key = 'mdop-' + digest(windows ? folder.toLowerCase() : folder).slice(0, 32);
  const previous = reservations.get(key) ?? Promise.resolve();
  let release;
  const current = new Promise(resolve => { release = resolve; });
  reservations.set(key, current);
  await previous;
  const endpoint = windows ? '\\\\.\\pipe\\' + key : process.platform === 'linux' ? '\0' + key : join(tmpdir(), key);
  const server = createServer(socket => socket.destroy());
  try {
    await new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(endpoint, resolve);
    });
  } catch (error) {
    release();
    if (reservations.get(key) === current) reservations.delete(key);
    throw error;
  }
  return { close() { server.close(() => {
    release();
    if (reservations.get(key) === current) reservations.delete(key);
  }); } };
}

async function alignFolderName(folder, name) {
  const parent = dirname(folder);
  const currentName = basename(folder);
  if (folderMatchesName(currentName, name)) return folder;
  const reservation = await reserveWorkspace(parent);
  try {
    const nextName = await availableFolderName(parent, name, currentName);
    const next = join(parent, nextName);
    for (let attempt = 0; ; attempt++) {
      try { await rename(folder, next); break; }
      catch (error) {
        if (attempt >= 5 || !['EBUSY', 'EPERM', 'EACCES'].includes(error.code)) throw error;
        await delay(50 * 2 ** attempt);
      }
    }
    return next;
  } finally { reservation.close(); }
}

async function replaceNamedRelation(folder, tree, revision, beforeVersion) {
  await replaceRelation(folder, tree, revision);
  const config = JSON.parse(await readFile(join(folder, files[0]), 'utf8'));
  try { return await alignFolderName(folder, config.name); }
  catch (error) {
    const previous = await openRelationVersion(folder, beforeVersion);
    await replaceRelation(folder, previous.tree, await relationRevision(folder));
    throw error;
  }
}

/** ツールの API が使う読み込み・手保存・履歴・出力をまとめる。 */
export function createTraceabilityStore(root) {
  async function access(id, operation) {
    requireValue(pathParts(id).length === 1, '関係 ID が不正です。');
    const parent = await traceabilityParent(root);
    const reservation = await reserveWorkspace(join(parent, '.id-' + id));
    try {
      let folder = await resolveTraceabilityFolder(root, id);
      await recoverRelation(folder);
      const config = JSON.parse(await readFile(await workspacePath(folder, files[0]), 'utf8'));
      folder = await alignFolderName(folder, traceabilityName(config.name));
      return await operation(folder);
    } finally { reservation.close(); }
  }

  async function parsed(folder) {
    const raw = await readState(folder);
    return { raw, config: JSON.parse(raw[files[0]]), source: JSON.parse(raw[files[1]]),
      target: JSON.parse(raw[files[2]]), mappings: JSON.parse(raw[files[3]]) };
  }

  async function detail(folder, id, version) {
    const currentFolder = version ? (await openRelationVersion(folder, version)).tree : folder;
    const state = await parsed(currentFolder);
    requireValue(state.config.id === id, '関係フォルダと設定の ID が一致しません。');
    const recordPath = join(currentFolder, 'review-state.json');
    const records = await statIfPresent(recordPath) ? JSON.parse(await readFile(recordPath, 'utf8')) : {};
    let basis;
    if (state.mappings.inputVersion) {
      try {
        const baseline = await openRelationVersion(folder, state.mappings.inputVersion);
        const value = await parsed(baseline.tree);
        basis = { source: value.source, target: value.target };
      } catch { /* 入力版が読めなければ比較不能を表示する。 */ }
    }
    const review = reviewStatus(state, records, basis, state.mappings.inputVersion);
    const matrix = traceabilityMatrix(state.source, state.target, state.mappings);
    return { id, folderName: basename(folder), config: state.config, source: state.source, target: state.target, mappings: state.mappings,
      revision: await relationRevision(currentFolder), review, matrix, ...(version && { version }) };
  }

  function expected(actual, revision) {
    requireValue(typeof revision === 'string', '表示中の版を指定してください。');
    if (actual !== revision) throw conflict('保存後に関係が更新されました。再読み込みしてください。', { revision: actual });
  }

  async function save(id, input) {
    return access(id, async folder => {
      const currentRevision = await relationRevision(folder);
      expected(currentRevision, input.revision);
      const state = await parsed(folder);
      const source = input.source ?? state.source;
      const target = input.target ?? state.target;
      const sourceIds = checkItemTable(source);
      checkItemTable(target);
      const fixedFiles = input.fixedFiles ?? state.config.fixedFiles ?? [];
      requireValue(Array.isArray(fixedFiles) && fixedFiles.every(name => Object.values(operations).includes(name))
        && new Set(fixedFiles).size === fixedFiles.length, '固定設定が不正です。');
      const removedIds = input.deleteMappingIds ?? [];
      requireValue(Array.isArray(removedIds) && new Set(removedIds).size === removedIds.length, '削除する判定 ID が不正です。');
      for (const value of removedIds) {
        const old = state.mappings.rows.find(row => row.id === value);
        requireValue(old && !sourceIds.has(old.sourceId), '元項目なしの判定行だけを明示して削除できます。');
      }
      const candidate = input.mappings?.rows ?? state.mappings.rows.filter(row => !removedIds.includes(row.id));
      requireValue(Array.isArray(candidate), '判定表を配列で指定してください。');
      for (const old of state.mappings.rows) {
        requireValue(removedIds.includes(old.id) || candidate.some(row => row.id === old.id), '判定行の削除対象 ID を明示してください。');
      }
      requireValue(!candidate.some(row => removedIds.includes(row.id)), '削除指定した判定行が残っています。');
      const raw = { ...state.raw, [files[1]]: JSON.stringify(source), [files[2]]: JSON.stringify(target) };
      const retained = { ...state.mappings, rows: state.mappings.rows.filter(row => !removedIds.includes(row.id)) };
      raw[files[3]] = JSON.stringify(retained);
      const mappings = result('map', candidate, raw, 'revise');
      const name = input.name === undefined ? state.config.name : traceabilityName(input.name);
      const config = { ...state.config, name, fixedFiles };
      const next = Object.fromEntries([config, source, target, mappings].map((value, index) => [files[index], JSON.stringify(value, null, 2) + '\n']));
      const runId = randomUUID();
      const beforeVersion = await snapshot(folder, state.raw, 'before-save', 'manual', 'revise', runId);
      const version = await snapshot(folder, next, 'saved', 'manual', 'revise', runId);
      const tree = (await openRelationVersion(folder, version)).tree;
      const renamed = await replaceNamedRelation(folder, tree, currentRevision, beforeVersion);
      return { ...await detail(renamed, id), savedVersion: version };
    });
  }

  async function confirm(id, input) {
    return access(id, async folder => {
      const currentRevision = await relationRevision(folder);
      expected(currentRevision, input.revision);
      requireValue(Array.isArray(input.sides) && input.sides.length > 0
        && input.sides.every(side => ['source', 'target'].includes(side)), '確認する項目表を指定してください。');
      const state = await parsed(folder);
      const path = join(folder, 'review-state.json');
      const records = await statIfPresent(path) ? JSON.parse(await readFile(path, 'utf8')) : {};
      const baseline = await snapshot(folder, state.raw, 'before-confirm', 'review', 'confirm');
      for (const side of input.sides) records[side] = { hash: businessHash(state[side]), version: baseline, confirmedAt: new Date().toISOString() };
      const version = await snapshot(folder, { ...state.raw, 'review-state.json': JSON.stringify(records, null, 2) + '\n' }, 'confirmed', 'review', 'confirm', baseline);
      await replaceRelation(folder, (await openRelationVersion(folder, version)).tree, currentRevision);
      return detail(folder, id);
    });
  }

  return {
    async list() {
      const parent = await ensureWorkspaceDirectory(await realpath(root), 'traceabilities');
      const result = [];
      for (const entry of await readdir(parent, { withFileTypes: true })) {
        if (!entry.isDirectory() || entry.name.startsWith('.')) continue;
        try {
          const original = await workspacePath(parent, entry.name, { directory: true });
          const identity = await traceabilityIdentity(original);
          requireValue(identity?.id, '関係の UUID を読み取れません。');
          result.push(await access(identity.id, async folder => {
            const config = JSON.parse(await readFile(await workspacePath(folder, files[0]), 'utf8'));
            const history = await relationHistory(folder);
            return { id: config.id, folderName: basename(folder), name: config.name, sourceUri: config.sourceUri, targetUri: config.targetUri,
              updatedAt: history[0]?.createdAt, assessment: config.assessment };
          }));
        } catch (error) { result.push({ id: entry.name, name: entry.name, error: error.message }); }
      }
      return result.sort((a, b) => (b.updatedAt ?? '').localeCompare(a.updatedAt ?? ''));
    },
    get: (id, version) => access(id, folder => detail(folder, id, version)),
    save, confirm,
    history: id => access(id, relationHistory),
    diff: (id, fromVersion, toVersion) => access(id, async folder => {
      requireValue(fromVersion, '比較元の版を選んでください。');
      const left = (await openRelationVersion(folder, fromVersion)).tree;
      const right = toVersion ? (await openRelationVersion(folder, toVersion)).tree : folder;
      return { fromVersion, toVersion: toVersion ?? null, ...await relationDiff(left, right) };
    }),
    restore: (id, version, input) => access(id, async folder => {
      const revision = await relationRevision(folder);
      expected(revision, input.revision);
      const target = await openRelationVersion(folder, version);
      requireValue((await parsed(target.tree)).config.id === id, '別の関係の版は復元できません。');
      const before = await snapshot(folder, (await parsed(folder)).raw, 'before-restore', 'restore', 'restore');
      const renamed = await replaceNamedRelation(folder, target.tree, revision, before);
      const restoredVersion = await snapshot(renamed, (await parsed(renamed)).raw, 'restored', 'restore', 'restore', before);
      return { ...await detail(renamed, id), restoredVersion, beforeVersion: before };
    }),
    markdown: (id, version) => access(id, async folder => traceabilityMarkdown(await detail(folder, id, version))),
    getSession: id => access(id, async folder => (await parsed(folder)).config.copilotSession ?? null),
    setSession: (id, binding) => access(id, async folder => {
      requireValue(binding?.relationId === id && nonempty(binding.sessionId), 'セッションと関係の ID が一致しません。');
      const state = await parsed(folder);
        if (isDeepStrictEqual(state.config.copilotSession, binding)) return binding;
        const next = { ...state.config, copilotSession: binding };
      await atomicWrite(join(folder, files[0]), JSON.stringify(next, null, 2) + '\n');
      return binding;
    }),
  };
}

function inputsUnchanged(before, current, operation) {
  const config = JSON.parse(before[files[0]]);
  const latest = JSON.parse(current[files[0]]);
  delete config.assessment;
  delete latest.assessment;
  delete config.copilotSession;
  delete latest.copilotSession;
  if (!isDeepStrictEqual(config, latest)) return false;
  const tables = operation === 'map' ? files.slice(1) : [operations[operation]];
  return tables.every(name => isDeepStrictEqual(JSON.parse(before[name]), JSON.parse(current[name])));
}

function candidateFor(context, response) {
  requireValue(response?.id === context.id && response?.runId === context.runId
    && response.operation === context.operation && response.mode === context.mode,
    '応答が今回の関係・操作・実行 ID と一致しません。');
  return response.candidate;
}

export async function beginTraceability(root, id, operation, mode = 'generate', options = {}) {
  options.signal?.throwIfAborted();
  requireValue(pathParts(id).length === 1, '関係 ID が不正です。');
  requireValue(operation !== 'related', '①の関係性調査は新規作成時のみ実行できます。');
  requireValue(Object.hasOwn(operations, operation) && ['revise', 'generate'].includes(mode), '更新操作が不正です。');
  const parent = await traceabilityParent(root);
  const file = operations[operation];
  const reservation = await reserveWorkspace(join(parent, '.id-' + id));
  let context;
  let before;
  try {
    let folder = await resolveTraceabilityFolder(root, id);
    await recoverRelation(folder);
    const initialConfig = JSON.parse(await readFile(await workspacePath(folder, files[0]), 'utf8'));
    folder = await alignFolderName(folder, traceabilityName(initialConfig.name));
    before = await readState(folder);
    const config = JSON.parse(before[files[0]]);
    requireValue(config.id === id, '関係フォルダと設定の ID が一致しません。');
    const { fixedFiles = [] } = config;
    requireValue(Array.isArray(fixedFiles), '固定設定が不正です。');
    if (fixedFiles.includes(file)) return { skipped: true, file };
    const runId = await snapshot(folder, before, 'before-run', operation, mode, undefined, undefined, options);
    options.signal?.throwIfAborted();
    context = Object.freeze({
      id, runId, operation, mode, file, inputTree: join(folder, 'backups', runId, 'tree'),
      name: config.name, sourceUri: config.sourceUri, targetUri: config.targetUri, granularity: config.granularity,
      groupId: options.groupId ?? runId, startVersion: options.startVersion ?? runId,
    });
  } finally { reservation.close(); }

  let saved;
  return {
    context,
    async save(response) {
      options.signal?.throwIfAborted();
      const candidate = candidateFor(context, response);
      const reservation = await reserveWorkspace(join(parent, '.id-' + id));
      try {
        if (saved) return saved;
        const folder = await resolveTraceabilityFolder(root, id);
        await recoverRelation(folder);
        const current = await readState(folder);
        if (!inputsUnchanged(before, current, operation)) throw conflict('開始後に使用する入力または保存先が変わりました。現行版を保持します。');
        const next = JSON.stringify(result(operation, candidate, before, mode, context.runId), null, 2) + '\n';
        const version = await snapshot(folder, { ...current, [file]: next }, mode === 'revise' ? 'revised' : 'generated', operation, mode, context.runId, undefined,
          { groupId: context.groupId, startVersion: context.startVersion });
        options.signal?.throwIfAborted();
        await atomicWrite(join(folder, file), next, { signal: options.signal });
        saved = { id, file, version };
        return saved;
      } finally { reservation.close(); }
    },
  };
}
