/**
 * @file VS CodeのAgent Hostを検出し、WebSocket上のAHP要求・応答と状態変更イベントを扱う。
 */

import { randomUUID } from 'node:crypto';
import { EventEmitter, on, once } from 'node:events';
import { readdir, readFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { isAbsolute, join } from 'node:path';
import WebSocket from 'ws';
import { ApiError } from '../api/errors.mjs';

export const ROOT = 'ahp-root://';
const SUPPORTED_PROTOCOLS = ['1.2.0', '1.1.0', '1.0.0', '0.10.0', '0.9.0'];
const IPC_PATH = /^\\\\\.\\pipe\\[^:?\0]+$/;
const CONNECT_TIMEOUT = 3000;
const RECEIVE_LIMIT = 32 * 1024 * 1024;

/** 明示されたユーザーデータの場所を優先し、省略時はOSごとのVS CodeとInsidersの既定候補を返す。 */
function defaultUserDataDirs() {
    const explicitPath = process.env.MD_OPERATOR_VSCODE_USER_DATA;
    if (explicitPath) return [explicitPath];
    const home = homedir();
    const dataRoot = process.platform === 'win32'
        ? process.env.APPDATA || join(home, 'AppData', 'Roaming')
        : process.platform === 'darwin'
            ? join(home, 'Library', 'Application Support')
            : process.env.XDG_CONFIG_HOME || join(home, '.config');
    return [join(dataRoot, 'Code'), join(dataRoot, 'Code - Insiders')];
}

/** Agent Hostの接続情報を読み込む。読めない候補は探索から除外する。 */
async function readMetadata(path) {
    try {
        return JSON.parse(await readFile(path, 'utf8'));
    } catch {
        return null;
    }
}

/** 接続情報をローカルのソケットまたはループバックの接続先へ変換する。 */
function endpointUrl(record) {
    if (!record || typeof record !== 'object' || !['editor', 'standalone'].includes(record.type)) return null;
    if (!Number.isInteger(record.pid) || record.pid < 1 || typeof record.instanceId !== 'string') return null;
    if (typeof record.protocolVersion !== 'string' || typeof record.connectionToken !== 'string' || !/^[A-Za-z0-9_-]{1,512}$/.test(record.connectionToken)) return null;
    try {
        process.kill(record.pid, 0);
    } catch (error) {
        if (error.code === 'ESRCH') return null;
    }
    const endpoint = record.schemaVersion === 1
        ? { type: 'socket', path: record.endpointPath }
        : record.schemaVersion === 2 ? record.endpoint : null;
    const query = `?tkn=${encodeURIComponent(record.connectionToken)}`;
    if (endpoint?.type === 'socket' && typeof endpoint.path === 'string') {
        const valid = process.platform === 'win32'
            ? IPC_PATH.test(endpoint.path)
            : isAbsolute(endpoint.path) && !/[:?\0]/.test(endpoint.path);
        return valid ? `ws+unix:${endpoint.path.replaceAll('%', '%25')}:/${query}` : null;
    }
    if (endpoint?.type === 'tcp' && ['127.0.0.1', '::1'].includes(endpoint.host) && Number.isInteger(endpoint.port) && endpoint.port > 0 && endpoint.port <= 65_535) {
        const host = endpoint.host === '::1' ? '[::1]' : endpoint.host;
        return `ws://${host}:${endpoint.port}/${query}`;
    }
    return null;
}

/** VS Codeのユーザーデータから有効な接続先を集め、接続候補を返す。 */
export async function discoverAhpEndpoints(userDataDirs = defaultUserDataDirs()) {
    const records = [];
    for (const dataDir of userDataDirs) {
        const registry = join(dataDir, 'agent-host', 'local-endpoint');
        const entriesDir = join(registry, 'entries');
        const entries = await readdir(entriesDir, { withFileTypes: true }).catch(() => []);
        const paths = entries.filter((entry) => entry.isFile() && /^[a-f0-9]{64}\.json$/.test(entry.name)).slice(0, 32);
        records.push(...await Promise.all(paths.map((entry) => readMetadata(join(entriesDir, entry.name)))));
        records.push(await readMetadata(join(registry, 'metadata.json')));
    }
    const seen = new Set();
    const endpoints = [];
    for (const record of records) {
        const url = endpointUrl(record);
        if (!url) continue;
        const id = `${record.type}:${record.pid}:${record.instanceId}`;
        if (seen.has(id)) continue;
        seen.add(id);
        endpoints.push({ type: record.type, url });
    }
    return endpoints.sort((first, second) => Number(second.type === 'editor') - Number(first.type === 'editor'));
}

/** WebSocket上のJSON-RPC要求と、AHPのアクション通知を同じ接続で管理する。 */
export class AhpConnection extends EventEmitter {
    #pending = new Map();
    #requestId = 0;
    #sequence = 0;
    #closeReason;

    /** 接続が開くまで待機し、中断や接続失敗時はソケットを閉じる。 */
    static async open(url, signal) {
        let connection;
        try {
            const socket = new WebSocket(url, { handshakeTimeout: CONNECT_TIMEOUT, maxPayload: RECEIVE_LIMIT, perMessageDeflate: false });
            connection = new AhpConnection(socket);
            await once(socket, 'open', { signal });
            return connection;
        } catch {
            connection?.close();
            signal?.throwIfAborted();
            throw new ApiError(503, 'AHP_CONNECT_FAILED', 'VS CodeのAgent Hostへ接続できませんでした。');
        }
    }

    /** ソケットのイベントを受け、応答IDに対応する待機処理と、アクションの購読へ振り分ける。 */
    constructor(socket) {
        super();
        this.socket = socket;
        socket.on('message', (bytes, binary) => {
            if (binary) return;
            let message;
            try {
                message = JSON.parse(bytes.toString());
            } catch {
                return;
            }
            if (!message || message.jsonrpc !== '2.0') return;
            if (message.id !== undefined && typeof message.method === 'string') {
                if (this.socket.readyState === WebSocket.OPEN) {
                    this.#send({ id: message.id, error: { code: -32601, message: 'Method not supported by this client' } });
                }
            } else if (message.id !== undefined) {
                this.#pending.get(message.id)?.(message);
            } else if (message.method === 'action' && message.params?.channel) {
                this.emit(message.params.channel, message.params);
            }
        });
        socket.on('error', (error) => this.#onClose(error));
        socket.on('close', () => this.#onClose());
    }

    get closeReason() {
        return this.#closeReason;
    }

    /** 接続終了を記録し、応答を待っている要求と通知の購読を終了する。 */
    #onClose(error) {
        if (this.#closeReason) return;
        this.#closeReason = error?.code === 'WS_ERR_UNSUPPORTED_MESSAGE_LENGTH'
            ? new ApiError(413, 'AHP_MESSAGE_TOO_LARGE', 'Agent Hostから受信した会話履歴または添付ファイルが大きすぎます。別のCopilotセッションを選んでください。')
            : new ApiError(503, 'AHP_DISCONNECTED', 'Agent Hostとの接続が切れました。');
        for (const finish of this.#pending.values()) finish(null);
        this.emit('closed');
    }

    /** 接続状態を検査し、プロトコルのメッセージをJSONで送る。 */
    #send(message) {
        if (this.socket.readyState !== WebSocket.OPEN) throw this.#closeReason ?? new ApiError(503, 'AHP_DISCONNECTED', 'Agent Hostとの接続が切れました。');
        this.socket.send(JSON.stringify({ jsonrpc: '2.0', ...message }));
    }

    /** 一意なIDで要求を送信し、応答・タイムアウト・中断のいずれかまで待つ。 */
    request(method, params, { signal, timeout = 8000 } = {}) {
        return new Promise((resolve, reject) => {
            signal?.throwIfAborted();
            const id = ++this.#requestId;
            const cleanup = () => {
                clearTimeout(timer);
                signal?.removeEventListener('abort', abort);
                this.#pending.delete(id);
            };
            const abort = () => {
                cleanup();
                reject(signal.reason);
            };
            const timer = setTimeout(() => {
                cleanup();
                reject(new ApiError(504, 'AHP_TIMEOUT', `Agent Hostから応答がありませんでした（${method}）。`));
            }, timeout);
            signal?.addEventListener('abort', abort, { once: true });
            this.#pending.set(id, (response) => {
                cleanup();
                if (!response) reject(this.#closeReason);
                else if (response.error) {
                    const detail = String(response.error.message ?? '').split(/\r?\n/)[0].slice(0, 300);
                    const error = new ApiError(502, 'AHP_REQUEST_FAILED', `Agent Hostで ${method} に失敗しました。${detail ? ` ${detail}` : ''}`);
                    error.rpcCode = response.error.code;
                    reject(error);
                } else resolve(response.result);
            });
            try {
                this.#send({ id, method, params });
            } catch (error) {
                cleanup();
                reject(error);
            }
        });
    }

    /** 指定チャンネルのアクションを非同期反復で受け取る。 */
    actions(channel, signal) {
        return on(this, channel, { signal, close: ['closed'] });
    }

    /** チャンネルにアクションを通知として送る。 */
    dispatch(channel, action) {
        this.#send({ method: 'dispatchAction', params: { channel, clientSeq: ++this.#sequence, action } });
    }

    /** 指定したチャンネルのターンに中断アクションを送る。 */
    cancelTurn(channel, turnId) {
        if (this.socket.readyState === WebSocket.OPEN) this.dispatch(channel, { type: 'chat/turnCancelled', turnId });
    }

    /** 呼び出し元が使用を終えた接続を閉じる。 */
    close() {
        if (this.socket.readyState === WebSocket.CONNECTING) this.socket.terminate();
        else this.socket.close();
    }
}

/** 接続候補を順に試し、プロトコルを初期化して利用可能なエージェントを選ぶ。 */
export async function connectAgentHost({ selectAgent, discover = discoverAhpEndpoints, signal }) {
    const endpoints = await discover();
    if (!endpoints.length) throw new ApiError(503, 'AHP_HOST_NOT_FOUND', 'VS CodeのAgent Hostが見つかりません。VS CodeでCopilotのエージェントを有効にしてください。');
    let failure;
    for (const endpoint of endpoints) {
        signal?.throwIfAborted();
        let connection;
        try {
            const handshakeSignal = signal ? AbortSignal.any([signal, AbortSignal.timeout(CONNECT_TIMEOUT)]) : AbortSignal.timeout(CONNECT_TIMEOUT);
            connection = await AhpConnection.open(endpoint.url, handshakeSignal);
            const result = await connection.request('initialize', {
                channel: ROOT,
                clientId: `md-operator-${randomUUID()}`,
                protocolVersions: SUPPORTED_PROTOCOLS,
                initialSubscriptions: [ROOT],
                _meta: { 'vscode.ahpSessionUris': true, 'vscode.ahpChatUris': true },
            }, { signal: handshakeSignal });
            if (!SUPPORTED_PROTOCOLS.includes(result?.protocolVersion)) throw new ApiError(503, 'AHP_PROTOCOL_MISMATCH', 'VS CodeのAgent Hostが対応するAHPバージョンを選択できませんでした。');
            const root = result.snapshots?.find((snapshot) => snapshot.resource === ROOT)?.state
                ?? (await connection.request('subscribe', { channel: ROOT }, { signal: handshakeSignal }))?.snapshot?.state;
            const agent = selectAgent(root?.agents ?? []);
            return { connection, agent, protocolVersion: result.protocolVersion };
        } catch (error) {
            connection?.close();
            failure = error;
        }
    }
    signal?.throwIfAborted();
    if (failure?.name === 'TimeoutError' || failure?.name === 'AbortError') throw new ApiError(504, 'AHP_TIMEOUT', 'VS CodeのAgent Hostへの接続がタイムアウトしました。');
    throw failure;
}
