/**
 * @file 文書一覧と編集欄の境界を、ポインターやキーボードで動かせるようにする。
 */

import { useEffect, useRef, useState } from 'react';
import type { KeyboardEvent, PointerEvent, RefObject } from 'react';

/** 画面幅と他の欄の最小幅から、文書一覧に割り当てられる幅を求める。 */
function measure(sidebar: HTMLElement, layout: HTMLElement) {
  const styles = getComputedStyle(layout);
  const min = parseFloat(styles.getPropertyValue('--sidebar-min-width'));
  const editorMin = parseFloat(styles.getPropertyValue('--editor-min-width'));
  const inspectorMin = parseFloat(styles.getPropertyValue('--inspector-min-width'));
  const gap = parseFloat(styles.getPropertyValue('--workspace-gap'));
  const padding = parseFloat(styles.paddingLeft) + parseFloat(styles.paddingRight);
  const max = Math.max(min, layout.clientWidth - padding - editorMin - inspectorMin - 2 * gap);
  return { width: sidebar.offsetWidth, min, max };
}

/** 文書一覧の幅調整ハンドルを表示し、ダブルクリックで初期幅へ戻す。 */
export default function SidebarResize({ sidebar, hidden }: {
  sidebar: RefObject<HTMLElement | null>;
  hidden: boolean;
}) {
  const drag = useRef<{ pointerId: number; x: number; width: number } | null>(null);
  const [size, setSize] = useState({ width: 0, min: 0, max: 0 });

  useEffect(() => {
    const tree = sidebar.current;
    const layout = tree?.parentElement;
    if (!tree || !layout) return;
    const observer = new ResizeObserver(() => setSize(measure(tree, layout)));
    observer.observe(tree);
    observer.observe(layout);
    return () => observer.disconnect();
  }, [sidebar]);

  /** 希望幅を設定し、引数省略時は画面幅に応じた初期幅へ戻す。 */
  function resize(width?: number) {
    const tree = sidebar.current;
    const layout = tree?.parentElement;
    if (!tree || !layout) return;
    if (width === undefined) layout.style.removeProperty('--sidebar-requested-width');
    else {
      const { min, max } = measure(tree, layout);
      layout.style.setProperty('--sidebar-requested-width', `${Math.min(max, Math.max(min, width))}px`);
    }
  }

  /** ドラッグ開始時の位置と幅を記録する。 */
  function start(event: PointerEvent<HTMLDivElement>) {
    if (event.button !== 0 || !sidebar.current) return;
    drag.current = { pointerId: event.pointerId, x: event.clientX, width: sidebar.current.offsetWidth };
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  /** ポインターの移動量を文書一覧の幅へ反映する。 */
  function move(event: PointerEvent<HTMLDivElement>) {
    const active = drag.current;
    if (active?.pointerId === event.pointerId) resize(active.width + event.clientX - active.x);
  }

  /** 矢印キーで幅を調整し、HomeとEndで範囲の端へ移動する。 */
  function keyboard(event: KeyboardEvent<HTMLDivElement>) {
    const tree = sidebar.current;
    const layout = tree?.parentElement;
    if (!tree || !layout) return;
    const { width, min, max } = measure(tree, layout);
    const step = event.shiftKey ? 48 : 16;
    const widths: Record<string, number> = { ArrowLeft: width - step, ArrowRight: width + step, Home: min, End: max };
    const next = Object.hasOwn(widths, event.key) ? widths[event.key] : undefined;
    if (next === undefined) return;
    event.preventDefault();
    resize(next);
  }

  return <div className="sidebar-resize" role="separator" aria-orientation="vertical" aria-label="文書一覧の幅"
    aria-controls="workspace-documents" aria-valuenow={size.width} aria-valuemin={size.min} aria-valuemax={size.max}
    tabIndex={hidden ? -1 : 0} hidden={hidden}
    title="ドラッグまたは矢印キーで文書一覧の幅を調整。ダブルクリックで初期幅に戻す"
    onPointerDown={start} onPointerMove={move} onLostPointerCapture={() => { drag.current = null; }}
    onKeyDown={keyboard} onDoubleClick={() => resize()} />;
}
