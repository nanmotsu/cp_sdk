/**
 * @file 原本、設定、履歴、資産、出力の各ストアを同じ文書ルートに接続する。
 */

import { createConfigStore } from "./config/store.mjs";
import { loadCopilotTemplates } from "./assistance/templates.mjs";
import { createOutputStore } from "./export/output.mjs";
import { createAssetStore } from "./figures/assets.mjs";
import { createHistoryStore } from "./history/store.mjs";
import { createMarkdownStore } from "./markdown/store.mjs";
import { createDocumentWorkspace } from "./shared/workspace.mjs";

/** 各文書機能で、同じロックと復元状態を使うストアを作る。 */
export async function createDocumentStore(documentsRoot) {
    const workspace = await createDocumentWorkspace(documentsRoot);
    const { access, documentRoot, restoreVersion, checkRestoreVersion } = workspace;
    return { access, documentRoot, restoreVersion, checkRestoreVersion,
        copilotTemplates: id => access(id, folder => loadCopilotTemplates(workspace.root, folder)),
        ...createMarkdownStore(workspace), ...createConfigStore(workspace),
        ...createHistoryStore(workspace), ...createAssetStore(workspace), ...createOutputStore(workspace) };
}
