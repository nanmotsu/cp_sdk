/**
 * @file 文書本文とアップロードの入力形式・容量を検証する。
 */

import { ApiError, badRequest } from "../../common/api/errors.mjs";

/** 原本Markdownの読み書きで許容するバイト上限。 */
export const MARKDOWN_LIMIT = 5 * 1024 * 1024;
/** 一般の添付ファイルを復号する際の既定バイト上限。 */
export const ASSET_LIMIT = 20 * 1024 * 1024;

/** データが呼び出し元で指定した容量を超えた場合に413を返す。 */
export function checkSize(size, limit) {
    if (size > limit) throw new ApiError(413, "PAYLOAD_TOO_LARGE", `上限は ${Math.round(limit / 1024)} KiB です。`);
}

/** APIから受け取った値が文字列で、UTF-8のバイト上限内にあることを確認する。 */
export function textInput(value, label, limit = MARKDOWN_LIMIT) {
    if (typeof value !== "string") throw badRequest(`${label} は文字列で指定してください。`);
    checkSize(Buffer.byteLength(value), limit);
    return value;
}

/** 入力文字列と復号後のサイズ、Base64の形式を検査してバイト列を返す。 */
export function decodeBase64(value, limit = ASSET_LIMIT) {
    if (typeof value !== "string" || !value) throw badRequest("ファイルの内容をBase64で指定してください。");
    checkSize(value.length, Math.ceil(limit / 3) * 4);
    const padding = value.length - value.replace(/={1,2}$/, "").length;
    if (value.length % 4 !== 0 || /[^a-z\d+/]/i.test(value.slice(0, value.length - padding))) {
        throw badRequest("ファイルのBase64形式を確認してください。");
    }
    const data = Buffer.from(value, "base64");
    checkSize(data.length, limit);
    return data;
}
