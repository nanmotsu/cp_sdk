/**
 * @file PDF・Wordの出力とWord取り込みをジョブとして登録する。
 */

import { extname } from "node:path";
import { ApiError, badRequest, conflict } from "../../common/api/errors.mjs";
import { pathParts } from "../../common/filesystem/paths.mjs";
import { requireConfig } from "../config/yaml.mjs";
import { assetLink } from "../figures/asset-links.mjs";
import { createFigureStore } from "../figures/store.mjs";
import { decodeBase64, textInput } from "../shared/input.mjs";
import { assertRevisionHistoryOption, readJobDocument } from "../shared/job-context.mjs";
import { exportRelativePath } from "./output.mjs";
import { renderDocx, renderPdf } from "./render.mjs";
import { importDocx } from "./word.mjs";

/** Wordから抽出した画像を一枚ずつ図版として保存し、同じ版のMarkdownへ参照を入れる。 */
async function storeWordFigures(tree, result, signal) {
    let content = result.content;
    const figures = createFigureStore(async () => tree);
    for (const asset of result.assets) {
        signal.throwIfAborted();
        if (!content.includes(asset.placeholder)) continue;
        try {
            const figure = await figures.importImage(null, { ...asset, base64: asset.buffer.toString("base64") }, { signal });
            content = content.replaceAll(asset.placeholder, figure.path);
        } catch (error) {
            if (!(error instanceof ApiError) || ![400, 413].includes(error.status)) throw error;
            result.warnings.push(`${asset.name} を図版へ変換できませんでした。 ${error.message}`);
            content = content.replaceAll(asset.placeholder, "");
        }
    }
    return content;
}

/** 変換ジョブを登録し、書き込み完了まで同じ出力先を予約する。 */
export function exportJobs(documents, jobs) {
    const activeExports = new Set();

    /** 保存済み原本からPDFまたはWordの出力を受け付ける。 */
    async function startExport(input) {
        const { includeRevisionHistory } = input;
        assertRevisionHistoryOption(input);
        const { id, expectedRestore, folder, original } = await readJobDocument(documents, input);
        const config = requireConfig(await documents.config(id));
        const sourcePath = await documents.sourcePath(id, original.path);
        const render = input.type === "pdf" ? renderPdf : renderDocx;
        const output = exportRelativePath(original.path, input.type, config);
        const exportKey = `${folder}\u0000${output}`.toLowerCase();
        if (activeExports.has(exportKey)) throw conflict("同じ出力先の変換が実行中です。完了後に再試行してください。");
        const job = jobs.add(input.type, async ({ signal, onProgress }) => {
            onProgress(input.type === "pdf" ? "PDFを作成中" : "Wordを作成中");
            const result = await render({ content: original.content, sourcePath, documentRoot: folder, config, signal,
                ...(includeRevisionHistory !== undefined && { includeRevisionHistory }),
            });
            await documents.writeOutput(id, output, result.buffer, signal, expectedRestore);
            return { path: output, url: assetLink(id, output), warnings: result.warnings ?? [] };
        }, { onDone: () => activeExports.delete(exportKey) });
        activeExports.add(exportKey);
        return job;
    }

    /** Wordを取り込み、原本へ適用できる版を履歴に作る。 */
    async function startImport(input) {
        assertRevisionHistoryOption(input);
        const { id, expectedRestore, original } = await readJobDocument(documents, input);
        const name = textInput(input.name, "name", 512);
        if (pathParts(name).length !== 1 || name.startsWith(".") || extname(name).toLowerCase() !== ".docx") {
            throw badRequest(".docx ファイルを指定してください。");
        }
        const buffer = decodeBase64(input.base64);
        return jobs.add(input.type, async ({ signal }) => {
            const result = await importDocx({ buffer, name, signal });
            let content;
            const backup = await documents.archiveProposal(id, original, expectedRestore, {
                reason: "word", label: name, warnings: result.warnings, signal,
            }, async tree => {
                content = await storeWordFigures(tree, result, signal);
                return content;
            });
            return { path: original.path, content, revision: original.revision, warnings: result.warnings, backup };
        });
    }
    return { pdf: startExport, docx: startExport, "docx-import": startImport };
}
