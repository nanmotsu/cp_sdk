/**
 * @file 文書の図版一覧を表示し、図版エディターで作成・編集する。
 */

import { useEffect, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { ApiError, api, assetUrl, errorMessage, figurePartUrl } from '../api';
import type { FigureDetail, FigureSummary } from '../api';
import FigureEditor, { emptyImageLayout } from './FigureEditor';
import type { FigureEditorResult } from './FigureEditor';

/** 表示対象の文書と、図版が変わったことを本文やプレビューへ伝える操作。 */
interface Props {
  documentId: string;
  assetVersion: number;
  disabled: boolean;
  onInsertImage: (path: string, name: string) => void;
  onUpdated: () => void;
}

/** 固定パスで保存された図版を列挙し、種類に応じた編集画面を開く。 */
export default function FigureLibrary({ documentId, assetVersion, disabled, onInsertImage, onUpdated }: Props) {
  const [figures, setFigures] = useState<FigureSummary[]>([]);
  const [editing, setEditing] = useState<FigureDetail | 'new' | null>(null);
  const [newName, setNewName] = useState('');
  const [rename, setRename] = useState<{ figure: FigureSummary; value: string }>();
  const [renaming, setRenaming] = useState(false);
  const [loading, setLoading] = useState(true);
  const [opening, setOpening] = useState(false);
  const [error, setError] = useState('');
  const [refresh, setRefresh] = useState(0);
  const openRequest = useRef<AbortController | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError('');
    api.figures(documentId, controller.signal).then((result) => {
      if (!controller.signal.aborted) setFigures(result.figures);
    }).catch((exception: unknown) => {
      if (!controller.signal.aborted) setError(errorMessage(exception));
    }).finally(() => {
      if (!controller.signal.aborted) setLoading(false);
    });
    return () => controller.abort();
  }, [documentId, assetVersion, refresh]);

  useEffect(() => () => openRequest.current?.abort(), []);

  /** 選択した図版の詳細を取得し、SVGまたはラスタ配置の編集データへ変換する。 */
  async function openEditor(id: string) {
    const controller = new AbortController();
    openRequest.current = controller;
    setOpening(true);
    setError('');
    try {
      const result = await api.figure(documentId, id, controller.signal);
      if (!controller.signal.aborted) setEditing(result.figure);
    } catch (exception) {
      if (!controller.signal.aborted) setError(errorMessage(exception));
    } finally {
      if (!controller.signal.aborted) setOpening(false);
    }
  }

  /** 編集結果と取得時のリビジョンを送信し、保存後に一覧と本文の表示を更新する。 */
  async function saveEdit(result: FigureEditorResult) {
    if (!editing || editing === 'new') return;
    const revision = editing.revision;
    try {
      await api.updateFigure(documentId, editing.id, result.kind === 'svg'
        ? { kind: 'svg', revision, svg: result.svg }
        : { kind: 'raster', revision, annotations: result.annotations, composition: result.composition });
      setEditing(null);
      onUpdated();
    } catch (exception) {
      if (exception instanceof ApiError && exception.status === 409) {
        throw new Error('図版が更新されています。編集画面を閉じ、図版を開き直してください。');
      }
      throw exception;
    }
  }

  /** キャンバスで作った図版を登録し、本文に完成画像の参照を追加する。 */
  async function saveNew(result: FigureEditorResult) {
    if (result.kind !== 'screenshot') return;
    const name = newName.trim() || '図版';
    const { figure } = await api.createFigure(documentId, {
      name, kind: 'raster', annotations: result.annotations, composition: result.composition,
    });
    onInsertImage(figure.path, figure.name);
    setEditing(null);
  }

  /** 図版一覧の名前を、取得時のリビジョンで照合して保存する。 */
  async function saveName(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const name = rename?.value.trim();
    if (!rename || !name || disabled || renaming) return;
    const { id, revision } = rename.figure;
    setRenaming(true);
    setError('');
    try {
      const { figure } = await api.updateFigure(documentId, id, { kind: 'rename', name, revision });
      setFigures(current => current.map(item => item.id === id ? figure : item));
      setRename(undefined);
      onUpdated();
    } catch (exception) {
      setError(errorMessage(exception));
    } finally {
      setRenaming(false);
    }
  }

  return <section className="form-panel stack" aria-label="文書の図版">
    <div className="subsection-head">
      <h3>図版</h3>
      <div className="form-actions">
        <button type="button" className="primary" disabled={opening || renaming || disabled} onClick={() => {
          setNewName('');
          setEditing('new');
        }}>新規作成</button>
        <button type="button" disabled={loading || opening || renaming || disabled} onClick={() => {
          setRename(undefined);
          setRefresh(version => version + 1);
        }}>再読み込み</button>
      </div>
    </div>
    {loading && <p className="muted" role="status">図版を読み込んでいます…</p>}
    {opening && <p className="muted" role="status">図版を開いています…</p>}
    {error && <p className="error" role="alert">{error}</p>}
    {!loading && !error && !figures.length && <p className="muted">この文書には図版がありません。</p>}
    {figures.length > 0 && <div className="candidate-grid">
      {figures.map((figure) => <figure className="candidate" key={figure.id}>
        <img alt={figure.name} loading="lazy" src={assetUrl(documentId, figure.path, figure.revision)} />
        <figcaption>
          {rename?.figure.id === figure.id ? <form className="stack" aria-label="図版の名前を変更" onSubmit={saveName}>
            <label>図版の名前<input autoFocus required maxLength={120} value={rename.value} disabled={renaming || disabled}
              onChange={event => setRename({ figure: rename.figure, value: event.target.value })} /></label>
            <div className="form-actions">
              <button type="button" disabled={renaming} onClick={() => setRename(undefined)}>キャンセル</button>
              <button type="submit" disabled={renaming || disabled || !rename.value.trim()}>名前を保存</button>
            </div>
          </form> : <>
            <span>{figure.name}</span>
            <div className="form-actions">
              <button type="button" aria-label={`${figure.name}を本文に挿入`} disabled={opening || renaming || disabled}
                onClick={() => onInsertImage(figure.path, figure.name)}>本文に挿入</button>
              <button type="button" aria-label={`${figure.name}を編集`} disabled={opening || renaming || disabled}
                onClick={() => void openEditor(figure.id)}>編集</button>
              <button type="button" aria-label={`${figure.name}の名前を変更`} disabled={opening || renaming || disabled}
                onClick={() => setRename({ figure, value: figure.name })}>名前を変更</button>
            </div>
          </>}
        </figcaption>
      </figure>)}
    </div>}
    {editing === 'new' ? <FigureEditor title={newName} onTitleChange={setNewName} documentId={documentId}
      value={emptyImageLayout} applyLabel="図版を保存して本文に追加" onApply={saveNew} onClose={() => setEditing(null)} />
      : editing && <FigureEditor title={editing.name} documentId={documentId} value={editing.kind === 'svg'
      ? { kind: 'svg', svg: editing.svg }
      : {
        kind: 'screenshot',
        width: editing.width, height: editing.height, annotations: editing.annotations,
        images: editing.images.map(({ originalPath: _path, ...placement }) =>
          ({ ...placement, url: figurePartUrl(documentId, editing.id, placement.id) })),
      }} onApply={saveEdit} onClose={() => setEditing(null)} />}
  </section>;
}
