/**
 * @file ビジュアル編集用にMarkdownをブロックへ分割し、HTMLと原本の往復で未編集部分を保つ。
 */

import { marked } from 'marked';
import type { Token, Tokens } from 'marked';
import TurndownService from 'turndown';
import { gfm } from 'turndown-plugin-gfm';

/** 元のMarkdown、表示HTML、見出しやMermaidの抽出内容を含む単位。 */
export interface MarkdownBlock {
  kind: 'editable' | 'table' | 'protected' | 'space';
  raw: string;
  html?: string;
  mermaid?: string[];
  heading?: Tokens.Heading;
}

const visualBlocks = new Set(['blockquote', 'heading', 'list', 'paragraph', 'table']);
const protectedSyntax = /\{\{\s*ref:|\[\[\s*ref:|\[\^[^\]]+\]|\[[^\]\r\n]+\][ \t]?\[[^\]\r\n]*\]|\uFEFF|<!--|<\/?[A-Za-z][\w:-]*(?=\s|\/?\s*>)|^\s*:::/m;

/** 正規化後の文字数を、CRLFを含む原本の文字オフセットに戻す。 */
export function normalizedLength(source: string, limit: number, start: number) {
  let offset = start;
  for (let i = 0; i < limit; i += 1) {
    offset += source[offset] === '\r' && source[offset + 1] === '\n' ? 2 : 1;
  }
  return offset;
}

/** textarea上の変更範囲だけを原本へ反映し、残りの改行や文字を保持する。 */
export function editBlockSource(previous: string, value: string, lineEnding: string) {
  const normalized = previous.replace(/\r\n?/g, '\n');
  if (value === normalized) return previous;

  let start = 0;
  while (start < value.length && normalized[start] === value[start]) start += 1;

  let previousEnd = normalized.length;
  let valueEnd = value.length;
  while (previousEnd > start && valueEnd > start && normalized[previousEnd - 1] === value[valueEnd - 1]) {
    previousEnd -= 1;
    valueEnd -= 1;
  }

  const rawStart = normalizedLength(previous, start, 0);
  const rawEnd = normalizedLength(previous, previousEnd - start, rawStart);
  return previous.slice(0, rawStart) + value.slice(start, valueEnd).replaceAll('\n', lineEnding) + previous.slice(rawEnd);
}

/** 既存の記号または下線式の見出しを対象レベルにし、周囲のソースを保持する。 */
export function changeHeadingLevel(raw: string, depth: number) {
  const prefix = '#'.repeat(depth);
  const atx = /^( {0,3})#{1,6}(?=[ \t\r\n]|$)/;
  if (atx.test(raw)) return raw.replace(atx, (_, indent) => indent + prefix);

  const first = marked.lexer(raw.replace(/\r\n?/g, '\n'), { gfm: true })[0];
  const end = first ? normalizedLength(raw, first.raw.length, 0) : raw.length;
  const block = raw.slice(0, end);
  const setext = /(?:\r\n|\r|\n) {0,3}(?:=+|-+)[ \t]*(?=\r\n|\r|\n|$)/;
  const underline = first?.type === 'heading' ? setext.exec(block) : null;
  const headingText = underline ? block.slice(0, underline.index) : block;
  const tail = /(?:\r\n|\r|\n)+$/.exec(block)?.[0] ?? '';
  const text = headingText.trim().replace(/[ \t]*(?:\r\n|\r|\n)[ \t]*/g, ' ');
  return (text ? `${prefix} ${text}` : prefix) + tail + raw.slice(end);
}

/** 見出しの本文を取り出し、段落にしたときだけ意味が変わる記号をエスケープする。 */
export function headingAsParagraph(raw: string, lineEnding: string) {
  const tokens = marked.lexer(raw, { gfm: true });
  const heading = tokens[0];
  if (heading?.type !== 'heading') return undefined;
  const text = (heading as Tokens.Heading).text;
  const body = marked.lexer(text, { gfm: true });
  const markdown = body.length === 1 && body[0].type === 'paragraph'
    ? text.replaceAll('\n', lineEnding)
    : blockMarkdown(marked.parser(tokens).replace(/^<h[1-6]>([\s\S]*?)<\/h[1-6]>/, '<p>$1</p>'), '', lineEnding)
      .replace(/^(\d{1,9})\)(?=[ \t]|$)/gm, '$1\\)');
  const trailing = /(?:\r\n|\n|\r)+$/.exec(raw)?.[0] ?? '';
  return { markdown: markdown.replace(/^[ \t]*:::\w/gm, start => start.replace(':', '\\:')), trailing };
}

/** 挿入位置の前後に必要な改行だけを加え、本文と新しい開始位置を返す。 */
export function insertMarkdownBlock(parts: string[], index: number, markdown: string, lineEnding: string) {
  const before = parts.slice(0, index).join('');
  const after = parts.slice(index).join('');
  const endings = /\r\n|\r|\n/g;
  const trailing = before.match(/(?:\r\n|\r|\n)+$/)?.[0].match(endings)?.length ?? 0;
  const leading = after.match(/^(?:\r\n|\r|\n)+/)?.[0].match(endings)?.length ?? 0;
  const prefix = before + lineEnding.repeat(before ? Math.max(0, 2 - trailing) : 0);
  const suffix = lineEnding.repeat(after ? Math.max(0, 2 - leading) : 1) + after;
  return { markdown: prefix + markdown + suffix, start: prefix.length };
}

/** Markdownのトークンを再帰的にたどり、Mermaidのソースを集める。 */
function mermaidSources(tokens: Token[]) {
  const sources: string[] = [];
  marked.walkTokens(tokens, (token) => {
    if (token.type === 'code' && /^mermaid(?:\s|$)/i.test(token.lang ?? '')) sources.push(token.text);
  });
  return sources;
}

/** 元のソースを編集欄へそのまま渡すブロックを作り、必要なら図の描画情報を抽出する。 */
function protectedBlock(raw: string, prepareEditor: boolean): MarkdownBlock {
  return { kind: 'protected', raw, mermaid: prepareEditor ? mermaidSources(marked.lexer(raw, { gfm: true })) : undefined };
}

/** 通常のMarkdownをトークンで分け、HTMLで直接編集する単位と保護対象を決める。 */
function splitMarkdownChunk(source: string, prepareEditor: boolean): MarkdownBlock[] {
  if (!source) return [];
  const normalized = source.replace(/\r\n?/g, '\n');
  const tokens = marked.lexer(normalized, { gfm: true });
  const linkLabels = Object.keys(tokens.links);
  const blocks: MarkdownBlock[] = [];
  let offset = 0;
  let sourceOffset = 0;

  for (const token of tokens) {
    if (!token.raw) continue;
    const tokenStart = normalized.indexOf(token.raw, offset);
    if (tokenStart < 0) return [{ kind: 'protected', raw: source }];
    if (tokenStart > offset) {
      const whitespaceEnd = normalizedLength(source, tokenStart - offset, sourceOffset);
      blocks.push({ kind: 'protected', raw: source.slice(sourceOffset, whitespaceEnd) });
      sourceOffset = whitespaceEnd;
    }

    const nextOffset = normalizedLength(source, token.raw.length, sourceOffset);
    const raw = source.slice(sourceOffset, nextOffset);
    if (token.type === 'space') {
      blocks.push({ kind: 'space', raw });
    } else if (!prepareEditor) {
      blocks.push({ kind: 'protected', raw, heading: token.type === 'heading' ? token as Tokens.Heading : undefined });
    } else if (token.type === 'table') {
      blocks.push({ kind: 'table', raw });
    } else {
      const mermaid = mermaidSources([token]);
      const heading = token.type === 'heading' ? token as Tokens.Heading : undefined;
      if (!mermaid.length && visualBlocks.has(token.type) && !protectedSyntax.test(raw)
        && !linkLabels.some((label) => raw.toLowerCase().includes(`[${label}]`))) {
        blocks.push({ kind: 'editable', raw, heading, html: marked.parser(Object.assign([token], { links: tokens.links })) });
      } else {
        blocks.push({ kind: 'protected', raw, mermaid, heading });
      }
    }
    offset = tokenStart + token.raw.length;
    sourceOffset = nextOffset;
  }

  if (sourceOffset < source.length) blocks.push({ kind: 'protected', raw: source.slice(sourceOffset) });
  return blocks;
}

/** 本文全体を分け、ブロックの元ソースを連結すれば原本に戻る形で返す。 */
export function markdownBlocks(source: string, { prepareEditor = true } = {}): MarkdownBlock[] {
  const blocks: MarkdownBlock[] = [];
  if (source.startsWith('\uFEFF')) {
    blocks.push({ kind: 'space', raw: '\uFEFF' });
    source = source.slice(1);
  }
  let text = '';
  let directive = '';
  let directiveDepth = 0;
  let fence: { character: string; length: number } | undefined;
  const lines = source.match(/[^\r\n]*(?:\r\n|\n|\r|$)/g) || [];

  for (const line of lines) {
    if (!line) continue;
    const marker = /^ {0,3}(`{3,}|~{3,})([^\r\n]*)/.exec(line);
    if (marker) {
      const [, run, suffix] = marker;
      if (!fence) fence = { character: run[0], length: run.length };
      else if (fence.character === run[0] && run.length >= fence.length && !suffix.trim()) fence = undefined;
    }

    const opens = !fence && /^\s*:::\w/.test(line);
    const closes = !fence && /^\s*:::(?!\w)/.test(line);
    const selfClosing = opens && /:::\s*$/.test(line.slice(3));
    if (opens) {
      if (!directiveDepth) {
        blocks.push(...splitMarkdownChunk(text, prepareEditor));
        text = '';
      }
      if (!selfClosing) directiveDepth += 1;
    }

    if (directiveDepth || opens) {
      directive += line;
      if (closes) directiveDepth -= 1;
      if (!directiveDepth) {
        blocks.push(protectedBlock(directive, prepareEditor));
        directive = '';
      }
    } else {
      text += line;
    }
  }

  if (directive) blocks.push(protectedBlock(directive, prepareEditor));
  blocks.push(...splitMarkdownChunk(text, prepareEditor));
  if (blocks.every(block => block.kind === 'space')) blocks.push({ kind: 'editable', raw: '', html: '<p><br></p>' });
  return blocks;
}

const safeTags = new Set([
  'A', 'B', 'BLOCKQUOTE', 'BR', 'CAPTION', 'CODE', 'COL', 'COLGROUP', 'DEL', 'DIV', 'EM', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6',
  'HR', 'I', 'IMG', 'INPUT', 'LI', 'OL', 'P', 'PRE', 'S', 'SPAN', 'STRIKE', 'STRONG', 'TABLE', 'TBODY', 'TD', 'TFOOT', 'TH',
  'THEAD', 'TR', 'UL',
]);

/** ビジュアル編集のリンクや画像として扱えるURLかを判定する。 */
function safeUrl(value: string) {
  const normalized = value.trim().replace(/[\u0000-\u0020]/g, '');
  return /^(https?:|mailto:)/i.test(normalized) || !/^[a-z][\w+.-]*:/i.test(normalized);
}

const dataImage = /^data:image\/(?:png|jpeg|gif|webp|svg\+xml|bmp);base64,[A-Za-z0-9+/=]+$/i;

/** 編集欄で表示するHTMLから不要な要素や属性を取り除き、必要な画像リンクを解決する。 */
export function editorHtml(html: string, resolveImage?: (path: string) => string | undefined) {
  const template = document.createElement('template');
  template.innerHTML = html;
  for (const element of Array.from(template.content.querySelectorAll('*'))) {
    const tag = element.tagName;
    if (!safeTags.has(tag)) {
      element.replaceWith(...element.childNodes);
      continue;
    }

    for (const attribute of Array.from(element.attributes)) {
      const allowed = (tag === 'A' && ['href', 'title'].includes(attribute.name))
        || (tag === 'IMG' && ['src', 'alt', 'title', 'data-original-src'].includes(attribute.name))
        || (tag === 'OL' && attribute.name === 'start')
        || (['TH', 'TD'].includes(tag) && ['align', 'rowspan', 'colspan'].includes(attribute.name))
        || (tag === 'INPUT' && ['type', 'checked', 'disabled'].includes(attribute.name));
      if (!allowed) element.removeAttribute(attribute.name);
    }

    if (tag === 'A' && !safeUrl(element.getAttribute('href') || '')) element.removeAttribute('href');
    if (tag === 'IMG') {
      const source = element.getAttribute('data-original-src') ?? element.getAttribute('src') ?? '';
      if (!safeUrl(source) && !dataImage.test(source)) {
        element.remove();
        continue;
      }
      element.removeAttribute('data-original-src');
      if (resolveImage) element.setAttribute('data-original-src', source);
      const src = resolveImage ? resolveImage(source) : source;
      if (src) element.setAttribute('src', src);
      else element.removeAttribute('src');
    }
    if (tag === 'INPUT') {
      if (element.getAttribute('type') !== 'checkbox') element.remove();
      else element.setAttribute('disabled', '');
    }
  }
  return template.innerHTML;
}

const convert = new TurndownService({ bulletListMarker: '-', headingStyle: 'atx', codeBlockStyle: 'fenced' });
convert.use(gfm);

/** 編集済みブロックのHTMLをMarkdownへ戻し、既存の改行や末尾に合わせる。 */
export function blockMarkdown(html: string, previous: string, lineEnding: string) {
  const tail = /(?:\r\n|\r|\n)+$/.exec(previous)?.[0] || '';
  const converted = convert.turndown(editorHtml(html)).replaceAll('\n', lineEnding);
  return converted + tail;
}
