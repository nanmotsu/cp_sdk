/**
 * @file 文書から配信できる図版や出力ファイルの種類とパスを確認する。
 */

import { basename, extname } from "node:path";
import { badRequest, notFound } from "../../common/api/errors.mjs";
import { pathParts, workspacePath } from "../../common/filesystem/paths.mjs";
import { isBackupPath } from "../history/backups.mjs";
import { figureImageFile } from "./media.mjs";

const contentTypes = new Map([
    [".png", "image/png"], [".jpg", "image/jpeg"], [".jpeg", "image/jpeg"], [".gif", "image/gif"],
    [".webp", "image/webp"], [".svg", "image/svg+xml"], [".bmp", "image/bmp"],
    [".pdf", "application/pdf"],
    [".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
]);

/** アップロードする画像のファイル名と対応形式を確認する。 */
function imageMime(value) {
    if (pathParts(value).length !== 1 || value.startsWith(".")) throw badRequest("画像のファイル名を確認してください。");
    const mime = contentTypes.get(extname(value).toLowerCase());
    if (!mime?.startsWith("image/")) throw badRequest("PNG・JPEG・GIF・WebP・SVG・BMPの画像を選んでください。");
    return mime;
}

/** ブラウザーへ配信する資産を文書内で解決する。 */
export function createAssetStore({ access }) {
    /** 配信可能なファイルのパスとコンテンツ種別を解決する。 */
    async function asset(id, path) {
        const type = contentTypes.get(extname(typeof path === "string" ? path : "").toLowerCase());
        if (!type || isBackupPath(path)) throw notFound("配信対象のファイルが見つかりません。");
        return access(id, async folder => {
            const absolute = type.startsWith("image/") ? await figureImageFile(folder, path) : await workspacePath(folder, path);
            return { absolute, type, name: basename(path) };
        });
    }

    return { asset, imageMime };
}
