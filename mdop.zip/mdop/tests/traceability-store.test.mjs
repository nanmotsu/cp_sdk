import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, readdir, rename, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';
import { beginTraceability, createTraceability, createTraceabilityStore, resolveTraceabilityFolder } from '../apps/server/src/traceability/store.mjs';
import { copyRelation } from '../apps/server/src/traceability/history.mjs';

const table = ids => ({ items: ids.map(id => ({ id, content: id + 'の条件', location: id + 'の節' })),
  scope: { read: ['全体'], unread: [] } });
const mapping = (sourceId, targetId) => ({ id: 'M-' + sourceId, sourceId, targetIds: [targetId], degree: '全', detail: '条件を満たす' });

test('判定表未作成と、0件を一括判定した版と、手作成の判定表を区別する', async t => {
  const root = await mkdtemp(join(tmpdir(), 'mdop-review-initial-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const created = await createTraceability(root, {
    name: '初回', sourceUri: 'file:///a', targetUri: 'file:///b', granularity: '節',
  }, context => ({ ...context, candidate: { status: '関連あり', reason: '同じ機能' } }));
  const store = createTraceabilityStore(root);
  const initial = await store.get(created.id);
  assert.equal(initial.review.source.status, 'not-created');
  assert.equal(initial.review.target.message, '判定未作成');
  const run = await beginTraceability(root, created.id, 'map', 'generate');
  await run.save({ ...run.context, candidate: [] });
  const zero = await store.get(created.id);
  assert.equal(zero.matrix.total, 0);
  assert.equal(zero.review.source.status, 'unconfirmed');
  assert.equal(zero.review.source.message, '未確認');
  const folder = await resolveTraceabilityFolder(root, created.id);
  await writeFile(join(folder, 'source-items.json'), JSON.stringify(table(['A'])));
  await writeFile(join(folder, 'target-items.json'), JSON.stringify(table(['T1'])));
  await writeFile(join(folder, 'mappings.json'), JSON.stringify({ rows: [mapping('A', 'T1')] }));
  const handmade = await store.get(created.id);
  assert.equal(handmade.review.source.status, 'unconfirmed');
  assert.equal(handmade.review.source.message, '未確認（比較元なし）');
});

async function fixture(t) {
  const root = await mkdtemp(join(tmpdir(), 'mdop-trace-store-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const created = await createTraceability(root, {
    name: '登録の網羅性', sourceUri: 'file:///requirements.md', targetUri: 'file:///spec.md', granularity: '条件ごと',
  }, ctx => ({ ...ctx, candidate: { status: '関連あり', reason: '同じ機能' } }));
  const store = createTraceabilityStore(root);
  const folder = await resolveTraceabilityFolder(root, created.id);
  let value = await store.get(created.id);
  value = await store.save(created.id, { revision: value.revision, source: table(['A', 'B']), target: table(['T1', 'T2']) });
  const run = await beginTraceability(root, created.id, 'map');
  await run.save({ ...run.context, candidate: [mapping('A', 'T1'), mapping('B', 'T2')] });
  return { root, store, folder, id: created.id, value: await store.get(created.id) };
}

test('④は元項目を起点に未作成・参照切れを表示し、明示した孤立行だけ削除できる', async t => {
  const { store, id, value } = await fixture(t);
  const changed = await store.save(id, { revision: value.revision, source: table(['B', 'C']), target: table(['T2']), fixedFiles: ['mappings.json'] });
  assert.equal(changed.matrix.total, 2);
  assert.equal(changed.matrix.counts.全, 1);
  assert.equal(changed.matrix.counts.判定未作成, 1);
  assert.equal(changed.matrix.orphans[0].sourceId, 'A');
  assert.equal(changed.review.source.status, 'changed');
  assert.equal(changed.review.target.status, 'changed');
  const fullText = await store.markdown(id);
  assert.match(fullText, /判定未作成/);
  assert.match(fullText, /元項目なし/);
  const cleaned = await store.save(id, { revision: changed.revision, deleteMappingIds: ['M-A'] });
  assert.equal(cleaned.matrix.orphans.length, 0);
  assert.deepEqual(cleaned.mappings.rows, [mapping('B', 'T2')]);
  assert.equal(cleaned.mappings.inputVersion, value.mappings.inputVersion);
  await assert.rejects(store.save(id, { revision: cleaned.revision, deleteMappingIds: ['M-B'] }), /元項目なし/);
  const history = await store.history(id);
  const beforeDelete = history.find(row => row.reason === 'before-save' && row.runId ===
    history.find(row => row.id === cleaned.savedVersion).runId);
  assert.equal((await store.get(id, beforeDelete.id)).matrix.orphans.length, 1);
});

test('初回は④の入力版、確認後は人の確認版から項目表だけの変更を通知する', async t => {
  const { store, id, value } = await fixture(t);
  assert.equal(value.review.target.status, 'unconfirmed');
  const target = structuredClone(value.target);
  target.items[0].notes = '位置を補足';
  const changed = await store.save(id, { revision: value.revision, target });
  assert.equal(changed.review.target.status, 'changed');
  assert.match(changed.review.target.message, /判定後に先項目表/);
  const diff = await store.diff(id, changed.review.target.baselineVersion);
  assert.deepEqual(diff.rows.find(row => row.id === 'T1').cells, [{ column: 'notes', before: null, after: '位置を補足' }]);
  await assert.rejects(store.confirm(id, { revision: value.revision, sides: ['target'] }), /再読み込み/);
  const confirmed = await store.confirm(id, { revision: changed.revision, sides: ['target'] });
  assert.equal(confirmed.review.target.status, 'confirmed');
  const map = structuredClone(confirmed.mappings);
  map.rows[0].notes = '人が根拠を確認';
  const afterMapEdit = await store.save(id, { revision: confirmed.revision, mappings: map });
  assert.equal(afterMapEdit.review.target.status, 'confirmed');
  assert.equal(afterMapEdit.review.source.status, 'unconfirmed');
  const source = structuredClone(afterMapEdit.source);
  source.items[0].content += '追記';
  const next = await store.save(id, { revision: afterMapEdit.revision, source });
  assert.equal(next.review.source.status, 'changed');
  assert.equal(next.review.target.status, 'confirmed');
});

test('途中開始した連続実行は最初の変更前版でまとめて取り出せる', async t => {
  const { root, store, id } = await fixture(t);
  const first = await beginTraceability(root, id, 'source', 'generate');
  const sourceVersion = await first.save({ ...first.context, candidate: table(['A', 'B', 'C']) });
  const group = { groupId: first.context.groupId, startVersion: first.context.startVersion };
  const second = await beginTraceability(root, id, 'target', 'generate', group);
  await second.save({ ...second.context, candidate: table(['T1', 'T2', 'T3']) });
  const history = await store.history(id);
  const sequence = history.filter(row => row.groupId === first.context.groupId);
  assert.equal(sequence.length, 4);
  assert.ok(sequence.every(row => row.startVersion === first.context.runId));
  assert.equal((await store.get(id, first.context.startVersion)).source.items.length, 2);
  assert.equal((await store.get(id, sourceVersion.version)).source.items.length, 3);
});

test('全体復元で添付資料・空フォルダ・確認記録を戻し、追加ファイルを外す', async t => {
  const { store, id, folder, value } = await fixture(t);
  await mkdir(join(folder, '資料', '空'), { recursive: true });
  await writeFile(join(folder, '資料', '仕様.txt'), '初版');
  const loaded = await store.get(id);
  const confirmed = await store.confirm(id, { revision: loaded.revision, sides: ['source', 'target'] });
  const chosen = (await store.history(id)).find(row => row.reason === 'confirmed');
  await writeFile(join(folder, '資料', '仕様.txt'), '変更後');
  await writeFile(join(folder, '追加.txt'), '追加');
  const current = await store.get(id);
  await store.restore(id, chosen.id, { revision: current.revision });
  assert.equal(await readFile(join(folder, '資料', '仕様.txt'), 'utf8'), '初版');
  assert.deepEqual(await readdir(join(folder, '資料', '空')), []);
  await assert.rejects(readFile(join(folder, '追加.txt')), { code: 'ENOENT' });
  const restored = await store.get(id);
  assert.equal(restored.review.source.status, 'confirmed');
  assert.equal(restored.mappings.inputVersion, value.mappings.inputVersion);
  const preRestore = (await store.history(id)).find(row => row.reason === 'before-restore');
  assert.equal(await readFile(join(folder, 'backups', preRestore.id, 'tree', '追加.txt'), 'utf8'), '追加');
  assert.equal((await store.get(id, chosen.id)).revision, confirmed.revision);
});

test('置換途中の停止は次回アクセス時に全体を保存前へ戻す', async t => {
  const { store, id, folder } = await fixture(t);
  const initial = await readFile(join(folder, 'source-items.json'), 'utf8');
  const stage = join(folder, 'backups', '.transaction');
  await mkdir(stage);
  await copyRelation(folder, join(stage, 'next'));
  await mkdir(join(stage, 'previous'));
  for (const name of await readdir(folder)) {
    if (name !== 'backups') await rename(join(folder, name), join(stage, 'previous', name));
  }
  await writeFile(join(stage, 'next', 'source-items.json'), JSON.stringify(table(['NEW'])));
  await rename(join(stage, 'next', 'source-items.json'), join(folder, 'source-items.json'));
  await writeFile(join(stage, 'phase'), 'replace');
  const loaded = await store.get(id);
  assert.equal(loaded.source.items[0].id, 'A');
  assert.equal(await readFile(join(folder, 'source-items.json'), 'utf8'), initial);
  await assert.rejects(readdir(stage), { code: 'ENOENT' });
});

test('中止した新規作成と AI 更新は現行データへ公開しない', async t => {
  const root = await mkdtemp(join(tmpdir(), 'mdop-abort-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const controller = new AbortController();
  await assert.rejects(createTraceability(root, {
    name: '中止', sourceUri: 'file:///a', targetUri: 'file:///b', granularity: '節',
    signal: controller.signal,
  }, context => {
    controller.abort();
    return { ...context, candidate: { status: '関連あり', reason: '同じ主題' } };
  }), { name: 'AbortError' });
  assert.deepEqual(await readdir(join(root, 'traceabilities')), []);
  const { root: preparedRoot, store, id } = await fixture(t);
  const original = await store.get(id);
  const stop = new AbortController();
  const run = await beginTraceability(preparedRoot, id, 'map', 'generate', { signal: stop.signal });
  stop.abort();
  await assert.rejects(run.save({ ...run.context, candidate: [] }), { name: 'AbortError' });
  assert.equal((await store.get(id)).revision, original.revision);
});
