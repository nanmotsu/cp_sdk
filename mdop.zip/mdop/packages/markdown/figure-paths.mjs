/**
 * @file 本文で参照する図版と編集用の素材に使う、文書内の保存場所。
 */

/** 文書表示用の画像と図版の編集情報を保存する場所。 */
export const FIGURES_DIRECTORY = "assets/figures";
/** ラスタ図版の編集に使う画像素材を保存する場所。 */
export const FIGURE_PARTS_DIRECTORY = "assets/parts";
/** 図版と追加レイヤーに使うUUIDの形式。 */
export const figureIdPattern = /^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/;

/** 本文の画像リンクと配信で使える図版の表示ファイルか調べる。 */
export function isFigureImagePath(path) {
    const [assets, figures, id, file, ...rest] = path.split("/");
    return !rest.length && `${assets}/${figures}` === FIGURES_DIRECTORY && figureIdPattern.test(id)
        && (file === "image.png" || file === "image.svg");
}
