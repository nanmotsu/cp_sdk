/**
 * @file AIに渡す参照元を確認し、ファイルURIの添付対象を登録する。
 */

import { useState } from 'react';
import type { FormEvent } from 'react';
import { api, errorMessage } from '../api';
import type { SourceInfo, SourceRequest } from '../api';
import { Warnings } from './Feedback';
import SourceBrowseDialog from './SourceBrowseDialog';

/** 登録済み資料を受け取り、変更をAI依頼画面へ返す契約。 */
interface Props {
  sources: SourceRequest[];
  onChange: (sources: SourceRequest[]) => void;
  disabled: boolean;
}

/** Excelと他の資料に適した、資料の読み方の入力例を返す。 */
function readingNoteExample(excel: boolean) {
  return excel
    ? '「要件」シートのA1:F80を読む。状態列が「廃止」の行は対象外。'
    : '@deprecated が付いた処理は旧仕様として扱う。';
}

/** 参照元候補の確認と、今回の依頼に使う資料の登録を別々に扱う。 */
export default function SourcePicker({ sources, onChange, disabled }: Props) {
  const [path, setPath] = useState('');
  const [candidate, setCandidate] = useState<SourceInfo | null>(null);
  const [values, setValues] = useState<string[]>([]);
  const [folderScope, setFolderScope] = useState<'directory' | 'files'>('files');
  const [readingNote, setReadingNote] = useState('');
  const [filter, setFilter] = useState('');
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState('');
  const [browsing, setBrowsing] = useState(false);

  /** パスを調べ、資料の種類に応じたチェック項目と警告を取得する。 */
  async function inspect(chosenPath: string) {
    if (!chosenPath.trim() || checking || disabled) return;
    setChecking(true);
    setError('');
    setCandidate(null);
    setFilter('');
    try {
      const result = await api.inspectSource(chosenPath.trim());
      setCandidate(result);
      setValues([]);
      setFolderScope('files');
      setReadingNote('');
    } catch (exception) {
      setError(errorMessage(exception));
    } finally {
      setChecking(false);
    }
  }

  /** 選択ダイアログの結果を入力欄に入れ、そのパスの候補を読み込む。 */
  function choosePath(chosenPath: string) {
    setBrowsing(false);
    setPath(chosenPath);
    void inspect(chosenPath);
  }

  /** 選択済みのファイル・シート・範囲・読み方を、依頼に使う資料一覧へ追加する。 */
  function add() {
    if (!candidate || disabled || sources.some((source) => source.path === candidate.path)) return;
    const source: SourceRequest = { path: candidate.path };
    if (candidate.kind === 'project') {
      if (folderScope === 'directory') source.scope = 'directory';
      else source.files = values;
    }
    if (readingNote.trim()) source.readingNote = readingNote.trim();
    onChange([...sources, source]);
    setPath('');
    setCandidate(null);
  }

  const options = candidate?.files || [];
  const registeredAttachments = sources.reduce((count, source) => count + (source.files?.length ?? 1), 0);
  const candidateAttachments = candidate?.kind === 'project' && folderScope === 'files' ? values.length : 1;
  const exceedsLimit = Boolean(candidate && registeredAttachments + candidateAttachments > 20);

  return <section className="stack" aria-label="参照元の登録">
    <div className="subsection-head">
      <h4>参照元（任意）</h4>
      <span className="muted">登録済み {registeredAttachments}/20 件</span>
    </div>
    <p className="muted assist-field-hint">「参照元に追加」した資料を今回の依頼に使います。</p>
    <form className="field-row" onSubmit={(event: FormEvent) => { event.preventDefault(); void inspect(path); }}>
      <input aria-label="外部プロジェクト、ファイル、Excelのパス" placeholder="apps/server または C:\projects\requirements.xlsx"
        value={path} onChange={(event) => { setPath(event.target.value); setCandidate(null); }} required disabled={disabled || checking} />
      <button type="submit" disabled={disabled || checking}>{checking ? '確認中…' : '確認'}</button>
    </form>
    <div className="form-actions"><button type="button" disabled={disabled || checking} onClick={() => setBrowsing(true)}>ファイル・フォルダを選ぶ</button></div>
    {browsing && <SourceBrowseDialog onChoose={choosePath} onClose={() => setBrowsing(false)} />}
    {error && <p className="error" role="alert">{error}</p>}
    {candidate && <div className="source-candidate stack">
      <code>{candidate.path}</code>
      <Warnings warnings={candidate.warnings} />
      {candidate.kind === 'project' && <div className="stack" role="group" aria-label="フォルダの参照範囲">
        <label className="check-label"><input type="radio" name="folder-scope" checked={folderScope === 'directory'} disabled={disabled}
          onChange={() => setFolderScope('directory')} />フォルダ全体を参照</label>
        <label className="check-label"><input type="radio" name="folder-scope" checked={folderScope === 'files'} disabled={disabled}
          onChange={() => setFolderScope('files')} />選択したファイルだけ参照</label>
        {folderScope === 'directory' && <p className="muted assist-field-hint">このフォルダのURIを渡します。Copilotが配下を探索でき、候補一覧に表示されないファイルも参照範囲に含まれます。</p>}
      </div>}
      {candidate.kind === 'project' && folderScope === 'files' && <label>ファイルを絞り込む<input value={filter} onChange={(event) => setFilter(event.target.value)} /></label>}
      {candidate.kind === 'project' && folderScope === 'files' && <div className="choice-list" aria-label="参照するファイル">
        {options.filter((option) => option.toLocaleLowerCase().includes(filter.toLocaleLowerCase())).map((option) => (
          <label key={option} className="check-label">
            <input type="checkbox" checked={values.includes(option)} disabled={disabled} onChange={(event) => {
              setValues((selected) => event.target.checked ? [...selected, option] : selected.filter((value) => value !== option));
            }} />
            <span>{option}</span>
          </label>
        ))}
      </div>}
      {candidate.kind === 'excel' && <p className="muted assist-field-hint">Excelファイル全体を添付します。読むシートやセル範囲は「資料の読み方」に指定できます。</p>}
      <label>資料の読み方（任意）
        <textarea value={readingNote} onChange={(event) => setReadingNote(event.target.value)}
          placeholder={readingNoteExample(candidate.kind === 'excel')} rows={2} maxLength={1000} disabled={disabled} />
      </label>
      {exceedsLimit && <p className="error">参照元の添付は合計20件までです。</p>}
      <div className="form-actions"><button type="button" onClick={add} disabled={disabled
        || exceedsLimit || (candidate.kind === 'project' && folderScope === 'files' && !values.length) || sources.some((source) => source.path === candidate.path)}>
        参照元に追加{candidate.kind === 'project' && folderScope === 'files' && values.length > 0 ? ` (${values.length})` : ''}
      </button></div>
    </div>}
    {sources.length > 0 && <ul className="source-list">
      {sources.map((source) => <li key={source.path}>
        <div className="source-list-row">
          <div className="source-list-path"><code>{source.path}</code>
            {source.files && <span>{source.files.join('、')}</span>}
            {source.scope === 'directory' && <span>フォルダ全体</span>}
          </div>
          <button type="button" disabled={disabled} onClick={() => onChange(sources.filter((entry) => entry.path !== source.path))}>解除</button>
        </div>
        <details className="source-reading-note">
          <summary>{source.readingNote?.trim() ? '資料の読み方を編集' : '資料の読み方を追加'}</summary>
          <textarea aria-label={`資料の読み方: ${source.path}`} value={source.readingNote ?? ''} rows={2} maxLength={1000}
            placeholder={readingNoteExample(source.path.toLowerCase().endsWith('.xlsx'))} disabled={disabled}
            onChange={(event) => {
              const value = event.target.value;
              onChange(sources.map((entry) => entry.path === source.path ? { ...entry, readingNote: value || undefined } : entry));
            }} />
        </details>
        {source.readingNote?.trim() && <p className="source-note-preview muted">{source.readingNote}</p>}
      </li>)}
    </ul>}
  </section>;
}
