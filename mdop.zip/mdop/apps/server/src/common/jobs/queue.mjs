/**
 * @file 非同期ジョブの受付・並列数・進行状態・中断と、終了済み結果の保持を管理する。
 */

import { randomUUID } from "node:crypto";
import { ApiError, notFound } from "../api/errors.mjs";

/** 受付済みで、待機中または処理中の状態かを判定する。 */
const active = status => status === "queued" || status === "running";

/** 指定された並列実行数、受付上限、履歴件数でジョブキューを作る。 */
export function createJobQueue({ concurrency = 2, maxActive = 12, historySize = 32 } = {}) {
    const jobs = new Map();
    const pending = [];
    let running = 0;

    /** 履歴が目安を超えた場合、終了したジョブを古いものから除去する。 */
    function trim() {
        for (const [id, entry] of jobs) {
            if (jobs.size <= historySize) break;
            if (!active(entry.job.status)) jobs.delete(id);
        }
    }

    /** 実行枠が空いている間、待機中のジョブを開始する。成功・失敗・中断を記録し、空いた枠で後続を実行する。 */
    function schedule() {
        while (running < concurrency && pending.length) {
            const entry = pending.shift();
            if (entry.job.status !== "queued") continue;
            const { job, controller, perform } = entry;
            running++;
            job.status = "running";
            Promise.resolve().then(() => perform({
                signal: controller.signal,
                /** 処理側から受け取った進行メッセージを表示用の長さに抑えて記録する。 */
                onProgress(message) { if (typeof message === "string") job.progress = message.slice(0, 500); },
            })).then(result => {
                controller.signal.throwIfAborted();
                job.status = "succeeded";
                job.result = result;
            }).catch(error => {
                if (controller.signal.aborted) {
                    job.status = "canceled";
                } else {
                    job.status = "failed";
                    job.error = {
                        code: error.code ?? "JOB_FAILED",
                        message: error.message ?? "ジョブに失敗しました。",
                        ...(error.details !== undefined ? { details: error.details } : {}),
                    };
                }
            }).finally(() => {
                running--;
                entry.perform = null;
                entry.onDone?.();
                trim();
                schedule();
            });
        }
    }

    /** IDからジョブの内部状態を取得する。履歴にないIDは404にする。 */
    function lookup(id) {
        const entry = jobs.get(id);
        if (!entry) throw notFound("ジョブが見つかりません。");
        return entry;
    }

    /** 処理をキューに登録し、待機中のスナップショットを返す。受付上限に達した場合は429になる。 */
    function add(type, perform, { onDone } = {}) {
        if (running + pending.length >= maxActive) {
            throw new ApiError(429, "JOB_QUEUE_FULL", "処理中のジョブが多いため、完了後に再試行してください。");
        }
        const job = { id: randomUUID(), type, status: "queued" };
        const entry = { job, perform, onDone, controller: new AbortController() };
        jobs.set(job.id, entry);
        pending.push(entry);
        setImmediate(schedule);
        return { ...job };
    }

    /** 待機中の処理を取り消すか、実行中の処理へ中断を伝える。既に終了した状態はそのまま返す。 */
    function cancel(id) {
        const { job, controller } = lookup(id);
        if (active(job.status)) {
            controller.abort();
            if (job.status === "queued") {
                const [entry] = pending.splice(pending.findIndex(item => item.job.id === id), 1);
                entry.perform = null;
                entry.onDone?.();
            }
            job.status = "canceled";
            trim();
        }
        return { ...job };
    }

    /** サーバーの終了時に未完了のジョブへ中断を伝える。 */
    function dispose() {
        for (const [id, entry] of jobs) {
            if (active(entry.job.status)) cancel(id);
        }
    }

    return { add, get: id => ({ ...lookup(id).job }), cancel, dispose };
}
