/** @file 図のサイズ指定と列幅を、編集画面と文書レンダラーで同じ方法で読む。 */

/** 数値と単位だけからなる表示サイズを返す。 */
export function layoutLength(value) {
    const text = typeof value === "string" ? value.trim() : "";
    return /^\d+(?:\.\d+)?(?:%|mm|cm|in|pt|px|em|rem)$/i.test(text) ? text : undefined;
}

/** Mermaidの先頭に置くアプリ用ディレクティブを、図のコードから分離する。 */
export function readMermaidLayout(source) {
    const directives = [];
    let code = source;
    let width = null;
    let height = null;
    let fontSize = null;
    for (let match; (match = /^[ \t]*%%[ \t]*(width|height|fontsize)[ \t]*:[ \t]*(.*?)[ \t]*%%[ \t]*(?:\r\n|\n|\r|$)/i.exec(code));) {
        const name = match[1].toLowerCase();
        const value = layoutLength(match[2]);
        if (value && name === "width") width = value;
        if (value && name === "height") height = value;
        if (value && name === "fontsize") fontSize = value;
        directives.push({ name, raw: match[0] });
        code = code.slice(match[0].length);
    }
    return { code, width, height, fontSize, directives };
}

/** 比率の並びはパーセントへ変換する。単位付きの列幅はそのまま使う。 */
export function parseColumnWidths(raw) {
    const parts = raw?.split(/[,:]/).map(value => value.trim()).filter(Boolean) ?? [];
    const ratios = parts.map(Number);
    if (ratios.length && ratios.every(value => Number.isFinite(value) && value > 0)) {
        const total = ratios.reduce((sum, value) => sum + value, 0);
        return ratios.map(value => `${100 * value / total}%`);
    }
    return parts;
}

/** 図版で本文として扱うソースと、図の下に出す題を分ける。 */
export function splitFigureSource(source) {
    const lines = source.trimEnd().split(/\r\n|\n|\r/);
    const imageLines = lines.filter(line => /^!\[/.test(line.trim()));
    if (imageLines.length) {
        const captionLines = lines.flatMap((line, index) => !/^!\[/.test(line.trim()) && line.trim() ? [index] : []);
        return { body: imageLines.join("\n"), caption: captionLines.map(index => lines[index]).join(" ").trim(), captionLines };
    }

    let captionLine = -1;
    let fence;
    for (const [index, line] of lines.entries()) {
        const marker = /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(line);
        if (fence) {
            if (marker && marker[1][0] === fence[0] && marker[1].length >= fence.length && !marker[2].trim()) fence = undefined;
        } else if (marker) fence = marker[1];
        else if (line.trim()) captionLine = index;
    }
    if (captionLine < 0) return { body: source.trimEnd(), caption: "", captionLines: [] };
    const caption = lines[captionLine].trim();
    lines.splice(captionLine, 1);
    return { body: lines.join("\n").trimEnd(), caption, captionLines: [captionLine] };
}
