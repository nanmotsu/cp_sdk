/** @file 図版の編集対象や再利用する画像素材をサムネイルから選ぶ。 */

import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { api, errorMessage, figurePartUrl } from '../api';
import type { FigurePart } from '../api';

/** キャンバスに配置されたレイヤーの選択用データ。 */
interface PlacedImage {
  id: string;
  name: string;
  url: string;
}

/** 配置する画像ファイルに、素材一覧で使っている表示名を添える。 */
export interface FigureImageFile {
  file: File;
  name?: string;
}

/** 所属文書、配置済みの画像と、選択・追加の操作。 */
interface Props {
  documentId: string;
  placed: PlacedImage[];
  selected: string;
  remaining: number;
  uploadLimit: number;
  accept: string;
  onSelect: (id: string) => void;
  onAdd: (files: FigureImageFile[]) => Promise<void>;
  onClose: () => void;
}

/** 選んだ外部ファイルのサムネイルを表示し、選択から外す操作を提供する。 */
function ExternalImage({ file, disabled, onRemove }: { file: File; disabled: boolean; onRemove: () => void }) {
  const [src, setSrc] = useState('');
  useEffect(() => {
    const url = URL.createObjectURL(file);
    setSrc(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  return <button type="button" className="figure-part-card" aria-label={`${file.name}を選択から外す`}
    aria-pressed="true" onClick={onRemove} disabled={disabled}>
    {src && <img src={src} alt="" />}
    <span>{file.name}</span>
    <span className="figure-part-check" aria-hidden="true">✓</span>
  </button>;
}

/** 配置済みの画像を選ぶか、文書内の画像素材や外部ファイルを新しく配置する。 */
export default function FigurePartsDialog({ documentId, placed, selected, remaining, uploadLimit, accept, onSelect, onAdd, onClose }: Props) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const [parts, setParts] = useState<FigurePart[] | null>(null);
  const [pickedParts, setPickedParts] = useState<FigurePart[]>([]);
  const [pickedFiles, setPickedFiles] = useState<{ key: string; file: File }[]>([]);
  const [loadError, setLoadError] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const pickedCount = pickedParts.length + pickedFiles.length;
  const atLimit = pickedCount >= remaining;

  useLayoutEffect(() => {
    const dialog = dialogRef.current!;
    dialog.showModal();
    return () => dialog.close();
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    api.figureParts(documentId, controller.signal).then(({ parts }) => {
      if (!controller.signal.aborted) setParts(parts);
    }).catch((exception: unknown) => {
      if (!controller.signal.aborted) setLoadError(errorMessage(exception));
    });
    return () => controller.abort();
  }, [documentId]);

  /** 同じ画像カードをもう一度押すと、配置する素材の選択から外す。 */
  function togglePart(part: FigurePart) {
    setError('');
    setPickedParts(current => current.includes(part) ? current.filter(item => item !== part) : [...current, part]);
  }

  /** ファイルピッカーで選んだ画像を、配置する素材の選択に加える。 */
  function pickFiles(files: File[]) {
    if (!files.length) return;
    if (files.length > remaining - pickedCount) {
      setError(`あと${remaining - pickedCount}枚まで選べます。`);
      return;
    }
    setError('');
    setPickedFiles(current => [...current, ...files.map(file => ({ key: crypto.randomUUID(), file }))]);
  }

  /** 選んだ画像をまとめて渡す。読み込めなかった場合は選択を保持する。 */
  async function placeSelected() {
    if (busy || !pickedCount) return;
    setBusy(true);
    setError('');
    try {
      const files: FigureImageFile[] = [];
      let bytes = pickedFiles.reduce((total, { file }) => total + file.size, 0);
      if (bytes > uploadLimit) throw new Error('追加する画像の合計を20 MiB以下にしてください。');
      for (const part of pickedParts) {
        const response = await fetch(figurePartUrl(documentId, part.figureId, part.id));
        if (!response.ok) throw new Error(`画像素材「${part.name}」を読み込めませんでした。`);
        const blob = await response.blob();
        bytes += blob.size;
        if (bytes > uploadLimit) throw new Error('追加する画像の合計を20 MiB以下にしてください。');
        files.push({ file: new File([blob], part.fileName, { type: blob.type }), name: part.name });
      }
      files.push(...pickedFiles.map(({ file }) => ({ file })));
      await onAdd(files);
      onClose();
    } catch (exception) {
      setError(errorMessage(exception));
      setBusy(false);
    }
  }

  return <dialog ref={dialogRef} className="figure-parts-dialog" aria-label="画像パーツ"
    onKeyDown={event => event.stopPropagation()} onCancel={event => {
      event.preventDefault();
      event.stopPropagation();
      if (!busy) onClose();
    }}>
    <div className="figure-parts-shell">
      <header className="figure-editor-heading">
        <h2>画像パーツ</h2>
        <button type="button" disabled={busy} onClick={onClose}>閉じる</button>
      </header>
      {placed.length > 0 && <section aria-label="配置済みの画像">
        <h3>配置済みの画像</h3>
        <div className="figure-parts-grid">
          {placed.map(image => <button type="button" className="figure-part-card" aria-pressed={image.id === selected}
            aria-label={`${image.name}を編集`} key={image.id} disabled={busy}
            onClick={() => { onSelect(image.id); onClose(); }}>
            <img src={image.url} alt="" loading="lazy" />
            <span>{image.name}</span>
          </button>)}
        </div>
      </section>}
      <section aria-label="文書の画像パーツ">
        <div className="figure-editor-heading">
          <h3>文書の画像パーツ</h3>
          <input ref={fileInput} type="file" accept={accept} multiple hidden aria-label="外部画像ファイル"
            onChange={(event) => {
              const files = Array.from(event.currentTarget.files ?? []);
              event.currentTarget.value = '';
              pickFiles(files);
            }} />
          <button type="button" disabled={atLimit || busy} onClick={() => fileInput.current?.click()}>外部画像を追加</button>
        </div>
        {loadError ? <p className="figure-editor-error" role="alert">{loadError}</p>
          : !parts ? <p className="muted" role="status">画像パーツを読み込んでいます…</p>
            : !parts.length ? <p className="muted">保存済みの画像パーツはありません。</p>
              : <div className="figure-parts-grid">
                {parts.map(part => {
                  const checked = pickedParts.includes(part);
                  return <button type="button" className="figure-part-card" key={`${part.figureId}/${part.id}`}
                    aria-label={`${part.name}（${part.figureName}）`} aria-pressed={checked}
                    disabled={busy || (atLimit && !checked)} onClick={() => togglePart(part)}>
                    <img src={figurePartUrl(documentId, part.figureId, part.id)} alt="" loading="lazy" />
                    <span>{part.name}</span>
                    {part.name !== part.figureName && <small>{part.figureName}</small>}
                    {checked && <span className="figure-part-check" aria-hidden="true">✓</span>}
                  </button>;
                })}
              </div>}
      </section>
      {pickedFiles.length > 0 && <section aria-label="外部画像">
        <h3>外部画像</h3>
        <div className="figure-parts-grid">
          {pickedFiles.map(({ key, file }) => <ExternalImage key={key} file={file} disabled={busy} onRemove={() => {
            setError('');
            setPickedFiles(current => current.filter(item => item.key !== key));
          }} />)}
        </div>
      </section>}
      {error && <p className="figure-editor-error" role="alert">{error}</p>}
      <footer className="figure-parts-actions">
        <span className="muted" role="status">{busy ? '画像を配置しています…'
          : remaining === 0 ? '配置できる画像の上限に達しています。' : `${pickedCount}枚選択中（あと${remaining - pickedCount}枚）`}</span>
        <button type="button" className="figure-editor-primary" disabled={!pickedCount || busy}
          onClick={() => void placeSelected()}>選択した画像を配置</button>
      </footer>
    </div>
  </dialog>;
}
