/**
 * @file 履歴の一覧・比較・削除・復元と、編集案からの履歴の派生をHTTPで提供する。
 */

import { readJson, sendJson } from "../../common/api/http.mjs";
import { updateProposalFigures } from "../assistance/proposal-figures.mjs";

/** 文書履歴のルートを登録する。 */
export function historyRoutes(documents, uploads) {
    return [
        ["GET", "/documents/:id/backups", async (_request, response, { id }) =>
            sendJson(response, 200, { backups: await documents.listBackups(id) })],
        ["GET", "/documents/:id/backups/:backupId", async (_request, response, { id, backupId }) =>
            sendJson(response, 200, await documents.backupDetail(id, backupId))],
        ["DELETE", "/documents/:id/backups/:backupId", async (_request, response, { id, backupId }) => {
            await documents.deleteBackup(id, backupId);
            return sendJson(response, 200, { deletedId: backupId });
        }],
        ["POST", "/documents/:id/backups/:backupId/restore", async (request, response, { id, backupId }) =>
            sendJson(response, 200, await documents.restoreBackup(id, backupId, await readJson(request)))],
        ["POST", "/documents/:id/backups/:backupId/figures", async (request, response, { id, backupId }) => {
            const input = await readJson(request, uploads);
            const backup = await documents.forkCopilotBackup(id, backupId, (tree, markdown) => updateProposalFigures(tree, markdown, input));
            return sendJson(response, 201, { backup });
        }],
    ];
}
