/**
 * @file PDF・Wordを出力し、Wordの取り込み結果を文書の履歴から開く画面。
 */

import { useRef, useState } from 'react';
import { errorMessage, fileBase64 } from '../api';
import type { ExportResult, WordImportResult } from '../api';
import type { OpenFile } from '../workspace';
import { useJob } from '../useJob';
import { JobFeedback, Warnings } from './Feedback';

/** 成果物の出力、ダウンロード、Word取り込みとその警告を提供する。 */
export default function OutputPanel({ file, busy, save, onHistory }: {
  file: OpenFile;
  busy: boolean;
  save: () => Promise<OpenFile | null>;
  onHistory: (id: string) => void;
}) {
  const output = useJob<ExportResult>();
  const incoming = useJob<WordImportResult>();
  const input = useRef<HTMLInputElement>(null);
  const [importError, setImportError] = useState('');
  const [reading, setReading] = useState(false);
  const exportResult = output.job?.status === 'succeeded' ? output.job.result : undefined;
  const importResult = incoming.job?.status === 'succeeded' ? incoming.job.result : undefined;

  /** 原本の保存に成功したときだけ、そのリビジョンを指定して出力を開始する。 */
  async function exportFile(type: 'pdf' | 'docx') {
    const saved = await save();
    if (!saved) return;
    await output.start({ type, documentId: saved.documentId, path: saved.path, revision: saved.revision });
  }

  /** 選んだDOCXをBase64へ変換し、原本への取り込み案を作るジョブへ渡す。 */
  async function importWord(selected: File) {
    setReading(true);
    setImportError('');
    try {
      const base64 = await fileBase64(selected);
      await incoming.start({ type: 'docx-import', documentId: file.documentId, path: file.path,
        revision: file.revision, name: selected.name, base64 });
    } catch (exception) {
      setImportError(errorMessage(exception));
    } finally {
      setReading(false);
    }
  }

  return <div className="form-panel stack">
    <section className="stack">
      <h3>PDF</h3>
      <div className="form-actions"><button className="primary" type="button" disabled={busy || output.busy}
        onClick={() => void exportFile('pdf')}>保存してPDFを出力</button></div>
    </section>
    <section className="stack">
      <h3>Word</h3>
      <p className="muted">Word変換は補助機能です。改ページや複雑な書式の再現は、変換後に確認してください。</p>
      <div className="form-actions">
        <button type="button" disabled={busy || output.busy} onClick={() => void exportFile('docx')}>保存してWordを出力</button>
        <button type="button" disabled={busy || incoming.busy || reading} onClick={() => input.current?.click()}>Wordを取り込む</button>
        <input hidden type="file" ref={input} accept=".docx" aria-label="Word文書" onChange={(event) => {
          const selected = event.target.files?.[0];
          event.target.value = '';
          if (selected) void importWord(selected);
        }} />
      </div>
    </section>
    <JobFeedback state={output} />
    {exportResult && <div className="job-result">
      <a href={exportResult.url} download>{exportResult.path.split('/').at(-1)} をダウンロード</a>
      <Warnings warnings={exportResult.warnings} />
    </div>}
    {reading && <p className="muted" role="status">Wordを読み込んでいます…</p>}
    {importError && <p className="error" role="alert">{importError}</p>}
    <JobFeedback state={incoming} />
    {importResult && <section className="job-result stack" aria-label="Word取り込みの結果">
      <p>Word取り込みの版を履歴に保存しました。</p>
      <Warnings warnings={importResult.warnings} />
      <div className="form-actions"><button type="button" disabled={busy}
        onClick={() => onHistory(importResult.backup.id)}>履歴で比較</button></div>
    </section>}
  </div>;
}
