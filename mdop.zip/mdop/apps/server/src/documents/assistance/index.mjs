/**
 * @file 本文と図版の生成依頼を組み立て、返された編集案を検証する。
 */

import { randomUUID } from 'node:crypto';
import yaml from 'js-yaml';
import { ApiError } from '../../common/api/errors.mjs';
import { prepareFigureRasterAttachment } from '../figures/raster.mjs';
import { resolveRenderingDsl } from '../shared/settings.mjs';
import { validateGeneratedMarkdown } from '../shared/validate-markdown.mjs';
import { boundedText, documentTarget } from './context.mjs';
import { extractDraftFigures } from './draft-figures.mjs';
import { figureDraftPrompt, parseFigureDraft } from './figure-draft.mjs';
import { collectSources } from './sources.mjs';

/** 応答全体を包むMarkdownフェンスと設定用フロントマターを取り除いて原本用の本文を得る。 */
function cleanGeneratedMarkdown(text, warnings) {
    const wrapped = /^(`{3,})(?:md|markdown)\s*\r?\n([\s\S]+)\r?\n\1\s*$/i.exec(text.trim());
    const markdown = wrapped?.[2] ?? text.trim();
    const frontmatter = /^---\r?\n([\s\S]*?)\r?\n---(?:\r?\n|$)/.exec(markdown);
    if (frontmatter) {
        try {
            const metadata = yaml.load(frontmatter[1]);
            if (metadata && typeof metadata === 'object' && !Array.isArray(metadata)) {
                warnings.push('生成結果のフロントマターを除去しました。文書設定は config.yaml を使用します。');
                return markdown.slice(frontmatter[0].length).trim();
            }
        } catch {
            // A leading horizontal rule and ordinary Markdown are left intact.
        }
    }
    return markdown;
}

/** 今回の設定で有効なDSLだけを、種類、形、書式例とともに伝える。 */
function documentDslContext(dsl) {
    const examples = dsl.blocks.flatMap(({ snippet }) => {
        const lines = snippet?.body;
        return Array.isArray(lines) && lines.every(line => typeof line === 'string') ? [lines.join('\n')] : [];
    }).filter(example => example.length <= 500).slice(0, 12);
    const allowed = dsl.blocks.map(block => `:::${block.name}`);
    const definitions = dsl.blocks.map(({ name, selfClosing, captionPosition }) => ({
        name, selfClosing: Boolean(selfClosing), ...(captionPosition && { captionPosition }),
    }));
    return [
        allowed.length
            ? `今回の文書で有効なDSL。許可する種類: ${allowed.join('、')}\n${JSON.stringify(definitions)}`
            : '今回の文書で有効なDSLはありません。通常のMarkdownを使ってください。',
        examples.length ? `DSLの書式例。スニペットの変数や例のパスは文書に合わせて置き換えてください。\n${examples.join('\n\n')}` : '',
    ].filter(Boolean).join('\n');
}

/** 依頼と資料のURI添付を作り、検証済みの編集案を返す。 */
async function generate(agent, renderMermaid, { documentId, documentFolder, markdownPath, template,
    instruction, sources = [], documentInput, dsl,
    sessionId, modelId, sessionTitle, signal, onProgress }) {
    const requestText = boundedText(instruction, 8000, '依頼内容');
    const activeDsl = resolveRenderingDsl({ dsl });
    onProgress?.('選択した参照元を確認しています。');
    const context = await collectSources(sources, signal);
    if (!context.attachments.length && !documentInput?.hasText && !requestText) {
        throw new ApiError(400, 'GENERATION_CONTEXT_REQUIRED', '参照元、編集中のMarkdown、依頼内容のいずれかを指定してください。');
    }
    const target = documentId ? { ...documentTarget(documentId, documentFolder), markdownPath } : undefined;
    const prompt = [
        target ? `今回の対象文書:\n${JSON.stringify(target)}` : '',
        documentInput ? '今回の原本Markdownはファイルで添付しています。' : '今回の原本Markdownの添付はありません。',
        `用途: ${template.label}\n文書の書き方:\n${template.prompt}`,
        requestText ? `今回の編集依頼:\n${requestText}` : '',
        context.readingNotes.length ? `利用者が指定した資料の読み方（JSON。各メモの sources のみに適用する）:\n${JSON.stringify(context.readingNotes)}` : '',
        context.sources.length ? `今回の参照資料はファイルで添付しています。資料名と出典の対応:\n${JSON.stringify(context.sources)}`
            : '今回の参照資料の添付はありません。',
        context.sources.some(source => source.path.toLowerCase().endsWith('.xlsx'))
            ? 'Excel資料は添付ファイルから必要なシートとセルを読み取ってください。読めない場合は推測して編集案を作らず、理由を返してください。' : '',
        documentDslContext(activeDsl),
    ].filter(Boolean).join('\n\n');
    const { text: response, session } = await agent.complete({
        purpose: 'edit-document', prompt, attachments: [...(documentInput?.attachments ?? []), ...context.attachments],
        sessionId, modelId, sessionTitle, signal, onProgress,
    });
    if (response.trimStart().startsWith('MD_OPERATOR_SOURCE_UNREADABLE:')) {
        throw new ApiError(422, 'SOURCE_UNREADABLE', response.trim().slice(30, 530));
    }
    const draft = cleanGeneratedMarkdown(response, context.warnings);
    if (!draft) throw new ApiError(502, 'AHP_EMPTY_RESPONSE', 'Copilotから利用できるMarkdown本文を受信できませんでした。');
    onProgress?.('編集案の文法と図版を確認しています。');
    const { markdown, figures, diagnostics: figureDiagnostics } = extractDraftFigures(draft);
    const markdownDiagnostics = await validateGeneratedMarkdown(markdown, { dsl: activeDsl, renderMermaid, signal });
    const diagnostics = [...figureDiagnostics, ...markdownDiagnostics]
        .sort((first, second) => (first.line ?? Infinity) - (second.line ?? Infinity));
    return { markdown: `${markdown}\n`, sources: context.sources, warnings: context.warnings, diagnostics,
        ...(figures.length && { figures }),
        ...(session && { session }) };
}

/** 必要な素材を添え、画像や枠・矢印・文字を別々に編集できる図版案を返す。 */
async function composeFigure(agent, prepareRasterAttachment, { documentId, documentFolder, images, instruction, sessionId, modelId, sessionTitle, signal, onProgress }) {
    const requestText = boundedText(instruction, 8000, '図版の依頼内容');
    if (!requestText) throw new ApiError(400, 'FIGURE_INSTRUCTION_REQUIRED', '図版に入れたい内容を入力してください。');
    const document = documentTarget(documentId, documentFolder);
    const materials = [];
    const attachments = [];
    const maxBytes = Math.min(2 * 1024 * 1024, Math.floor(16 * 1024 * 1024 / Math.max(1, images.length)));
    for (const [index, image] of images.entries()) {
        onProgress?.(`画像素材を準備しています（${index + 1}/${images.length}）`);
        const { width, height, mime, bytes } = await prepareRasterAttachment({ ...image, signal, maxBytes });
        materials.push({ id: image.id, name: image.name, width, height });
        attachments.push({ kind: 'image',
            label: `素材${index + 1} ${image.name}`, mime, bytes });
    }
    signal?.throwIfAborted();
    const { text: reply, session, generatedImages = [] } = await agent.complete({
        purpose: 'compose-figure', prompt: figureDraftPrompt(requestText, materials, document),
        attachments, sessionId, modelId, sessionTitle, signal, onProgress,
    });
    const generatedMaterials = generatedImages.map(({ mime, bytes }, index) => ({
        id: randomUUID(), name: `生成画像${index + 1}`, mime, original: bytes,
    }));
    return { ...parseFigureDraft(reply, materials, generatedMaterials), generatedMaterials, ...(session && { session }) };
}

/**
 * 文書の生成処理にエージェントを接続する。テストでは描画依存も差し替えられる。
 * @param {{ agent: import('../../copilot/agent.mjs').Agent, renderMermaid?: Function, prepareRasterAttachment?: Function }} options
 */
export function createAssistance({ agent, renderMermaid, prepareRasterAttachment = prepareFigureRasterAttachment }) {
    return {
        generate: input => generate(agent, renderMermaid, input),
        composeFigure: input => composeFigure(agent, prepareRasterAttachment, input),
    };
}
