/**
 * @file GUIがローカルAPIと通信する窓口。共有型、URL生成、応答のエラー処理をまとめる。
 */

import type {
  BackupDetail, BackupRestoreInput, BackupRestoreResult, BackupSummary, BasicSettingsPatch, ConfigInfo, CopilotSessions, CopilotTemplateList,
  DocumentInfo, FigureCreateInput, FigureDetail, FigurePart, FigureSummary, FigureUpdateInput,
  IntegrationStatus, Job, JobPayload, MarkdownFile, PreviewResult, ResponseError, SourceFolderContents, SourceInfo, VisualElements, VisualElementsInput,
} from '../../../packages/api-contracts/types';
export type * from '../../../packages/api-contracts/types';

const API = '/api/v1';

/** APIが返したHTTP状態と診断情報を、GUIで扱える例外に保持する。 */
export class ApiError extends Error {
  status: number;
  code?: string;
  details?: unknown;

  /** 応答から得た表示文、状態コード、追加診断を保存する。 */
  constructor(message: string, status: number, code?: string, details?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

/** JSONを送受信し、APIのエラー応答を ApiError に変換する。呼び出し側からの中断にも対応する。 */
async function request<T>(url: string, method = 'GET', body?: unknown, signal?: AbortSignal): Promise<T> {
  const response = await fetch(`${API}${url}`, {
    method,
    headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
    signal,
  });
  const result = await response.json().catch(() => undefined);

  if (!response.ok || result === undefined) {
    const error: ResponseError | string | undefined = result?.error;
    const message = typeof error === 'string' ? error : error?.message;
    throw new ApiError(message || `APIへのリクエストに失敗しました (${response.status})`, response.status,
      typeof error === 'object' ? error?.code : undefined, typeof error === 'object' ? error?.details : undefined);
  }

  return result as T;
}

/** 文書IDをエンコードしたAPIのパスを作る。 */
function documentRoute(id: string) {
  return `/documents/${encodeURIComponent(id)}`;
}

/** 図版の一覧または個別図版へのパスを作る。 */
function figuresRoute(id: string, figureId?: string) {
  const route = `${documentRoute(id)}/figures`;
  return figureId ? `${route}/${encodeURIComponent(figureId)}` : route;
}

/** 文書の履歴一覧または指定した版へのAPIパスを作る。 */
function backupRoute(id: string, backupId?: string) {
  const route = `${documentRoute(id)}/backups`;
  return backupId ? `${route}/${encodeURIComponent(backupId)}` : route;
}

/** 本文や図版が使う資産URLを組み立てる。リビジョン指定時は同じパスの更新をブラウザーに区別させる。 */
export function assetUrl(id: string, path: string, revision?: string) {
  const route = `${API}${documentRoute(id)}/assets?path=${encodeURIComponent(path)}`;
  return revision ? `${route}&revision=${encodeURIComponent(revision)}` : route;
}

/** 図版エディターが画像素材を表示・取得するURLを組み立てる。 */
export function figurePartUrl(id: string, figureId: string, partId: string) {
  return `${API}${figuresRoute(id, figureId)}/parts/${encodeURIComponent(partId)}`;
}

/** 文書、設定、ジョブと連携機能ごとの型付きHTTP操作を提供する。 */
export const api = {
  documents: () => request<{ documents: DocumentInfo[] }>('/documents'),
  createDocument: (name: string) => request<{ document: DocumentInfo }>('/documents', 'POST', { name }),
  file: (id: string, path: string) => request<MarkdownFile>(`${documentRoute(id)}/files?path=${encodeURIComponent(path)}`),
  /** 原本がない文書にだけ、新しい原本を作る。 */
  createFile: (id: string, path: string, content: string) => request<MarkdownFile>(`${documentRoute(id)}/files`, 'POST', { path, content }),
  /** 取得時のリビジョンとともに原本の本文を保存する。 */
  saveFile: (id: string, file: MarkdownFile) => request<MarkdownFile>(`${documentRoute(id)}/files`, 'PUT', file),
  backups: (id: string, signal?: AbortSignal) =>
    request<{ backups: BackupSummary[] }>(backupRoute(id), 'GET', undefined, signal),
  backup: (id: string, backupId: string, signal?: AbortSignal) =>
    request<BackupDetail>(backupRoute(id, backupId), 'GET', undefined, signal),
  deleteBackup: (id: string, backupId: string, signal?: AbortSignal) =>
    request<{ deletedId: string }>(backupRoute(id, backupId), 'DELETE', undefined, signal),
  restoreBackup: (id: string, backupId: string, input: BackupRestoreInput) =>
    request<BackupRestoreResult>(`${backupRoute(id, backupId)}/restore`, 'POST', input),
  saveBackupFigures: (id: string, backupId: string, figures: { id: string; svg: string }[]) =>
    request<{ backup: BackupSummary }>(`${backupRoute(id, backupId)}/figures`, 'POST', { figures }),
  /** 文書別の有効な設定を取得する。不正なYAMLは設定診断として受け取る。 */
  config: (id: string, signal?: AbortSignal) => request<ConfigInfo>(`${documentRoute(id)}/config`, 'GET', undefined, signal),
  saveBasicSettings: (id: string, changes: BasicSettingsPatch, revision: string) =>
    request<ConfigInfo>(`${documentRoute(id)}/config`, 'PATCH', { changes, revision }),
  /** 対象文書で選べるテンプレートの表示情報を取得する。 */
  copilotTemplates: (id: string, signal?: AbortSignal) =>
    request<CopilotTemplateList>(`${documentRoute(id)}/copilot-templates`, 'GET', undefined, signal),
  /** 未保存の本文を含め、指定のMarkdownを文書プレビューとして描画する。 */
  preview: (id: string, path: string, content: string, signal?: AbortSignal) => request<PreviewResult>(`${documentRoute(id)}/preview`, 'POST', { path, content }, signal),
  visualElements: (id: string, path: string, input: VisualElementsInput, signal?: AbortSignal) =>
    request<VisualElements>(`${documentRoute(id)}/visual-elements`, 'POST', { path, ...input }, signal),
  figures: (id: string, signal?: AbortSignal) => request<{ figures: FigureSummary[] }>(figuresRoute(id), 'GET', undefined, signal),
  figureParts: (id: string, signal?: AbortSignal) =>
    request<{ parts: FigurePart[] }>(`${documentRoute(id)}/parts`, 'GET', undefined, signal),
  figure: (id: string, figureId: string, signal?: AbortSignal) =>
    request<{ figure: FigureDetail }>(figuresRoute(id, figureId), 'GET', undefined, signal),
  createFigure: (id: string, figure: FigureCreateInput) => request<{ figure: FigureDetail }>(figuresRoute(id), 'POST', figure),
  updateFigure: (id: string, figureId: string, figure: FigureUpdateInput) =>
    request<{ figure: FigureDetail }>(figuresRoute(id, figureId), 'PUT', figure),
  prepareSvg: (id: string, svg: string) => request<{ svg: string }>(`${figuresRoute(id)}/prepare-svg`, 'POST', { svg }),
  integrationStatus: () => request<IntegrationStatus>('/integrations/status'),
  copilotSessions: () => request<CopilotSessions>('/integrations/sessions'),
  inspectSource: (path: string) => request<SourceInfo>('/sources/inspect', 'POST', { path }),
  browseSourceFolder: (path?: string, signal?: AbortSignal) => request<SourceFolderContents>('/sources/browse', 'POST', { path }, signal),
  /** 変換・生成を登録し、結果を追跡するためのジョブIDと受付状態を得る。 */
  startJob: <T>(payload: JobPayload) => request<{ job: Job<T> }>('/jobs', 'POST', payload),
  job: <T>(id: string, signal?: AbortSignal) => request<{ job: Job<T> }>(`/jobs/${encodeURIComponent(id)}`, 'GET', undefined, signal),
  cancelJob: <T>(id: string) => request<{ job: Job<T> }>(`/jobs/${encodeURIComponent(id)}/cancel`, 'POST'),
};

/** ジョブの失敗情報から表示用メッセージを取り出す。 */
export function jobError(job: Job<unknown>) {
  return typeof job.error === 'string' ? job.error : job.error?.message || '処理に失敗しました';
}

/** 設定診断などの詳細がある場合は、主メッセージと合わせて画面用の文字列にする。 */
export function errorMessage(error: unknown) {
  if (error instanceof ApiError && Array.isArray(error.details) && error.details.every((detail) => typeof detail === 'string')) {
    return [error.message, ...error.details].join('\n');
  }
  return error instanceof Error ? error.message : String(error);
}

/** ブラウザーの File を読み込み、API送信用のBase64本体を返す。 */
export function fileBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',', 2)[1] ?? '');
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}
