/**
 * @file config.yaml で受け付けるキーと値の検証。
 * YAMLの読み込みは yaml.mjs、保存は store.mjs。描画の既定値と解決順は shared/settings.mjs。
 */

import { validateDslDefinitions } from "../shared/dsl-definition.mjs";
import { pathParts } from "../../common/filesystem/paths.mjs";

// 文書名、表紙、画像の基準パス、用紙などの文字列。
const stringKeys = ["title", "subtitle", "cover", "paper", "assetsBase"];
const boolKeys = ["paragraphIndent", "toc", "titlePage", "headingNumbering"];
// 書式は shared/settings.mjs、DSLは shared/dsl-definition.mjs に解決処理がある。
const objectKeys = ["margin", "typography", "colors", "spacing", "heading", "headerFooter", "dsl",
    "titlePageStyle", "orderedListStyle", "revisionHistoryVisibility"];
// 出力先に使う文書内のパスとファイル名。
const outputDirs = ["outputDir", "pdfOutputDir", "docxOutputDir"];
const outputNames = { pdfFileName: ".pdf", docxFileName: ".docx" };
const orderedListStyles = ["decimal", "lower-alpha", "upper-alpha", "paren-decimal", "paren-lower-alpha", "paren-upper-alpha"];
const knownKeys = new Set([
    ...stringKeys, ...boolKeys, ...objectKeys, ...outputDirs, ...Object.keys(outputNames),
    "orientation", "tocDepth", "tocManual", "revisionHistory",
]);
/** YAMLの値が配列以外のオブジェクトかを判定する。 */
const record = value => value && typeof value === "object" && !Array.isArray(value);
/** 余白やヘッダーに使う単位付き長さと、単位なしの 0 を検査する。 */
const cssLength = value => /^(?:0|\d+(?:\.\d+)?(?:mm|cm|in|pt|px))$/.test(String(value));

/** YAMLのキーと値の形式を検査し、設定画面でまとめて表示する診断を返す。 */
export function validateConfig(config) {
    if (!record(config)) return ["設定の先頭はキーと値の対応で記述してください。空の設定は {} で指定できます。"];
    const diagnostics = [];
    for (const key of Object.keys(config)) {
        if (!knownKeys.has(key)) diagnostics.push(`未定義の設定項目です: ${key}`);
    }
    for (const key of stringKeys) {
        if (key in config && typeof config[key] !== "string") diagnostics.push(`${key} は文字列で指定してください。`);
    }
    for (const key of boolKeys) {
        if (key in config && typeof config[key] !== "boolean") diagnostics.push(`${key} は true または false で指定してください。`);
    }
    for (const key of objectKeys) {
        if (key in config && !record(config[key])) diagnostics.push(`${key} はキーと値の対応で指定してください。`);
    }
    if ("orientation" in config && !["portrait", "landscape"].includes(config.orientation)) {
        diagnostics.push("orientation は portrait または landscape で指定してください。");
    }
    if ("paper" in config && !/^(a[0-6]|letter|legal|tabloid|ledger)$/i.test(String(config.paper))) {
        diagnostics.push("paper は A0〜A6、letter、legal、tabloid、ledger のいずれかで指定してください。");
    }
    if ("tocDepth" in config && (!Number.isInteger(config.tocDepth) || config.tocDepth < 1 || config.tocDepth > 3)) {
        diagnostics.push("tocDepth は 1〜3 の整数で指定してください。");
    }
    if ("revisionHistory" in config && (!Array.isArray(config.revisionHistory) || config.revisionHistory.some(row => !record(row)))) {
        diagnostics.push("revisionHistory はキーと値の対応を並べた配列で指定してください。");
    }
    if (record(config.revisionHistoryVisibility)) {
        for (const [output, value] of Object.entries(config.revisionHistoryVisibility)) {
            if (!["preview", "pdf", "docx"].includes(output)) {
                diagnostics.push(`未定義の設定項目です: revisionHistoryVisibility.${output}`);
            } else if (typeof value !== "boolean") {
                diagnostics.push(`revisionHistoryVisibility.${output} は true または false で指定してください。`);
            }
        }
    }
    if ("tocManual" in config && typeof config.tocManual !== "string" && !Array.isArray(config.tocManual)) {
        diagnostics.push("tocManual は Markdown 文字列または行の配列で指定してください。");
    }
    if (record(config.margin)) {
        for (const [side, value] of Object.entries(config.margin)) {
            if (!["top", "right", "bottom", "left"].includes(side) || !cssLength(value)) {
                diagnostics.push(`margin.${side} は 10mm などの長さで指定してください。`);
            }
        }
    }
    if (record(config.heading)) {
        const { levels } = config.heading;
        for (const key of Object.keys(config.heading)) {
            if (key !== "levels") diagnostics.push(`未定義の設定項目です: heading.${key}`);
        }
        if (levels !== undefined && (!Array.isArray(levels) || new Set(levels).size !== levels.length
            || levels.some(level => !["h1", "h2", "h3"].includes(level)))) {
            diagnostics.push("heading.levels は h1・h2・h3 から重複なしで選んだ配列で指定してください。");
        }
    }
    if (record(config.orderedListStyle)) {
        for (const [key, value] of Object.entries(config.orderedListStyle)) {
            if (!["level1", "level2"].includes(key)) {
                diagnostics.push(`未定義の設定項目です: orderedListStyle.${key}`);
            } else if (!orderedListStyles.includes(value)) {
                diagnostics.push(`orderedListStyle.${key} は ${orderedListStyles.join("、")} のいずれかで指定してください。`);
            }
        }
    }
    if (record(config.headerFooter)) {
        const { enabled, fontSize, header, footer } = config.headerFooter;
        if (enabled !== undefined && typeof enabled !== "boolean") diagnostics.push("headerFooter.enabled は true または false で指定してください。");
        if (fontSize !== undefined && !cssLength(fontSize)) diagnostics.push("headerFooter.fontSize は 9px などの長さで指定してください。");
        for (const [key, section] of Object.entries({ header, footer })) {
            if (section === undefined) continue;
            if (!record(section)) {
                diagnostics.push(`headerFooter.${key} はキーと値の対応で指定してください。`);
                continue;
            }
            for (const [side, value] of Object.entries(section)) {
                if (["leftColor", "centerColor", "rightColor"].includes(side)) {
                    if (typeof value !== "string" || !/^#(?:[a-f\d]{3}|[a-f\d]{6})$/i.test(value)) {
                        diagnostics.push(`headerFooter.${key}.${side} は '#c00000' などの色で指定してください。`);
                    }
                } else if (!["left", "center", "right"].includes(side) || typeof value !== "string") {
                    diagnostics.push(`headerFooter.${key} は left・center・right に文字列を指定してください。`);
                }
            }
        }
    }
    if (record(config.typography)) {
        for (const key of ["fontSize", "fontWeight"]) {
            if (key in config.typography && !record(config.typography[key])) diagnostics.push(`typography.${key} はキーと値の対応で指定してください。`);
        }
    }
    if (record(config.dsl)) validateDslDefinitions(config.dsl, diagnostics);
    for (const [key, value] of Object.entries(config)) {
        if (outputDirs.includes(key)) {
            try {
                if (value !== ".") pathParts(typeof value === "string" ? value.replace(/^\.\//, "") : value);
            } catch {
                diagnostics.push(`${key} は文書フォルダ内の相対パスで指定してください。`);
            }
        }
        if (Object.hasOwn(outputNames, key)) {
            try {
                if (pathParts(value).length !== 1 || !value.toLowerCase().endsWith(outputNames[key])) throw new Error();
            } catch {
                diagnostics.push(`${key} は ${outputNames[key]} のファイル名で指定してください。`);
            }
        }
    }
    return diagnostics;
}

