/**
 * @file 文書フォルダと単一の原本Markdownを作成・読み書きする。
 */

import { createHash } from "node:crypto";
import { mkdir, readdir, readFile, rmdir, stat, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { badRequest, conflict, notFound } from "../../common/api/errors.mjs";
import { atomicWrite, pathParts, statIfPresent, workspacePath } from "../../common/filesystem/paths.mjs";
import { checkSize, MARKDOWN_LIMIT, textInput } from "../shared/input.mjs";
import { documentId } from "../shared/workspace.mjs";

const markdownExt = /\.m(?:d|arkdown)$/i;

/** 原本として扱える文書直下のMarkdownファイル名を検査する。 */
function markdownPath(value) {
    if (pathParts(value).length !== 1 || value.startsWith(".") || !markdownExt.test(value)) {
        throw badRequest("文書フォルダ直下の .md または .markdown ファイルを指定してください。");
    }
    return value;
}

/** 原本の比較に使うSHA-256ハッシュを計算する。 */
function revision(data) {
    return createHash("sha256").update(data).digest("hex");
}

/** 原本のパスと本文に、保存時の照合に使うリビジョンを付ける。 */
function withRevision(path, content) {
    return { path, content, revision: revision(content) };
}

/** 文書フォルダ直下の原本候補を列挙し、GUIの表示順に整える。 */
export async function markdownFiles(root) {
    const results = [];
    for (const entry of await readdir(root, { withFileTypes: true })) {
        if (!entry.isFile() || entry.name.startsWith(".") || !markdownExt.test(entry.name)) continue;
        try { markdownPath(entry.name); } catch { continue; }
        results.push({ path: entry.name });
    }
    return results.sort((left, right) => left.path.localeCompare(right.path, "ja"));
}

const multipleFilesMessage = "文書フォルダの原本Markdownを1ファイルにしてください。";

/** 文書ツリー用に原本を示す。複数の候補があれば解消方法を添える。 */
export function documentSummary(id, files) {
    return { id, name: id, files: files.length > 1 ? [] : files,
        ...(files.length > 1 && { conflict: `${multipleFilesMessage} ${files.map(file => file.path).join("、")}` }),
    };
}

/** 文書内の唯一の原本を決定する。原本数と要求パスの整合性を検査する。 */
async function onlyFile(folder, path) {
    if (path !== undefined) markdownPath(path);
    const files = await markdownFiles(folder);
    if (files.length > 1) throw conflict(multipleFilesMessage, files);
    if (!files.length || (path !== undefined && files[0].path !== path)) throw notFound("原本Markdownが見つかりません。");
    return files[0].path;
}

/** 検査済みの文書フォルダまたは履歴の版から、唯一の原本を読み取る。 */
export async function readOriginal(folder, path) {
    const original = await onlyFile(folder, path);
    const absolute = await workspacePath(folder, original);
    const stat = await statIfPresent(absolute);
    checkSize(stat?.size ?? 0, MARKDOWN_LIMIT);
    return withRevision(original, await readFile(absolute, "utf8"));
}

/** 同じ文書ロックで原本を読み書きするストアを構成する。 */
export function createMarkdownStore({ root, backups, locked, access }) {
    /** 文書フォルダを列挙し、原本が複数あるフォルダには競合情報を添える。 */
    async function list() {
        const documents = [];
        for (const entry of await readdir(root, { withFileTypes: true })) {
            if (!entry.isDirectory()) continue;
            try { documentId(entry.name); } catch { continue; }
            const { files, updatedAt } = await access(entry.name, async folder => {
                const files = await markdownFiles(folder);
                const dates = await Promise.all(files.map(async file => (await stat(join(folder, file.path))).mtimeMs));
                return { files, updatedAt: new Date(dates.length ? Math.max(...dates) : (await stat(folder)).mtimeMs).toISOString() };
            });
            documents.push({ ...documentSummary(entry.name, files), updatedAt });
        }
        return documents.sort((left, right) => left.name.localeCompare(right.name, "ja"));
    }

    /** 文書フォルダと初期の index.md を作る。原本作成中に失敗した場合は空のフォルダの除去を試みる。 */
    async function create(name) {
        const id = documentId(textInput(name, "name", 512).trim().normalize("NFC"));
        return locked(id, async () => {
            const path = await workspacePath(root, id, { directory: true, mayBeMissing: true });
            try {
                await mkdir(path);
            } catch (error) {
                if (error.code === "EEXIST") throw conflict(`すでに文書フォルダがあります: ${id}`);
                throw error;
            }
            try {
                await writeFile(join(path, "index.md"), `# ${id}\n`, { flag: "wx" });
            } catch (error) {
                await rmdir(path).catch(() => {});
                throw error;
            }
            return { id, name: id, files: [{ path: "index.md" }], updatedAt: (await stat(join(path, "index.md"))).mtime.toISOString() };
        });
    }

    /** 対象文書の原本を読み、本文と現在のリビジョンを返す。 */
    function read(id, path) {
        return access(id, folder => readOriginal(folder, path));
    }

    /** 原本がない文書に原本を作る。ストアのロック内で原本数を確認する。 */
    async function createFile(id, path, content) {
        markdownPath(path);
        textInput(content, "content");
        return access(id, async folder => {
            const files = await markdownFiles(folder);
            if (files.length) throw conflict("原本Markdownがすでにあります。", files);
            const absolute = await workspacePath(folder, path, { mayBeMissing: true });
            try {
                await writeFile(absolute, content, { flag: "wx" });
            } catch (error) {
                if (error.code === "EEXIST") throw conflict(`すでにファイルがあります: ${path}`);
                throw error;
            }
            return withRevision(path, content);
        });
    }

    /** リビジョンを照合し、本文が変わった場合だけ原本を置き換えて版を作る。 */
    async function save(id, path, content, expectedRevision) {
        markdownPath(path);
        textInput(content, "content");
        if (typeof expectedRevision !== "string" || !/^[a-f\d]{64}$/.test(expectedRevision)) {
            throw badRequest("取得時の revision を指定してください。");
        }
        return access(id, async folder => {
            const current = await readOriginal(folder, path);
            if (current.revision !== expectedRevision) {
                throw conflict("ファイルが別の操作で更新されています。最新の内容を確認してください。", { revision: current.revision });
            }
            if (current.content === content) return current;
            const history = await backups.list(folder);
            if (!history.some(item => ["initial", "save", "before-restore"].includes(item.reason))) {
                await backups.capture(folder, { path, reason: "initial" });
            }
            const version = await backups.capture(folder, { path, reason: "save" }, async tree => {
                await atomicWrite(await workspacePath(tree, path), content);
            });
            try {
                const confirmed = await readOriginal(folder, path);
                if (confirmed.revision !== expectedRevision) {
                    throw conflict("版の保存中に原本が更新されました。最新の内容を確認してください。", { revision: confirmed.revision });
                }
                await atomicWrite(await workspacePath(folder, path), content);
            } catch (error) {
                await backups.discard(folder, version.id);
                throw error;
            }
            return withRevision(path, content);
        });
    }

    return {
        list, create, read, createFile, save,
        sourcePath: (id, path) => access(id, async folder => workspacePath(folder, await onlyFile(folder, path))),
    };
}
