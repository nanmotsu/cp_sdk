/**
 * @file Agent Host上のCopilotセッションの選択、モデル指定、ターン送信と応答の受信を扱う。
 */

import { randomUUID } from 'node:crypto';
import { realpath } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { workspacePath } from '../../common/filesystem/paths.mjs';
import { connectAgentHost } from '../../common/ahp/client.mjs';
import { createSession, listSessions, primaryDirectory, readySession, resolveSessionConfig, titleSession } from '../../common/ahp/sessions.mjs';
import { generateTurn } from '../../common/ahp/turn.mjs';
import { workspaceRoot } from '../../common/filesystem/locations.mjs';
import { ApiError } from '../../common/api/errors.mjs';

const MAX_GENERATED_IMAGE_BYTES = 12 * 1024 * 1024;
const MAX_GENERATED_TOTAL_BYTES = 20 * 1024 * 1024;
const agentFiles = {
    'edit-document': '.github/agents/document-editor.agent.md',
    'compose-figure': '.github/agents/figure-composer.agent.md',
    'traceability-generate-related': '.github/agents/traceability/generate/related.agent.md',
};
for (const mode of ['generate', 'revise', 'check']) {
    for (const stage of ['source', 'target', 'map']) {
        agentFiles[`traceability-${mode}-${stage}`] = `.github/agents/traceability/${mode}/${stage}.agent.md`;
    }
}
const providerIds = ['copilotcli', 'copilot'];
const TURN_TIMEOUT = 180_000;
const FIGURE_TURN_TIMEOUT = 360_000;
const LIST_TIMEOUT = 15_000;
const SESSION_ARCHIVED = 1 << 6;


/** プロトコルで利用可能なセッション設定を確認し、作業場所と承認モードを含む作成要求を組み立てる。 */
async function sessionOptions(connection, { provider, workingDirectory, protocolVersion, purpose, signal }) {
    const requested = {
        mode: purpose === 'compose-figure' ? 'interactive' : 'plan', approvals: 'manual',
        autoApprove: 'default', approvalMode: 'manual',
        sandboxEnabled: 'on', isolation: 'folder', target: 'workspace',
    };
    const { schema, values } = await resolveSessionConfig(connection, provider, workingDirectory, requested, signal);
    const config = {};
    const properties = schema?.properties ?? {};
    for (const [key, desired] of Object.entries(requested)) {
        if (properties[key]?.enum?.includes(desired) && values?.[key] === desired) config[key] = desired;
    }
    assertApprovalMode({ ...config, effectiveApprovalMode: values?.effectiveApprovalMode }, purpose);
    if (values?.isolation === 'worktree' || values?.target === 'worktree'
        || (properties.isolation?.enum?.includes('folder') && config.isolation !== 'folder')
        || (properties.target?.enum?.includes('workspace') && config.target !== 'workspace')) {
        throw new ApiError(409, 'AHP_WORKSPACE', 'Copilotセッションの作業場所をこのアプリのリポジトリ直下に設定できませんでした。');
    }
    return { provider, config, workingDirectory, protocolVersion };
}

/** 用途に応じたCopilotモードと手動承認が有効なチャットだけを通す。 */
function assertApprovalMode({ mode, approvals, autoApprove, approvalMode, effectiveApprovalMode }, purpose) {
    const manual = (approvals === 'manual' || autoApprove === 'default' || approvalMode === 'manual')
        && (approvals === undefined || approvals === 'manual')
        && (autoApprove === undefined || autoApprove === 'default')
        && (approvalMode === undefined || approvalMode === 'manual');
    const validMode = purpose === 'compose-figure' ? mode === 'interactive' : mode === 'plan' || mode === 'interactive';
    if (!validMode || !manual || (effectiveApprovalMode && !['default', 'manual'].includes(effectiveApprovalMode))) {
        throw new ApiError(409, 'AHP_APPROVAL_MODE',
            `VS CodeでこのCopilotチャットを${purpose === 'compose-figure' ? 'Interactive' : 'PlanまたはInteractive'}モードと手動のツール承認に設定してから再実行してください。`);
    }
}

/** ファイルシステム上の作業場所を比較するため、パスの表記をそろえる。 */
function normalizedPath(path) {
    const absolute = resolve(path);
    return process.platform === 'win32' ? absolute.toLowerCase() : absolute;
}


/** ファイルURIをローカルパスへ変換し、パス表記の違いを吸収して比較する。 */
function sameLocalPath(uri, path) {
    try {
        return normalizedPath(fileURLToPath(uri)) === normalizedPath(path);
    } catch {
        return false;
    }
}

/** 再利用するセッションIDが扱えるリソースURIの形式かを確認する。 */
function validSessionId(id) {
    return typeof id === 'string' && /^(?:ahp-session|copilotcli|copilot):\/[^\s]+$/.test(id);
}

/** Agent Hostの情報を、GUIのセッション選択に必要な項目へ変換する。 */
function presentSession(session) {
    return {
        id: session.resource,
        title: session.title?.trim() || 'Copilot セッション',
        ...(typeof session.modifiedAt === 'string' && { modifiedAt: session.modifiedAt }),
    };
}

/** Agent Hostの一覧を順に取得し、アプリと同じ作業場所・プロバイダーの有効なセッションを返す。 */
async function* repositorySessions(connection, provider, repository, signal) {
    for await (const session of listSessions(connection, signal)) {
        if (session.provider === provider && validSessionId(session.resource) && !(session.status & SESSION_ARCHIVED)
            && sameLocalPath(primaryDirectory(session), repository)) yield session;
    }
}

/** 選択されたセッションが、このアプリで再利用できる一覧にあることを確認する。 */
async function chooseSession(connection, provider, repository, sessionId, signal) {
    if (!validSessionId(sessionId)) throw new ApiError(400, 'AHP_SESSION_ID', 'CopilotセッションのIDが無効です。');
    for await (const session of repositorySessions(connection, provider, repository, signal)) {
        if (session.resource === sessionId) return session;
    }
    throw new ApiError(404, 'AHP_SESSION_NOT_FOUND', 'このリポジトリのCopilotセッションが見つかりません。セッション一覧を更新してください。');
}


/** Agent Hostのモデル一覧から、識別子があり無効化されていないものを選ぶ。 */
function availableModels(models) {
    return Array.isArray(models) ? models.filter((model) => typeof model?.id === 'string' && model.id && model.policyState !== 'disabled') : [];
}

/** 画像入力に対応していないことが分かるモデルでの添付付き依頼を止める。 */
function requireImageModel(candidates, model) {
    const unsupported = model?.id
        ? candidates.find(({ id }) => id === model.id)?.supportsVision === false
        : candidates.length > 0 && candidates.every(({ supportsVision }) => supportsVision === false);
    if (unsupported) {
        throw new ApiError(409, 'AHP_IMAGE_MODEL_REQUIRED', '現在のCopilotモデルは画像入力に対応していません。画像入力に対応するモデルを選んでください。');
    }
}


/** 同じCopilotチャットで別のターンが進行中であることを通知する。 */
function sessionBusy() {
    return new ApiError(409, 'AHP_SESSION_BUSY', 'このCopilotチャットは応答中です。VS Codeで完了を待つか、別のセッションを選んでください。');
}

/** アプリのファイル・画像添付をAHPのメッセージ形式へ変換する。 */
function ahpAttachment(attachment) {
    if (attachment.kind === 'image') {
        const { label, mime, bytes } = attachment;
        return { type: 'embeddedResource', displayKind: 'image', label, contentType: mime, data: Buffer.from(bytes).toString('base64') };
    }
    const { uri, label, role, range } = attachment;
    return { type: 'resource', uri, label, displayKind: role, ...(range && { selection: { range } }) };
}

/** 画像生成ツールのAHP結果から、元画像のバイナリだけを読み取る。 */
async function generatedImageResults(connection, result, signal) {
    const contents = result.content ?? [];
    const originals = result.structuredContent?.imageGeneration?.images;
    const selected = Array.isArray(originals) ? originals.map(item => contents[item.contentIndex]) : contents;
    const images = [];
    for (const content of selected) {
        if (!content || !['embeddedResource', 'resource'].includes(content.type)) continue;
        let resource = content;
        if (content.type === 'resource') {
            const uri = content.uri;
            if (typeof uri !== 'string') continue;
            resource = await connection.request('resourceRead',
                { channel: 'ahp-root://', uri, encoding: 'base64', length: MAX_GENERATED_IMAGE_BYTES + 1 },
                { signal, timeout: 15_000 });
        }
        const mime = resource.contentType ?? content.contentType;
        if (typeof mime !== 'string' || !mime.startsWith('image/') || typeof resource.data !== 'string') continue;
        if (resource.data.length > Math.ceil(MAX_GENERATED_IMAGE_BYTES * 4 / 3) + 4) {
            throw new ApiError(413, 'AHP_GENERATED_IMAGE_TOO_LARGE', 'Copilotが生成した画像が12 MiBを超えました。');
        }
        const bytes = Buffer.from(resource.data, 'base64');
        if (!bytes.length || bytes.length > MAX_GENERATED_IMAGE_BYTES) {
            throw new ApiError(413, 'AHP_GENERATED_IMAGE_TOO_LARGE', 'Copilotが生成した画像を読み込めませんでした。');
        }
        images.push({ mime, bytes });
    }
    return images;
}

/** GitHub Copilotが公開されているAgent Hostへ接続する。 */
export async function connectCopilot({ discover, signal } = {}) {
    const { connection, agent, protocolVersion } = await connectAgentHost({
        discover, signal,
        selectAgent(agents) {
            for (const provider of providerIds) {
                const selected = agents.find(agent => agent.provider === provider);
                if (selected) return selected;
            }
            throw new ApiError(503, 'AHP_COPILOT_UNAVAILABLE', 'Agent HostでGitHub Copilotを利用できません。VS CodeのCopilotを確認してください。');
        },
    });
    return { connection, provider: agent.provider, models: agent.models, protocolVersion };
}

/** 送信前に作業場所、Planモードと手動承認、モデルの画像対応を確認する。 */
function validateChat(chatState, { session, provider, repository, config, imageRequest, models, model, purpose }) {
    if (chatState?.activeTurn) throw sessionBusy();
    if (chatState?.provider && chatState.provider !== provider) {
        throw new ApiError(409, 'AHP_CHAT_PROVIDER', 'VS CodeセッションのメインチャットがGitHub Copilotを使用していません。');
    }
    if (primaryDirectory(chatState) && !sameLocalPath(primaryDirectory(chatState), repository)) {
        throw new ApiError(409, 'AHP_WORKSPACE', 'VS Codeセッションのメインチャットの作業場所が、このアプリのリポジトリと異なります。');
    }
    assertApprovalMode({ ...config, ...session.config?.values, ...chatState?.config?.values }, purpose);
    if (imageRequest && !model) requireImageModel(models, chatState?.model ?? session.model);
}

/**
 * Agent Host接続と作業場所を差し替え可能にしたCopilotアダプターを作る。
 * @returns {import('../agent.mjs').Agent}
 */
export function createGitHubCopilot({ connect = connectCopilot, repositoryRoot = workspaceRoot } = {}) {
    const running = new Set();
    return {
        /** 接続可否を確認し、使える場合はプロトコルとモデル候補を返す。 */
        async status() {
            try {
                const { connection, protocolVersion, models } = await connect({ signal: AbortSignal.timeout(4500) });
                connection.close();
                return {
                    available: true, protocolVersion, message: 'VS CodeのAgent HostでGitHub Copilotを検出しました。',
                    models: availableModels(models).map(({ id, name, supportsVision }) => ({
                        id, name: typeof name === 'string' && name.trim() ? name : id,
                        ...(typeof supportsVision === 'boolean' && { supportsVision }),
                    })),
                };
            } catch (error) {
                return { available: false, message: error.status ? error.message : 'VS CodeのAgent Hostに接続できません。VS Codeを起動し、Copilotのログイン状態を確認してください。' };
            }
        },

        /** 時間制限内で、このアプリの作業場所に属するセッションを列挙する。 */
        async listSessions({ signal } = {}) {
            const timeout = AbortSignal.timeout(LIST_TIMEOUT);
            const listSignal = signal ? AbortSignal.any([signal, timeout]) : timeout;
            listSignal.throwIfAborted();
            let connection;
            try {
                const repository = await realpath(repositoryRoot);
                const host = await connect({ signal: listSignal });
                connection = host.connection;
                const sessions = [];
                for await (const session of repositorySessions(connection, host.provider, repository, listSignal)) {
                    sessions.push(presentSession(session));
                }
                return sessions;
            } catch (error) {
                signal?.throwIfAborted();
                if (timeout.aborted) throw new ApiError(504, 'AHP_TIMEOUT', 'Copilotセッション一覧の取得がタイムアウトしました。');
                throw error;
            } finally {
                connection?.close();
            }
        },

        /** モデルを確認し、新規または選択済みセッションで依頼を実行する。終了時は接続と実行中の記録を解放する。 */
        async complete({ purpose, prompt, attachments, sessionId, sessionTitle, modelId, signal, onProgress }) {
            const agentPath = Object.hasOwn(agentFiles, purpose) && agentFiles[purpose];
            if (!agentPath) throw new ApiError(400, 'INVALID_AGENT_PURPOSE', 'エージェントの用途を確認してください。');
            const imageRequest = attachments?.some(item => item.kind === 'image');
            const generatedImages = [];
            const timeout = AbortSignal.timeout(purpose === 'compose-figure' ? FIGURE_TURN_TIMEOUT : TURN_TIMEOUT);
            const jobSignal = signal ? AbortSignal.any([signal, timeout]) : timeout;
            jobSignal.throwIfAborted();
            const selected = sessionId != null;
            const id = sessionId ?? `ahp-session:/${randomUUID()}`;
            if (running.has(id)) throw sessionBusy();
            running.add(id);
            let connection;
            try {
                onProgress?.('VS CodeのAgent Hostに接続しています。');
                const repository = await realpath(repositoryRoot);
                const agentFile = agentPath && await workspacePath(repository, agentPath).catch(() => {
                    throw new ApiError(409, 'AHP_CUSTOM_AGENT_NOT_FOUND', `作業フォルダで専用エージェント ${agentPath} を確認してください。`);
                });
                const host = await connect({ signal: jobSignal });
                const { provider, protocolVersion } = host;
                connection = host.connection;
                const models = availableModels(host.models);
                const model = modelId == null ? undefined : { id: modelId };
                if (model && !models.some(({ id }) => id === model.id)) {
                    throw new ApiError(409, 'AHP_MODEL_UNAVAILABLE', '選択したCopilotモデルを利用できません。接続を確認してモデルを選び直してください。');
                }
                if (model && imageRequest) requireImageModel(models, model);
                let summary;
                let config;
                if (selected) {
                    summary = await chooseSession(connection, provider, repository, id, jobSignal);
                } else {
                    const workingDirectory = pathToFileURL(repository).href;
                    const options = await sessionOptions(connection, { provider, workingDirectory, protocolVersion, purpose, signal: jobSignal });
                    config = options.config;
                    await createSession(connection, id, { ...options, ...(model && { model }) }, jobSignal);
                    const title = sessionTitle?.trim().slice(0, 160) || 'MD Operator';
                    summary = { resource: id, title };
                }
                const agentDiscovery = AbortSignal.timeout(10_000);
                const readySignal = AbortSignal.any([jobSignal, agentDiscovery]);
                const { session, agent } = await readySession(connection, id, readySignal, uri => sameLocalPath(uri, agentFile)).catch(error => {
                    if (agentDiscovery.aborted && !jobSignal.aborted) {
                        throw new ApiError(409, 'AHP_CUSTOM_AGENT_UNAVAILABLE',
                            `VS Codeでこのアプリのルートを開き、専用エージェント ${agentPath} が有効か確認してください。`);
                    }
                    throw error;
                });
                if ((session.provider && session.provider !== provider)
                    || (primaryDirectory(session) && !sameLocalPath(primaryDirectory(session), repository))
                    || (session.status & SESSION_ARCHIVED)) {
                    throw new ApiError(409, 'AHP_WORKSPACE', 'このリポジトリで使用できるCopilotセッションを選んでください。');
                }
                if (!selected) titleSession(connection, id, summary.title);
                onProgress?.(purpose === 'compose-figure'
                    ? 'Copilotに図版と画像パーツの作成を依頼しています。' : 'Copilotに依頼しています。');
                const text = await generateTurn(connection, {
                    session, model, agent, prompt, attachments: attachments?.map(ahpAttachment), imageRequest, signal: jobSignal,
                    validateChat: state => validateChat(state, { session, provider, repository, config, imageRequest, models, model, purpose }),
                    allowedTools: purpose === 'compose-figure' ? ['image_generation'] : [],
                    manualTools: purpose.startsWith('traceability-')
                        ? ['read', 'read_file', 'readFile', 'search', 'file_search', 'grep_search', 'list_dir', 'list_directory']
                        : purpose === 'edit-document'
                        ? ['read', 'read_file', 'readFile', 'search', 'file_search', 'grep_search',
                            'execute', 'run_in_terminal', 'runInTerminal', 'powershell', 'bash', 'local_shell'] : [],
                    onToolApprovalNeeded: () => onProgress?.('VS Codeで資料の読み取りに必要なツールを確認してください。'),
                    async onToolResult(_name, result) {
                        onProgress?.('Copilotが生成した画像を受信しています。');
                        const images = await generatedImageResults(connection, result, jobSignal);
                        generatedImages.push(...images);
                        if (generatedImages.length > 16 || generatedImages.reduce((sum, image) => sum + image.bytes.length, 0) > MAX_GENERATED_TOTAL_BYTES) {
                            throw new ApiError(413, 'AHP_GENERATED_IMAGES_TOO_LARGE', 'Copilotが生成した画像の合計を20 MiB以下にしてください。');
                        }
                    },
                    onToolDenied: () => onProgress?.('Copilotの外部ツール要求を拒否しました。'),
                    onText: () => onProgress?.(imageRequest ? 'Copilotの図版案を受信しています。' : 'Copilotの応答を受信しています。'),
                });
                if (!text) throw new ApiError(502, 'AHP_EMPTY_RESPONSE', 'Copilotから本文を受信できませんでした。');
                return { text, session: presentSession(summary), ...(purpose === 'compose-figure' && { generatedImages }) };
            } catch (error) {
                signal?.throwIfAborted();
                if (timeout.aborted) throw new ApiError(504, 'AHP_TIMEOUT', 'Copilotの応答がタイムアウトしました。');
                throw error;
            } finally {
                connection?.close();
                running.delete(id);
            }
        },
    };
}
