/** @file ブロックの右クリックメニュー、図のサイズ調整、個別のMarkdown編集欄。 */

import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import type { FormEvent, KeyboardEvent } from 'react';
import { createPortal } from 'react-dom';
import { layoutLength } from '../../../../packages/markdown/layout.mjs';

/** 右クリックしたブロックに提供する個別操作。 */
export interface BlockMenuAction { label: string; run: () => void }

/** 右クリックした図の掲載寸法と、その変更を反映する操作。 */
interface FigureSizeOptions {
  width: string;
  height: string;
  mermaid: boolean;
  onApply: (changes: Record<string, string>) => void;
}

/** ブロック固有の操作と、横に開く追加・サイズ変更の入力欄を表示する。 */
export function VisualBlockMenu({ x, y, actions, sizeOptions, captionOptions, canDelete, tableEnabled, onClose, onDelete, onParagraph, onTable, onMermaid, onFigure }: {
  x: number;
  y: number;
  actions: BlockMenuAction[];
  sizeOptions?: FigureSizeOptions;
  captionOptions?: { value: string; onApply: (value: string) => void };
  canDelete: boolean;
  tableEnabled: boolean;
  onClose: (restoreFocus: boolean) => void;
  onDelete: () => void;
  onParagraph: () => void;
  onTable: (event: FormEvent<HTMLFormElement>) => void;
  onMermaid: () => void;
  onFigure: () => void;
}) {
  const popup = useRef<HTMLDivElement>(null);
  const menu = useRef<HTMLDivElement>(null);
  const submenu = useRef<HTMLDivElement>(null);
  const addButton = useRef<HTMLButtonElement>(null);
  const sizeButton = useRef<HTMLButtonElement>(null);
  const captionButton = useRef<HTMLButtonElement>(null);
  const [branch, setBranch] = useState<'closed' | 'add' | 'table' | 'size' | 'caption'>('closed');
  const adding = branch === 'add' || branch === 'table';
  const triggerRef = branch === 'size' ? sizeButton : branch === 'caption' ? captionButton : addButton;
  const figureForm = branch === 'size' || branch === 'caption';

  useLayoutEffect(() => {
    const element = menu.current!;
    positionMenu(element, x, y);
    element.querySelector<HTMLElement>('[role="menuitem"]:not(:disabled)')?.focus({ preventScroll: true });
  }, [x, y]);

  useLayoutEffect(() => {
    const element = submenu.current;
    const trigger = triggerRef.current;
    if (!element || !trigger) return;
    const positionSubmenu = () => {
      const anchor = trigger.getBoundingClientRect();
      const width = element.getBoundingClientRect().width;
      const right = anchor.right + 8;
      const left = anchor.left - width - 8;
      positionMenu(element, right + width <= window.innerWidth - 8 || left < 8 ? right : left, anchor.top);
    };
    positionSubmenu();
    element.querySelector<HTMLElement>('input, [role="menuitem"]:not(:disabled)')?.focus({ preventScroll: true });
    const observer = new ResizeObserver(positionSubmenu);
    observer.observe(element);
    return () => observer.disconnect();
  }, [branch, triggerRef, x, y]);

  useEffect(() => {
    function dismissOutside(event: Event) {
      if (event.target instanceof Node && !popup.current?.contains(event.target)) onClose(false);
    }
    document.addEventListener('pointerdown', dismissOutside);
    document.addEventListener('focusin', dismissOutside);
    document.addEventListener('wheel', dismissOutside, { passive: true });
    return () => {
      document.removeEventListener('pointerdown', dismissOutside);
      document.removeEventListener('focusin', dismissOutside);
      document.removeEventListener('wheel', dismissOutside);
    };
  }, [onClose]);

  /** 横に開いた欄を閉じ、呼び出し元の項目へフォーカスを戻す。 */
  function closeSubmenu() {
    const trigger = triggerRef.current;
    setBranch('closed');
    trigger?.focus({ preventScroll: true });
  }

  /** 矢印で同じ階層の項目を移動し、Escapeで一つ前の階層へ戻る。 */
  function navigate(event: KeyboardEvent<HTMLDivElement>) {
    const target = event.target as HTMLElement;
    const insideSubmenu = submenu.current?.contains(target);
    if (event.key === 'Escape') {
      event.preventDefault();
      event.stopPropagation();
      if (insideSubmenu) closeSubmenu();
      else onClose(true);
      return;
    }
    const requested = target === sizeButton.current ? 'size' : target === captionButton.current ? 'caption'
      : target === addButton.current ? 'add' : undefined;
    if (event.key === 'ArrowRight' && requested) {
      event.preventDefault();
      if (requested === 'add' ? adding : branch === requested) {
        submenu.current?.querySelector<HTMLElement>('input, [role="menuitem"]:not(:disabled)')?.focus();
      } else setBranch(requested);
      return;
    }
    const list = target.closest('[role="menu"]');
    if (!list) return;
    if (event.key === 'ArrowLeft' && insideSubmenu) {
      event.preventDefault();
      closeSubmenu();
      return;
    }
    if (!['ArrowUp', 'ArrowDown', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    const items = Array.from(list.querySelectorAll<HTMLButtonElement>('[role="menuitem"]:not(:disabled)'));
    const index = items.indexOf(document.activeElement as HTMLButtonElement);
    const next = event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1
      : (index + (event.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
    items[next]?.focus();
  }

  return createPortal(
    <div ref={popup} onKeyDown={navigate}>
      <div ref={menu} className="visual-context-menu visual-menu-surface" role="menu" aria-label="ブロックの操作">
        {actions.map(({ label, run }) => <button key={label} type="button" role="menuitem" tabIndex={-1} onClick={run}>{label}</button>)}
        {sizeOptions && <button ref={sizeButton} type="button" role="menuitem" tabIndex={-1}
          aria-label="サイズを調整" aria-haspopup="dialog" aria-expanded={branch === 'size'}
          onClick={() => branch === 'size' ? closeSubmenu() : setBranch('size')}>
          サイズを調整 <span aria-hidden="true">▸</span>
        </button>}
        {captionOptions && <button ref={captionButton} type="button" role="menuitem" tabIndex={-1}
          aria-label="図題を編集" aria-haspopup="dialog" aria-expanded={branch === 'caption'}
          onClick={() => branch === 'caption' ? closeSubmenu() : setBranch('caption')}>
          図題を編集 <span aria-hidden="true">▸</span>
        </button>}
        {(actions.length > 0 || sizeOptions || captionOptions) && <div className="visual-menu-divider" role="separator" />}
        <button ref={addButton} type="button" role="menuitem" tabIndex={-1} aria-haspopup="menu" aria-expanded={adding}
          onClick={() => adding ? closeSubmenu() : setBranch('add')}>
          このブロックの下に追加 <span aria-hidden="true">▸</span>
        </button>
        <button type="button" role="menuitem" tabIndex={-1} className="visual-menu-delete" disabled={!canDelete}
          onClick={onDelete}>このブロックを削除</button>
      </div>
      {branch !== 'closed' && <div ref={submenu} className={figureForm ? 'visual-menu-surface' : 'visual-add-menu visual-menu-surface'}
        role={figureForm ? 'dialog' : undefined} aria-label={branch === 'caption' ? '図題の編集' : branch === 'size' ? '図のサイズ調整' : undefined}>
        {branch === 'size' && sizeOptions && <FigureSizeFields {...sizeOptions} onCancel={closeSubmenu} />}
        {branch === 'caption' && captionOptions && <form className="visual-caption-fields" onSubmit={event => {
          event.preventDefault();
          captionOptions.onApply(String(new FormData(event.currentTarget).get('caption') ?? ''));
        }}>
          <label>図題<input name="caption" defaultValue={captionOptions.value} /></label>
          <div className="form-actions">
            <button type="button" onClick={closeSubmenu}>キャンセル</button>
            <button type="submit" className="primary">図題を反映</button>
          </div>
        </form>}
        {branch === 'table' && <form className="visual-table-options" aria-label="挿入する表" onSubmit={onTable}>
          <label>列数 <input name="columns" type="number" min={1} max={20} defaultValue={3} required /></label>
          <label>データ行数 <input name="rows" type="number" min={0} max={30} defaultValue={2} required /></label>
          <label>表題（任意）<input name="caption" type="text" /></label>
          <div className="form-actions">
            <button type="button" onClick={closeSubmenu}>キャンセル</button>
            <button type="submit" className="primary" disabled={!tableEnabled}>表を追加</button>
          </div>
        </form>}
        {branch === 'add' && <div role="menu" aria-label="このブロックの下に追加">
          <button type="button" role="menuitem" tabIndex={-1} onClick={onParagraph}>空段落</button>
          <button type="button" role="menuitem" tabIndex={-1} disabled={!tableEnabled}
            onClick={() => setBranch('table')}>テーブルDSL</button>
          <button type="button" role="menuitem" tabIndex={-1} onClick={onMermaid}>Mermaid DSL</button>
          <button type="button" role="menuitem" tabIndex={-1} onClick={onFigure}>図版</button>
        </div>}
      </div>}
    </div>,
    document.body,
  );
}

/** スクロール領域から切り離したメニューをビューポートに収める。 */
function positionMenu(element: HTMLElement, x: number, y: number) {
  const { width, height } = element.getBoundingClientRect();
  element.style.left = `${Math.max(8, Math.min(x, window.innerWidth - width - 8))}px`;
  element.style.top = `${Math.max(8, Math.min(y, window.innerHeight - height - 8))}px`;
}

/** 図のサイズを適用する。空欄は、原本にあるその項目の指定を解除する。 */
function FigureSizeFields({ width, height, mermaid, onApply, onCancel }: FigureSizeOptions & { onCancel: () => void }) {
  const [error, setError] = useState('');

  function apply(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const changes = Object.fromEntries(Object.entries({ width, height }).flatMap(([key, previous]) => {
      const value = String(data.get(key) ?? '').trim();
      return value === previous ? [] : [[key, value]];
    }));
    if (Object.values(changes).some(value => value && !layoutLength(value))) {
      setError('80% や 240px のように、数値と単位を指定してください。空欄で既定値に戻ります。');
      return;
    }
    onApply(changes);
  }

  return <form className="visual-size-fields" aria-label="図のサイズ" onSubmit={apply}>
    <label>幅<input name="width" defaultValue={width} placeholder="例 80%" /></label>
    <label>{mermaid ? '最大の高さ' : '高さ'}<input name="height" defaultValue={height} placeholder="例 240px" /></label>
    {error && <p className="error" role="alert">{error}</p>}
    <div className="form-actions">
      <button type="button" onClick={onCancel}>キャンセル</button>
      <button type="submit" className="primary">サイズを反映</button>
    </div>
  </form>;
}

/** 直接編集したソースは、更新操作でビジュアル表示へ反映する。 */
export function BlockSource({ source, mermaid, pending, disabled, onChange, onRefresh }: {
  source: string;
  mermaid: boolean;
  pending: boolean;
  disabled: boolean;
  onChange: (element: HTMLTextAreaElement, inputType: string) => void;
  onRefresh: () => void;
}) {
  return <details className={mermaid ? 'visual-mermaid-source visual-block-source' : 'visual-block-source'}>
    <summary>ソースを編集</summary>
    <textarea aria-label={mermaid ? 'MermaidのMarkdownソース' : 'ブロックのMarkdownソース'} spellCheck={false}
      readOnly={disabled} value={source.replace(/\r\n?/g, '\n')}
      onChange={event => onChange(event.currentTarget, (event.nativeEvent as InputEvent).inputType)} rows={8} />
    <button type="button" disabled={disabled || !pending} onClick={onRefresh}>{mermaid ? '図を更新' : '表示に反映'}</button>
  </details>;
}
