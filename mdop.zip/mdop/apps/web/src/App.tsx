/**
 * @file MD Operatorの画面全体。文書の選択と中央の編集欄、右側の操作パネルを同期する。
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { KeyboardEvent as ReactKeyboardEvent } from 'react';
import { isFigureImagePath } from '../../../packages/markdown/figure-paths.mjs';
import { api, errorMessage } from './api';
import type { BackupDetail, DocumentInfo } from './api';
import { hasUnsavedChanges, useWorkspace } from './workspace';
import AssistPanel from './components/AssistPanel';
import ConfigPanel from './components/ConfigPanel';
import DocumentLibrary from './components/DocumentLibrary';
import DocumentTree from './components/DocumentTree';
import FigureLibrary from './components/FigureLibrary';
import HistoryPanel from './components/HistoryPanel';
import InspectorResize from './components/InspectorResize';
import OutputPanel from './components/OutputPanel';
import PreviewPanel from './components/PreviewPanel';
import SidebarResize from './components/SidebarResize';
import VisualEditor from './components/VisualEditor';
import TraceabilityLibrary from './components/traceability/TraceabilityLibrary';
import TraceabilityEditor from './components/traceability/TraceabilityEditor';
import type { VisualEditorHandle } from './components/VisualEditor';
import { insertMarkdownBlock } from './editor/blocks';
import { encodeFigureCaption } from './editor/directives';
import { editDocumentHeadingNumbers } from './editor/headingNumbers';
import type { HeadingNumberAction } from './editor/headingNumbers';
import { buildHeadingOutline } from './editor/outline';
import type { HeadingOutlineEntry } from './editor/outline';
import { VisualHistory } from './editor/visualHistory';

const panels = [
  { id: 'preview', text: 'プレビュー' },
  { id: 'output', text: '出力・Word' },
  { id: 'history', text: '履歴' },
  { id: 'config', text: '設定' },
  { id: 'assist', text: 'AIエージェント（GitHub Copilot）支援' },
  { id: 'figures', text: '図版' },
] as const;

/** 右側で開けるパネルの識別子。 */
type Panel = typeof panels[number]['id'];

const defaultTocDepth = 3;

/** ソース上の見出しへカーソルを移し、折り返しも考慮して付近が見える位置までスクロールする。 */
function revealSourceHeading(field: HTMLTextAreaElement, markdown: string, offset: number) {
  const previous = markdown.slice(0, offset).replace(/\r\n?/g, '\n');
  field.focus({ preventScroll: true });
  field.setSelectionRange(previous.length, previous.length);

  // Measure preceding text at the current line-wrap width of the editor.
  const mirror = field.cloneNode(false) as HTMLTextAreaElement;
  const lineHeight = parseFloat(getComputedStyle(field).lineHeight);
  mirror.value = previous;
  mirror.removeAttribute('aria-label');
  mirror.setAttribute('aria-hidden', 'true');
  mirror.style.cssText = `position:absolute;visibility:hidden;overflow:hidden;height:0;width:${field.clientWidth}px`;
  field.parentElement?.append(mirror);
  field.scrollTop = Math.max(0, mirror.scrollHeight - lineHeight * 2);
  mirror.remove();
}

/** 文書の開閉、編集モード、保存、プレビューと各操作パネルの起点を提供する。 */
export default function App() {
  const { documents, documentId, file, opening, saving, restoring, conflict, error, message,
    refreshDocuments, open, update: updateMarkdown, save, restore, setError, setMessage } = useWorkspace();
  const [loading, setLoading] = useState(true);
  const [traceabilityId, setTraceabilityId] = useState<string | null>(null);
  const [panel, setPanel] = useState<Panel>('preview');
  const [mode, setMode] = useState<'visual' | 'source'>('visual');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [visited, setVisited] = useState<Panel[]>([]);
  const [configVersion, setConfigVersion] = useState(0);
  const [assetVersion, setAssetVersion] = useState(0);
  const figureCreated = useCallback(() => setAssetVersion(version => version + 1), []);
  const [restoredVersion, setRestoredVersion] = useState(0);
  const [selectedBackup, setSelectedBackup] = useState('');
  const [outlineConfig, setOutlineConfig] = useState<{ documentId: string; depth: number } | null>(null);
  const editorPane = useRef<HTMLElement>(null);
  const sidebarPane = useRef<HTMLElement>(null);
  const inspectorPane = useRef<HTMLElement>(null);
  const sourceEditor = useRef<HTMLTextAreaElement>(null);
  const sourceHeadingEdit = useRef<{ content: string; history: VisualHistory } | undefined>(undefined);
  const visualEditor = useRef<VisualEditorHandle>(null);
  const dirty = hasUnsavedChanges(file);
  const changingDocument = opening || restoring;
  const document = documents.find((item) => item.id === documentId);
  const activeDocumentId = file?.documentId;
  const currentMarkdown = file?.content;
  const outlineDepth = outlineConfig?.documentId === activeDocumentId ? outlineConfig?.depth : undefined;
  const outline = useMemo(() => currentMarkdown && outlineDepth
    ? buildHeadingOutline(currentMarkdown, outlineDepth) : [], [currentMarkdown, outlineDepth]);

  useEffect(() => {
    if (!activeDocumentId) return;
    const controller = new AbortController();
    api.config(activeDocumentId, controller.signal).then(({ config }) => {
      const value = config?.tocDepth;
      const depth = typeof value === 'number' && Number.isInteger(value) && value >= 1 && value <= defaultTocDepth
        ? value : defaultTocDepth;
      if (!controller.signal.aborted) setOutlineConfig({ documentId: activeDocumentId, depth });
    }).catch(() => {
      if (!controller.signal.aborted) setOutlineConfig({ documentId: activeDocumentId, depth: defaultTocDepth });
    });
    return () => controller.abort();
  }, [activeDocumentId, configVersion]);

  useEffect(() => { sourceHeadingEdit.current = undefined; }, [activeDocumentId, file?.path, mode, restoredVersion]);

  useEffect(() => {
    let active = true;
    void refreshDocuments().catch((exception: unknown) => {
      if (active) setError(errorMessage(exception));
    }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [refreshDocuments, open, setError]);

  useEffect(() => {
    /** ダイアログを閉じている状態で、CtrlまたはCommandとSによる保存を処理する。 */
    function shortcut(event: KeyboardEvent) {
      if (traceabilityId) return;
      if (!(event.ctrlKey || event.metaKey) || event.key.toLowerCase() !== 's') return;
      event.preventDefault();
      if (window.document.querySelector('dialog[open]')) return;
      void save();
    }
    window.addEventListener('keydown', shortcut);
    return () => window.removeEventListener('keydown', shortcut);
  }, [save, traceabilityId]);

  useEffect(() => {
    if (!dirty) return;
    /** 未保存時にブラウザーのページ離脱確認を要求する。 */
    function confirmLeave(event: BeforeUnloadEvent) { event.preventDefault(); }
    window.addEventListener('beforeunload', confirmLeave);
    return () => window.removeEventListener('beforeunload', confirmLeave);
  }, [dirty]);

  /** 未保存の本文を確認してから文書選択を切り替え、パネルを初期化する。 */
  function select(id: string | null, path?: string) {
    const current = useWorkspace.getState();
    if (current.saving || current.restoring) return;
    if (current.documentId === id && current.file?.path === path) return;
    if (hasUnsavedChanges(current.file) && !window.confirm('未保存の編集を破棄して移動しますか？')) return;
    setPanel('preview');
    setVisited([]);
    setSelectedBackup('');
    void open(id, path);
  }

  /** 指定の右側パネルを選び、初回表示に必要なコンポーネントを準備する。 */
  function showPanel(next: Panel) {
    if (next !== 'figures') visualEditor.current?.clearFigureTarget();
    setPanel(next);
    setVisited((current) => current.includes(next) ? current : [...current, next]);
  }

  /** 本文の挿入先から開いた図版一覧へ、キーボードのフォーカスも移す。 */
  function chooseFigure() {
    showPanel('figures');
    inspectorPane.current?.querySelector<HTMLButtonElement>('[data-panel="figures"]')?.focus();
  }

  /** 現在の編集モードに合う方法で原本内の見出しへ移動する。 */
  function jumpToHeading(heading: HeadingOutlineEntry) {
    if (!file || changingDocument) return;
    if (mode === 'source' && sourceEditor.current) {
      revealSourceHeading(sourceEditor.current, file.content, heading.offset);
    } else {
      visualEditor.current?.revealHeading(heading.offset);
    }
  }

  /** 選択中の文書で、見出し番号をまとめて変更する。 */
  function changeHeadingNumbers(action: HeadingNumberAction) {
    if (!file || changingDocument || saving) return;
    const content = editDocumentHeadingNumbers(file.content, action);
    if (content === file.content) {
      setMessage(action === 'add' ? '番号を追加する見出しがありません。' : '消せる見出し番号がありません。');
      return;
    }
    setMessage('');
    if (mode === 'visual') {
      visualEditor.current?.replaceHeadingNumbers(content);
      return;
    }
    const edit = sourceHeadingEdit.current;
    const history = edit?.content === file.content ? edit.history : new VisualHistory();
    history.remember({ markdown: file.content });
    sourceHeadingEdit.current = { content, history };
    updateMarkdown(content);
    sourceEditor.current?.focus();
  }

  /** ソース欄で番号変更をまとめて取り消す。入力中の文字編集はブラウザーの履歴に任せる。 */
  function sourceHeadingShortcut(event: ReactKeyboardEvent<HTMLTextAreaElement>) {
    if (!file || changingDocument || event.nativeEvent.isComposing || !(event.ctrlKey || event.metaKey) || event.altKey) return;
    const edit = sourceHeadingEdit.current;
    if (!edit || edit.content !== file.content) return;
    const key = event.key.toLowerCase();
    const direction = key === 'z' ? (event.shiftKey ? 'redo' : 'undo') : key === 'y' ? 'redo' : undefined;
    const next = direction && edit.history.step(direction, { markdown: file.content });
    if (!next) return;
    event.preventDefault();
    edit.content = next.markdown;
    updateMarkdown(next.markdown);
  }

  /** トップで選んだ文書を開く。 */
  function openDocument(target: DocumentInfo) {
    setPanel('preview');
    setVisited([]);
    setSelectedBackup('');
    void open(target.id, target.files[0]?.path);
  }

  /** 新規作成後に文書一覧を更新し、作成した文書を開く。 */
  async function created(target: DocumentInfo) {
    await refreshDocuments();
    openDocument(target);
  }

  /** 編集を抜ける際、未保存の本文があれば確認してから一覧に戻る。 */
  function backToLibrary() {
    const current = useWorkspace.getState();
    if (current.saving || current.restoring || current.opening) return;
    if (hasUnsavedChanges(current.file) && !window.confirm('未保存の編集を破棄して文書一覧に戻りますか？')) return;
    void open(null);
    setPanel('preview');
    setVisited([]);
    setSelectedBackup('');
    void refreshDocuments().catch((exception: unknown) => setError(errorMessage(exception)));
  }

  /** 選択中の文書に原本がない場合、空の index.md の作成を依頼する。 */
  async function recover() {
    if (!documentId) return;
    try {
      const recovered = await api.createFile(documentId, 'index.md', '');
      await refreshDocuments();
      select(documentId, recovered.path);
    } catch (exception) {
      setError(errorMessage(exception));
    }
  }

  /** Word取り込みやCopilotから、結果の版を選んで履歴を表示する。 */
  function openHistory(id: string) {
    if (useWorkspace.getState().file?.documentId !== file?.documentId) return;
    setSelectedBackup(id);
    showPanel('history');
  }

  /** 確認を得てからフォルダを復元し、本文・設定・画像・プレビューを読み替える。 */
  async function applyBackup(detail: BackupDetail) {
    if (!window.confirm('本文・設定・画像・出力ファイルを選んだ版の状態に戻します。編集中の本文を含む直前の状態は履歴に退避します。復元しますか？')) return;
    if (!await restore(detail)) return;
    setConfigVersion(version => version + 1);
    setAssetVersion(version => version + 1);
    setRestoredVersion(version => version + 1);
  }

  /** 設定の更新を各パネルへ知らせるため、表示用の版を進める。 */
  function configSaved() {
    setConfigVersion((version) => version + 1);
  }

  /** 保存した図版を、あとから表示サイズを指定できる図版ブロックとして挿入する。 */
  function insertFigure(path: string, name: string) {
    const active = useWorkspace.getState().file;
    if (!active || active.documentId !== documentId || active.path !== file?.path) return;
    if (!isFigureImagePath(path)) {
      setError('本文に挿入できる図版を選んでください。');
      return;
    }
    const description = name.replace(/[\[\]\\\r\n]/g, ' ');
    const source = path.split('/').map(encodeURIComponent).join('/');
    const lineEnding = /\r\n|\n|\r/.exec(active.content)?.[0] || '\n';
    const caption = encodeFigureCaption(name);
    const block = [':::figure', `![${description}](<${source}>)`, ...(caption ? ['', caption] : []), ':::'].join(lineEnding);
    const editor = visualEditor.current;
    const inserted = editor ? editor.insertFigure(block) : true;
    if (!editor) updateMarkdown(insertMarkdownBlock([active.content], 1, block, lineEnding).markdown);
    setAssetVersion((version) => version + 1);
    if (!inserted) {
      setError('本文を右クリックし、図版を入れる位置を選び直してください。');
      return;
    }
    setMessage('図版を本文に追加しました');
  }

  const history = documentId && panel === 'history' ? <div className="side-content">
    <HistoryPanel key={documentId} documentId={documentId} file={file} selectedId={selectedBackup}
      onSelect={setSelectedBackup} disabled={saving || changingDocument} onRestore={applyBackup}
      version={`${file?.revision ?? ''}/${restoredVersion}`} />
  </div> : null;

  if (traceabilityId) return <TraceabilityEditor key={traceabilityId} id={traceabilityId} onBack={() => setTraceabilityId(null)} />;

  return (
    <div className="workspace-app">
      <header className="app-bar">
        {documentId && <button className="back-button" type="button" onClick={backToLibrary}
          disabled={saving || changingDocument} aria-label="文書一覧に戻る" title="文書一覧に戻る">← <span>文書一覧</span></button>}
        <div className="branding"><span className="brand-icon" aria-hidden="true">M</span><h1>MD Operator</h1></div>
        <span className="header-location">{document?.name || '文書ワークスペース'}{file && <><span aria-hidden="true"> / </span>{file.path}</>}</span>
        <div className="app-actions">
          {file && <>
            <span className="save-status" role="status">{restoring ? '復元中…' : saving ? '保存中…' : dirty ? '未保存' : '保存済み'}</span>
            <button className="save-button" type="button" disabled={!dirty || saving || changingDocument} onClick={() => void save()}>保存</button>
          </>}
        </div>
      </header>
      {(error || message) && <div className={`workspace-notice ${error ? 'error' : 'success'}`} role={error ? 'alert' : 'status'}>
        <span>{error || message}</span>
        {conflict && file && <button type="button" onClick={() => {
          if (window.confirm('ディスク上の内容を読み込み、未保存の編集を破棄しますか？')) void open(file.documentId, file.path);
        }}>ディスクから読み直す</button>}
        <button type="button" aria-label="通知を閉じる" onClick={() => setMessage('')}>×</button>
      </div>}
      {!documentId ? <div className="top-library"><DocumentLibrary documents={documents} loading={loading} opening={opening}
        onOpen={openDocument} onCreated={created} onError={setError} />
        <TraceabilityLibrary documents={documents} onOpen={setTraceabilityId} /></div> : <main className={`workspace-main${sidebarCollapsed ? ' sidebar-collapsed' : ''}`}>
        {sidebarCollapsed && <button className="sidebar-reopen" type="button" aria-label="この文書の目次を開く"
          aria-controls="workspace-documents" aria-expanded="false" title="この文書の目次を開く"
          onClick={() => setSidebarCollapsed(false)}>▶ 目次</button>}
        {document && <DocumentTree document={document} path={file?.path} outline={outline}
          hidden={sidebarCollapsed} blocked={saving || loading || changingDocument} sidebarRef={sidebarPane}
          onCollapse={() => setSidebarCollapsed(true)} onSelect={select} onJump={jumpToHeading} />}
        <SidebarResize sidebar={sidebarPane} hidden={sidebarCollapsed} />
        <section className="editor-panel surface" aria-label="Markdown編集" ref={editorPane}>
          <div className="panel-header">
            <h2>{file?.path || 'Markdown'}</h2>
            {file && <div className="panel-header-actions">
              <div className="heading-number-actions" role="group" aria-label="文書全体の見出し番号">
                <button type="button" disabled={changingDocument || saving} onClick={() => changeHeadingNumbers('add')}>見出しに番号を付ける</button>
                <button type="button" disabled={changingDocument || saving} onClick={() => changeHeadingNumbers('remove')}>見出しの番号を消す</button>
              </div>
              <div className="segmented" aria-label="編集モード">
                <button type="button" disabled={restoring} aria-pressed={mode === 'visual'} onClick={() => setMode('visual')}>ビジュアル</button>
                <button type="button" disabled={restoring} aria-pressed={mode === 'source'} onClick={() => setMode('source')}>ソース</button>
              </div>
            </div>}
          </div>
          {file ? (mode === 'visual'
            ? <VisualEditor ref={visualEditor} key={`${file.documentId}/${file.path}/${restoredVersion}`} documentId={file.documentId} path={file.path}
              content={file.content} assetVersion={assetVersion} configVersion={configVersion} disabled={changingDocument}
              onChange={updateMarkdown} onChooseFigure={chooseFigure} />
            : <textarea ref={sourceEditor} key={restoredVersion} className="source-editor" aria-label="Markdownソース" spellCheck={false} value={file.content}
              readOnly={changingDocument} onKeyDown={sourceHeadingShortcut} onChange={(event) => updateMarkdown(event.target.value)} />)
            : <div className="empty-state">
              {document?.conflict
                ? <p className="error" role="alert">{document.conflict}</p>
                : <p>{loading || opening ? '文書を読み込んでいます…' : documentId ? '原本のMarkdownがありません。' : '文書フォルダを選ぶか、作成してください。'}</p>}
              {documentId && !opening && !document?.conflict && document?.files.length === 0
                && <button type="button" onClick={() => void recover()}>原本を作成</button>}
            </div>}
        </section>
        <InspectorResize editor={editorPane} inspector={inspectorPane} />
        <section className="inspector surface" id="workspace-inspector" ref={inspectorPane} aria-label="プレビューと文書操作">
          <div className="panel-header inspector-tabs" aria-label="文書パネル">
            {panels.map((entry) => <button key={entry.id} type="button" data-panel={entry.id} aria-pressed={documentId !== null && panel === entry.id}
              disabled={!documentId || changingDocument || (!file && entry.id !== 'config' && entry.id !== 'history')}
              onClick={() => showPanel(entry.id)}>{entry.text}</button>)}
          </div>
          {file ? <div className="panel-set" key={`${file.documentId}/${file.path}`}>
            <PreviewPanel key={restoredVersion} hidden={panel !== 'preview'} documentId={file.documentId} path={file.path}
              content={file.content} configVersion={configVersion} assetVersion={assetVersion} />
            <div className="side-content" hidden={panel !== 'output'}><OutputPanel file={file} busy={saving || changingDocument} save={save} onHistory={openHistory} /></div>
            {history}
            {visited.includes('config') && <div className="side-content" hidden={panel !== 'config'}><ConfigPanel key={restoredVersion} documentId={file.documentId}
              configVersion={configVersion} onSaved={configSaved} /></div>}
            {visited.includes('assist') && <div className="side-content" hidden={panel !== 'assist'}>
              <AssistPanel file={file} disabled={changingDocument || saving} configVersion={configVersion}
                onHistory={openHistory} onFigureCreated={figureCreated} onOpenFigures={() => showPanel('figures')} />
            </div>}
            {visited.includes('figures') && <div className="side-content" hidden={panel !== 'figures'}>
              <FigureLibrary key={restoredVersion} documentId={file.documentId} assetVersion={assetVersion}
                disabled={changingDocument || saving} onInsertImage={insertFigure} onUpdated={() => {
                setAssetVersion((version) => version + 1);
                setMessage('図版を更新しました');
              }} />
            </div>}
          </div> : history ?? (documentId && panel === 'config'
            ? <div className="side-content"><ConfigPanel key={documentId} documentId={documentId} configVersion={configVersion} onSaved={configSaved} /></div>
            : <div className="empty-state">文書を開くとプレビューを表示します。</div>)}
        </section>
      </main>}
    </div>
  );
}

