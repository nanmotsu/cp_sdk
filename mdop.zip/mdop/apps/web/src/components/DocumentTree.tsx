/**
 * @file 開いている文書の原本と見出しへの移動を提供する。
 */

import { useId, useState } from 'react';
import type { RefObject } from 'react';
import type { DocumentInfo } from '../api';
import type { HeadingOutlineEntry } from '../editor/outline';
import './DocumentTree.css';

/** 文書一覧、選択中の原本、見出し階層と操作の受け渡し。 */
interface Props {
  document: DocumentInfo;
  path?: string;
  hidden?: boolean;
  sidebarRef: RefObject<HTMLElement | null>;
  onCollapse: () => void;
  blocked: boolean;
  outline: HeadingOutlineEntry[];
  onJump: (entry: HeadingOutlineEntry) => void;
  onSelect: (documentId: string | null, path?: string) => void;
}

/** 再帰的な見出しツリーで共有する開閉と移動の状態。 */
interface OutlineState {
  blocked: boolean;
  depth: number;
  toggled: ReadonlySet<string>;
  onJump: Props['onJump'];
  onToggle: (key: string) => void;
}

/** 原本ごとの表示階層と、個別に開閉した見出しを保持する。 */
interface OutlineView {
  depth: number;
  toggled: ReadonlySet<string>;
}

/** 見出しを階層表示し、子を持つ見出しに独立した開閉ボタンを付ける。 */
function HeadingOutline({ entries, state, scope, id, tier = 1, root = false, hidden }: {
  entries: HeadingOutlineEntry[];
  state: OutlineState;
  scope: (string | number)[];
  id: string;
  tier?: number;
  root?: boolean;
  hidden?: boolean;
}) {
  const occurrences = new Map<string, number>();
  return <ul className="heading-outline" id={id} aria-label={root ? '見出し一覧' : undefined} hidden={hidden}>
    {entries.map((entry, index) => {
      const labelKey = `${entry.level}:${entry.label}`;
      const occurrence = (occurrences.get(labelKey) ?? 0) + 1;
      occurrences.set(labelKey, occurrence);
      const childrenScope = [...scope, entry.level, entry.label, occurrence];
      const key = JSON.stringify(childrenScope);
      const expanded = (tier < state.depth) !== state.toggled.has(key);
      const childrenId = `${id}-${index}`;
      return <li key={key}>
        {entry.children.length > 0 && <button type="button" className="tree-heading-toggle" aria-label={`${entry.label}の子見出しを開閉`}
          aria-controls={childrenId} aria-expanded={expanded}
          title={expanded ? '子見出しを閉じる' : '子見出しを開く'}
          disabled={state.blocked} onClick={() => state.onToggle(key)}>
          <span aria-hidden="true">{expanded ? '▾' : '▶'}</span>
        </button>}
        <button type="button" className="tree-heading" title={entry.label} disabled={state.blocked}
          onClick={() => state.onJump(entry)}>{entry.label}</button>
        {entry.children.length > 0
          && <HeadingOutline entries={entry.children} state={state} scope={childrenScope} id={childrenId} tier={tier + 1} hidden={!expanded} />}
      </li>;
    })}
  </ul>;
}

/** 文書フォルダ、原本行、見出しを表示し、選択変更をアプリへ伝える。 */
export default function DocumentTree({ document, path, hidden, sidebarRef, onCollapse, blocked, outline, onJump, onSelect }: Props) {
  const [outlineViews, setOutlineViews] = useState(() => new Map<string, OutlineView>());
  const outlineId = useId();

  /** 原本の見出し一覧を指定階層に揃え、個別の開閉状態を解除する。 */
  function setOutlineDepth(fileKey: string, depth: number) {
    setOutlineViews(current => {
      const next = new Map(current);
      next.set(fileKey, { depth, toggled: new Set<string>() });
      return next;
    });
  }

  /** 指定した見出しだけ、現在の表示階層と逆の開閉状態にする。 */
  function toggleOutline(fileKey: string, headingKey: string) {
    setOutlineViews(current => {
      const next = new Map(current);
      const view = current.get(fileKey) ?? { depth: 3, toggled: new Set<string>() };
      const toggled = new Set(view.toggled);
      if (toggled.has(headingKey)) toggled.delete(headingKey);
      else toggled.add(headingKey);
      next.set(fileKey, { depth: view.depth, toggled });
      return next;
    });
  }

  return (
    <nav id="workspace-documents" ref={sidebarRef} aria-label="この文書" className="document-tree" hidden={hidden}>
      <div className="sidebar-head">
        <div className="sidebar-head-title">
          <h2>{document.name}</h2>
          <button className="icon-button sidebar-collapse-button" type="button" aria-label="この文書の目次を閉じる"
            aria-controls="workspace-documents" aria-expanded="true" title="この文書の目次を閉じる" onClick={onCollapse}>◀</button>
        </div>
      </div>
      {document.files.length === 0 && <p className="sidebar-empty">原本のMarkdownがありません。</p>}
      <ul className="document-folders">
        <li>
          <ul className="file-tree">
            {document.files.map(file => {
              const active = path === file.path;
              const hasOutline = active && outline.length > 0;
              const outlineScope = [document.id, file.path];
              const outlineKey = JSON.stringify(outlineScope);
              const view = outlineViews.get(outlineKey) ?? { depth: 3, toggled: new Set<string>() };
              return <li key={file.path}>
                <div className="tree-file-row">
                  <button className="tree-file" type="button" title={file.path} aria-current={active ? 'page' : undefined}
                    disabled={blocked} onClick={() => onSelect(document.id, file.path)}>
                    <span className="file-icon" aria-hidden="true">M</span><span>{file.path}</span>
                  </button>
                  {hasOutline && <select className="tree-outline-depth" aria-label={`${file.path}の見出し表示階層`}
                    aria-controls={outlineId} title="見出しの表示階層。0は全閉じ、1〜3は指定階層まで展開"
                    value={view.toggled.size > 0 ? 'custom' : view.depth}
                    disabled={blocked} onChange={event => setOutlineDepth(outlineKey, Number(event.target.value))}>
                    {view.toggled.size > 0 && <option value="custom" disabled>個別</option>}
                    <option value="0">0</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                  </select>}
                </div>
                {hasOutline && <HeadingOutline entries={outline} scope={outlineScope}
                  state={{ blocked, depth: view.depth, toggled: view.toggled, onJump,
                    onToggle: key => toggleOutline(outlineKey, key) }}
                  id={outlineId} root hidden={view.depth === 0} />}
              </li>;
            })}
          </ul>
        </li>
      </ul>
    </nav>
  );
}
