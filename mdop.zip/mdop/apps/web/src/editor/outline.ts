/**
 * @file 原本の見出しを解析し、左の文書ツリーで表示・移動できる階層データを作る。
 */

import { Parser, TextRenderer } from 'marked';
import type { Tokens } from 'marked';
import { markdownBlocks } from './blocks';

/** 見出しの表示名、深さ、原本内の位置と子見出し。 */
export interface HeadingOutlineEntry {
  label: string;
  level: number;
  offset: number;
  blockIndex: number;
  children: HeadingOutlineEntry[];
}

/** 見出しのMarkdown装飾を表示名から除き、安全にテキストとして取得する。 */
export function createHeadingLabelReader() {
  const parser = new Parser();
  const renderer = new TextRenderer();
  const template = document.createElement('template');
  return (heading: Tokens.Heading) => {
    template.innerHTML = parser.parseInline(heading.tokens, renderer);
    return template.content.textContent?.replace(/\s+/g, ' ').trim() || '（無題の見出し）';
  };
}

/** 指定の深さまでの見出しを階層にまとめ、編集位置へ移動するための文字オフセットを保持する。 */
export function buildHeadingOutline(markdown: string, tocDepth = 3): HeadingOutlineEntry[] {
  const entries: HeadingOutlineEntry[] = [];
  const parents: HeadingOutlineEntry[] = [];
  const readLabel = createHeadingLabelReader();
  let offset = 0;

  markdownBlocks(markdown, { prepareEditor: false }).forEach(({ raw, heading }, blockIndex) => {
    const start = offset;
    offset += raw.length;
    if (!heading || heading.depth > tocDepth) return;

    const label = readLabel(heading);
    const entry = { label, level: heading.depth, offset: start, blockIndex, children: [] };
    while (parents.length && parents.at(-1)!.level >= entry.level) parents.pop();
    (parents.at(-1)?.children ?? entries).push(entry);
    parents.push(entry);
  });

  return entries;
}
