/**
 * @file 原本の見出しを解析し、番号を文書全体で付け外しする。
 */

import { createHeadingNumberer, readWrittenHeadingNumber } from '../../../../packages/markdown/headings.mjs';
import { markdownBlocks } from './blocks';
import { createHeadingLabelReader } from './outline';

/** 一回の操作で行う番号変更。 */
export type HeadingNumberAction = 'add' | 'remove';

/** # 形式の見出しだけを編集し、番号の前後にある原本の文字を保つ。 */
export function editDocumentHeadingNumbers(source: string, action: HeadingNumberAction): string {
  const nextNumber = createHeadingNumberer([1, 2, 3, 4, 5, 6]);
  const readLabel = createHeadingLabelReader();
  return markdownBlocks(source, { prepareEditor: false }).map(({ raw, heading }) => {
    if (!heading?.text.trim()) return raw;
    const number = nextNumber(heading.depth);
    const marker = /^ {0,3}#{1,6}[ \t]+/.exec(raw)?.[0];
    if (!marker) return raw;
    const title = raw.slice(marker.length);
    const written = readWrittenHeadingNumber(title);
    if (action === 'add') return written || readWrittenHeadingNumber(readLabel(heading)) ? raw : `${marker}${number} ${title}`;
    // 末尾のドットがない階層表記は、バージョン名などとして使われる場合がある。
    return written?.number.endsWith('.') && heading.text.trim() !== written.number
      ? marker + title.slice(written.length) : raw;
  }).join('');
}

