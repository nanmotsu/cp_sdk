/**
 * @file HTTPメソッドとパスから担当ルートを選び、ローカルGUIとAPIへ要求を振り分ける。
 */

import { badRequest, notFound } from "./errors.mjs";
import { checkLocalRequest, sendError } from "./http.mjs";

/** URLパスを区切り単位でデコードする。 */
function urlSegments(url) {
    try {
        return url.pathname.split("/").slice(1).map(decodeURIComponent);
    } catch {
        throw badRequest("URLのパスを確認してください。");
    }
}

/** ルートの順序を維持し、固定部分とパラメーターを照合して担当処理を呼ぶ。 */
export function createRouter(routes) {
    const registered = routes.map(([methods, pattern, handler]) => ({
        methods: [methods].flat(), parts: pattern.split("/").slice(1), handler,
    }));
    return function route(request, response, url, segments) {
        for (const { methods, parts, handler } of registered) {
            if (!methods.includes(request.method) || parts.length !== segments.length) continue;
            if (!parts.every((part, index) => part.startsWith(":") || part === segments[index])) continue;
            const params = Object.fromEntries(parts.flatMap((part, index) =>
                part.startsWith(":") ? [[part.slice(1), segments[index]]] : []));
            return handler(request, response, params, url);
        }
        throw notFound("APIが見つかりません。");
    };
}

/** ローカル要求を検査し、URLをデコードしてからAPIとGUIへ分岐する。 */
export function createRequestListener(api, serveWeb) {
    return async (request, response) => {
        try {
            checkLocalRequest(request);
            const url = new URL(request.url, "http://localhost");
            const segments = urlSegments(url);
            if (segments[0] === "api") {
                if (segments[1] !== "v1") throw notFound("APIが見つかりません。");
                await api(request, response, url, segments.slice(2));
            } else {
                await serveWeb(request, response, segments);
            }
        } catch (error) {
            if (response.destroyed) return;
            if (response.headersSent) response.destroy(error);
            else sendError(response, error);
        }
    };
}
