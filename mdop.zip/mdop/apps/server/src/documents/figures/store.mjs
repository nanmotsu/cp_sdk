/**
 * @file 編集可能な図版の保存と取得を管理する。固定の画像パスで配信し、ラスタ図版は原本と配置を保存して再編集に備える。
 */

import { createHash, randomUUID } from "node:crypto";
import { mkdir, readFile, readdir, rename, rm, rmdir, writeFile } from "node:fs/promises";
import { join } from "node:path";
import yaml from "js-yaml";
import { FIGURES_DIRECTORY, FIGURE_PARTS_DIRECTORY, figureIdPattern } from "../../../../../packages/markdown/figure-paths.mjs";
import { ApiError, badRequest, conflict, notFound } from "../../common/api/errors.mjs";
import { normalizeFigureSvg } from "../shared/svg.mjs";
import { figureFormats, validateFigureMaterial } from "./formats.mjs";
import { renderFigureRaster } from "./raster.mjs";
import { atomicWrite, ensureWorkspaceDirectory, statIfPresent, workspacePath } from "../../common/filesystem/paths.mjs";
import { ASSET_LIMIT, decodeBase64, textInput } from "../shared/input.mjs";

const acceptedSvg = "image.svg";
const acceptedRaster = "image.png";
const metadataFile = "asset.yaml";
const mermaidFile = "source.mmd";
const annotationsFile = "annotations.json";
const pendingAnnotationsFile = "annotations.pending.json";
const revisionPattern = /^[a-f0-9]{64}$/;
/** 図版に使うラスタ原本のバイト上限。 */
export const FIGURE_RASTER_LIMIT = 12 * 1024 * 1024;
const svgLimit = 256 * 1024;
const annotationIdPattern = /^[A-Za-z0-9_-]{1,100}$/;
const hexColor = /^#[0-9a-f]{6}$/i;
/** 図版に置ける画像レイヤー数。 */
export const FIGURE_LAYER_LIMIT = 16;
const primaryId = "original";
const materialMimes = new Map(Object.entries(figureFormats).map(([mime, extension]) => [extension, mime]));

/** ファイル内容や図版状態の識別に使うSHA-256を計算する。 */
function hash(value) {
    return createHash("sha256").update(value).digest("hex");
}

/** 図版フォルダ内のファイルを指す、文書からの相対パスを作る。 */
function figurePath(id, file) {
    return `${FIGURES_DIRECTORY}/${id}${file ? `/${file}` : ""}`;
}

/** 元の画像を図版IDのグループにまとめ、表示ファイルとは別のフォルダに置く。 */
function materialPath(id, file) {
    return `${FIGURE_PARTS_DIRECTORY}/${id}${file ? `/${file}` : ""}`;
}

/** 図版IDが許可されるUUID形式か検査する。 */
function figureId(value) {
    if (typeof value !== "string" || !figureIdPattern.test(value)) throw notFound("図版が見つかりません。");
    return value;
}

/** 主画像のメディア種別に対応する保存名を決める。 */
function originalFilename(mime) {
    if (!Object.hasOwn(figureFormats, mime)) throw badRequest("PNG・JPEG・WebP・GIF・BMP・SVGの画像を指定してください。");
    const extension = figureFormats[mime];
    return `original.${extension}`;
}

/** ブラウザーに渡す画像の形式を確認し、SVGの外部参照を取り除く。 */
function material(bytes, mime) {
    try {
        return validateFigureMaterial(bytes, mime);
    } catch (error) {
        throw badRequest(error.message);
    }
}

/** 追加画像をレイヤーIDと種別から一意の名前にする。 */
function layerFilename(id, mime) {
    return originalFilename(mime).replace(/^original/, `layer-${id}`);
}

/** 座標に使える有限の数値かを確認する。 */
function coordinate(value) {
    return Number.isFinite(value) && Math.abs(value) <= 100000;
}

/** 寸法や線幅などに使える正の有限値かを確認する。 */
function positive(value, limit = 100000) {
    return Number.isFinite(value) && value > 0 && value <= limit;
}

/** 枠、矢印、ラベルの座標・寸法・表示属性を検証し、保存用の値へそろえる。 */
export function parseFigureAnnotations(input) {
    if (!Array.isArray(input) || input.length > 300) throw badRequest("注釈は300件以内の配列で指定してください。");
    const ids = new Set();
    return input.map(item => {
        const { id, type, x, y, color } = item ?? {};
        if (typeof id !== "string" || !annotationIdPattern.test(id) || ids.has(id) || !coordinate(x) || !coordinate(y)) {
            throw badRequest("注釈の識別子と位置を確認してください。");
        }
        ids.add(id);
        if (color !== undefined && (typeof color !== "string" || !hexColor.test(color))) {
            throw badRequest("注釈の色は #RRGGBB で指定してください。");
        }
        const position = { id, type, x, y, ...(color !== undefined && { color }) };
        const strokeWidth = item.strokeWidth;
        if ((type === "box" || type === "arrow") && strokeWidth !== undefined && !positive(strokeWidth, 100)) {
            throw badRequest("注釈の線幅は 0 より大きく 100 以下で指定してください。");
        }
        const stroke = strokeWidth === undefined ? {} : { strokeWidth };
        if (type === "box" && coordinate(item.width) && coordinate(item.height) && item.width > 0 && item.height > 0) {
            return { ...position, width: item.width, height: item.height, ...stroke };
        }
        if (type === "arrow" && coordinate(item.dx) && coordinate(item.dy)) {
            return { ...position, dx: item.dx, dy: item.dy, ...stroke };
        }
        if (type === "label" && typeof item.text === "string" && Buffer.byteLength(item.text) <= 1000) {
            const { fontSize, fontWeight } = item;
            if ((fontSize !== undefined && !positive(fontSize, 512))
                || (fontWeight !== undefined && fontWeight !== "normal" && fontWeight !== "bold")) {
                throw badRequest("注釈の文字サイズまたは太さを確認してください。");
            }
            return { ...position, text: item.text, ...(fontSize !== undefined && { fontSize }), ...(fontWeight !== undefined && { fontWeight }) };
        }
        throw badRequest("枠・矢印・文字の注釈内容を確認してください。");
    });
}

/** 画像レイヤーの識別子と位置・寸法を検査する。 */
function parsePlacements(input) {
    if (!Array.isArray(input) || input.length > FIGURE_LAYER_LIMIT) {
        throw badRequest(`図版の画像は${FIGURE_LAYER_LIMIT}枚までです。`);
    }
    const ids = new Set();
    return input.map(item => {
        const { id, name, x, y, width, height } = item ?? {};
        if (typeof id !== "string" || (id !== primaryId && !figureIdPattern.test(id)) || ids.has(id)
            || !coordinate(x) || !coordinate(y) || !positive(width) || !positive(height)) {
            throw badRequest("図版に配置する画像の識別子・座標・大きさを確認してください。");
        }
        ids.add(id);
        return { id, x, y, width, height, ...(name !== undefined && { name: textInput(name, "画像の名前", 512) }) };
    });
}

/** 図版の通常ファイルを検査して、指定された容量内で読み込む。 */
async function readFigureFile(directory, name, limit, { optional = false } = {}) {
    const path = await workspacePath(directory, name, { mayBeMissing: optional });
    const info = await statIfPresent(path);
    if (!info) {
        if (optional) return undefined;
        throw notFound("図版のファイルが見つかりません。");
    }
    if (info.size > limit) throw badRequest("図版ファイルのサイズが上限を超えています。");
    return readFile(path);
}

/** 図版の素材フォルダから、保存名に合う通常の画像ファイルを列挙する。 */
async function storedParts(directory) {
    const materials = new Map();
    for (const entry of await readdir(directory, { withFileTypes: true })) {
        if (!entry.isFile()) continue;
        const match = /^(original|layer-([a-f0-9-]+))\.([a-z]+)$/.exec(entry.name);
        if (!match) continue;
        const [, , layerId, extension] = match;
        const mime = materialMimes.get(extension);
        if (mime && (!layerId || figureIdPattern.test(layerId))) {
            const id = layerId ?? primaryId;
            materials.set(id, { id, file: entry.name, mime });
        }
    }
    return materials;
}

/** 合成画像のハッシュと整合する配置・注釈を選ぶ。書き込み途中からの復旧にも使う。 */
async function rasterState(directory, imageHash, original, originalMime) {
    // The accepted image is the commit point. A process interrupted before promotion can still recover matching annotations.
    for (const filename of [pendingAnnotationsFile, annotationsFile]) {
        const data = await readFigureFile(directory, filename, 512 * 1024, { optional: true });
        if (!data) continue;
        let state;
        try {
            state = JSON.parse(data.toString("utf8"));
        } catch {
            continue;
        }
        if (state?.imageHash === imageHash && Number.isInteger(state.width) && state.width > 0
            && Number.isInteger(state.height) && state.height > 0) {
            const accepted = { width: state.width, height: state.height, annotations: parseFigureAnnotations(state.annotations) };
            const images = parsePlacements(state.images).map((placement, index) => {
                const { file, mime } = state.images[index];
                const expected = placement.id === primaryId ? original : layerFilename(placement.id, mime);
                if (!expected || file !== expected || (placement.id === primaryId && mime !== originalMime)) {
                    throw badRequest("図版の画像配置情報を確認してください。");
                }
                return { ...placement, file, mime };
            });
            return { ...accepted, images };
        }
    }
    throw badRequest("図版の画像と注釈情報が一致しません。");
}

/** 保持している原本と今回のアップロードから、描画に必要なレイヤーを解決する。 */
async function composeRaster(input, { original, originalName, mime, directory, previous }) {
    const layout = input === undefined ? previous : input;
    if (layout === undefined) return { files: new Map() };
    const { width, height } = layout ?? {};
    if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1
        || width > 100000 || height > 100000 || width * height > 40_000_000) {
        throw badRequest("図版全体の幅・高さを確認してください。");
    }
    const placements = parsePlacements(layout.images);
    const uploads = layout.uploads === undefined ? [] : layout.uploads;
    if (!Array.isArray(uploads) || uploads.length > FIGURE_LAYER_LIMIT) throw badRequest("画像ファイルの一覧を確認してください。");
    const existing = new Map((previous?.images ?? []).map(image => [image.id, image]));
    const files = new Map();
    const added = new Map();
    let bytes = original?.length ?? 0;
    for (const item of uploads) {
        const { id, mime: layerMime, base64 } = item ?? {};
        if (typeof id !== "string" || !figureIdPattern.test(id) || !placements.some(image => image.id === id)
            || added.has(id) || existing.has(id)) {
            throw badRequest("追加画像の識別子を確認してください。");
        }
        const file = layerFilename(id, layerMime);
        const uploaded = material(decodeBase64(base64, FIGURE_RASTER_LIMIT), layerMime);
        bytes += uploaded.length;
        if (bytes > ASSET_LIMIT) throw badRequest("図版の元画像は合計20 MiBまでです。");
        added.set(id, { file, mime: layerMime });
        files.set(file, uploaded);
    }
    const images = [];
    const renderImages = [];
    for (const placement of placements) {
        const image = placement.id === primaryId && originalName ? { file: originalName, mime }
            : (added.get(placement.id) ?? existing.get(placement.id));
        if (!image) throw badRequest("配置する画像の元ファイルを指定してください。");
        let source = placement.id === primaryId ? original : files.get(image.file);
        if (!source) {
            source = await readFigureFile(directory, image.file, FIGURE_RASTER_LIMIT);
            bytes += source.length;
            if (bytes > ASSET_LIMIT) throw badRequest("図版の元画像は合計20 MiBまでです。");
        }
        images.push({ ...placement, file: image.file, mime: image.mime });
        renderImages.push({ ...placement, original: source, mime: image.mime });
    }
    return { images, render: { width, height, images: renderImages }, files };
}

/** 更新で追加された原本画像を図版フォルダへ保存する。 */
async function installSources(directory, files) {
    for (const [file, bytes] of files) {
        const existing = await readFigureFile(directory, file, FIGURE_RASTER_LIMIT, { optional: true });
        if (!existing) await atomicWrite(await workspacePath(directory, file, { mayBeMissing: true }), bytes);
        else if (!existing.equals(bytes)) throw conflict("配置する画像はすでに別の内容で保存されています。");
    }
}

/** 新規図版を一時フォルダに組み立て、必要なファイルが揃ってから公開する。 */
async function publishNew(directory, id, files) {
    const temp = join(directory, `.${id}.${randomUUID()}.tmp`);
    await mkdir(temp);
    const written = [];
    try {
        for (const [name, data] of files) {
            const target = join(temp, name);
            written.push(target);
            await writeFile(target, data, { flag: "wx" });
        }
        await rename(temp, join(directory, id));
    } catch (error) {
        for (const path of written) await rm(path, { force: true }).catch(() => {});
        await rmdir(temp).catch(() => {});
        throw error;
    }
}

/** 更新要求のリビジョンを検査し、現在の図版と異なれば競合を返す。 */
function revisionConflict(expected, current) {
    if (typeof expected !== "string" || !revisionPattern.test(expected)) {
        throw badRequest("図版取得時の revision を指定してください。");
    }
    if (expected !== current) {
        throw conflict("図版が別の操作で更新されています。最新の図版を読み込み直してください。", { revision: current });
    }
}

/** 図版の読み取りと書き込みを提供する。SVGの整理とラスタ描画はテストで差し替えられる。 */
export function createFigureStore(documentRoot, { normalizeSvg = normalizeFigureSvg, renderRaster = renderFigureRaster } = {}) {
    const locks = new Map();

    /** 同じ文書内の同じ図版IDを更新する処理を直列化する。 */
    function locked(folder, id, work) {
        const key = `${folder.toLowerCase()}\0${id}`;
        const operation = (locks.get(key) ?? Promise.resolve()).then(work);
        const tail = operation.then(() => {}, () => {});
        locks.set(key, tail);
        return operation.finally(() => { if (locks.get(key) === tail) locks.delete(key); });
    }

    /** SVGを保存前に正規化し、入力上限と編集可能な形式を確認する。 */
    function cleanSvg(svg) {
        const text = textInput(svg, "svg", svgLimit);
        try {
            return textInput(normalizeSvg(text), "svg", svgLimit);
        } catch (error) {
            if (error instanceof ApiError) throw error;
            throw badRequest(error.message || "SVGを読み込めませんでした。");
        }
    }

    /** 元画像と配置・注釈から、本文表示用のPNGと次回の編集に必要な情報を作る。 */
    async function prepareRaster(original, mime, annotations, composition, signal) {
        if (composition.images?.length === 0 && !annotations.length) {
            throw badRequest("図版に画像、枠、矢印、文字のいずれかを追加してください。");
        }
        let result;
        try {
            result = await renderRaster({ original, mime, annotations, composition: composition.render, signal });
        } catch (error) {
            signal?.throwIfAborted();
            if (error instanceof ApiError) throw error;
            throw badRequest(error.message || "画像を描画できませんでした。");
        }
        if (!Buffer.isBuffer(result.buffer) || !result.buffer.length || result.buffer.length > FIGURE_RASTER_LIMIT
            || !Number.isInteger(result.width) || result.width < 1 || !Number.isInteger(result.height) || result.height < 1) {
            throw badRequest("描画した画像のサイズを確認してください。");
        }
        const { width, height, buffer } = result;
        const images = composition.images ?? [{ id: primaryId, x: 0, y: 0, width, height, file: originalFilename(mime), mime }];
        return { buffer, state: { imageHash: hash(buffer), width, height, annotations, images } };
    }

    /** 図版のメタデータと画像を読み、種類に応じた編集用データとリビジョンを返す。 */
    async function read(folder, id) {
        const directory = await workspacePath(folder, figurePath(id), { directory: true });
        const rawManifest = await readFigureFile(directory, metadataFile, 8192);
        let manifest;
        try {
            manifest = yaml.load(rawManifest.toString("utf8"), { schema: yaml.JSON_SCHEMA });
        } catch {
            throw badRequest("図版の設定ファイルを確認してください。");
        }
        const { name, kind, mime } = manifest ?? {};
        if (typeof name !== "string" || !name.trim() || (kind !== "svg" && kind !== "raster")) {
            throw badRequest("図版の設定ファイルを確認してください。");
        }
        const imageFile = kind === "svg" ? acceptedSvg : acceptedRaster;
        const image = await readFigureFile(directory, imageFile, kind === "svg" ? svgLimit : FIGURE_RASTER_LIMIT);
        const imageHash = hash(image);
        const summary = { id, name, kind, path: figurePath(id, imageFile), revision: hash(`${imageHash}\n${name}`) };
        if (kind === "svg") {
            const mermaid = await readFigureFile(directory, mermaidFile, svgLimit, { optional: true });
            return { directory, summary, manifest, imageHash, detail: {
                ...summary, svg: cleanSvg(image.toString("utf8")), ...(mermaid && { mermaidSource: mermaid.toString("utf8") }),
            } };
        }

        const original = mime === undefined ? undefined : originalFilename(mime);
        const state = await rasterState(directory, imageHash, original, mime);
        const { images, ...raster } = state;
        const parts = await workspacePath(folder, materialPath(id), { directory: true, mayBeMissing: !original && !images.length });
        if (original) await workspacePath(parts, original);
        const imageDetails = await Promise.all(images.map(async ({ file, mime: _mime, ...placement }) => {
            await workspacePath(parts, file);
            return { ...placement, originalPath: materialPath(id, file) };
        }));
        summary.revision = hash(`${summary.revision}\n${JSON.stringify(state)}`);
        return { directory, parts, summary, manifest, mime, original, imageHash, state,
            detail: { ...summary, ...(original && { originalPath: materialPath(id, original) }), ...raster, images: imageDetails } };
    }

    /** 文書内の有効な図版を、表示情報と編集用の状態を含めて順に読み取る。 */
    async function* records(folder) {
        const root = await workspacePath(folder, FIGURES_DIRECTORY, { mayBeMissing: true, directory: true });
        if (!await statIfPresent(root)) return;
        for (const { name: id } of (await readdir(root, { withFileTypes: true }))
            .filter(entry => entry.isDirectory() && figureIdPattern.test(entry.name))) {
            try {
                yield await locked(folder, id, () => read(folder, id));
            } catch (error) {
                if (!(error instanceof ApiError && (error.status === 400 || error.status === 404)) && error.code !== "ENOENT") throw error;
            }
        }
    }

    /** 文書の図版を名前順に並べ、一覧表示用の情報を返す。 */
    async function list(documentId) {
        const folder = await documentRoot(documentId);
        const summaries = [];
        for await (const { summary } of records(folder)) summaries.push(summary);
        return summaries.sort((left, right) => left.name.localeCompare(right.name, "ja"));
    }

    /** 他の図版でも再利用できるよう、文書に保存された画像素材をまとめて返す。 */
    async function listParts(documentId) {
        const folder = await documentRoot(documentId);
        const catalog = [];
        for await (const { summary, parts, state } of records(folder)) {
            if (!parts || !await statIfPresent(parts)) continue;
            const placements = new Map(state.images.map(image => [image.file, image]));
            for (const { id, file } of (await storedParts(parts)).values()) {
                const name = placements.get(file)?.name || (id === primaryId ? summary.name : file);
                catalog.push({ id, name, fileName: file, figureId: summary.id, figureName: summary.name });
            }
        }
        return catalog.sort((left, right) => left.name.localeCompare(right.name, "ja"));
    }

    /** 指定された図版1件の内容を、編集可能な形式で返す。 */
    async function get(documentId, id) {
        const folder = await documentRoot(documentId);
        const record = await locked(folder, figureId(id), () => read(folder, id));
        return record.detail;
    }

    /** エディターで表示や再配置をするため、指定図版が保持する素材のパスと形式を返す。 */
    async function part(documentId, id, partId) {
        const folder = await documentRoot(documentId);
        return locked(folder, figureId(id), async () => {
            await workspacePath(folder, figurePath(id, metadataFile));
            const parts = await workspacePath(folder, materialPath(id), { directory: true });
            const material = (await storedParts(parts)).get(partId);
            if (!material) throw notFound("図版の画像素材が見つかりません。");
            return { absolute: await workspacePath(parts, material.file), type: material.mime };
        });
    }

    /** SVGまたはラスタ図版を保存し、本文に挿入する固定パスを返す。 */
    async function create(documentId, input, { signal } = {}) {
        const folder = await documentRoot(documentId);
        const requestedId = input.id;
        if (requestedId !== undefined && (input.kind !== "svg" || typeof requestedId !== "string" || !figureIdPattern.test(requestedId))) {
            throw badRequest("SVG図版の id は UUID で指定してください。");
        }
        const id = requestedId ?? randomUUID();
        const name = textInput(input.name, "name", 512).trim();
        const { kind } = input;
        if (!name || (kind !== "svg" && kind !== "raster")) throw badRequest("図版名と種類を指定してください。");
        const manifest = { kind, name };
        const files = new Map();
        const partFiles = new Map();
        if (kind === "svg") {
            files.set(acceptedSvg, cleanSvg(input.svg));
            if (input.mermaidSource !== undefined) files.set(mermaidFile, textInput(input.mermaidSource, "mermaidSource", svgLimit));
        } else {
            const { mime } = input;
            const annotations = parseFigureAnnotations(input.annotations ?? []);
            const original = mime !== undefined || input.base64 !== undefined ? originalFilename(mime) : undefined;
            const bytes = original ? material(decodeBase64(input.base64, FIGURE_RASTER_LIMIT), mime) : undefined;
            const composition = await composeRaster(input.composition, { original: bytes, originalName: original, mime });
            if (!original && !composition.render) throw badRequest("図版のキャンバスの寸法と配置を指定してください。");
            const { buffer, state } = await prepareRaster(bytes, mime, annotations, composition, signal);
            if (original) {
                manifest.mime = mime;
                partFiles.set(original, bytes);
            }
            for (const [file, source] of composition.files) partFiles.set(file, source);
            files.set(acceptedRaster, buffer);
            files.set(annotationsFile, JSON.stringify(state));
        }
        files.set(metadataFile, yaml.dump(manifest, { lineWidth: -1, schema: yaml.JSON_SCHEMA }));
        const root = await ensureWorkspaceDirectory(folder, FIGURES_DIRECTORY);
        return locked(folder, id, async () => {
            signal?.throwIfAborted();
            if (requestedId && await statIfPresent(join(root, id))) {
                const { detail, imageHash } = await read(folder, id);
                if (detail.kind !== kind || detail.name !== name || imageHash !== hash(files.get(acceptedSvg))
                    || detail.mermaidSource !== files.get(mermaidFile)) {
                    throw conflict("同じ id の図版がすでに保存されています。", { revision: detail.revision });
                }
                return detail;
            }
            // 表示ファイルの公開を最後にして、図版一覧には素材がそろった図版だけを載せる。
            const partsRoot = partFiles.size ? await ensureWorkspaceDirectory(folder, FIGURE_PARTS_DIRECTORY) : null;
            if (partsRoot) await publishNew(partsRoot, id, partFiles);
            try {
                signal?.throwIfAborted();
                await publishNew(root, id, files);
            } catch (error) {
                if (partsRoot) {
                    const parts = join(partsRoot, id);
                    for (const file of partFiles.keys()) await rm(join(parts, file), { force: true });
                    await rmdir(parts);
                }
                throw error;
            }
            return (await read(folder, id)).detail;
        });
    }

    /** 文書に追加する画像一枚を、原本と配置を持つ図版として保存する。 */
    function importImage(documentId, { name, mime, base64 }, options) {
        return create(documentId, { kind: "raster", name, mime, base64 }, options);
    }

    /** 取得時のリビジョンを照合して図版を更新する。ラスタ図版は配置情報とPNGの不整合から復旧できる順序で公開する。 */
    async function update(documentId, id, input) {
        const folder = await documentRoot(documentId);
        return locked(folder, figureId(id), async () => {
            const { directory, parts, detail, manifest, original, mime, imageHash, state: previous } = await read(folder, id);
            revisionConflict(input.revision, detail.revision);
            if (input.kind === "rename") {
                const name = textInput(input.name, "name", 512).trim();
                if (!name) throw badRequest("図版名を入力してください。");
                if (name === detail.name) return detail;
                const target = await workspacePath(directory, metadataFile);
                await atomicWrite(target, yaml.dump({ ...manifest, name }, { lineWidth: -1, schema: yaml.JSON_SCHEMA }));
                return (await read(folder, id)).detail;
            }
            if (input.kind !== detail.kind) throw badRequest("図版の種類は変更できません。");
            if (detail.kind === "svg") {
                await atomicWrite(await workspacePath(directory, acceptedSvg), cleanSvg(input.svg));
            } else {
                const annotations = parseFigureAnnotations(input.annotations);
                const bytes = original ? await readFigureFile(parts, original, FIGURE_RASTER_LIMIT) : undefined;
                const composition = await composeRaster(input.composition, { original: bytes, originalName: original, mime, directory: parts, previous });
                const { buffer, state } = await prepareRaster(bytes, mime, annotations, composition);
                revisionConflict(input.revision, (await read(folder, id)).detail.revision);
                const pending = await workspacePath(directory, pendingAnnotationsFile, { mayBeMissing: true });
                const settled = await workspacePath(directory, annotationsFile);
                const image = await workspacePath(directory, acceptedRaster);
                // Repair the settled state first so a failed second update can still read the previous accepted image.
                if (composition.files.size) {
                    const destination = await ensureWorkspaceDirectory(folder, materialPath(id));
                    await installSources(destination, composition.files);
                }
                await atomicWrite(settled, JSON.stringify({ imageHash, ...previous }));
                await atomicWrite(pending, JSON.stringify(state));
                await atomicWrite(image, buffer);
                // Pending already describes the accepted image if promotion is interrupted.
                await rename(pending, settled).catch(() => {});
            }
            return (await read(folder, id)).detail;
        });
    }

    return { list, listParts, get, part, create, importImage, update, prepareSvg: cleanSvg };
}
