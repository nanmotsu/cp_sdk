/**
 * @file AIの本文編集案に含まれるSVGを、履歴内の図版として登録・更新する。
 */

import { badRequest } from "../../common/api/errors.mjs";
import { createFigureStore } from "../figures/store.mjs";

/** Copilot案中の仮リンクを、同じ版に保存した編集可能な図版へつなぎ替える。 */
export async function storeProposalFigures(tree, proposal, signal) {
    let markdown = proposal.markdown;
    const archiveFigures = createFigureStore(async () => tree);
    for (const figure of proposal.figures ?? []) {
        signal.throwIfAborted();
        if (!markdown.includes(figure.placeholder)) throw badRequest("本文内の図版の挿入位置を確認できませんでした。");
        const { path } = await archiveFigures.create(null, { ...figure, kind: "svg" });
        markdown = markdown.replaceAll(figure.placeholder, path);
    }
    return markdown;
}

/** 履歴の本文が参照するSVGだけを、版のコピー上で更新する。 */
export async function updateProposalFigures(tree, markdown, input) {
    const changes = input.figures;
    if (!Array.isArray(changes) || !changes.length || changes.length > 12) {
        throw badRequest("調整した図版を1〜12点指定してください。");
    }
    const archiveFigures = createFigureStore(async () => tree);
    const updated = new Set();
    for (const change of changes) {
        const figure = await archiveFigures.get(null, change?.id);
        if (figure.kind !== "svg" || !markdown.includes(figure.path) || updated.has(figure.id)) {
            throw badRequest("編集案の本文が参照しているSVG図版を1点ずつ指定してください。");
        }
        await archiveFigures.update(null, figure.id, { svg: change.svg, kind: "svg", revision: figure.revision });
        updated.add(figure.id);
    }
}
