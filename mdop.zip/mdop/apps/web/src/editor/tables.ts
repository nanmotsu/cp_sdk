/** @file GFM表のセル・行・列を元のMarkdown上で編集する。 */

import { marked, Parser } from 'marked';
import type { Tokens } from 'marked';
import { blockMarkdown, normalizedLength } from './blocks';

/** 見出し行を0、データ行を1以降として扱うセル位置。 */
export interface TableCell { row: number; column: number }

/** 選んだ行または列へ適用する構造の編集。 */
export interface TableAction { axis: 'row' | 'column'; kind: 'add' | 'delete'; cell: TableCell }

interface TableLine {
  start: number;
  end: number;
  ending: string;
  indent: string;
  cells: string[];
}

/** 原本上の行と、ビジュアル画面に描画するセルのHTML。 */
export interface MarkdownTable {
  header: TableLine;
  separator: TableLine;
  rows: TableLine[];
  align: Tokens.Table['align'];
  html: string[][];
}

/** バックスラッシュでエスケープしたパイプを残し、区切りのパイプだけで行を分ける。 */
function splitCells(line: string) {
  const text = line.trim().replace(/^\|/, '');
  const cells = [];
  let start = 0;
  for (const pipe of text.matchAll(/(\\*)\|/g)) {
    if (pipe[1].length % 2 !== 0) continue;
    const end = pipe.index + pipe[1].length;
    cells.push(text.slice(start, end).trim());
    start = end + 1;
  }
  if (start < text.length || cells.length === 0) cells.push(text.slice(start).trim());
  return cells;
}

/** Markedが認識する先頭のGFM表を探し、行の範囲を元の改行で記録する。 */
export function readTable(source: string, start = 0, end = source.length): MarkdownTable | undefined {
  const body = source.slice(start, end);
  const normalized = body.replace(/\r\n?/g, '\n');
  const tokens = marked.lexer(normalized, { gfm: true });
  const token = tokens.find(entry => entry.type === 'table') as Tokens.Table | undefined;
  if (!token) return undefined;

  // テーブルと同じ文字列が手前のコードフェンス等にあっても、そこで照合しない。
  let offset = 0;
  for (const entry of tokens) {
    const at = normalized.indexOf(entry.raw, offset);
    if (at < 0) return undefined;
    if (entry === token) { offset = at; break; }
    offset = at + entry.raw.length;
  }
  let position = start + normalizedLength(body, offset, 0);
  const lines = [];
  for (const match of source.slice(position, end).matchAll(/([^\r\n]*)(\r\n|\n|\r|$)/g)) {
    if (!match[0] || lines.length === token.rows.length + 2) break;
    const [, line, ending] = match;
    const last = position + match[0].length;
    lines.push({ start: position, end: last, ending, indent: /^[ \t]*/.exec(line)![0], cells: splitCells(line) });
    position = last;
  }
  if (lines.length !== token.rows.length + 2) return undefined;
  const [header, separator, ...rows] = lines;
  const html = [token.header, ...token.rows].map(row => row.map(cell => Parser.parseInline(cell.tokens)));
  return { header, separator, rows, align: token.align, html };
}

/** 入力されたHTMLを、改行やパイプが隣のセルを壊さないMarkdownにする。 */
export function tableCellMarkdown(html: string) {
  return blockMarkdown(html, '', '\n').trim().replace(/[ \t]*\n+/g, '<br>')
    .replace(/(\\*)\|/g, (_, slashes: string) => `${slashes}${slashes.length % 2 === 0 ? '\\' : ''}|`);
}

/** 列の足りない行には空セルを補い、元々存在したMarkdownセルの内容は保持する。 */
function rowCells(line: TableLine, columns: number) {
  return Array.from({ length: Math.max(columns, line.cells.length) }, (_, index) => line.cells[index] ?? '');
}

/** 新しく書き出す行にGFMの区切りを付ける。 */
function tableRow(cells: string[]) {
  return `| ${cells.join(' | ')} |`;
}

/** 変更したセルがある行だけを書き換える。 */
export function editTableCell(source: string, table: MarkdownTable, cell: TableCell, value: string) {
  const line = cell.row === 0 ? table.header : table.rows[cell.row - 1];
  if (!line || cell.column < 0 || cell.column >= table.align.length) return source;
  const cells = rowCells(line, table.align.length);
  if (cells[cell.column] === value) return source;
  cells[cell.column] = value;
  return source.slice(0, line.start) + line.indent + tableRow(cells) + line.ending + source.slice(line.end);
}

/** 選択位置で行・列の構造を変え、表以外の原本と既存の列揃えを保持する。 */
export function editTableStructure(source: string, table: MarkdownTable, { axis, kind, cell }: TableAction) {
  const columns = table.align.length;
  if (axis === 'row') {
    const line = cell.row === 0 ? table.separator : table.rows[cell.row - 1];
    if (!line) return source;
    if (kind === 'delete') return cell.row === 0 ? source : source.slice(0, line.start) + source.slice(line.end);
    const row = line.indent + tableRow(Array<string>(columns).fill(''));
    const added = line.ending ? row + line.ending : (table.header.ending || '\n') + row;
    return source.slice(0, line.end) + added + source.slice(line.end);
  }
  if (cell.column < 0 || cell.column >= columns || (columns === 1 && kind === 'delete')) return source;
  const lines = [table.header, table.separator, ...table.rows];
  const changed = lines.map(line => {
    const cells = rowCells(line, columns);
    if (kind === 'add') cells.splice(cell.column + 1, 0, line === table.separator ? '---' : '');
    else cells.splice(cell.column, 1);
    return line.indent + tableRow(cells) + line.ending;
  });
  return source.slice(0, table.header.start) + changed.join('') + source.slice(lines.at(-1)!.end);
}
