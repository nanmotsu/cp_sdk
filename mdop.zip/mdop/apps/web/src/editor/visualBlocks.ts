/** @file ビジュアル編集に表示する図表とDSLの情報を、原本と文書設定から組み立てる。 */

import { marked, Parser } from 'marked';
import { layoutLength, parseColumnWidths, splitFigureSource } from '../../../../packages/markdown/layout.mjs';
import type { VisualDslDefinition, VisualLayout } from '../api';
import { editorHtml } from './blocks';
import type { MarkdownBlock } from './blocks';
import { dslTableBody, readDslBlock, standaloneMermaidSize } from './directives';
import { readTable } from './tables';

const editableDslContent = new Set(['paragraph', 'blockquote', 'list', 'space']);
const complexMarkdown = /\{\{\s*ref:|\[\[\s*ref:|\[[^\]\r\n]*\][ \t]*\[[^\]\r\n]*\]|<!--|<\/?[A-Za-z]|^\s*:::/m;
const fallbackKinds: Partial<Record<string, VisualDslDefinition['kind']>> = { table: 'table', figure: 'figure', pagebreak: 'separator' };

/** 表か図のキャプションから手書き番号を分離し、見出しに対応する番号を付ける。 */
export function describeVisualBlocks(blocks: MarkdownBlock[], layout: VisualLayout | undefined, resolveImage: (src: string) => string | undefined) {
  const defs = new Map(layout?.blocks.map(block => [block.name, block]));
  const levels = layout?.headingLevels ?? [];
  let section = 0;
  let tables = 0;
  let figures = 0;
  let heading = '';

  return blocks.map(block => {
    if (block.heading && levels.includes(block.heading.depth)) {
      heading = block.heading.text;
      if (block.heading.depth === levels[0]) { section += 1; tables = 0; figures = 0; }
    }
    const dsl = block.kind === 'protected' ? readDslBlock(block.raw) : undefined;
    const definition = dsl ? defs.get(dsl.name) : undefined;
    const kind = dsl ? definition?.kind ?? (layout ? 'text' : fallbackKinds[dsl.name] ?? 'text') : undefined;
    const tableBody = dsl && kind === 'table' ? dslTableBody(block.raw, dsl) : undefined;
    const table = block.kind === 'table' ? readTable(block.raw)
      : tableBody && readTable(block.raw, tableBody.start, dsl?.bodyEnd);
    const body = dsl ? block.raw.slice(dsl.bodyStart, dsl.bodyEnd) : '';
    const figure = kind === 'figure' ? splitFigureSource(body) : undefined;
    const sizeOptions = figure && dsl ? { width: dsl.attributes.width ?? '', height: dsl.attributes.height ?? '' }
      : !dsl && block.mermaid?.length ? standaloneMermaidSize(block.raw) : undefined;
    const attributes = dsl?.attributes;
    const width = layoutLength(attributes?.width) ?? (attributes?.width ? undefined : definition?.defaults.width);
    const height = layoutLength(attributes?.height) ?? (attributes?.height ? undefined : definition?.defaults.height);
    const align: 'left' | 'right' | 'center' = attributes?.align === 'left' || attributes?.align === 'right' ? attributes.align : 'center';
    const isHtmlTable = block.kind === 'protected' && /^\s*<table\b/i.test(block.raw);
    const tableCaption = tableBody?.caption || (table && levels.length ? heading || '表' : '');
    const title = figure?.caption ?? tableCaption;
    const figureNumber = levels.length && figure ? `${layout!.figurePrefix}${section}.${++figures}` : '';
    const number = levels.length ? table ? `${layout!.tablePrefix}${section}.${++tables}`
      : isHtmlTable ? (tables++, '') : title ? figureNumber : '' : '';
    const caption = number ? title.replace(/^(図|表)\s*\d+(?:\.\d+)?\s*/, '') : title;
    const bodyMarkdown = figure?.body ?? body;
    const editable = kind === 'text' && dsl?.name !== 'hide' && !block.mermaid?.length && !complexMarkdown.test(body)
      && marked.lexer(body).every(token => editableDslContent.has(token.type));
    const html = dsl || isHtmlTable
      ? editorHtml(Parser.parse(marked.lexer(isHtmlTable ? block.raw : bodyMarkdown)), resolveImage)
      : '';
    const rawWidths = parseColumnWidths(attributes?.colRatio);
    return {
      dsl, definition, kind, table, figure, width, height, sizeOptions, number,
      caption: editorHtml(caption, resolveImage),
      html: { __html: html || (editable ? '<p><br></p>' : '') }, editable, isHtmlTable,
      align,
      fontSize: layoutLength(attributes?.fontSize),
      columnWidths: rawWidths.every(value => value === 'auto' || layoutLength(value)) ? rawWidths : [],
    };
  });
}
