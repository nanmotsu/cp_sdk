/** 設定の h1〜h3 を、採番に使う深さの順に並べる。 */
export function headingNumberLevels(levels?: readonly string[]): number[];

/** 文書順に見出しを受け取り、設定で選ばれた階層の番号を返す。 */
export function createHeadingNumberer(levels?: readonly number[]): (level: number) => string;

/** 見出し冒頭にある章番号に似た表記と、それに続く空白を取得する。 */
export function readWrittenHeadingNumber(text: string): { number: string; length: number } | undefined;

