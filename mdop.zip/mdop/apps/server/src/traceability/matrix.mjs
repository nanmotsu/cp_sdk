export const degrees = ['全', 'ほぼ', '一部', '未', '判定不能'];

/** 現在の元項目を起点に、未判定と参照切れも含めて表示する。 */
export function traceabilityMatrix(source, target, mappings) {
  const bySource = new Map(mappings.rows.map(row => [row.sourceId, row]));
  const targets = new Map(target.items.map(row => [row.id, row]));
  const sourceIds = new Set(source.items.map(row => row.id));
  const counts = Object.fromEntries([...degrees, '判定未作成'].map(value => [value, 0]));
  const rows = source.items.map(item => {
    const mapping = bySource.get(item.id) ?? null;
    counts[mapping?.degree ?? '判定未作成']++;
    return { source: item, mapping, targets: (mapping?.targetIds ?? []).map(id => targets.get(id) ?? { id, missing: true }),
      missingTargetIds: (mapping?.targetIds ?? []).filter(id => !targets.has(id)) };
  });
  return { rows, orphans: mappings.rows.filter(row => !sourceIds.has(row.sourceId)), counts, total: source.items.length };
}
