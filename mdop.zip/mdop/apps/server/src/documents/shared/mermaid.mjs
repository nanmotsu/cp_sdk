/**
 * @file Mermaidのコードをブラウザーで描画し、出力先に合わせて埋め込みSVGまたはPNGへ置き換える。
 */

import { createRequire } from "node:module";
import { parseDocument } from "htmlparser2";
import { readMermaidLayout } from "../../../../../packages/markdown/layout.mjs";
import { withBrowserPage } from "./browser-page.mjs";
import { escapeHtml } from "./markup.mjs";

const require = createRequire(import.meta.url);
const scriptPath = require.resolve("mermaid/dist/mermaid.min.js");
const fencedDiagram = /<pre><code class="language-mermaid">([\s\S]*?)<\/code><\/pre>/gi;

/** 空の描画ページを準備し、同梱のMermaidスクリプトを読み込む。 */
async function preparePage(page) {
    await page.setContent("<!doctype html><meta charset=utf-8><style>body{margin:0;background:white}</style><body></body>");
    await page.addScriptTag({ path: scriptPath });
}

/** 文書内のMermaidを表示用SVGに変換する。 */
async function draw(page, code, index, fontSize) {
    const svg = await page.evaluate(async ({ code, index, fontSize }) => {
        window.mermaid.initialize({
            startOnLoad: false,
            securityLevel: "strict",
            theme: "neutral",
            fontFamily: "'Noto Sans JP', 'Yu Gothic', 'Meiryo', sans-serif",
            themeVariables: { fontSize },
            htmlLabels: true,
            flowchart: { htmlLabels: true },
            sequence: { useMaxWidth: false },
        });
        const id = `md-diagram-${index}`;
        try {
            return (await window.mermaid.render(id, code)).svg;
        } finally {
            document.getElementById(id)?.remove();
            document.getElementById(`d${id}`)?.remove();
        }
    }, { code, index, fontSize });
    return svg.replace(/<p\b[^>]*>([\s\S]*?)<\/p>/g, "$1")
        .replace(/style="display: table-cell;([^"]*)"/g, 'style="display:flex;align-items:center;justify-content:center;height:100%;$1"');
}

/** 描画前のHTMLに含まれるMermaidコードブロックを順番に取り出す。 */
export function extractMermaidSources(html) {
    return Array.from(html.matchAll(fencedDiagram), match =>
        parseDocument(match[1]).children.map(node => node.data ?? "").join("")
    );
}

/** 描画を実行して、各入力が有効かと失敗理由を取得する。 */
export async function checkMermaidSources(sources, { signal } = {}) {
    return withBrowserPage(async page => {
        await preparePage(page);
        const results = [];
        for (const [index, source] of sources.entries()) {
            signal?.throwIfAborted();
            const { code, fontSize } = readMermaidLayout(source);
            try {
                await draw(page, code, index, fontSize ?? "16px");
                results.push(null);
            } catch (error) {
                signal?.throwIfAborted();
                results.push(error.message || "描画できませんでした。");
            }
        }
        return results;
    }, { scripts: true, signal });
}

/** 複数の図を共有ページで描画し、図ごとのSVG・PNGまたはエラーを入力順に返す。 */
export async function renderMermaidFigures(sources, { fontSize, raster, signal }) {
    if (!sources.length) return [];
    return withBrowserPage(async page => {
        await preparePage(page);
        const results = [];
        for (const [index, source] of sources.entries()) {
            signal?.throwIfAborted();
            const diagram = readMermaidLayout(source);
            try {
                const svg = await draw(page, diagram.code, index, diagram.fontSize ?? fontSize);
                if (raster) {
                    await page.evaluate(value => { document.body.innerHTML = value; }, svg);
                    const element = await page.$("body > svg");
                    const png = await element.screenshot({ type: "png" });
                    results.push({ png: Buffer.from(png).toString("base64"), width: diagram.width });
                    continue;
                }
                results.push({ svg, width: diagram.width, maxHeight: diagram.height });
            } catch (error) {
                signal?.throwIfAborted();
                results.push({ error: error.message || "描画できませんでした。" });
            }
        }
        return results;
    }, { scripts: true, signal });
}

/** 文書中のMermaidフェンスを描画結果で置き換え、失敗した図の診断を警告へ追加する。 */
export async function renderMermaidBlocks(html, { warnings, ...options }) {
    const output = await renderMermaidFigures(extractMermaidSources(html), options);
    let index = 0;
    return html.replace(fencedDiagram, () => {
        const diagram = output[index++];
        if (diagram.error) {
            const message = `Mermaid ${index}: ${diagram.error}`;
            warnings.push(message);
            return `<p>${escapeHtml(message)}</p>`;
        }
        if (diagram.png) return `<img src="data:image/png;base64,${diagram.png}" alt=""${diagram.width ? ` style="width:${diagram.width}"` : ""}>`;
        const size = [diagram.width && `width:${diagram.width}`, diagram.maxHeight && `--mermaid-height:${diagram.maxHeight}`]
            .filter(Boolean).join(";");
        return `<div class="mermaid-block"${size ? ` style="${size};margin:0 auto"` : ""}>${diagram.svg}</div>`;
    });
}
