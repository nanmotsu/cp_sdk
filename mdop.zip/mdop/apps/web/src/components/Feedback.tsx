/**
 * @file 出力・生成・プレビューで共通利用する、警告とジョブ進捗の表示部品。
 */

import { jobError } from '../api';
import type { JobState } from '../useJob';

/** 処理から返った警告がある場合だけ、一覧を表示する。 */
export function Warnings({ warnings }: { warnings?: string[] }) {
  if (!warnings?.length) return null;
  return <ul className="warnings">{warnings.map((warning, index) => <li key={index}>{warning}</li>)}</ul>;
}

/** ジョブの進行、中断操作、失敗を共通の見た目で表示する。 */
export function JobFeedback<T>({ state }: { state: JobState<T> }) {
  return (
    <>
      {state.error && <p className="error" role="alert">{state.error}</p>}
      {state.busy && <div className="job-status" role="status">
        <span>{state.job?.progress || (state.job?.status === 'queued' ? '処理待ち…' : '処理中…')}</span>
        {state.job && <button type="button" disabled={state.canceling} onClick={() => void state.cancel()}>中止</button>}
      </div>}
      {state.job?.status === 'failed' && <p className="error" role="alert">{jobError(state.job)}</p>}
      {state.job?.status === 'canceled' && <p className="muted" role="status">中止しました</p>}
    </>
  );
}
