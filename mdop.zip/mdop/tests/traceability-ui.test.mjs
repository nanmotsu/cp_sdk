import assert from 'node:assert/strict';
import { once } from 'node:events';
import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';
import { createAppServer } from '../apps/server/src/index.mjs';
import { createTraceability, beginTraceability, createTraceabilityStore } from '../apps/server/src/traceability/store.mjs';
import { launchBrowser } from '../apps/server/src/documents/shared/browser.mjs';

test('トレーサビリティ画面で編集・保存・変更確認・履歴差分・離脱確認を操作できる', {
  skip: process.env.MD_OPERATOR_TEST_CHROME !== '1', timeout: 45000,
}, async t => {
  const root = await mkdtemp(join(tmpdir(), 'mdop-trace-ui-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const docs = join(root, 'documents');
  await mkdir(docs);
  await writeFile(join(docs, 'config.yaml'), 'toc: false\n');
  await writeFile(join(root, 'requirements.md'), '# 要件\n登録できる');
  await writeFile(join(root, 'specification.md'), '# 仕様\n登録処理');
  const created = await createTraceability(root, {
    name: '画面試験の要件と仕様', sourceUri: 'file:///requirements.md', targetUri: 'file:///specification.md', granularity: '機能ごと',
  }, async context => ({ ...context, candidate: { status: '関連あり', reason: '同じ製品の資料' } }));
  const store = createTraceabilityStore(root);
  const initial = await store.get(created.id);
  await store.save(created.id, {
    revision: initial.revision,
    source: { items: [{ id: 'S1', content: '登録できる', location: '要件1' }], scope: { read: ['全文'], unread: [] } },
    target: { items: [{ id: 'T1', content: '登録処理', location: '仕様1' }], scope: { read: ['全文'], unread: [] } },
  });
  const run = await beginTraceability(root, created.id, 'map');
  await run.save({ ...run.context, candidate: [{ id: 'M1', sourceId: 'S1', targetIds: ['T1'], degree: '全', detail: '登録処理がある' }] });
  const calls = [];
  const sessions = new Set();
  const agent = {
    async listSessions() { return [...sessions].map(id => ({ id })); },
    async complete(input) {
      const context = JSON.parse(input.prompt.split('\n\n')[1]);
      calls.push(context.operation);
      const values = {
        related: { status: '関連あり', reason: '同じ製品' },
        source: { items: [{ id: 'S1', content: '登録できる', location: '要件1' }], scope: { read: ['全文'], unread: [] } },
        target: { items: [{ id: 'T1', content: '登録処理', location: '仕様1' }], scope: { read: ['全文'], unread: [] } },
        map: [{ id: 'M1', sourceId: 'S1', targetIds: ['T1'], degree: '全', detail: '登録処理がある' }],
      };
      const sessionId = input.sessionId || 'ahp-session:/' + context.id;
      sessions.add(sessionId);
      return { text: JSON.stringify({ ...context, candidate: values[context.operation] }), session: { id: sessionId } };
    },
  };
  const server = await createAppServer({ documentsRoot: docs, traceabilityRoot: root, agent });
  t.after(() => new Promise(resolve => server.close(resolve)));
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const base = 'http://127.0.0.1:' + server.address().port;
  const browser = await launchBrowser();
  t.after(() => browser.close());
  const page = await browser.newPage();
  await page.setViewport({ width: 1440, height: 900 });
  page.setDefaultTimeout(8000);
  const runtimeErrors = [];
  page.on('pageerror', error => runtimeErrors.push(error.message));
  await page.goto(base);
  await page.waitForSelector('.trace-card:not(.trace-new)');
  await page.type('.trace-library input[type="search"]', '該当なし');
  await page.waitForSelector('.trace-card:not(.trace-new)', { hidden: true });
  await page.focus('.trace-library input[type="search"]');
  await page.keyboard.down('Control');
  await page.keyboard.press('a');
  await page.keyboard.up('Control');
  await page.keyboard.press('Backspace');
  await page.waitForSelector('.trace-card:not(.trace-new)');
  await page.click('.trace-card:not(.trace-new)');
  await page.waitForSelector('table[aria-label="判定表"]');
  assert.ok(await page.$eval('.app-bar', header => header.firstElementChild.classList.contains('back-button')));
  assert.equal(await page.$eval('select[aria-label="S1 対応度"]', element => element.value), '全');
  assert.ok(await page.$eval('input[aria-label="トレーサビリティ名"]', element => {
    const input = element.getBoundingClientRect();
    const header = element.closest('.trace-editor-heading');
    const actions = header.querySelector('.trace-actions').getBoundingClientRect();
    return Math.abs(input.width - header.getBoundingClientRect().width) < 2 && actions.top >= input.bottom;
  }));
  await page.focus('input[aria-label="トレーサビリティ名"]');
  await page.keyboard.down('Control');
  await page.keyboard.press('a');
  await page.keyboard.up('Control');
  await page.type('input[aria-label="トレーサビリティ名"]', '画面で変更した名前');
  await page.click('.save-button');
  await page.waitForFunction(() => document.querySelector('.save-status')?.textContent === '保存済み');
  const renamed = await store.get(created.id);
  assert.equal(renamed.id, created.id);
  assert.equal(renamed.config.name, '画面で変更した名前');
  assert.equal(renamed.folderName, '画面で変更した名前');
  await page.click('.trace-context summary');
  await page.click('button::-p-text(④の判定に使った版を開く)');
  await page.waitForSelector('.trace-history-banner');
  assert.match(await page.$eval('.trace-history-banner', element => element.textContent), new RegExp(run.context.runId));
  await page.click('button::-p-text(編集画面に戻る)');
  await page.click('.trace-tabs button::-p-text(先項目)');
  await page.type('textarea[aria-label="T1 特記事項"]', '保存する注記');
  await page.keyboard.down('Control');
  await page.keyboard.press('s');
  await page.keyboard.up('Control');
  await page.waitForFunction(() => document.querySelector('.save-status')?.textContent === '保存済み');
  assert.equal((await store.get(created.id)).target.items[0].notes, '保存する注記');
  await page.click('.trace-tabs button::-p-text(判定表)');
  await page.waitForSelector('.trace-review-item.changed');
  assert.match(await page.$eval('.trace-review-item.changed', element => element.textContent), /先項目表/);
  await page.click('.trace-review-item.changed button::-p-text(履歴差分)');
  await page.waitForSelector('button::-p-text(差分を表示)');
  assert.ok(await page.$('button::-p-text(今回の実行前版を開く)'));
  await page.click('button::-p-text(差分を表示)');
  await page.waitForSelector('.trace-cell-diff');
  assert.match(await page.$eval('.trace-difference', element => element.textContent), /保存する注記/);
  await page.click('.trace-tabs button::-p-text(元項目)');
  await page.click('button::-p-text(元項目を追加)');
  const row = await page.$('table[aria-label="元項目表"] tbody tr:last-child');
  const cells = await row.$$('textarea');
  await cells[0].type('取消できる');
  await cells[1].type('要件2');
  await page.click('.save-button');
  await page.waitForFunction(() => document.querySelector('.save-status')?.textContent === '保存済み');
  await page.click('.trace-tabs button::-p-text(判定表)');
  assert.equal(await page.$$eval('table[aria-label="判定表"] tbody tr', elements => elements.length), 2);
  assert.match(await page.$eval('table[aria-label="判定表"]', element => element.textContent), /判定未作成/);
  const markdown = await (await fetch(base + '/api/v1/traceabilities/' + created.id + '/markdown')).text();
  assert.match(markdown, /取消できる/);
  assert.match(markdown, /判定未作成/);
  await page.type('textarea[aria-label="S1 判定の特記事項"]', '未保存');
  page.once('dialog', dialog => void dialog.dismiss());
  await page.click('.back-button');
  assert.ok(await page.$('.trace-app'));
  page.once('dialog', dialog => void dialog.accept());
  await page.click('.back-button');
  await page.waitForSelector('.trace-library');
  assert.equal(await page.$('.trace-app'), null);
  await page.waitForSelector('.trace-new');
  await page.click('.trace-new');
  const fields = await page.$$('.trace-create input');
  await fields[0].type('新しく作った関係');
  await fields[1].type(join(root, 'requirements.md'));
  await fields[2].type(join(root, 'specification.md'));
  await page.type('.trace-create textarea', '機能単位で抽出');
  page.once('dialog', dialog => void dialog.accept());
  await page.click('.trace-create button[type="submit"]');
  await page.waitForSelector('.trace-app');
  await page.waitForSelector('table[aria-label="判定表"]');
  const newId = await page.$eval('.trace-relation-id', element => element.textContent);
  assert.notEqual(newId, created.id);
  const choices = await page.$$('.trace-run-options select');
  await choices[0].select('source');
  await page.click('.trace-run-options input[type="checkbox"]');
  await page.click('button::-p-text(Copilotで実行)');
  await page.waitForFunction(() => [...document.querySelectorAll('.trace-notice')].some(element => element.textContent.includes('Copilotの処理が完了')));
  assert.deepEqual(calls, ['related', 'source', 'target', 'map']);
  assert.equal(await page.$$eval('table[aria-label="判定表"] tbody tr', elements => elements.length), 0);
  assert.equal((await store.get(newId)).mappings.rows.length, 1);
  await page.click('button::-p-text(画面を再読み込み)');
  await page.waitForSelector('select[aria-label="S1 対応度"]');
  assert.equal(await page.$eval('select[aria-label="S1 対応度"]', element => element.value), '全');
  assert.deepEqual(runtimeErrors, []);
});
