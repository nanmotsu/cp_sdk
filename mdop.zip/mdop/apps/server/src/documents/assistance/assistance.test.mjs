/**
 * @file 代替のCopilotとローカルのAgent Hostを使い、参照抽出、生成結果、セッション、モデル、添付を検証する。
 */

import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readFile, readdir, realpath, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { test } from 'node:test';
import { pathToFileURL } from 'node:url';
import { parseDocument } from 'htmlparser2';
import { createAssistance } from './index.mjs';
import { figureFromDraft } from './figure-materials.mjs';
import { collectSources, inspectSource } from './sources.mjs';
import { workspaceRoot } from '../../common/filesystem/locations.mjs';
import { prepareDocumentInput } from './document-input.mjs';

const editingTemplate = { label: '本文の修正', prompt: '依頼と無関係な文章を維持する。' };
const sourceTemplate = { label: 'ソースから文書化', prompt: '概要、利用者と対象範囲を説明する。' };

/** テスト用の参照資料を置く一時フォルダを用意する。 */
async function workspace(t) {
    const parent = await realpath(tmpdir());
    const directory = await mkdtemp(join(parent, 'md-operator-adapters-test-'));
    t.after(async () => {
        const actual = await realpath(directory);
        assert.equal(dirname(actual), parent);
        await rm(actual, { recursive: true, force: true });
    });
    return directory;
}

/** 選択したソースとExcelをURIで添付し、内容をプロンプトへ展開しないことを検証する。 */
test('selected source code and Excel are attached by URI', async (t) => {
    const root = await workspace(t);
    const project = join(root, 'reference');
    await mkdir(project);
    await writeFile(join(project, 'one.js'), 'const included = true;');
    await writeFile(join(project, 'two.js'), 'const excluded = true;');
    await writeFile(join(project, 'external.md'), '# External Markdown');
    await writeFile(join(project, '.env'), 'FILE_SHOULD_NOT_BE_RETURNED=true');
    const bookPath = join(root, 'requirements.xlsx');
    await writeFile(bookPath, Buffer.from('Excel data remains in the attached file'));

    assert.deepEqual((await inspectSource({ path: project })).files, ['external.md', 'one.js', 'two.js']);
    assert.equal((await inspectSource({ path: bookPath })).kind, 'excel');
    assert.equal((await inspectSource({ path: join(project, 'external.md') })).kind, 'file');
    await assert.rejects(collectSources([{ path: project, files: ['../outside.js'] }]), { code: 'INVALID_SOURCE_FILE' });
    await assert.rejects(collectSources([{ path: project, files: ['one.js'], readingNote: 'a'.repeat(1001) }]), { code: 'INVALID_SOURCE_NOTE' });

    let sent;
    const integrations = createAssistance({ agent: { complete: async (request) => {
        sent = request;
        return { text: '```markdown\n---\ntitle: XYZ\n---\n# 下書き\n```' };
    } } });
    const result = await integrations.generate({
        template: { label: 'Excel要件から仕様書', prompt: '製品名を明記する。\n文末を揃える。' },
        instruction: '動作を説明する。',
        sources: [
            { path: project, files: ['one.js'], readingNote: '定数は有効フラグ。' },
            { path: bookPath, readingNote: '「要件」シートのA1を読む。A列は要件ID。' },
        ],
    });
    const { prompt, purpose, attachments } = sent;
    assert.deepEqual(attachments, [
        { kind: 'file', uri: pathToFileURL(join(project, 'one.js')).href, label: 'reference/one.js', role: 'document' },
        { kind: 'file', uri: pathToFileURL(bookPath).href, label: 'requirements.xlsx', role: 'document' },
    ]);
    assert.match(prompt, /製品名/);
    assert.match(prompt, /文末を揃える/);
    assert.match(prompt, /用途: Excel要件から仕様書/);
    assert.match(prompt, /今回の編集依頼:\n動作を説明/);
    assert.match(prompt, /"note":"定数は有効フラグ。","sources":\[\{"path":"reference\/one\.js"\}\]/);
    assert.match(prompt, /"note":"「要件」シートのA1を読む。A列は要件ID。","sources":\[\{"path":"requirements\.xlsx"\}\]/);
    assert.match(prompt, /許可する種類:[^\n]*:::figure/);
    assert.equal(purpose, 'edit-document');
    assert.doesNotMatch(prompt, /const included|const excluded|Excel data remains|External Markdown|実装を明記/);
    assert.deepEqual(result.sources, [{ path: 'reference/one.js' }, { path: 'requirements.xlsx' }]);
    assert.equal(result.markdown, '# 下書き\n');
    assert.equal(result.warnings.length, 1);
    assert.deepEqual(result.diagnostics, []);
});

/** フォルダ全体は候補ファイルに展開せず、ディレクトリURIを1件だけ添付する。 */
test('a whole folder is attached as one directory URI', async (t) => {
    const root = await workspace(t);
    const project = join(root, 'reference');
    await mkdir(project);
    await writeFile(join(project, 'one.js'), 'const included = true;');

    const result = await collectSources([{ path: project, scope: 'directory', readingNote: '公開APIを調べる。' }]);
    assert.deepEqual(result.attachments, [{
        kind: 'file', uri: pathToFileURL(project).href, label: 'reference/', role: 'directory',
    }]);
    assert.deepEqual(result.sources, [{ path: 'reference/' }]);
    assert.deepEqual(result.readingNotes, [{ note: '公開APIを調べる。', sources: [{ path: 'reference/' }] }]);
    await assert.rejects(collectSources([{ path: project, scope: 'directory', files: ['one.js'] }]),
        { code: 'INVALID_SOURCE_SELECTION' });
    await assert.rejects(collectSources([{ path: join(project, 'one.js'), scope: 'directory' }]),
        { code: 'INVALID_SOURCE_SELECTION' });
});

/** Copilotが添付を読めない場合に編集案として保存しないことを検証する。 */
test('an unreadable attachment stops document generation', async () => {
    const integrations = createAssistance({ agent: { async complete() {
        return { text: 'MD_OPERATOR_SOURCE_UNREADABLE: Excelファイルを読み取れませんでした。' };
    } } });
    await assert.rejects(integrations.generate({ template: sourceTemplate, instruction: '要件を整理する。' }),
        { code: 'SOURCE_UNREADABLE' });
});

/** 選択されたテンプレートの文面を、その回の依頼にだけ使う。 */
test('writing guidance uses the selected template prompt for the current request', async () => {
    let sent;
    const integrations = createAssistance({ agent: { complete: async ({ prompt }) => {
        sent = prompt;
        return { text: '# 編集結果' };
    } } });
    const input = { instruction: '本文を整理する。' };
    await integrations.generate({ ...input, template: { label: '用語の統一', prompt: '既存の用語に従う。' } });
    assert.match(sent, /文書の書き方:\n既存の用語に従う。/);
    await integrations.generate({ ...input, template: { label: '要件の整理', prompt: '目的、スコープ、機能要件を整理する。' } });
    assert.match(sent, /文書の書き方:\n目的、スコープ、機能要件/);
    assert.doesNotMatch(sent, /既存の用語に従う/);
});

/** 設定で有効にしたDSLが生成用の指示と出力検証の両方に使われることを検証する。 */
test('the generated draft uses its document DSL and returns actionable diagnostics', async () => {
    let sent;
    const integrations = createAssistance({ agent: { complete: async ({ prompt }) => {
        sent = prompt;
        return { text: '# 仕様\n\n:::review\n本文\n:::\n\n:::warning\n対象外\n:::' };
    } } });
    const result = await integrations.generate({
        template: sourceTemplate,
        instruction: '手順を説明する。',
        dsl: { blocks: [{ name: 'review', snippet: { body: [':::review', '確認内容', ':::'] } }] },
    });
    assert.match(sent, /許可する種類: :::review/);
    assert.match(sent, /:::review\n確認内容\n:::/);
    assert.match(sent, /概要、利用者と対象範囲/);
    assert.doesNotMatch(sent, /:::warning/);
    assert.ok(result.diagnostics.some(item => item.severity === 'error' && item.line === 7 && item.message.includes('warning')));
});

/** 編集可能な図版が所定位置の参照になり、本文に埋め込むMermaidはコードとして保持されることを検証する。 */
test('document edits propose movable SVG figures at the intended Markdown position and keep Mermaid source', async (t) => {
    const vector = '<svg viewBox="0 0 80 40" onclick="unsafe()"><script>unsafe()</script>' +
        '<g id="entry" aria-label="入社"><rect width="80" height="40"/><text x="6" y="20">入社</text></g></svg>';
    const mermaid = ['```mermaid', 'flowchart LR', 'A --> B', '```'].join('\n');
    const response = ['# 採用手順', '', 'ここに追加します。', '', '```md-operator-figure ステップ [1]', vector,
        '```', '', 'この節にはMermaidを使います。', '', mermaid, '', '# 変更しない節'].join('\n');
    const directory = await workspace(t);
    const path = 'index.md';
    const content = '# 採用手順\r\n\r\nここに追加します。\r\n\r\n# 変更しない節';
    await writeFile(join(directory, path), content);
    const documentInput = await prepareDocumentInput(directory, { path, content });
    let sent;
    const integrations = createAssistance({
        agent: { /** 生成時に送られた指示と添付を保存し、固定のMarkdownを返す。 */ async complete(request) { sent = request; return { text: response }; } },
        /** Mermaidの入力を観測する代替レンダラー。 */
        async renderMermaid(source) { assert.match(source, /A --> B/); },
    });
    const result = await integrations.generate({
        template: editingTemplate, instruction: '採用手順の最初の段落の後に図を追加。次の節はMermaidで。',
        documentInput,
    });
    const uri = pathToFileURL(join(directory, path)).href;
    assert.deepEqual(sent.attachments, [
        { kind: 'file', uri, label: path, role: 'document',
            range: { start: { line: 0, character: 0 }, end: { line: 4, character: 8 } } },
    ]);
    assert.doesNotMatch(sent.prompt, /現在の本文の文字列|ここに追加します。|# 採用手順|# 変更しない節|currentMarkdown/);
    assert.match(sent.prompt, /採用手順の最初の段落の後に図を追加/);
    assert.match(sent.prompt, /依頼と無関係な文章/);
    assert.equal(sent.purpose, 'edit-document');
    assert.deepEqual(result.diagnostics, []);
    assert.equal(result.figures.length, 1);
    const [figure] = result.figures;
    assert.equal(figure.name, 'ステップ [1]');
    assert.equal(figure.placeholder, `./__md_operator_figures__/${figure.id}.svg`);
    const group = parseDocument(figure.svg, { xmlMode: true }).children[0].children.find(node => node.name === 'g');
    assert.equal(group.attribs.id, 'entry');
    assert.equal(group.attribs['aria-label'], '入社');
    assert.doesNotMatch(figure.svg, /onclick|<script/);
    assert.ok(result.markdown.includes(`ここに追加します。\n\n![ステップ \\[1\\]](${figure.placeholder})\n\nこの節にはMermaid`));
    assert.ok(result.markdown.includes(mermaid));
    assert.ok(result.markdown.endsWith('# 変更しない節\n'));
});

/** セッションを共有する2文書でも、現在の原本と規則だけを各送信に含める。 */
test('document edit requests carry their own target, attachment and DSL in a shared Copilot session', async (t) => {
    const directory = await workspace(t);
    const source = join(directory, 'reference.js');
    await writeFile(source, 'const firstRequestOnly = true;');
    const calls = [];
    const integrations = createAssistance({ agent: { async complete(request) {
        calls.push(request);
        return { text: '# 編集結果' };
    } } });
    for (const [id, block] of [['仕様書 A', 'first'], ['仕様書 B', 'second']]) {
        const folder = join(workspaceRoot, 'documents', id);
        const uri = pathToFileURL(join(folder, 'index.md')).href;
        await integrations.generate({
            documentId: id, documentFolder: folder, markdownPath: 'index.md',
            documentInput: { hasText: true, attachments: [{ kind: 'file', uri, label: 'index.md', role: 'document' }] },
            sessionId: 'ahp-session:/shared', instruction: `${id} の最初の段落を整理する。`,
            template: { ...editingTemplate, prompt: `${id} の書き方` }, dsl: { blocks: [{ name: block }] },
            sources: block === 'first' ? [{ path: source, readingNote: '今回だけの資料の読み方' }] : [],
        });
    }
    const [first, second] = calls;
    assert.equal(second.purpose, 'edit-document');
    assert.equal(second.sessionId, first.sessionId);
    assert.notEqual(second.attachments[0].uri, first.attachments[0].uri);
    assert.match(first.prompt, /仕様書 A の最初の段落を整理する/);
    assert.equal(first.attachments[1].uri, pathToFileURL(source).href);
    assert.match(first.prompt, /今回だけの資料の読み方/);
    assert.ok(second.prompt.includes(JSON.stringify({
        documentId: '仕様書 B', workspaceFolder: 'documents/仕様書 B', markdownPath: 'index.md',
    })));
    assert.match(second.prompt, /仕様書 B の書き方/);
    assert.match(second.prompt, /許可する種類: :::second/);
    assert.match(second.prompt, /仕様書 B の最初の段落を整理する/);
    assert.match(second.prompt, /今回の参照資料の添付はありません/);
    assert.doesNotMatch(second.prompt, /仕様書 A|:::first|firstRequestOnly|今回だけの資料の読み方/);
});

/** 原本へのリンクだけを用意し、補助ファイルを作らないことを検証する。 */
test('Copilot file inputs attach the complete saved Markdown by URI', async (t) => {
    const directory = await workspace(t);
    const path = '文書 #1.md';
    const content = '# 📝\r\n\r\n**編集**範囲\r\n';
    await writeFile(join(directory, path), content);
    const input = await prepareDocumentInput(directory, { path, content });
    assert.equal(input.hasText, true);
    assert.equal(input.attachments.length, 1);
    const [file] = input.attachments;
    assert.equal(file.uri, pathToFileURL(join(directory, path)).href);
    assert.match(file.uri, /%23/);
    assert.equal(await readFile(new URL(file.uri), 'utf8'), content);
    assert.deepEqual(file.range, { start: { line: 0, character: 0 }, end: { line: 3, character: 0 } });
    assert.deepEqual(await readdir(directory), [path]);
});

/** 不正な図版を診断し、コード例を採用可能な図ではないものとして扱うことを検証する。 */
test('a malformed editable figure yields diagnostics and code examples are never extracted', async () => {
    const response = ['# 例', '', '````markdown', '```md-operator-figure 仕様例', '<svg/>', '```', '````', '',
        '```md-operator-figure 壊れた図', '<svg><image href="https://example.invalid/raster.png"/></svg>', '```', '',
        '```md-operator-figure 途中の図', '<svg/>'].join('\n');
    const integrations = createAssistance({ agent: { /** 不正な図版とコード例を含む固定のMarkdownを返す。 */ async complete() { return { text: response }; } } });
    const result = await integrations.generate({ template: editingTemplate, instruction: '図を追加する。' });
    assert.equal(result.markdown, `${response}\n`);
    assert.equal(result.figures, undefined);
    assert.deepEqual(result.diagnostics.map(({ severity, code, line }) => ({ severity, code, line })), [
        { severity: 'error', code: 'INVALID_DRAFT_FIGURE', line: 9 },
        { severity: 'error', code: 'UNCLOSED_DRAFT_FIGURE', line: 13 },
    ]);
});

/** 二枚の素材と生成SVGを、別々に配置できる状態で返すことを検証する。 */
test('Copilot figure drafts keep multiple file materials and generated parts as layers', async () => {
    const original = Buffer.from('fictional screenshot');
    const session = { id: 'ahp-session:/image', title: 'figure review' };
    const images = ['before', 'after'].map(id => ({ id, original, name: `${id}.png`, mime: 'image/png' }));
    const svg = '<svg viewBox="0 0 60 70"><rect width="60" height="70" fill="red"/></svg>';
    const box = { type: 'box', x: 230, y: 20, width: 90, height: 115 };
    const integrations = createAssistance({
        /** テストで送信用画像と寸法の準備を差し替える。 */
        async prepareRasterAttachment({ original, mime }) { return { width: 800, height: 400, bytes: original, mime }; },
        agent: {
            /** 添付順を検証し、別々のレイヤーを指定した図版案を返す。 */
            async complete({ prompt, attachments, purpose, sessionId }) {
                assert.match(prompt, /比較して確認マークを置いてください/);
                assert.equal(purpose, 'compose-figure');
                assert.doesNotMatch(prompt, /md-operator-figure-v1/);
                assert.ok(prompt.includes(JSON.stringify({ documentId: '仕様書 A', workspaceFolder: 'documents/仕様書 A' })));
                assert.match(prompt, /"source":2,"name":"after.png","width":800,"height":400/);
                assert.equal(sessionId, session.id);
                assert.deepEqual(attachments.map(({ label, bytes }) => [label, bytes]), [
                    ['素材1 before.png', original], ['素材2 after.png', original],
                ]);
                return { session, text: JSON.stringify({ format: 'md-operator-figure-v1', name: '比較図', width: 500, height: 210, images: [
                    { source: 1, x: 20, y: 30, width: 200, height: 100 },
                    { source: 2, x: 230, y: 30, width: 200, height: 100 },
                    { name: '確認マーク', svg, x: 350, y: 135, width: 60, height: 70 },
                ], annotations: [box] }) };
            },
        },
    });
    const result = await integrations.composeFigure({ documentId: '仕様書 A', documentFolder: join(workspaceRoot, 'documents', '仕様書 A'),
        images, instruction: '比較して確認マークを置いてください', sessionId: session.id });
    assert.equal(result.name, '比較図');
    assert.equal(result.width, 500);
    assert.equal(result.height, 210);
    assert.deepEqual(result.images.slice(0, 2).map(({ sourceId, x }) => [sourceId, x]), [['before', 20], ['after', 230]]);
    assert.match(result.images[2].svg, /<rect/);
    assert.equal(result.images[2].name, '確認マーク');
    assert.deepEqual(result.annotations.map(({ id, ...shape }) => shape), [box]);
    assert.deepEqual(result.session, session);
});

/** 添付なしで作ったSVGパーツを利用でき、不正な配置は図版に保存できないことを確認する。 */
test('Copilot figure drafts can start without files and reject malformed layouts', async () => {
    const image = { name: 'Icon', svg: '<svg viewBox="0 0 30 40"><rect width="30" height="40"/></svg>', x: 0, y: 0, width: 30, height: 40 };
    const output = { format: 'md-operator-figure-v1', name: 'マーク', width: 100, height: 100, images: [image], annotations: [] };
    const integrations = createAssistance({ agent: {
        /** 添付が空のときに独立したSVGパーツを返す。 */
        async complete({ attachments }) {
            assert.deepEqual(attachments, []);
            return { text: JSON.stringify(output) };
        },
    } });
    const input = { documentId: '図案', documentFolder: join(workspaceRoot, 'documents', '図案'),
        images: [], instruction: 'マークを作る' };
    assert.equal((await integrations.composeFigure(input)).images[0].name, 'Icon');
    output.format = undefined;
    await assert.rejects(integrations.composeFigure(input), { code: 'INVALID_FIGURE_DRAFT', message: /専用エージェント/ });
    output.format = 'md-operator-figure-v1';
    image.x = 90;
    await assert.rejects(integrations.composeFigure(input), { code: 'INVALID_FIGURE_DRAFT' });
});

/** Copilotが生成した画像を図版の独立した保存用パーツに変換する。 */
test('Copilot image generation results become editable raster figure parts', async () => {
    const bytes = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10, 1, 2, 3]);
    const integrations = createAssistance({ agent: {
        async complete() {
            return { text: JSON.stringify({ format: 'md-operator-figure-v1', name: '説明図', width: 100, height: 100,
                images: [{ generated: 1, name: '生成イラスト', x: 10, y: 10, width: 80, height: 80 }], annotations: [] }),
                generatedImages: [{ mime: 'image/png', bytes }] };
        },
    } });
    const draft = await integrations.composeFigure({ documentId: '図案', documentFolder: join(workspaceRoot, 'documents', '図案'),
        images: [], instruction: '説明用のイラストを生成して配置する' });
    const figure = figureFromDraft(draft, []);
    assert.equal(figure.composition.images[0].name, '生成イラスト');
    assert.equal(figure.composition.uploads[0].base64, bytes.toString('base64'));
    assert.equal(figure.composition.uploads[0].mime, 'image/png');
});
