/**
 * @file AI支援に登録するローカル資料を選び、内容を展開せずAHPのURI添付に変換する。
 */

import { lstat, opendir, realpath } from 'node:fs/promises';
import { basename, dirname, extname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { pathToFileURL } from 'node:url';
import { workspaceRoot } from '../../common/filesystem/locations.mjs';
import { ApiError } from '../../common/api/errors.mjs';

const PROJECT_FILES_LIMIT = 500;
const PROJECT_ENTRIES_LIMIT = 6000;
const MAX_SELECTIONS = 20;
const TEXT_EXTENSIONS = new Set(`.md .markdown .txt .csv .tsv .js .jsx .mjs .cjs .ts .tsx .mts .cts .json .jsonc .yaml .yml .toml .xml .html .css .scss .sass .less .vue .svelte .py .rb .php .java .kt .kts .cs .fs .go .rs .swift .c .cc .cpp .h .hpp .sql .sh .ps1 .bat .cmd .gradle .properties .proto .graphql .tf .tfvars`.split(' '));
const IGNORED_DIRECTORIES = new Set(['.git', '.svn', '.hg', '.ssh', '.aws', '.venv', '__pycache__', '.next', 'node_modules', 'vendor', 'dist', 'build', 'target', 'coverage']);
const IGNORED_LOCKS = new Set(['package-lock.json', 'pnpm-lock.yaml', 'yarn.lock', 'bun.lock', 'composer.lock', 'cargo.lock']);
/** 相対参照パスの起点となるアプリのリポジトリルート。 */

/** 本文の抽出をサポートするテキストファイル名かを判定する。 */
function textFile(name) {
    const lower = name.toLowerCase();
    return !ignoredFile(lower) && (TEXT_EXTENSIONS.has(extname(lower)) || /^(dockerfile|makefile|gemfile|license)$/.test(lower));
}

/** 探索対象から外すロックファイルや設定などを名前で判定する。 */
function ignoredFile(name) {
    return IGNORED_LOCKS.has(name) || /^\.env(?:\.|$)|^\.npmrc$|^\.netrc$|^id_(rsa|dsa|ecdsa|ed25519)(?:\.|$)/.test(name);
}

/** アプリのルート基準または絶対パスで資料を解決し、読み取り対象の種類を検査する。 */
async function resolveSource(path) {
    if (typeof path !== 'string' || !path.trim() || path.includes('\0')) {
        throw new ApiError(400, 'INVALID_SOURCE', '参照元のパスを指定してください。');
    }
    const input = path.trim();
    if (/^[a-z][\w+.-]*:/i.test(input) && !(process.platform === 'win32' && /^[a-z]:[\\/]/i.test(input))) {
        throw new ApiError(400, 'INVALID_SOURCE', 'ローカルの相対パスまたは絶対パスを指定してください。');
    }
    const localPath = isAbsolute(input) ? input : resolve(workspaceRoot, input);
    if (process.platform === 'win32' && !/^[a-z]:[\\/][^:]*$/i.test(localPath)) {
        throw new ApiError(400, 'INVALID_SOURCE', '参照元はローカルドライブの絶対パスで指定してください。');
    }
    try {
        const info = await lstat(localPath);
        const absolutePath = await realpath(localPath);
        if (info.isDirectory()) return { path: absolutePath, kind: 'project', size: info.size };
        if (info.isFile()) {
            const name = basename(absolutePath);
            if (extname(name).toLowerCase() === '.xlsx') return { path: absolutePath, kind: 'excel', size: info.size };
            if (extname(name).toLowerCase() === '.docx' || textFile(name)) return { path: absolutePath, kind: 'file', size: info.size };
        }
        throw new ApiError(400, 'INVALID_SOURCE', '参照元にはフォルダ、対応するテキストファイル、または .xlsx・.docx を指定してください。');
    } catch (error) {
        if (error.code === 'ENOENT') throw new ApiError(404, 'SOURCE_NOT_FOUND', '指定された参照元が見つかりません。');
        if (error.code === 'EACCES' || error.code === 'EPERM') throw new ApiError(403, 'SOURCE_ACCESS_DENIED', '指定された参照元を読み取れません。');
        throw error;
    }
}

/** プロジェクト配下を探索し、利用者が選べるテキスト候補を上限つきで列挙する。 */
async function listProjectFiles(root) {
    const files = [];
    const folders = [''];
    let inspected = 0;
    let truncated = false;
    while (folders.length && !truncated) {
        const folder = folders.shift();
        const entries = await opendir(join(root, folder));
        for await (const entry of entries) {
            inspected += 1;
            if (inspected > PROJECT_ENTRIES_LIMIT || files.length >= PROJECT_FILES_LIMIT) {
                truncated = true;
                break;
            }
            const next = join(folder, entry.name);
            if (entry.isDirectory() && !IGNORED_DIRECTORIES.has(entry.name.toLowerCase())) folders.push(next);
            if (entry.isFile() && textFile(entry.name)) files.push(next.split(sep).join('/'));
        }
    }
    return { files: files.sort((first, second) => first.localeCompare(second)), truncated };
}

/** 選択UI向けに、入力元の種類とフォルダ内の候補ファイルを返す。 */
export async function inspectSource({ path }) {
    const source = await resolveSource(path);
    if (source.kind === 'project') {
        const { files, truncated } = await listProjectFiles(source.path);
        return { path: source.path, kind: source.kind, files, warnings: truncated ? ['候補一覧は最大500件です。必要に応じて対象のサブフォルダを指定してください。'] : [] };
    }
    return { path: source.path, kind: source.kind, warnings: [] };
}

/** フォルダ選択画面に表示できる直下の項目と、親フォルダを返す。 */
export async function browseSourceFolder({ path = '.' } = {}) {
    const folder = await resolveSource(path);
    if (folder.kind !== 'project') {
        throw new ApiError(400, 'SOURCE_FOLDER_REQUIRED', 'フォルダのパスを指定してください。');
    }
    const entries = [];
    let inspected = 0;
    let truncated = false;
    try {
        for await (const entry of await opendir(folder.path)) {
            if (++inspected > PROJECT_ENTRIES_LIMIT || entries.length === PROJECT_FILES_LIMIT) {
                truncated = true;
                break;
            }
            const lower = entry.name.toLowerCase();
            if (lower.startsWith('.')) continue;
            if (entry.isDirectory() && !IGNORED_DIRECTORIES.has(lower)) {
                entries.push({ name: entry.name, path: join(folder.path, entry.name), kind: 'folder' });
            } else if (entry.isFile() && (textFile(lower) || ['.xlsx', '.docx'].includes(extname(lower)))) {
                entries.push({ name: entry.name, path: join(folder.path, entry.name), kind: 'file' });
            }
        }
    } catch (error) {
        if (error.code === 'ENOENT') throw new ApiError(404, 'SOURCE_NOT_FOUND', '指定されたフォルダが見つかりません。');
        if (error.code === 'EACCES' || error.code === 'EPERM') throw new ApiError(403, 'SOURCE_ACCESS_DENIED', '指定されたフォルダを読み取れません。');
        throw error;
    }
    const parent = dirname(folder.path);
    entries.sort((a, b) => a.kind === b.kind ? a.name.localeCompare(b.name) : a.kind === 'folder' ? -1 : 1);
    return { path: folder.path, parent: parent === folder.path ? null : parent, entries, truncated };
}

/** 選択された相対パスをプロジェクト内の許可されるファイルへ解決する。 */
async function selectedProjectFile(root, path) {
    const parts = typeof path === 'string' ? path.split(/[\\/]/) : [];
    if (!parts.length || parts.some((part) => !part || part === '.' || part === '..' || /[:\0]/.test(part)) || !textFile(parts.at(-1))) {
        throw new ApiError(400, 'INVALID_SOURCE_FILE', 'プロジェクト内の対応する相対ファイルを指定してください。');
    }
    if (parts.slice(0, -1).some((part) => IGNORED_DIRECTORIES.has(part.toLowerCase()))) {
        throw new ApiError(400, 'INVALID_SOURCE_FILE', '選択したプロジェクトファイルは参照対象外です。');
    }
    let target = root;
    for (const part of parts) {
        target = join(target, part);
        if ((await lstat(target).catch(() => null))?.isSymbolicLink()) throw new ApiError(400, 'INVALID_SOURCE_FILE', 'シンボリックリンクは参照元にできません。');
    }
    const source = await resolveSource(target);
    const rel = relative(root, source.path);
    if (source.kind !== 'file' || !rel || isAbsolute(rel) || rel === '..' || rel.startsWith(`..${sep}`)) {
        throw new ApiError(400, 'INVALID_SOURCE_FILE', 'プロジェクト内のファイルを指定してください。');
    }
    return source;
}

/** フォルダから指定するファイルを検査し、重複を除く。 */
function selectionList(value) {
    if (!Array.isArray(value) || !value.length || value.length > MAX_SELECTIONS || value.some((item) => typeof item !== 'string' || !item)) {
        throw new ApiError(400, 'INVALID_SOURCE_SELECTION', `参照するプロジェクトファイルを選択してください（最大${MAX_SELECTIONS}件）。`);
    }
    return [...new Set(value)];
}

/** 登録された資料の読み方を検査し、空白を取り除く。 */
function sourceNote(value) {
    if (value === undefined) return '';
    if (typeof value !== 'string' || value.length > 1000) {
        throw new ApiError(400, 'INVALID_SOURCE_NOTE', '資料の読み方は1000文字以内で入力してください。');
    }
    return value.trim();
}

/** 登録された資料を検証し、ファイルまたはディレクトリURIの添付と資料ごとの読み方を用意する。 */
export async function collectSources(selections, signal) {
    if (!Array.isArray(selections) || selections.length > MAX_SELECTIONS) {
        throw new ApiError(400, 'INVALID_SOURCE_SELECTION', '参照元の指定が無効です。');
    }
    const attachments = [];
    const sources = [];
    const readingNotes = [];
    for (const selection of selections) {
        signal?.throwIfAborted();
        const note = sourceNote(selection?.readingNote);
        const source = await resolveSource(selection?.path);
        const label = basename(source.path);
        if (selection?.scope !== undefined && selection.scope !== 'directory') {
            throw new ApiError(400, 'INVALID_SOURCE_SELECTION', '参照元の範囲指定が無効です。');
        }
        if (selection?.scope === 'directory') {
            if (source.kind !== 'project' || selection.files !== undefined) {
                throw new ApiError(400, 'INVALID_SOURCE_SELECTION', 'フォルダ全体と個別ファイルは同時に指定できません。');
            }
            if (attachments.length >= MAX_SELECTIONS) {
                throw new ApiError(400, 'INVALID_SOURCE_SELECTION', `参照元は合計${MAX_SELECTIONS}件までです。`);
            }
            const citation = { path: `${label}/` };
            attachments.push({ kind: 'file', uri: pathToFileURL(source.path).href, label: citation.path, role: 'directory' });
            sources.push(citation);
            if (note) readingNotes.push({ note, sources: [citation] });
            continue;
        }
        const selected = source.kind === 'project'
            ? await Promise.all(selectionList(selection.files).map(file => selectedProjectFile(source.path, file)))
            : [source];
        const citations = [];
        for (const file of selected) {
            if (attachments.length >= MAX_SELECTIONS) {
                throw new ApiError(400, 'INVALID_SOURCE_SELECTION', `参照するファイルは合計${MAX_SELECTIONS}件までです。`);
            }
            const citation = { path: source.kind === 'project'
                ? `${label}/${relative(source.path, file.path).split(sep).join('/')}` : label };
            attachments.push({ kind: 'file', uri: pathToFileURL(file.path).href, label: citation.path, role: 'document' });
            sources.push(citation);
            citations.push(citation);
        }
        if (note) readingNotes.push({ note, sources: citations });
    }
    return { attachments, sources, readingNotes, warnings: [] };
}
