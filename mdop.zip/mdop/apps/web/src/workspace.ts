/**
 * @file GUIの文書選択、編集中の原本、保存結果と画面用通知を管理するZustandストア。
 */

import { create } from 'zustand';
import { api, ApiError, errorMessage } from './api';
import type { BackupDetail, DocumentInfo, MarkdownFile } from './api';

/** 現在の本文と取得・保存時の本文を並べて保持する、文書選択中の原本。 */
interface OpenFile extends MarkdownFile {
  documentId: string;
  savedContent: string;
}

/** 各パネルが共有する文書、原本、通信状態と操作の契約。 */
interface WorkspaceState {
  documents: DocumentInfo[];
  documentId: string | null;
  file: OpenFile | null;
  opening: boolean;
  saving: boolean;
  restoring: boolean;
  conflict: boolean;
  error: string;
  message: string;
  refreshDocuments: () => Promise<DocumentInfo[]>;
  open: (documentId: string | null, path?: string) => Promise<void>;
  update: (content: string) => void;
  save: () => Promise<OpenFile | null>;
  restore: (detail: BackupDetail) => Promise<boolean>;
  setError: (error: string) => void;
  setMessage: (message: string) => void;
}

let openRequest = 0;

/** 作業中の本文と保存済みの本文が異なるかを判定する。 */
const hasUnsavedChanges = (file: OpenFile | null) => !!file && file.content !== file.savedContent;

/** GUIで共有する文書状態と、その状態を更新する操作を公開する。 */
export const useWorkspace = create<WorkspaceState>((set, get) => ({
  documents: [],
  documentId: null,
  file: null,
  opening: false,
  saving: false,
  restoring: false,
  conflict: false,
  error: '',
  message: '',

  /** ローカルAPIから文書一覧を再取得し、ツリーのデータを更新する。 */
  async refreshDocuments() {
    const { documents } = await api.documents();
    set({ documents });
    return documents;
  },

  /** 文書と原本を選択する。要求番号で古い応答を除外し、文書IDが null なら編集対象を解除する。 */
  async open(documentId, path) {
    if (get().saving || get().restoring) return;
    const request = ++openRequest;

    if (documentId === null || !path) {
      set({ documentId, file: null, opening: false, conflict: false, error: '', message: '' });
      return;
    }

    set({ opening: true, error: '', message: '' });
    try {
      const result = await api.file(documentId, path);
      if (request !== openRequest) return;
      set({
        documentId,
        file: { ...result, documentId, savedContent: result.content },
        opening: false,
        conflict: false,
      });
    } catch (error) {
      if (request === openRequest) set({ error: errorMessage(error), opening: false });
    }
  },

  /** 選択中の原本の作業本文を更新する。保存済みの比較元は保持する。 */
  update(content) {
    const { file, restoring } = get();
    if (file && !restoring && file.content !== content) set({ file: { ...file, content } });
  },

  /** 変更を保存し、保存中の追加入力を作業本文に残す。競合時はディスクからの再読み込みを案内できる状態にする。 */
  async save() {
    const { file, opening, saving, restoring } = get();
    if (!file || opening || saving || restoring) return null;
    if (!hasUnsavedChanges(file)) return file;

    set({ saving: true, error: '', message: '' });
    try {
      const { path, content, revision } = file;
      const result = await api.saveFile(file.documentId, { path, content, revision });
      const savedFile = { ...file, ...result, savedContent: result.content ?? content };
      const current = get().file;
      if (current?.documentId === file.documentId && current.path === file.path) {
        set({
          file: { ...savedFile, content: current.content },
          conflict: false,
          message: '保存し、履歴に版を追加しました。',
        });
      }
      return savedFile;
    } catch (error) {
      set({ error: errorMessage(error), conflict: error instanceof ApiError && error.status === 409 });
      return null;
    } finally {
      set({ saving: false });
    }
  },

  /** 比較済みの版を復元し、本文とファイルツリーを復元した結果から更新する。 */
  async restore(detail) {
    const { documentId, file, saving, opening, restoring } = get();
    if (!documentId || saving || opening || restoring) return false;
    set({ restoring: true, error: '', message: '' });
    try {
      const { file: original, document } = await api.restoreBackup(documentId, detail.backup.id, {
        currentRevision: detail.currentRevision,
        ...(file && hasUnsavedChanges(file) && { currentMarkdown: file.content, revision: file.revision }),
      });
      set(state => ({
        file: original && { ...original, documentId, savedContent: original.content },
        documents: state.documents.map(item => item.id === documentId ? document : item),
        message: '文書フォルダを復元しました。直前の状態は履歴に保存しました。',
        conflict: false,
      }));
      return true;
    } catch (error) {
      set({ error: errorMessage(error), conflict: false });
      return false;
    } finally {
      set({ restoring: false });
    }
  },

  /** 画面の通知をエラーに切り替える。 */
  setError(error) {
    set({ error, message: '' });
  },

  /** 画面の通知を利用者向けの操作結果に切り替える。 */
  setMessage(message) {
    set({ message, error: '' });
  },
}));

export { hasUnsavedChanges };
export type { OpenFile };
