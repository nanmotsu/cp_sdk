/**
 * @file PDF・Wordの出力先を決め、文書内に成果物を保存する。
 */

import { posix } from "node:path";
import { badRequest } from "../../common/api/errors.mjs";
import { atomicWrite, ensureWorkspaceDirectory, workspacePath } from "../../common/filesystem/paths.mjs";
import { isBackupPath } from "../history/backups.mjs";

const outputTypes = { pdf: "pdf", docx: "docx" };

/** 設定で指定した文書ルートと、先頭に ./ が付いた相対フォルダを正規化する。 */
function normalizeOutputDir(value) {
    return value === "." ? "" : value?.replace(/^\.\//, "");
}

/** 形式別の出力名・出力先を優先し、文書フォルダからの成果物パスを決める。 */
export function exportRelativePath(path, type, config) {
    const extension = outputTypes[type];
    const fileName = config[`${extension}FileName`] ?? `${posix.basename(path, posix.extname(path))}.${extension}`;
    const explicitDir = normalizeOutputDir(config[`${extension}OutputDir`] ?? config.outputDir);
    const directory = explicitDir ?? "output";
    const output = posix.join(directory, fileName);
    if (isBackupPath(output)) throw badRequest("backups は履歴専用です。別の出力先を指定してください。");
    return output;
}

/** 復元状態を照合してから出力ファイルを保存する。 */
export function createOutputStore({ access, checkRestoreVersion }) {
    /** 変換結果を文書内に書く。出力先を作成し、公開前に中断を再確認する。 */
    async function writeOutput(id, path, buffer, signal, expectedRestore) {
        if (isBackupPath(path)) throw badRequest("backups は履歴専用です。別の出力先を指定してください。");
        return access(id, async folder => {
            checkRestoreVersion(id, expectedRestore);
            signal.throwIfAborted();
            const directory = posix.dirname(path);
            if (directory !== ".") await ensureWorkspaceDirectory(folder, directory);
            signal.throwIfAborted();
            await atomicWrite(await workspacePath(folder, path, { mayBeMissing: true }), buffer, { signal });
        });
    }

    return { writeOutput };
}
