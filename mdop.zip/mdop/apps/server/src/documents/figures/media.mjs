/**
 * @file 文書で参照できる図版の表示ファイルを解決する。
 */

import { posix } from "node:path";
import { isFigureImagePath } from "../../../../../packages/markdown/figure-paths.mjs";
import { notFound } from "../../common/api/errors.mjs";
import { workspacePath } from "../../common/filesystem/paths.mjs";

/** 登録済みの図版に対応する表示ファイルだけを、文書内の通常ファイルとして開く。 */
export async function figureImageFile(folder, relative) {
    if (!isFigureImagePath(relative)) throw notFound("文書に挿入できる画像は「図版」から選んでください。");
    await workspacePath(folder, `${posix.dirname(relative)}/asset.yaml`);
    return workspacePath(folder, relative);
}
