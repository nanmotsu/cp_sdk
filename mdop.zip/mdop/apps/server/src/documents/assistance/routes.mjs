/**
 * @file AI支援へ渡す資料の探索と、ファイルやシートの候補確認をHTTPで提供する。
 */

import { readJson, sendJson } from "../../common/api/http.mjs";
import { browseSourceFolder, inspectSource } from "./sources.mjs";

/** テンプレートの選択肢と、参照資料のルートを登録する。 */
export function assistanceRoutes(documents) {
    return [
        ["GET", "/documents/:id/copilot-templates", async (_request, response, { id }) => {
            const { source, path, templates, diagnostics } = await documents.copilotTemplates(id);
            return sendJson(response, 200, { source, path, diagnostics,
                templates: templates.map(({ id, label, prompt, instructionOptionalWithSources }) => ({ id, label, prompt, instructionOptionalWithSources })) });
        }],
        ["POST", "/sources/inspect", async (request, response) => {
            const { path } = await readJson(request);
            return sendJson(response, 200, await inspectSource({ path }));
        }],
        ["POST", "/sources/browse", async (request, response) => {
            const { path } = await readJson(request);
            return sendJson(response, 200, await browseSourceFolder({ path }));
        }],
    ];
}
