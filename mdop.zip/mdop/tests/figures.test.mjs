/**
 * @file SVGとラスタ図版の作成・更新・復旧を、一時フォルダとChrome描画で検証する。
 */

import assert from "node:assert/strict";
import { createHash, randomUUID } from "node:crypto";
import { mkdir, mkdtemp, readFile, realpath, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { test } from "node:test";
import { createFigureStore } from "../apps/server/src/documents/figures/store.mjs";
import { figureFromDraft } from "../apps/server/src/documents/assistance/figure-materials.mjs";
import { launchBrowser } from "../apps/server/src/documents/shared/browser.mjs";

/** 図版の保存に使う一時文書を作り、テスト終了時に片付ける。 */
async function fixture(t, renderers) {
    const parent = await realpath(tmpdir());
    const folder = await mkdtemp(join(parent, "md-operator-figure-test-"));
    t.after(async () => {
        const actual = await realpath(folder);
        assert.equal(dirname(actual), parent);
        await rm(actual, { recursive: true, force: true });
    });
    const figures = createFigureStore(async id => {
        assert.equal(id, "sample");
        return folder;
    }, renderers);
    return { folder, figures };
}

/** SVGの編集前後で本文のパスと元のMermaidソースを保持できることを検証する。 */
test("a managed SVG keeps one asset path and its Mermaid source across revisions", async t => {
    const { folder, figures } = await fixture(t);
    const svg = '<svg viewBox="0 0 80 40"><g id="login"><rect width="80" height="40"/></g></svg>';
    const shifted = svg.replace('id="login"', 'id="login" transform="translate(6 2)"');
    const mermaidSource = "flowchart LR\n A --> B\n";
    await mkdir(join(folder, "assets"));
    await writeFile(join(folder, "assets", "existing.svg"), svg);
    assert.deepEqual(await figures.list("sample"), []);
    assert.match(figures.prepareSvg(svg), /<g[^>]+id="login"/);

    const initial = await figures.create("sample", { kind: "svg", name: "ログイン", svg, mermaidSource });
    assert.match(initial.path, /^assets\/figures\/[a-f0-9-]+\/image\.svg$/);
    assert.equal(initial.mermaidSource, mermaidSource);
    assert.deepEqual(await figures.list("sample"), [{
        id: initial.id, name: "ログイン", kind: "svg", path: initial.path, revision: initial.revision,
    }]);

    const adopted = await figures.update("sample", initial.id, { kind: "svg", revision: initial.revision, svg: shifted });
    assert.equal(adopted.path, initial.path);
    assert.notEqual(adopted.revision, initial.revision);
    assert.match(await readFile(join(folder, adopted.path), "utf8"), /transform="translate\(6 2\)"/);
    assert.equal(adopted.mermaidSource, mermaidSource);
    assert.equal(await readFile(join(folder, "assets", "existing.svg"), "utf8"), svg);
    await assert.rejects(figures.update("sample", initial.id, { kind: "svg", revision: initial.revision, svg }), { status: 409 });
    await assert.rejects(figures.get("sample", "../existing.svg"), { status: 404 });
});

/** 同じ候補IDを再採用した際、保存済みの図版編集を上書きしないことを検証する。 */
test("accepting a draft SVG again reuses its stable path and never replaces existing edits", async t => {
    const { figures } = await fixture(t);
    const id = randomUUID();
    const input = { id, kind: "svg", name: "編集案の図", svg: '<svg viewBox="0 0 80 40"><rect width="80" height="40"/></svg>' };
    const [initial, retry] = await Promise.all([figures.create("sample", input), figures.create("sample", input)]);
    assert.deepEqual(retry, initial);
    assert.equal(initial.path, `assets/figures/${id}/image.svg`);
    const svg = input.svg.replace('width="80"', 'width="60"');
    await figures.update("sample", id, { kind: "svg", revision: initial.revision, svg });
    await assert.rejects(figures.create("sample", input), { status: 409 });
    await assert.rejects(figures.create("sample", { ...input, id: "../asset" }), { status: 400 });
    assert.equal((await figures.list("sample")).length, 1);
    assert.match((await figures.get("sample", id)).svg, /<rect width="60"/);
});

/** ラスタ更新の途中状態から、表示PNGに対応する注釈を読み直せることを検証する。 */
test("raster annotation updates retain originals and recover the accepted state after interrupted promotion", async t => {
    const original = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
    const output = annotations => annotations.length ? Buffer.from(JSON.stringify(annotations)) : original;
    const renderRaster = async ({ original: image, mime, annotations }) => {
        assert.deepEqual(image, original);
        assert.equal(mime, "image/png");
        if (annotations.some(({ x }) => x === -13)) throw new Error("render interrupted");
        return { buffer: output(annotations), width: 160, height: 90 };
    };
    const { folder, figures } = await fixture(t, { renderRaster });
    const initial = await figures.create("sample", { kind: "raster", name: "操作画面", mime: "image/png", base64: original.toString("base64") });
    assert.equal(initial.width, 160);
    assert.equal(initial.height, 90);
    assert.deepEqual(initial.annotations, []);
    assert.deepEqual(initial.images, [{ id: "original", x: 0, y: 0, width: 160, height: 90, originalPath: initial.originalPath }]);
    assert.deepEqual(await readFile(join(folder, initial.path)), original);
    const box = { id: "box-1", type: "box", x: 20, y: 8, width: 40, height: 12 };
    const input = { kind: "raster", revision: initial.revision, annotations: [box] };
    const results = await Promise.allSettled([
        figures.update("sample", initial.id, input),
        figures.update("sample", initial.id, input),
    ]);
    const [adopted, stale] = results;
    assert.equal(adopted.status, "fulfilled");
    assert.equal(stale.status, "rejected");
    assert.equal(stale.reason.status, 409);
    assert.deepEqual(adopted.value.annotations, [box]);
    assert.equal(adopted.value.path, initial.path);
    assert.equal(adopted.value.originalPath, initial.originalPath);
    const target = join(folder, initial.path);
    assert.deepEqual(await readFile(target), output([box]));
    assert.deepEqual(await readFile(join(folder, initial.originalPath)), original);

    // Simulate an accepted PNG whose annotations file wasn't promoted before the process exited.
    const pending = { ...box, x: 29 };
    const bytes = output([pending]);
    const imageHash = createHash("sha256").update(bytes).digest("hex");
    const images = [{ id: "original", x: 0, y: 0, width: 160, height: 90, file: "original.png", mime: "image/png" }];
    await writeFile(join(dirname(target), "annotations.pending.json"), JSON.stringify({ imageHash, width: 160, height: 90, annotations: [pending], images }));
    assert.deepEqual((await figures.get("sample", initial.id)).annotations, [box]);
    await writeFile(target, bytes);
    const recovered = await figures.get("sample", initial.id);
    assert.deepEqual(recovered.annotations, [pending]);
    assert.notEqual(recovered.revision, adopted.value.revision);

    await assert.rejects(figures.update("sample", initial.id, { ...input, revision: recovered.revision, annotations: [{ ...box, x: -13 }] }), { status: 400 });
    assert.deepEqual((await figures.get("sample", initial.id)).annotations, [pending]);
    assert.deepEqual(await readFile(target), bytes);
});

/** 画像レイヤー付きの図版を再編集しても、原本のパスと表示属性を保持できることを検証する。 */
test("composed raster figures retain immutable original paths and annotation styles on later updates", async t => {
    const first = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
    const second = Buffer.from([255, 216, 255]);
    const id = randomUUID();
    const { folder, figures } = await fixture(t, {
        renderRaster: async ({ composition, annotations }) => {
            assert.deepEqual(composition.images.map(image => image.original), [first, second]);
            const { width, height } = composition;
            return { width, height, buffer: Buffer.from(JSON.stringify({ composition, annotations })) };
        },
    });
    const images = [
        { id: "original", x: 0, y: 0, width: 120, height: 90 },
        { id, x: 122, y: 5, width: 80, height: 60 },
    ];
    const annotations = [
        { id: "box", type: "box", x: 10, y: 8, width: 40, height: 12, strokeWidth: 6, color: "#00aabb" },
        { id: "text", type: "label", x: 122, y: 66, text: "手順", fontSize: 30, fontWeight: "bold", color: "#223344" },
    ];
    const initial = await figures.create("sample", {
        kind: "raster", name: "比較", mime: "image/png", base64: first.toString("base64"), annotations,
        composition: {
            width: 210, height: 95, images,
            uploads: [{ id, mime: "image/jpeg", base64: second.toString("base64") }],
        },
    });
    assert.deepEqual(initial.annotations, annotations);
    assert.deepEqual(initial.images.map(({ originalPath: _path, ...placement }) => placement), images);
    assert.equal(initial.path, `assets/figures/${initial.id}/image.png`);
    assert.equal(initial.originalPath, `assets/parts/${initial.id}/original.png`);
    assert.equal(initial.images[0].originalPath, initial.originalPath);
    assert.equal(initial.images[1].originalPath, `assets/parts/${initial.id}/layer-${id}.jpg`);
    assert.deepEqual(await readFile(join(folder, initial.originalPath)), first);
    assert.deepEqual(await readFile(join(folder, initial.images[1].originalPath)), second);

    const revised = await figures.update("sample", initial.id, {
        kind: "raster", revision: initial.revision, annotations,
        composition: { width: 240, height: 100, images: [images[0], { ...images[1], x: 135, width: 95 }] },
    });
    assert.equal(revised.path, initial.path);
    assert.notEqual(revised.revision, initial.revision);
    assert.deepEqual(revised.images.map(image => image.originalPath), initial.images.map(image => image.originalPath));
    assert.equal(revised.images[1].width, 95);
    assert.deepEqual(await readFile(join(folder, revised.images[1].originalPath)), second);

    const changed = await figures.update("sample", initial.id, { kind: "raster", revision: revised.revision, annotations: [] });
    assert.deepEqual(changed.images, revised.images);
    assert.deepEqual(changed.annotations, []);
    await assert.rejects(figures.update("sample", initial.id, {
        kind: "raster", revision: changed.revision, annotations: [],
        composition: {
            width: 240, height: 100, images,
            uploads: [{ id, mime: "image/jpeg", base64: first.toString("base64") }],
        },
    }), { status: 400 });
    await assert.rejects(figures.update("sample", initial.id, {
        kind: "raster", revision: changed.revision, annotations: [{ ...annotations[0], color: "url(https://example.test)" }],
    }), { status: 400 });
    assert.deepEqual((await figures.get("sample", initial.id)).images, changed.images);
});

/** Copilot生成画像を、完成画像と切り離した編集用パーツとして保存する。 */
test("Copilot generated images are persisted as movable figure parts", async t => {
    const id = randomUUID();
    const generated = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10, 1, 2, 3]);
    const { folder, figures } = await fixture(t, {
        renderRaster: async ({ composition }) => ({ width: composition.width, height: composition.height,
            buffer: Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]) }),
    });
    const draft = { name: "生成イラスト", width: 100, height: 80, annotations: [],
        images: [{ id, sourceId: id, name: "イラスト", x: 5, y: 5, width: 90, height: 70 }],
        generatedMaterials: [{ id, name: "生成画像1", mime: "image/png", original: generated }] };
    const figure = await figures.create("sample", figureFromDraft(draft, []));
    assert.equal(figure.path, `assets/figures/${figure.id}/image.png`);
    assert.equal(figure.images[0].originalPath, `assets/parts/${figure.id}/layer-${id}.png`);
    assert.deepEqual(await readFile(join(folder, figure.images[0].originalPath)), generated);
    assert.equal(figure.images[0].name, "イラスト");
});

/** 描画画像の配置と注釈のスタイルが、ChromeのPNG合成へ反映されることを検証する。 */
test("Chrome composites positioned PNG layers and renders the selected annotation styles", {
    skip: process.env.MD_OPERATOR_TEST_CHROME !== "1",
}, async t => {
    const browser = await launchBrowser();
    t.after(() => browser.close());
    const page = await browser.newPage();
    const [first, second] = await page.evaluate(() => {
        const canvas = document.createElement("canvas");
        canvas.width = 20;
        canvas.height = 20;
        const canvas2d = canvas.getContext("2d");
        return ["#0000ff", "#ff0000"].map(color => {
            canvas2d.fillStyle = color;
            canvas2d.fillRect(0, 0, 20, 20);
            return canvas.toDataURL("image/png").split(",")[1];
        });
    });
    const { folder, figures } = await fixture(t);
    const extra = randomUUID();
    const figure = await figures.create("sample", {
        kind: "raster", name: "図版", mime: "image/png", base64: first,
        composition: {
            width: 120, height: 60,
            images: [
                { id: "original", x: 0, y: 0, width: 60, height: 60 },
                { id: extra, x: 40, y: 0, width: 80, height: 60 },
            ],
            uploads: [{ id: extra, mime: "image/png", base64: second }],
        },
        annotations: [
            { id: "box", type: "box", x: 15, y: 10, width: 30, height: 35, strokeWidth: 6, color: "#00ff00" },
            { id: "arrow", type: "arrow", x: 52, y: 38, dx: 42, dy: 0, strokeWidth: 8, color: "#ffff00" },
            { id: "label", type: "label", x: 80, y: 7, text: "H", fontSize: 20, fontWeight: "bold", color: "#ffffff" },
        ],
    });
    const base64 = (await readFile(join(folder, figure.path))).toString("base64");
    const pixels = await page.evaluate(async encoded => {
        const image = new Image();
        image.src = `data:image/png;base64,${encoded}`;
        await image.decode();
        const canvas = document.createElement("canvas");
        canvas.width = image.naturalWidth;
        canvas.height = image.naturalHeight;
        const canvas2d = canvas.getContext("2d");
        canvas2d.drawImage(image, 0, 0);
        const rgb = (x, y) => Array.from(canvas2d.getImageData(x, y, 1, 1).data.slice(0, 3));
        const label = canvas2d.getImageData(80, 8, 25, 22).data;
        let white = 0;
        for (let i = 0; i < label.length; i += 4) {
            if (label[i] === 255 && label[i + 1] === 255 && label[i + 2] === 255) white += 1;
        }
        return { dimensions: [canvas.width, canvas.height], sampled: [[5, 5], [52, 5], [17, 27], [19, 27], [70, 35]].map(([x, y]) => rgb(x, y)), white };
    }, base64);
    assert.deepEqual(pixels.dimensions, [120, 60]);
    assert.deepEqual(pixels.sampled, [[0, 0, 255], [255, 0, 0], [0, 255, 0], [0, 0, 255], [255, 255, 0]]);
    assert.ok(pixels.white > 20);
});
