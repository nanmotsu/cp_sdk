/**
 * @file Copilotの接続とモデル選択、本文の編集案、図版の作成を操作する画面。
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { api, errorMessage } from '../api';
import type { ConfigInfo, CopilotSession, CopilotTemplateList, FigureGenerationResult, FigureMaterialInput, GenerationResult, IntegrationStatus, SourceRequest } from '../api';
import { useJob } from '../useJob';
import { hasUnsavedChanges } from '../workspace';
import type { OpenFile } from '../workspace';
import { JobFeedback, Warnings } from './Feedback';
import FigureRequest from './FigureRequest';
import ProposedFigures from './ProposedFigures';
import SourcePicker from './SourcePicker';
import './assist-panel.css';

/** 現在の原本と、AI支援の結果を作業画面に反映するための操作。 */
interface Props {
  file: OpenFile;
  disabled: boolean;
  configVersion: number;
  onHistory: (id: string) => void;
  onFigureCreated: () => void;
  onOpenFigures: () => void;
}

/** 対象文書のAI支援の条件、ジョブ、プレビュー、採用を管理する。 */
export default function AssistPanel({ file, disabled, configVersion, onHistory, onFigureCreated, onOpenFigures }: Props) {
  const [workflow, setWorkflow] = useState<'document' | 'image'>('document');
  const [status, setStatus] = useState<IntegrationStatus | null>(null);
  const [statusError, setStatusError] = useState('');
  const [loadingStatus, setLoadingStatus] = useState(false);
  const [sessions, setSessions] = useState<CopilotSession[]>([]);
  const [sessionId, setSessionId] = useState('');
  const [modelId, setModelId] = useState('');
  const [sessionError, setSessionError] = useState('');
  const [loadingSessions, setLoadingSessions] = useState(false);
  const generationSession = useRef('');
  const figureSession = useRef('');
  const [sources, setSources] = useState<SourceRequest[]>([]);
  const [templateId, setTemplateId] = useState('');
  const [config, setConfig] = useState<ConfigInfo | null>(null);
  const [configLoading, setConfigLoading] = useState(true);
  const [configError, setConfigError] = useState('');
  const [templates, setTemplates] = useState<CopilotTemplateList | null>(null);
  const [templatesLoading, setTemplatesLoading] = useState(true);
  const [templatesError, setTemplatesError] = useState('');
  const [reloadTemplates, setReloadTemplates] = useState(0);
  const [reloadConfig, setReloadConfig] = useState(0);
  const [instruction, setInstruction] = useState('');
  const [figureEdits, setFigureEdits] = useState<Record<string, string>>({});
  const [applying, setApplying] = useState(false);
  const [applyError, setApplyError] = useState('');
  const [figureVersion, setFigureVersion] = useState<{ id: string; edits: Record<string, string> }>();
  const generation = useJob<GenerationResult>();
  const figureJob = useJob<FigureGenerationResult>();
  const copilotBusy = generation.busy || figureJob.busy;

  /** 現在の作業場所で再利用できるCopilotセッションを再取得する。 */
  async function loadSessions() {
    setLoadingSessions(true);
    setSessionError('');
    try {
      const result = await api.copilotSessions();
      setSessions(result.sessions);
    } catch (exception) {
      setSessionError(errorMessage(exception));
    } finally {
      setLoadingSessions(false);
    }
  }

  const rememberSession = useCallback((session: CopilotSession, requested: string) => {
    setSessions(current => [session, ...current.filter(item => item.id !== session.id)]);
    setSessionId(current => current === requested ? session.id : current);
  }, []);

  const usedSession = generation.job?.result?.session;
  useEffect(() => {
    if (usedSession) rememberSession(usedSession, generationSession.current);
  }, [usedSession, rememberSession]);

  const figureResult = figureJob.job?.status === 'succeeded' ? figureJob.job.result : undefined;
  useEffect(() => {
    if (!figureResult) return;
    if (figureResult.session) rememberSession(figureResult.session, figureSession.current);
    onFigureCreated();
  }, [figureResult, onFigureCreated, rememberSession]);

  /** 接続状態とモデルを更新し、接続できる場合はセッション一覧も読み込む。 */
  async function loadStatus() {
    setLoadingStatus(true);
    setStatusError('');
    try {
      const result = await api.integrationStatus();
      setStatus(result);
      if (result.copilot.available) void loadSessions();
    } catch (exception) {
      setStatusError(errorMessage(exception));
    } finally {
      setLoadingStatus(false);
    }
  }

  useEffect(() => { void loadStatus(); }, []);

  useEffect(() => {
    const controller = new AbortController();
    setConfigLoading(true);
    setConfigError('');
    api.config(file.documentId, controller.signal).then((result) => {
      if (!controller.signal.aborted) setConfig(result);
    }).catch((exception: unknown) => {
      if (!controller.signal.aborted) {
        setConfig(null);
        setConfigError(errorMessage(exception));
      }
    }).finally(() => {
      if (!controller.signal.aborted) setConfigLoading(false);
    });
    return () => controller.abort();
  }, [file.documentId, configVersion, reloadConfig]);

  useEffect(() => {
    const controller = new AbortController();
    setTemplatesLoading(true);
    setTemplatesError('');
    api.copilotTemplates(file.documentId, controller.signal).then((result) => {
      if (controller.signal.aborted) return;
      setTemplates(result);
      setTemplateId(current => result.templates.some(item => item.id === current) ? current : result.templates[0]?.id ?? '');
    }).catch((exception: unknown) => {
      if (!controller.signal.aborted) {
        setTemplates(null);
        setTemplateId('');
        setTemplatesError(errorMessage(exception));
      }
    }).finally(() => {
      if (!controller.signal.aborted) setTemplatesLoading(false);
    });
    return () => controller.abort();
  }, [file.documentId, configVersion, reloadTemplates]);

  const template = templates?.templates.find(entry => entry.id === templateId);
  const models = status?.copilot.models ?? [];
  const selectedModel = models.find(({ id }) => id === modelId);
  const modelUnavailable = Boolean(modelId && !selectedModel);
  const imageModelUnsupported = selectedModel?.supportsVision === false;
  const proposal = generation.job?.status === 'succeeded' ? generation.job.result : undefined;
  const syntaxErrors = proposal?.diagnostics?.some(({ severity }) => severity === 'error');
  const adjusted = Object.keys(figureEdits).length > 0 && figureVersion?.edits !== figureEdits;
  const instructionOptional = Boolean(template?.instructionOptionalWithSources && sources.length);
  const needsSave = hasUnsavedChanges(file);
  const ready = Boolean(status?.copilot.available && template && !modelUnavailable
    && (instruction.trim() || instructionOptional)
    && config?.config && !configLoading && !templatesLoading && !copilotBusy && !applying && !disabled && !needsSave);

  /** 素材と指示を、選択中のモデルとセッションで図版作成エージェントに渡す。 */
  async function composeFigure(images: FigureMaterialInput[], instruction: string) {
    figureSession.current = sessionId;
    await figureJob.start({
      type: 'compose-figure', documentId: file.documentId, images, instruction,
      sessionId: sessionId || undefined, modelId: modelId || undefined,
    });
  }

  /** 依頼時の本文を控え、条件と参照元をまとめて編集案ジョブを開始する。 */
  function generate(event: FormEvent) {
    event.preventDefault();
    if (!ready) return;
    generationSession.current = sessionId;
    setFigureEdits({});
    setFigureVersion(undefined);
    setApplyError('');
    void generation.start({ type: 'generate', documentId: file.documentId, path: file.path, revision: file.revision, templateId, instruction,
      sessionId: sessionId || undefined, modelId: modelId || undefined, sources });
  }

  /** 通常は生成された版を開き、図版を調整した場合はその状態を別の版として開く。 */
  async function compareProposal() {
    if (!proposal?.backup || applying || disabled) return;
    if (!adjusted) {
      onHistory(figureVersion?.id ?? proposal.backup.id);
      return;
    }
    setApplying(true);
    setApplyError('');
    try {
      const changes = Object.entries(figureEdits).map(([id, svg]) => ({ id, svg }));
      const { backup } = await api.saveBackupFigures(file.documentId, proposal.backup.id, changes);
      setFigureVersion({ id: backup.id, edits: figureEdits });
      onHistory(backup.id);
    } catch (exception) {
      setApplyError(errorMessage(exception));
    } finally {
      setApplying(false);
    }
  }

  return <div className="form-panel stack assist-panel">
    <div className="assist-workflow-switch" role="group" aria-label="AI支援で行う作業">
      <button type="button" id="assist-document-switch" aria-pressed={workflow === 'document'} aria-controls="assist-markdown"
        onClick={() => setWorkflow('document')}>本文を編集</button>
      <button type="button" id="assist-image-switch" aria-pressed={workflow === 'image'} aria-controls="assist-images"
        onClick={() => setWorkflow('image')}>図版を作る</button>
    </div>
    <section className="stack assist-connection" aria-labelledby="assist-connection-label">
      <div className="subsection-head">
        <h3 id="assist-connection-label">VS Codeとの接続</h3>
        <button type="button" disabled={loadingStatus} onClick={() => void loadStatus()}>接続を確認</button>
      </div>
      <p className={status?.copilot.available ? 'status-good' : 'muted'} role="status">
        {loadingStatus ? 'VS Code Agent Host を確認中…' : status?.copilot.message || '接続状態を確認してください'}
      </p>
      {statusError && <p className="error" role="alert">{statusError}</p>}
      {status?.workspace && <div className="stack">
        <span className="muted">VS Codeで開くフォルダ</span>
        <code className="workspace-path">{status.workspace}</code>
      </div>}
      <div className="stack">
        <label>Copilotのセッション<select aria-label="Copilotのセッション" value={sessionId} onChange={event => setSessionId(event.target.value)}
          disabled={!status?.copilot.available || copilotBusy || disabled}>
          <option value="">新しいセッション</option>
          {sessionId && !sessions.some(session => session.id === sessionId) && <option value={sessionId}>選択中のセッション</option>}
          {sessions.map(session => <option key={session.id} value={session.id}>{session.title}</option>)}
        </select></label>
        <div className="form-actions"><button type="button" disabled={!status?.copilot.available || loadingSessions || copilotBusy}
          onClick={() => void loadSessions()}>{loadingSessions ? '取得中…' : 'セッション一覧を更新'}</button></div>
        {sessionError && <p className="error" role="alert">{sessionError}</p>}
      </div>
      <label>Copilotのモデル<select value={modelId} onChange={event => setModelId(event.target.value)}
        disabled={!status?.copilot.available || loadingStatus || copilotBusy || disabled}>
        <option value="">VS Codeの設定に従う</option>
        {modelUnavailable && <option value={modelId} disabled>選択中のモデル（利用不可）</option>}
        {models.map(model => <option key={model.id} value={model.id}>
          {model.name}{workflow === 'image' && model.supportsVision === false ? '（画像入力非対応）' : ''}
        </option>)}
      </select></label>
      {modelUnavailable && <p className="muted assist-field-hint">利用できるモデルを選び直してください。</p>}
    </section>
    <section id="assist-markdown" className="stack" aria-labelledby="assist-document-switch" hidden={workflow !== 'document'}>
      {configLoading && <p className="muted" role="status">文書の設定を読み込んでいます…</p>}
      {!configLoading && config && !config.config && <p className="error" role="alert">設定タブで文書設定を確認してください。</p>}
      {configError && <div className="subsection-head">
        <p className="error" role="alert">{configError}</p>
        <button type="button" onClick={() => setReloadConfig((value) => value + 1)}>設定を再読み込み</button>
      </div>}
      <div className="stack assist-request" role="group" aria-label="今回の依頼条件">
        <form id="assist-generate-form" className="stack" onSubmit={generate}>
          <p className="muted assist-field-hint">添付する文書 <code>{file.path}</code></p>
          <label>依頼内容{instructionOptional ? '（任意）' : ''}
            <textarea name="instruction" value={instruction} rows={4} onChange={(event) => setInstruction(event.target.value)}
              placeholder="「保存手順」の最初の段落を短くして。"
              disabled={generation.busy || applying || disabled} />
          </label>
        </form>
        <SourcePicker sources={sources} onChange={setSources} disabled={generation.busy || applying || disabled} />
        <section className="stack">
          <div className="subsection-head assist-template-picker">
            <label>書き方のテンプレート<select name="templateId" value={templatesLoading ? '' : templateId}
              onChange={(event) => setTemplateId(event.target.value)}
              disabled={templatesLoading || !templates?.templates.length || generation.busy || applying || disabled}>
              {(templatesLoading || !templates?.templates.length) &&
                <option value="">{templatesLoading ? '読み込み中' : 'テンプレートなし'}</option>}
              {templates?.templates.map(item => <option key={item.id} value={item.id}>{item.label}</option>)}
            </select></label>
            <button type="button" disabled={templatesLoading || generation.busy || applying || disabled}
              onClick={() => setReloadTemplates(value => value + 1)}>テンプレートを再読み込み</button>
          </div>
          {template && <div className="assist-template-content" aria-label="選択中のテンプレートの内容">
            <p className="muted assist-field-hint">テンプレートの内容</p>
            <p className="assist-template-prompt">{template.prompt}</p>
          </div>}
          {templates && <p className="muted assist-field-hint">設定ファイル <code>{templates.path}</code></p>}
          {templatesError && <p className="error" role="alert">{templatesError}</p>}
          {templates && <Warnings warnings={templates.diagnostics} />}
        </section>
        <div className="stack assist-submit">
          <p className="muted assist-field-hint">上の条件を使って、この文書への編集案を作ります。反映前に差分を確認できます。</p>
          {needsSave && <p className="muted assist-field-hint" role="status">上部の「保存」を押してから編集案を作成してください。</p>}
          <div className="form-actions"><button className="primary" type="submit" form="assist-generate-form" disabled={!ready}>編集案を作成</button></div>
        </div>
      </div>
      <JobFeedback state={generation} />
      {proposal && <>
        <Warnings warnings={proposal.warnings} />
        {proposal.diagnostics && <section className="stack" aria-label="Markdownの文法チェック">
          <h4>Markdownの文法チェック</h4>
          {proposal.diagnostics.length > 0
            ? <ul className="warnings">
              {proposal.diagnostics.map((diagnostic, index) => (
                <li className={diagnostic.severity === 'error' ? 'error' : undefined} key={index}>
                  {diagnostic.line ? `${diagnostic.line}行目　` : ''}{diagnostic.message}
                </li>
              ))}
            </ul>
            : <p className="status-good">確認した範囲で構文エラーはありません。</p>}
          {syntaxErrors && <p className="error" role="alert">文法エラーがあるため、履歴に保存できませんでした。依頼内容を調整して作り直してください。</p>}
        </section>}
        {proposal.sources.length > 0 && <details open className="template-rules">
          <summary>編集案の出典</summary>
          <ul>{proposal.sources.map((source, index) => <li key={index}>
            <code>{source.path}</code>{source.sheet && ` · ${source.sheet}`}{source.range && ` · ${source.range}`}
          </li>)}</ul>
        </details>}
        {Boolean(proposal.backup && proposal.figures?.length) && <ProposedFigures key={generation.job!.id} figures={proposal.figures ?? []}
          values={figureEdits} disabled={disabled || applying}
          onEdit={(id, svg) => setFigureEdits((current) => ({ ...current, [id]: svg }))} />}
        {applyError && <p className="error" role="alert">{applyError}</p>}
        {proposal.backup && <section className="job-result stack" aria-label="Copilot編集案の結果">
            <p>Copilot編集案の版を履歴に保存しました。</p>
            <div className="form-actions"><button type="button" disabled={disabled || applying || generation.busy}
              onClick={() => void compareProposal()}>{applying ? '図版の調整を保存中…' : adjusted ? '図版の調整を保存して履歴で比較' : '履歴で比較'}</button></div>
          </section>}
      </>}
    </section>
    <section className="stack" id="assist-images" aria-labelledby="assist-image-switch" hidden={workflow !== 'image'}>
      {needsSave && <p className="muted">依頼する前に本文を保存してください。</p>}
      <FigureRequest disabled={disabled || applying} job={figureJob}
        canRequest={Boolean(status?.copilot.available) && !generation.busy && !modelUnavailable && !needsSave}
        imageModelUnsupported={imageModelUnsupported} onRequest={composeFigure} onOpenFigures={onOpenFigures} />
    </section>
  </div>;
}
