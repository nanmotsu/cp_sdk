/**
 * @file AI支援の文書操作をジョブとして実行し、編集案を履歴へ、図版を文書へ保存する。
 */

import { badRequest, conflict } from "../../common/api/errors.mjs";
import { requireConfig } from "../config/yaml.mjs";
import { readOriginal } from "../markdown/store.mjs";
import { textInput } from "../shared/input.mjs";
import { assertRevisionHistoryOption, readJobDocument } from "../shared/job-context.mjs";
import { prepareDocumentInput } from "./document-input.mjs";
import { figureMaterials, figureFromDraft } from "./figure-materials.mjs";
import { storeProposalFigures } from "./proposal-figures.mjs";
import { requireCopilotTemplate } from "./templates.mjs";

/** 原本のリビジョンを確認したうえで、依頼に添付するファイルを得る。 */
function documentInput(documents, id, original, expectedRestore, signal) {
    return documents.access(id, async folder => {
        signal.throwIfAborted();
        documents.checkRestoreVersion(id, expectedRestore);
        const current = await readOriginal(folder, original.path);
        if (current.revision !== original.revision) {
            throw conflict("依頼時から原本Markdownが更新されました。現在の文書でやり直してください。");
        }
        return prepareDocumentInput(folder, current, signal);
    });
}

/** 本文編集と図版作成を、文書の保存条件とジョブキューに接続する。 */
export function assistanceJobs(documents, figures, jobs, assistance) {
    /** 診断エラーがない編集案を、設定と原本の版を再照合して履歴に保存する。 */
    async function editDocument(input) {
        assertRevisionHistoryOption(input);
        if (Object.hasOwn(input, "selection")) {
            throw badRequest("編集したい箇所は依頼内容に記入してください。");
        }
        const { id, expectedRestore, folder, original } = await readJobDocument(documents, input);
        const configInfo = await documents.config(id);
        const config = requireConfig(configInfo);
        const template = requireCopilotTemplate(await documents.copilotTemplates(id), input.templateId);
        if (Object.hasOwn(input, "currentMarkdown")) {
            throw badRequest("currentMarkdown は復元用の項目です。本文編集の依頼では保存済みの原本を使います。");
        }
        return jobs.add(input.type, async ({ signal, onProgress }) => {
            const attachment = await documentInput(documents, id, original, expectedRestore, signal);
            const result = await assistance.generate({
                documentId: id, documentFolder: folder, markdownPath: original.path,
                template,
                instruction: input.instruction, sources: input.sources, documentInput: attachment, dsl: config.dsl,
                sessionId: input.sessionId, modelId: input.modelId, sessionTitle: `MD Operator · ${id}`, signal, onProgress,
            });
            if (result.diagnostics?.some(item => item.severity === "error")) return result;
            const warnings = [...(result.warnings ?? []), ...(result.diagnostics ?? []).map(item => item.message)];
            const backup = await documents.archiveProposal(id, original, expectedRestore, {
                reason: "copilot", warnings, signal, configRevision: configInfo.revision,
            }, tree => storeProposalFigures(tree, result, signal));
            return { ...result, backup };
        });
    }

    /** 素材と図版案から、編集可能なレイヤーを文書の図版一覧へ登録する。 */
    async function composeFigure(input) {
        assertRevisionHistoryOption(input);
        const id = input.documentId;
        const expectedRestore = documents.restoreVersion(id);
        const folder = await documents.documentRoot(id);
        const instruction = textInput(input.instruction, "instruction", 32 * 1024).trim();
        if (!instruction) throw badRequest("図版の依頼内容を指定してください。");
        const images = figureMaterials(input.images);
        const { sessionId, modelId } = input;
        return jobs.add(input.type, async ({ signal, onProgress }) => {
            const draft = await assistance.composeFigure({
                documentId: id, documentFolder: folder, images, instruction,
                sessionId, modelId, sessionTitle: `MD Operator 図版 · ${id}`, signal, onProgress,
            });
            onProgress("編集可能な図版を登録しています。");
            return documents.access(id, async () => {
                signal.throwIfAborted();
                documents.checkRestoreVersion(id, expectedRestore);
                const { id: figureId, name, kind, path, revision } = await figures.create(id, figureFromDraft(draft, images), { signal });
                return { figure: { id: figureId, name, kind, path, revision }, ...(draft.session && { session: draft.session }) };
            });
        });
    }

    return { generate: editDocument, "compose-figure": composeFigure };
}
