/**
 * @file ループバック上の実サーバーとビルド済みGUIを使い、原本・設定・変換・AI支援の一連の操作を回帰検証する。
 */

import assert from "node:assert/strict";
import { once } from "node:events";
import { mkdir, mkdtemp, readFile, readdir, rename, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { basename, dirname, join, resolve } from "node:path";
import { test } from "node:test";
import { setTimeout as delay } from "node:timers/promises";
import { pathToFileURL } from "node:url";
import JSZip from "jszip";
import { createAppServer } from "../apps/server/src/index.mjs";
import { launchBrowser } from "../apps/server/src/documents/shared/browser.mjs";

const png = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/w8AAwMCAO+jBMcAAAAASUVORK5CYII=";
const useChrome = process.env.MD_OPERATOR_TEST_CHROME === "1";
const tempPrefix = "md-operator-test-";

/** トップの検索・作成と、未保存の本文を持つ編集画面からの戻りを確認する。 */
test("document library searches titles, creates cards and guards return", { skip: !useChrome, timeout: 25000 }, async t => {
    const { base, request } = await fixture(t);
    await request("/api/v1/documents", "POST", { name: "既存文書" }, 201);
    const browser = await launchBrowser();
    t.after(() => browser.close());
    const page = await browser.newPage();
    page.setDefaultTimeout(8000);
    await page.goto(base);
    await page.waitForSelector('main[aria-label="すべての文書"]');
    assert.equal(await page.$('.editor-panel'), null);
    assert.ok((await page.$eval('button[aria-label="既存文書を開く"]', button => button.textContent)).includes('最終更新日'));
    await page.type('.library-search input', '該当なし');
    await page.waitForSelector('button[aria-label="既存文書を開く"]', { hidden: true });
    assert.ok(await page.$('.library-grid > .new-document-slot:last-child'));
    await page.click('button[aria-label="新規文書を作成"]');
    await page.type('#new-document-name', '新しい文書');
    page.once('dialog', dialog => void dialog.dismiss());
    await page.click('.new-document-actions button[type="submit"]');
    assert.equal(await page.$('button[aria-label="新しい文書を開く"]'), null);
    page.once('dialog', dialog => void dialog.accept());
    await page.click('.new-document-actions button[type="submit"]');
    await page.waitForSelector('button[aria-label="文書一覧に戻る"]');
    assert.ok(await page.$eval('.app-bar', header => {
        const back = header.querySelector('.back-button');
        const brand = header.querySelector('.branding');
        return header.firstElementChild === back && back.getBoundingClientRect().right < brand.getBoundingClientRect().left;
    }));
    assert.equal(await page.$eval('.header-location', element => element.textContent), '新しい文書 / index.md');
    assert.equal(await page.$eval('.document-tree', element => element.textContent.includes('既存文書')), false);
    await page.click('.segmented button::-p-text(ソース)');
    await page.type('textarea.source-editor', '未保存の追記');
    await page.waitForFunction(() => document.querySelector('.save-status')?.textContent === '未保存');
    page.once('dialog', dialog => void dialog.dismiss());
    await page.click('button[aria-label="文書一覧に戻る"]');
    assert.ok(await page.$('textarea.source-editor'));
    page.once('dialog', dialog => void dialog.accept());
    await page.click('button[aria-label="文書一覧に戻る"]');
    await page.waitForSelector('main[aria-label="すべての文書"]');
    assert.equal(await page.$('textarea.source-editor'), null);
    await page.click('button[aria-label="既存文書を開く"]');
    await page.waitForSelector('button[aria-label="文書一覧に戻る"]');
    assert.equal(await page.$eval('.header-location', element => element.textContent), '既存文書 / index.md');
    await page.click('button[aria-label="文書一覧に戻る"]');
    await page.waitForSelector('main[aria-label="すべての文書"]');
    await page.click('button[aria-label="新しい文書を開く"]');
    await page.waitForSelector('button[aria-label="文書一覧に戻る"]');
    await page.click('.segmented button::-p-text(ソース)');
    assert.equal(await page.$eval('textarea.source-editor', element => element.value), '# 新しい文書\n');
});

/** テスト専用の文書ルートとサーバーを作成し、終了時にその一時領域だけを片付ける。 */
async function fixture(t, options = {}) {
    const temp = resolve(tmpdir());
    const root = await mkdtemp(join(temp, tempPrefix));
    const server = await createAppServer({ documentsRoot: root, ...options });
    t.after(async () => {
        await new Promise(resolveClose => server.close(resolveClose));
        assert.equal(dirname(root), temp);
        assert.ok(basename(root).startsWith(tempPrefix));
        await rm(root, { recursive: true, force: true });
    });
    await writeFile(join(root, "config.yaml"), "toc: false\noutputDir: output\n");
    const listening = once(server, "listening");
    server.listen(0, "127.0.0.1");
    await listening;
    const base = `http://127.0.0.1:${server.address().port}`;

    /** 指定経路に要求を送り、期待したHTTP状態を確認してJSONを返す。 */
    async function request(path, method = "GET", data, status = 200) {
        const response = await fetch(`${base}${path}`, {
            method,
            ...(data !== undefined && { headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }),
        });
        const content = await response.json();
        assert.equal(response.status, status, JSON.stringify(content));
        return content;
    }

    /** ジョブを開始し、期限内に成功した結果を取得する。失敗・中断もテストの失敗にする。 */
    async function createJob(input) {
        const { job } = await request("/api/v1/jobs", "POST", input, 202);
        const url = `/api/v1/jobs/${job.id}`;
        const deadline = Date.now() + 30000;
        while (Date.now() < deadline) {
            const state = (await request(url)).job;
            if (state.status === "succeeded") return state.result;
            if (["failed", "canceled"].includes(state.status)) assert.fail(JSON.stringify(state));
            await delay(25);
        }
        assert.fail(`Job timed out: ${input.type}`);
    }

    return { root, base, request, createJob };
}

/** 一文書一原本、YAMLのファイル単位の選択、競合時の保存拒否を確認する。 */
test("document workspace keeps one source, resolves YAML by file and guards saves", async t => {
    const { root, base, request } = await fixture(t);
    const name = "利用者 テスト";
    const { document } = await request("/api/v1/documents", "POST", { name }, 201);
    const api = `/api/v1/documents/${encodeURIComponent(document.id)}`;
    const created = await request(`${api}/files?path=index.md`);
    assert.deepEqual(document.files, [{ path: "index.md" }]);
    assert.ok(!Number.isNaN(Date.parse(document.updatedAt)));
    assert.match(created.content, /利用者 テスト/);
    await request(`${api}/files`, "POST", { path: "extra.md", content: "# Extra" }, 409);
    await request(`${api}/import`, "POST", { files: [{ path: "external.md", content: "# External" }] }, 404);
    await request(`${api}/files?path=..%2Foutside.md`, "GET", undefined, 400);
    assert.deepEqual(await readdir(join(root, document.id)), ["index.md"]);

    const config = await request(`${api}/config`);
    assert.equal(config.source, "shared");
    assert.equal(config.config.toc, false);
    const local = await request(`${api}/config`, "PUT", { yaml: "margin:\n  left: 23mm\n" });
    assert.equal(local.source, "document");
    assert.equal(local.config.margin.left, "23mm");
    assert.equal(Object.hasOwn(local.config, "toc"), false);

    const uploaded = await request(`${api}/assets`, "POST", { name: "図版.png", base64: png }, 201);
    assert.match(uploaded.path, /^assets\/figures\/[a-f0-9-]+\/image\.png$/);
    await request(`${api}/figures`, "POST", {
        name: "空の図版", kind: "raster", composition: { width: 400, height: 300, images: [] },
    }, 400);
    assert.deepEqual((await request(`${api}/figures/${uploaded.figure.id}`)).figure, uploaded.figure);
    const partPath = uploaded.figure.originalPath;
    assert.equal(partPath, `assets/parts/${uploaded.figure.id}/original.png`);
    assert.deepEqual((await request(`${api}/parts`)).parts, [{
        id: "original", name: "図版.png", fileName: "original.png", figureId: uploaded.figure.id, figureName: "図版.png",
    }]);
    await request(`${api}/assets?path=${encodeURIComponent(partPath)}`, "GET", undefined, 404);
    const partUrl = `${api}/figures/${uploaded.figure.id}/parts/original`;
    const part = await fetch(base + partUrl);
    assert.equal(part.status, 200);
    assert.equal(part.headers.get("Content-Type"), "image/png");
    assert.deepEqual(Buffer.from(await part.arrayBuffer()), Buffer.from(png, "base64"));
    const invalidImages = [
        `![素材](${partPath})`,
        `<img src="${partUrl}" alt="素材API">`,
        `![埋め込み画像](data:image/png;base64,${png})`,
    ].join("\n\n");
    const blocked = await request(`${api}/preview`, "POST", { path: "index.md", content: invalidImages });
    assert.doesNotMatch(blocked.html, /<img[^>]+\bsrc=/);
    assert.equal(blocked.warnings.length, 3);
    assert.ok(blocked.warnings.every(warning => warning.includes("「図版」")));
    const content = `# 編集中\n\n![図版](${uploaded.path})\n\n<script>throw new Error("unsafe")</script>\n`;
    const preview = await request(`${api}/preview`, "POST", { path: "index.md", content });
    assert.match(preview.html, /目次/);
    assert.match(preview.html, /編集中/);
    assert.match(preview.html, /\/api\/v1\/documents\/.*\/assets/);
    assert.doesNotMatch(preview.html, /<script>/);
    assert.deepEqual(preview.warnings, []);
    assert.equal((await request(`${api}/files?path=index.md`)).content, created.content);

    const saved = await request(`${api}/files`, "PUT", { path: "index.md", content, revision: created.revision });
    assert.notEqual(saved.revision, created.revision);
    const updated = (await request("/api/v1/documents")).documents.find(item => item.id === document.id);
    assert.ok(!Number.isNaN(Date.parse(updated.updatedAt)));
    await request(`${api}/files`, "PUT", { path: "index.md", content: "# 競合", revision: created.revision }, 409);
    assert.equal(await readFile(join(root, document.id, "index.md"), "utf8"), content);

    await writeFile(join(root, document.id, "config.yaml"), "margin: [invalid]");
    assert.ok((await request(`${api}/config`)).diagnostics.length);
    await request(`${api}/preview`, "POST", { path: "index.md", content }, 400);
    await writeFile(join(root, document.id, "extra.md"), "# Extra");
    const listed = await request("/api/v1/documents");
    assert.equal(listed.documents[0].files.length, 0);
    assert.ok(listed.documents[0].conflict);
    await request(`${api}/files?path=index.md`, "GET", undefined, 409);
});

/** 保存・比較・復元で、本文、設定、画像、出力、空フォルダをまとめて扱うことを確認する。 */
test("workspace backups compare and restore complete folders, retaining unsaved edits", async t => {
    const { root, request } = await fixture(t);
    const name = "folder-versions";
    const folder = join(root, name);
    const api = `/api/v1/documents/${name}`;
    const history = `${api}/backups`;
    await request("/api/v1/documents", "POST", { name }, 201);
    assert.deepEqual((await request(history)).backups, []);
    const original = await request(`${api}/files?path=index.md`);
    assert.deepEqual(await request(`${api}/files`, "PUT", original), original);
    await assert.rejects(readdir(join(folder, "backups")), { code: "ENOENT" });
    const shared = "title: 設定の初期版\ntocDepth: 2\n";
    await writeFile(join(root, "config.yaml"), shared);
    const asset = await request(`${api}/assets`, "POST", { name: "image.png", base64: png }, 201);
    await mkdir(join(folder, "notes", "empty"), { recursive: true });
    await mkdir(join(folder, "output"));
    await writeFile(join(folder, "output", "previous.pdf"), "output bytes");
    const first = await request(`${api}/files`, "PUT", { ...original, content: "# 1回目の保存\n\n共通の行\n" });
    assert.deepEqual(await Promise.all([
        request(`${api}/files`, "PUT", first),
        request(`${api}/files`, "PUT", first),
    ]), [first, first]);
    const { backups } = await request(history);
    assert.deepEqual(backups.map(item => item.reason), ["save", "initial"]);
    const archive = join(folder, "backups", backups[0].id);
    assert.equal(await readFile(join(archive, "document", first.path), "utf8"), first.content);
    assert.deepEqual(await readFile(join(archive, "document", asset.figure.originalPath)), Buffer.from(png, "base64"));
    assert.deepEqual(await readdir(join(archive, "document", "notes", "empty")), []);
    await request(`${api}/assets?path=backups/${backups[0].id}/document/${asset.path}`, "GET", undefined, 404);

    await writeFile(join(folder, asset.path), "changed image");
    await rm(join(folder, "output", "previous.pdf"));
    await writeFile(join(folder, "notes", "added.txt"), "added");
    await request(`${api}/config`, "PUT", { yaml: "tocDepth: 3\n" });
    const second = await request(`${api}/files`, "PUT", { ...first, content: "# 2回目の保存\n\n共通の行\n" });
    const comparison = `${history}/${backups[0].id}`;
    const detail = await request(comparison);
    assert.equal(detail.file.content, first.content);
    assert.equal(detail.current.content, second.content);
    assert.equal(detail.sharedConfigChanged, true);
    assert.deepEqual(Object.fromEntries(detail.files.map(file => [file.path, file.change])), {
        [asset.path]: "modified", "config.yaml": "added", "index.md": "modified",
        "notes/added.txt": "added", "output/previous.pdf": "removed",
    });
    await writeFile(join(folder, "later.txt"), "written after comparing");
    await request(`${comparison}/restore`, "POST", { currentRevision: detail.currentRevision }, 409);
    const newerShared = "title: Later shared config\n";
    await writeFile(join(root, "config.yaml"), newerShared);
    const { currentRevision } = await request(comparison);
    const working = "# 保存前の書きかけ\n";
    const { file } = await request(`${comparison}/restore`, "POST", {
        currentRevision, currentMarkdown: working, revision: second.revision,
    });
    assert.deepEqual(file, first);
    assert.equal(await readFile(join(folder, first.path), "utf8"), first.content);
    assert.equal(await readFile(join(folder, "config.yaml"), "utf8"), shared);
    assert.equal(await readFile(join(root, "config.yaml"), "utf8"), newerShared);
    assert.deepEqual(await readFile(join(folder, asset.path)), Buffer.from(png, "base64"));
    assert.equal(await readFile(join(folder, "output", "previous.pdf"), "utf8"), "output bytes");
    assert.deepEqual(await readdir(join(folder, "notes")), ["empty"]);
    assert.ok(!(await readdir(folder)).includes("later.txt"));
    const versions = (await request(history)).backups;
    assert.equal(versions.length, 4);
    assert.equal(versions[0].reason, "before-restore");
    const preserved = await request(`${history}/${versions[0].id}`);
    assert.equal(preserved.file.content, working);
    assert.equal(await readFile(join(folder, "backups", versions[0].id, "document", "later.txt"), "utf8"), "written after comparing");

    const removed = backups[1];
    assert.deepEqual(await request(`${history}/${removed.id}`, "DELETE"), { deletedId: removed.id });
    await assert.rejects(readdir(join(folder, "backups", removed.id)), { code: "ENOENT" });
    await request(`${history}/${removed.id}`, "GET", undefined, 404);
    await request(`${history}/${removed.id}`, "DELETE", undefined, 404);
    await request(`${history}/.restore`, "DELETE", undefined, 404);
    assert.deepEqual((await request(history)).backups, versions.filter(version => version.id !== removed.id));
    assert.deepEqual(await request(`${api}/files?path=index.md`), first);
});

/** 中断された復元を巻き戻し、原本がなくなった場合も保存済みの版から復元する。 */
test("workspace history recovers interrupted restores and restores a missing original", async t => {
    const { root, request } = await fixture(t);
    const name = "restore-original";
    const folder = join(root, name);
    const api = `/api/v1/documents/${name}`;
    await request("/api/v1/documents", "POST", { name }, 201);
    const original = await request(`${api}/files?path=index.md`);
    const saved = await request(`${api}/files`, "PUT", { ...original, content: "# 復元可能な本文\n" });
    const stage = join(folder, "backups", ".restore");
    await mkdir(join(stage, "previous"), { recursive: true });
    await mkdir(join(stage, "next"));
    await rename(join(folder, "index.md"), join(stage, "previous", "index.md"));
    await writeFile(join(folder, "index.md"), "# 途中の置き換え");
    await writeFile(join(stage, "phase"), "replace");
    assert.deepEqual(await request(`${api}/files?path=index.md`), saved);
    assert.ok(!(await readdir(join(folder, "backups"))).includes(".restore"));

    await rm(join(folder, "index.md"));
    assert.deepEqual((await request("/api/v1/documents")).documents[0].files, []);
    const { backups } = await request(`${api}/backups`);
    const url = `${api}/backups/${backups[0].id}`;
    const { current, currentRevision } = await request(url);
    assert.equal(current, null);
    const restored = await request(`${url}/restore`, "POST", { currentRevision });
    assert.deepEqual(restored.file, saved);
    assert.deepEqual(restored.document.files, [{ path: "index.md" }]);
    assert.equal((await request(`${api}/config`)).source, "shared");
    assert.equal((await request(`${api}/backups`)).backups[0].path, null);
});

/** テンプレートは文書別のファイル全体を優先し、表示と依頼時の両方でプロンプトを読み取る。 */
test("Copilot templates follow file precedence and expose prompts for preview", async t => {
    let prompt;
    const { root, request, createJob } = await fixture(t, { agent: { async complete(input) {
        prompt = input.prompt;
        return { text: "# Edited" };
    } } });
    await request("/api/v1/documents", "POST", { name: "review" }, 201);
    await request("/api/v1/documents", "POST", { name: "other" }, 201);
    const endpoint = "/api/v1/documents/review/copilot-templates";
    const localPath = join(root, "review", "copilot.yaml");
    assert.match((await request(endpoint)).diagnostics[0], /copilot\.yaml/);
    await writeFile(join(root, "copilot.yaml"), "templates:\n  - { id: shared-only, label: Shared, prompt: Shared prompt }\n");
    assert.deepEqual(await request(endpoint), {
        source: "shared", path: "documents/copilot.yaml", diagnostics: [],
        templates: [{ id: "shared-only", label: "Shared", prompt: "Shared prompt", instructionOptionalWithSources: false }],
    });
    await writeFile(localPath, "templates:\n  - { id: local-review, label: Local review, prompt: First prompt }\n");
    const options = await request(endpoint);
    assert.deepEqual(options, {
        source: "document", path: "copilot.yaml", diagnostics: [],
        templates: [{ id: "local-review", label: "Local review", prompt: "First prompt", instructionOptionalWithSources: false }],
    });
    assert.equal((await request("/api/v1/documents/other/copilot-templates")).templates[0].id, "shared-only");
    assert.equal((await request("/api/v1/documents/review/config")).source, "shared");
    await request(endpoint, "PUT", { prompt: "From GUI" }, 404);
    const job = { type: "generate", documentId: "review", templateId: "local-review", instruction: "Make a draft." };
    await request("/api/v1/jobs", "POST", { ...job, templateId: "shared-only" }, 400);
    await request("/api/v1/jobs", "POST", { ...job, selection: "Selected text" }, 400);
    await writeFile(localPath, "templates:\n  - { id: local-review, label: Local review, prompt: Updated local prompt }\n");
    assert.equal((await request(endpoint)).templates[0].prompt, "Updated local prompt");
    const draft = await createJob(job);
    assert.ok(draft.backup);
    assert.match(prompt, /Updated local prompt/);
    assert.doesNotMatch(prompt, /Shared prompt|First prompt/);
    await writeFile(localPath, "templates: []\n");
    assert.deepEqual(await request(endpoint), { source: "document", path: "copilot.yaml", templates: [], diagnostics: [] });
    await request("/api/v1/jobs", "POST", job, 400);
    await writeFile(localPath, "templates:\n  - { id: dup, label: A, prompt: One }\n  - { id: dup, label: B, prompt: Two }\n");
    assert.match((await request(endpoint)).diagnostics[0], /重複/);
    for (const contents of ["templates: [", "templates: [null]", "templates: [{id: 'oops', label: Work, prompt: false}]"]) {
        await writeFile(localPath, contents);
        const invalid = await request(endpoint);
        assert.equal(invalid.source, "document");
        assert.deepEqual(invalid.templates, []);
        assert.ok(invalid.diagnostics.length);
    }
    await request("/api/v1/jobs", "POST", job, 400);
});

/** 基本設定の変更有無で文書別設定の作成を切り替え、詳細設定を保持することを検証する。 */
test("basic settings keep advanced YAML and only create a local config when changed", async t => {
    const { root, request } = await fixture(t);
    const sharedPath = join(root, "config.yaml");
    const shared = [
        "# Shared layout notes", "toc: false", "margin: {left: 15mm}", "revisionHistory:",
        "  - version: '1.0'", "    description: Recorded revision",
        "revisionHistoryVisibility: {docx: false}", "headerFooter:", "  enabled: true",
        "  header:", '    left: "{{documentFolder}}"', "    right: ''", "    rightColor: '#990011' # Existing color",
        "  footer: {center: Footer}", "tocManual: |-", "  Line one.", "  Line two.", "",
    ].join("\r\n");
    await writeFile(sharedPath, shared);
    await request("/api/v1/documents", "POST", { name: "basic-settings" }, 201);
    const folder = join(root, "basic-settings");
    const configUrl = "/api/v1/documents/basic-settings/config";
    const original = await request(configUrl);
    const unchanged = await request(configUrl, "PATCH", { changes: { toc: false }, revision: original.revision });
    assert.equal(unchanged.source, "shared");
    assert.deepEqual(await readdir(folder), ["index.md"]);

    const changed = await request(configUrl, "PATCH", {
        changes: { title: "Form title", tocDepth: 2, revisionHistoryVisibility: { pdf: false }, headerFooter: { header: { right: "Review copy" } } },
        revision: original.revision,
    });
    assert.equal(changed.source, "document");
    assert.equal(changed.config.title, "Form title");
    assert.equal(changed.config.tocDepth, 2);
    assert.deepEqual(changed.config.revisionHistory, original.config.revisionHistory);
    assert.deepEqual(changed.config.revisionHistoryVisibility, { docx: false, pdf: false });
    assert.deepEqual(changed.config.margin, original.config.margin);
    assert.equal(changed.config.tocManual, original.config.tocManual);
    assert.deepEqual(changed.config.headerFooter, {
        enabled: true, header: { left: "{{documentFolder}}", right: "Review copy", rightColor: "#990011" }, footer: { center: "Footer" },
    });
    assert.match(changed.yaml, /# Shared layout notes\r\n/);
    assert.match(changed.yaml, /# Existing color\r\n/);
    assert.equal(await readFile(sharedPath, "utf8"), shared);

    const preview = await request("/api/v1/documents/basic-settings/preview", "POST", { path: "index.md", content: "# Original" });
    const header = /<header class="document-page-header".*?<\/header>/s.exec(preview.html)?.[0];
    assert.match(header, /basic-settings/);
    assert.match(header, /color:\s*#990011[^>]*>Review copy/);
    assert.match(preview.html, /Recorded revision/);

    await request(configUrl, "PATCH", { changes: { tocDepth: 4 }, revision: changed.revision }, 400);
    await request(configUrl, "PATCH", { changes: { margin: { left: "9mm" } }, revision: changed.revision }, 400);
    await request(configUrl, "PATCH", { changes: { title: "Stale" }, revision: original.revision }, 409);
    assert.equal((await request(configUrl)).revision, changed.revision);
});

/** API経由でWordを出力・取り込みしても原本が1件のまま扱われることを検証する。 */
test("Word export and import through API preserve the only original", async t => {
    const { root, base, request, createJob } = await fixture(t);
    const { document } = await request("/api/v1/documents", "POST", { name: "word" }, 201);
    const resource = "/api/v1/documents/word";
    const original = await request(`${resource}/files?path=index.md`);
    const input = { type: "docx", documentId: document.id, path: original.path };
    const asset = await request(`${resource}/assets`, "POST", { name: "image.png", base64: png }, 201);
    const content = `# 仕様書\n\n| ID | 名前 |\n| --- | --- |\n| 1 | 利用者 |\n\n![図版](${asset.path})\n`;
    const saved = await request(`${resource}/files`, "PUT", { path: original.path, content, revision: original.revision });
    await request("/api/v1/jobs", "POST", { ...input, revision: original.revision }, 409);
    const output = await createJob({ ...input, revision: saved.revision });
    assert.equal(output.path, "output/index.docx");
    const download = await fetch(`${base}${output.url}`);
    assert.equal(download.status, 200);
    assert.match(download.headers.get("content-disposition"), /^attachment/);
    const buffer = Buffer.from(await download.arrayBuffer());
    const archive = await JSZip.loadAsync(buffer);
    const documentXml = await archive.file("word/document.xml").async("string");
    assert.match(documentXml, /利用者/);
    const tableCaption = documentXml.match(/<w:p>(?:(?!<\/w:p>)[\s\S])*表1\.1 仕様書(?:(?!<\/w:p>)[\s\S])*<\/w:p>\s*<w:tbl>/)?.[0];
    assert.match(tableCaption, /<w:jc w:val="center"\s*\/>/);
    assert.ok(Object.values(archive.files).some(entry => entry.name.startsWith("word/media/") && !entry.dir));
    const draft = await createJob({ ...input, type: "docx-import", name: "仕様書.docx", base64: buffer.toString("base64"), revision: saved.revision });
    assert.equal(draft.path, "index.md");
    assert.equal(draft.revision, saved.revision);
    assert.match(draft.content, /利用者/);
    assert.match(draft.content, /assets\/figures\/[a-f0-9-]+\/image\.png/);
    const version = await request(`${resource}/backups/${draft.backup.id}`);
    assert.equal(version.backup.reason, "word");
    assert.equal(version.backup.label, "仕様書.docx");
    assert.equal(version.file.content, draft.content);
    const image = draft.content.match(/assets\/figures\/[a-f0-9-]+\/image\.png/)[0];
    assert.ok((await readFile(join(root, "word", "backups", draft.backup.id, "document", image))).length > 0);
    await assert.rejects(readFile(join(root, "word", image)), { code: "ENOENT" });
    assert.deepEqual((await readdir(join(root, "word"))).filter(file => file.endsWith(".md")), ["index.md"]);
    assert.equal((await request(`${resource}/files?path=index.md`)).content, content);
    await request(`${resource}/backups/${draft.backup.id}/restore`, "POST", { currentRevision: version.currentRevision });
    const imported = (await request(`${resource}/figures`)).figures.find(figure => figure.path === image);
    assert.match(imported.name, /Word画像/);
    const restored = (await request(`${resource}/figures/${imported.id}`)).figure;
    assert.equal(restored.images.length, 1);
    assert.equal(restored.images[0].originalPath, restored.originalPath);
    assert.equal(restored.originalPath, `assets/parts/${imported.id}/original.png`);
});

/** 本文と独立した履歴が表紙と目次の間に置かれ、出力設定で表示を調整できることを検証する。 */
test("YAML revision history appears between cover and TOC and is independent of the body", async t => {
    const { base, request, createJob } = await fixture(t);
    const { document } = await request("/api/v1/documents", "POST", { name: "history" }, 201);
    const resource = "/api/v1/documents/history";
    const original = await request(`${resource}/files?path=index.md`);
    const yaml = "title: 表紙タイトル\nrevisionHistory:\n  - version: '1.0'\n    date: '2026-11-21'\n    description: YAMLの改訂内容\n";
    const content = [
        "# 本文タイトル",
        "",
        "~~~markdown",
        ":::revision-history",
        "| A | B |",
        "| --- | --- |",
        "| 99 | コード例 |",
        ":::",
        "~~~",
        "",
        "{{ref:body-table}}",
        "",
        ":::table id=body-table",
        "本文の表",
        "",
        "| 項目 |",
        "| --- |",
        "| 試験 |",
        ":::",
        "",
    ].join("\r\n");
    await request(`${resource}/config`, "PUT", { yaml });
    const preview = text => request(`${resource}/preview`, "POST", { path: original.path, content: text });
    const result = await preview(content);
    const cover = result.html.indexOf('<header class="title-page">');
    const history = result.html.indexOf('<section class="revision-history">');
    const toc = result.html.indexOf('<nav class="toc">');
    assert.ok(cover >= 0 && cover < history && history < toc);
    assert.match(result.html.slice(cover, history), /表紙タイトル/);
    assert.match(result.html.slice(history, toc), /YAMLの改訂内容/);
    assert.doesNotMatch(result.html.slice(history, toc), /作成者|コード例/);
    assert.match(result.html, /<code class="language-markdown">:::revision-history[\s\S]+コード例/);
    assert.match(result.html, /表1\.1/);
    assert.deepEqual(result.warnings, []);
    const saved = await request(`${resource}/files`, "PUT", { path: original.path, content, revision: original.revision });
    const docx = await createJob({ documentId: document.id, path: original.path, revision: saved.revision, type: "docx" });
    const archive = await JSZip.loadAsync(await (await fetch(`${base}${docx.url}`)).arrayBuffer());
    const xml = await archive.file("word/document.xml").async("string");
    assert.match(xml, /改訂履歴[\s\S]+YAMLの改訂内容[\s\S]+本文タイトル/);

    await request(`${resource}/config`, "PUT", { yaml: `revisionHistoryVisibility: {preview: false}\n${yaml}` });
    const hidden = await preview(content);
    assert.doesNotMatch(hidden.html, /<section class="revision-history">|YAMLの改訂内容/);

    await request(`${resource}/config`, "PUT", { yaml: "{}\n" });
    const bodyOnly = await preview(content);
    assert.doesNotMatch(bodyOnly.html, /<section class="revision-history">/);
    assert.match(bodyOnly.html, /コード例/);
});

/** 実ブラウザーでMermaidと表題を描画し、共通の文書設定でPDFまで出力できることを検証する。 */
test("real Chrome preview and PDF share rendered Mermaid and document settings", { skip: !useChrome }, async t => {
    const { base, request, createJob } = await fixture(t);
    const { document } = await request("/api/v1/documents", "POST", { name: "pdf" }, 201);
    const resource = "/api/v1/documents/pdf";
    const original = await request(`${resource}/files?path=index.md`);
    const fixtureContent = await readFile(new URL("./fixtures/rendering.md", import.meta.url), "utf8");
    const landscapePng = "iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAEUlEQVR4nGP4r2GDFTFQTwIAw/wsYQe8wuUAAAAASUVORK5CYII=";
    const figure = await request(`${resource}/assets`, "POST", { name: "wide.png", base64: landscapePng }, 201);
    const image = `![横長の図](<${figure.path}>)`;
    const content = [
        fixtureContent, ":::figure id=untitled-before", image, ":::", "",
        "# 対象範囲", "", '<table style="width:45%"><tr><th>区分</th></tr><tr><td>対象</td></tr></table>', "",
        ":::figure id=untitled", image, ":::", "",
        ":::figure id=fitted width=320px height=40px", image, "", "横長の図版", ":::", "",
        "参照先は {{ref:fitted}}。", "",
    ].join("\n");
    const input = { documentId: document.id, path: original.path };
    const saved = await request(`${resource}/files`, "PUT", { path: original.path, content, revision: original.revision });
    const preview = await request(`${resource}/preview`, "POST", { path: original.path, content });
    assert.match(preview.html, /<svg\b/);
    assert.match(preview.html, /図1\.1/);
    assert.match(preview.html, /<caption class="table-caption">表1\.1 利用者の管理項目<\/caption>/);
    assert.match(preview.html, /<caption class="table-caption">表2\.1 対象範囲<\/caption>/);
    assert.match(preview.html, /<figcaption>図2\.2 横長の図版<\/figcaption>/);
    assert.match(preview.html, /参照先は 図2\.2。/);
    assert.doesNotMatch(preview.html, /class="toc"/);
    assert.deepEqual(preview.warnings, []);
    const browser = await launchBrowser();
    t.after(() => browser.close());
    const page = await browser.newPage();
    await page.goto(`${base}${resource}/files?path=index.md`);
    await page.setContent(preview.html, { waitUntil: "load" });
    assert.equal(await page.$("#untitled figcaption, #untitled-before figcaption"), null);
    for (const media of ["screen", "print"]) {
        await page.emulateMediaType(media);
        const gapBelowFigure = await page.$eval("#registration figcaption", caption => {
            const nextCaption = caption.closest("figure").nextElementSibling.querySelector("caption");
            return {
                topMargin: getComputedStyle(caption).marginTop,
                gap: nextCaption.getBoundingClientRect().top - caption.getBoundingClientRect().bottom,
            };
        });
        assert.equal(gapBelowFigure.topMargin, "0px", media);
        assert.ok(gapBelowFigure.gap >= 10, media);
        assert.deepEqual(await page.$eval("#fitted img", image => {
            const style = getComputedStyle(image);
            return [image.naturalWidth / image.naturalHeight, style.width, style.height, style.objectFit];
        }), [2, "320px", "40px", "contain"], media);
        const captionPositions = await page.$$eval("table > caption", captions => captions.map(caption => {
            const range = document.createRange();
            range.selectNodeContents(caption);
            const text = range.getBoundingClientRect();
            const row = caption.parentElement.rows[0].getBoundingClientRect();
            return {
                centerOffset: (text.left + text.right - row.left - row.right) / 2,
                isAbove: text.bottom <= row.top,
            };
        }));
        assert.equal(captionPositions.length, 2);
        for (const position of captionPositions) {
            assert.ok(position.isAbove, media);
            assert.ok(Math.abs(position.centerOffset) < 1, media);
        }
    }
    const pdf = await createJob({ ...input, type: "pdf", revision: saved.revision });
    const download = await fetch(`${base}${pdf.url}`);
    const buffer = Buffer.from(await download.arrayBuffer());
    assert.equal(buffer.subarray(0, 5).toString(), "%PDF-");
    assert.ok(buffer.length > 1000);
    assert.deepEqual(pdf.warnings, []);
    const docx = await createJob({ ...input, type: "docx", revision: saved.revision });
    const archive = await JSZip.loadAsync(await (await fetch(`${base}${docx.url}`)).arrayBuffer());
    const xml = await archive.file("word/document.xml").async("string");
    assert.match(xml, /図2\.2 横長の図版/);
    assert.match(xml, /<wp:extent cx="762000" cy="381000"/);
});

/** 文書のツリー、編集と差分採用、出力、図版調整を配信ビルドで操作する。Copilotはテスト用の応答を使う。 */
test("built GUI edits, exports, and reviews Word and generation results", { skip: !useChrome, timeout: 120000 }, async t => {
    const prompts = [];
    const sessionSelections = [];
    const modelSelections = [];
    const imageAttachments = [];
    const documentAttachments = [];
    const models = [
        { id: "text-test", name: "Text test model", supportsVision: false },
        { id: "vision-test", name: "Vision test model", supportsVision: true },
    ];
    const existingSession = { id: "ahp-session:/12345678-1234-1234-1234-123456789abc", title: "VS Codeの既存セッション" };
    const newSession = { id: "ahp-session:/87654321-4321-4321-4321-cba987654321", title: "MD Operator · 画面検証" };
    const agent = {
        /** GUIで選択できるテスト用の接続状態とモデル候補を返す。 */
        async status() { return { available: true, message: "接続済み", models }; },
        /** セッション切り替えを検証するための既存セッションを返す。 */
        async listSessions() { return [existingSession]; },
        /** 依頼内容に合わせて編集案・図版・注釈の応答を返し、送信条件を後続の検証用に控える。 */
        async complete({ prompt, sessionId, modelId, attachments, purpose }) {
            prompts.push(prompt);
            sessionSelections.push(sessionId);
            modelSelections.push(modelId);
            const session = sessionId === existingSession.id ? existingSession : newSession;
            if (prompt.includes("受付カードを囲って")) {
                assert.equal(purpose, "compose-figure");
                assert.ok(prompt.includes(JSON.stringify({ documentId: "画面検証" })));
                imageAttachments.push(...(attachments ?? []));
                return { session, text: JSON.stringify({ format: "md-operator-figure-v1", name: "受付の比較", width: 640, height: 460, images: [
                    { source: 2, x: 32, y: 24, width: 250, height: 170 },
                    { source: 1, x: 328, y: 24, width: 160, height: 160 },
                    { name: "確認マーク", svg: '<svg viewBox="0 0 50 50"><circle cx="25" cy="25" r="15" fill="green"/></svg>',
                        x: 380, y: 260, width: 50, height: 50 },
                ], annotations: [
                    { type: "box", x: 60, y: 51, width: 150, height: 80 },
                    { type: "arrow", x: 150, y: 220, dx: 100, dy: 45 },
                    { type: "label", x: 170, y: 150, text: "受付" },
                ] }) };
            }
            assert.equal(purpose, "edit-document");
            assert.ok(prompt.includes(JSON.stringify({ documentId: "画面検証", markdownPath: "index.md" })));
            documentAttachments.push(attachments ?? []);
            if (prompt.includes("ここに図版を追加")) {
                return { session, text: [
                    "# 受付", "", "図版の直前", "", "```md-operator-figure 受付の流れ",
                    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 200"><g id="card" aria-label="カード"><rect x="25" y="25" width="110" height="55" fill="green"/></g></svg>',
                    "```", "", "図版の直後", "", "```mermaid", "flowchart LR", "    A --> B", "```",
                ].join("\n") };
            }
            if (prompt.includes("不正文法テスト")) return { session, text: "# 生成した仕様書\n\n:::unknown\nテスト\n:::\n" };
            return { session, text: "# 生成した仕様書\n" };
        },
    };
    const { root, base, request } = await fixture(t, { agent });
    await writeFile(join(root, "copilot.yaml"), "templates:\n  - { id: shared-only, label: Shared writing template, prompt: Shared only text }\n");
    const browser = await launchBrowser();
    t.after(() => browser.close());
    const page = await browser.newPage();
    await page.setViewport({ width: 1903, height: 914 });
    page.setDefaultTimeout(8000);
    const pageErrors = [];
    const previewRequests = [];
    const visualRequests = [];
    const pdfRequests = [];
    page.on("pageerror", error => pageErrors.push(error.message));
    page.on("request", incoming => {
        if (incoming.method() !== "POST") return;
        const pathname = new URL(incoming.url()).pathname;
        if (pathname.endsWith("/preview")) {
            previewRequests.push(JSON.parse(incoming.postData()).content);
        } else if (pathname.endsWith("/visual-elements")) {
            visualRequests.push(pathname);
        } else if (pathname.endsWith("/jobs")) {
            const payload = JSON.parse(incoming.postData());
            if (payload.type === "pdf") pdfRequests.push(payload);
        }
    });
    const open = await page.goto(base);
    assert.equal(open.status(), 200, "Build the production GUI before running Chrome tests");

    /** 表示され操作可能なボタンを、表示名またはアクセス可能な名前からクリックする。 */
    async function clickButton(label) {
        const button = await page.waitForFunction(text => Array.from(document.querySelectorAll("button"))
            .find(element => (element.textContent.trim() === text || element.getAttribute("aria-label") === text)
                && !element.disabled && element.offsetWidth > 0), {}, label);
        const element = button.asElement();
        await element.click();
        await button.dispose();
    }
    /** ブラウザー上の入力欄に値を設定し、Reactに入力イベントを届ける。 */
    async function edit(selector, text) {
        await page.waitForSelector(selector);
        await page.$eval(selector, (element, value) => {
            const prototype = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
            Object.getOwnPropertyDescriptor(prototype, "value").set.call(element, value);
            element.dispatchEvent(new Event("input", { bubbles: true }));
        }, text);
    }
    /** ブロックや選択セルの右クリックメニューを開く。 */
    async function openBlockMenu(anchor) {
        if (typeof anchor === "string") await page.click(anchor, { button: "right" });
        else await anchor.click({ button: "right" });
        await page.waitForSelector(".visual-context-menu", { visible: true });
    }
    /** 指定した階層のメニュー項目を押す。 */
    async function blockAction(label, menu = ".visual-context-menu") {
        const action = await page.waitForFunction((container, text) => [...document.querySelectorAll(`${container} [role="menuitem"]`)]
            .find(item => item.textContent.trim() === text && !item.disabled), {}, menu, label);
        await action.asElement().click();
        await action.dispose();
    }
    /** 共通の追加メニューを開き、横に表示される候補を選ぶ。 */
    async function insertBelow(anchor, label) {
        await openBlockMenu(anchor);
        await page.click('.visual-context-menu [aria-haspopup="menu"]');
        await blockAction(label, ".visual-add-menu");
    }
    /** ビジュアルの直前の操作を取り消す。 */
    async function undoVisual() {
        await page.keyboard.down("Control");
        await page.keyboard.press("z");
        await page.keyboard.up("Control");
    }

    const name = "画面検証";
    const resource = `/api/v1/documents/${encodeURIComponent(name)}`;
    const source = 'textarea[aria-label="Markdownソース"]';
    const diagram = "```mermaid\nflowchart LR\n    Open --> Edit\n```";
    const wrapped = ":::figure id=a-flow\n```mermaid\nflowchart TD\n    Start --> Finish\n```\n手順図\n:::";
    const outlineFixture = [
        "## 手順の詳細", "", "### 確認項目", "", "#### 深い見出し", "",
        "```text", "# フェンスの中", "```", "",
        ...Array.from({ length: 42 }, (_, index) => `手順の本文 ${index + 1}`), "", "最終章", "======", "",
    ].join("\n");
    const body = `# 編集テスト\n\n本文 **太字**\n\n:::warning\n  個別構文を保持\n:::\n\n${diagram}\n\n${wrapped}\n\n${outlineFixture}`;
    await page.waitForSelector('button[aria-label="新規文書を作成"]:enabled');
    await page.click('button[aria-label="新規文書を作成"]');
    await edit('#new-document-name', name);
    page.once('dialog', dialog => void dialog.dismiss());
    await clickButton("作成");
    assert.equal(await page.$(`button[aria-label="${name}を開く"]`), null);
    page.once('dialog', dialog => void dialog.accept());
    await clickButton("作成");
    const previewSelector = 'iframe[title="文書プレビュー"]';
    const initialFrame = await page.waitForSelector(previewSelector);
    const initialPreview = await initialFrame.contentFrame();
    await initialPreview.waitForFunction(() => document.body.textContent.includes("画面検証"));
    assert.equal(previewRequests.length, 1);
    const inspector = "#workspace-inspector";
    const wideInspectorWidth = await page.$eval(inspector, pane => pane.offsetWidth);
    const wideEditorWidth = await page.$eval(".editor-panel", pane => pane.offsetWidth);
    assert.ok(wideInspectorWidth >= 390 && wideInspectorWidth <= 425);
    assert.ok(wideEditorWidth > wideInspectorWidth * 2.8);
    await page.setViewport({ width: 1180, height: 920 });
    const initialInspectorWidth = await page.$eval(inspector, pane => pane.offsetWidth);
    const separator = await page.waitForSelector('[role="separator"][aria-controls="workspace-inspector"]');
    const grip = await separator.boundingBox();
    await page.mouse.move(grip.x + grip.width / 2, grip.y + grip.height / 2);
    await page.mouse.down();
    await page.mouse.move(grip.x + grip.width / 2 + 80, grip.y + grip.height / 2, { steps: 5 });
    await page.mouse.up();
    const smallerWidth = await page.$eval(inspector, pane => pane.offsetWidth);
    assert.ok(smallerWidth <= initialInspectorWidth - 75);
    await separator.focus();
    await page.keyboard.press("ArrowLeft");
    assert.ok(await page.$eval(inspector, pane => pane.offsetWidth) > smallerWidth);
    await clickButton("ソース");
    await edit(source, body);
    const headings = 'ul.heading-outline[aria-label="見出し一覧"] .tree-heading';
    await page.waitForFunction(selector => document.querySelectorAll(selector).length === 4, {}, headings);
    assert.deepEqual(await page.$$eval(headings, buttons => buttons.map(button => button.textContent)),
        ["編集テスト", "手順の詳細", "確認項目", "最終章"]);
    assert.equal(await page.$$eval(headings, buttons => buttons[2].closest("ul").parentElement.querySelector(":scope > .tree-heading").textContent), "手順の詳細");
    const branchToggle = 'button.tree-heading-toggle[aria-label="手順の詳細の子見出しを開閉"]';
    assert.ok(await page.$eval(branchToggle, button => button.getBoundingClientRect().right
        <= button.nextElementSibling.getBoundingClientRect().left));
    assert.equal(await page.$('button.tree-heading-toggle[aria-label="確認項目の子見出しを開閉"]'), null);
    await page.click(branchToggle);
    const visibleHeadings = () => page.$$eval(headings, buttons => buttons.filter(button => button.offsetWidth > 0).map(button => button.textContent));
    assert.deepEqual(await visibleHeadings(), ["編集テスト", "手順の詳細", "最終章"]);
    assert.equal(await page.$eval(branchToggle, button => button.getAttribute("aria-expanded")), "false");
    const outlineToggle = 'button.sidebar-collapse-button';
    assert.equal(await page.$eval(outlineToggle, button => button.getAttribute("aria-expanded")), "true");
    await page.click(outlineToggle);
    await page.waitForSelector(headings, { hidden: true });
    await page.waitForSelector('button.sidebar-reopen', { visible: true });
    assert.equal(await page.$eval(source, editor => editor.value), body);
    await page.click('button.sidebar-reopen');
    await page.waitForSelector(headings, { visible: true });
    assert.deepEqual(await visibleHeadings(), ["編集テスト", "手順の詳細", "最終章"]);
    await page.click(branchToggle);
    assert.equal(await page.$eval(branchToggle, button => button.getAttribute("aria-expanded")), "true");
    await clickButton("ビジュアル");
    await page.waitForSelector('[contenteditable="true"]');
    await clickButton("確認項目");
    await page.waitForFunction(() => document.activeElement?.querySelector("h3")?.textContent === "確認項目");
    await page.waitForFunction(() => [...document.querySelectorAll("img.visual-mermaid-image")]
        .filter(image => image.naturalWidth > 0).length === 2);
    await page.$$eval("details.visual-mermaid-source summary", summaries => {
        if (summaries.at(-1)?.textContent !== "ソースを編集") throw new Error("Mermaid source editor label was not updated");
        summaries.at(-1).click();
    });
    const inlineSource = 'details.visual-mermaid-source[open] textarea[aria-label="MermaidのMarkdownソース"]';
    const originalInline = await page.$eval(inlineSource, field => field.value);
    assert.match(originalInline, /^:::figure id=a-flow/);
    const originalImage = await page.$$eval("img.visual-mermaid-image", images => images.at(-1).src);
    const beforeInlineEdit = visualRequests.length;
    const updatedWrapped = wrapped.replace("Start --> Finish", "Start --> Updated");
    await edit(inlineSource, originalInline.replace("Start --> Finish", "Start --> Updated"));
    assert.equal(visualRequests.length, beforeInlineEdit);
    assert.equal(await page.$$eval("img.visual-mermaid-image", images => images.at(-1).src), originalImage);
    await clickButton("図を更新");
    await page.waitForFunction(original => {
        const image = [...document.querySelectorAll("img.visual-mermaid-image")].at(-1);
        return image?.naturalWidth > 0 && image.src !== original;
    }, {}, originalImage);
    assert.equal(visualRequests.length, beforeInlineEdit + 1);
    await clickButton("設定");
    await edit('input[name="title"]', "更新した表紙");
    await edit('input[name="subtitle"]', "設定の副題");
    await page.select('select[name="tocDepth"]', "1");
    await page.click('input[name="revisionHistoryVisibility.pdf"]');
    await page.click('input[name="headerFooter.enabled"]');
    await edit('input[name="headerFooter.header.right"]', "レビュー中");
    assert.equal(await page.$(".config-settings textarea"), null);
    assert.ok((await page.$eval(".config-yaml-help pre", node => node.textContent)).includes("cover:"));
    await clickButton("この文書の設定として保存");
    const cover = await page.waitForSelector('iframe[title="表紙"]');
    const coverFrame = await cover.contentFrame();
    await coverFrame.waitForFunction(() => document.querySelector(".doc-title")?.textContent === "更新した表紙"
        && document.querySelector(".doc-subtitle")?.textContent === "設定の副題");
    const basicSettings = (await request(`${resource}/config`)).config;
    assert.deepEqual(basicSettings.revisionHistoryVisibility, { pdf: false });
    assert.deepEqual(basicSettings.headerFooter.header, { right: "レビュー中", left: "{{documentFolder}}", rightColor: "#c00000" });
    await page.waitForFunction(selector => [...document.querySelectorAll(selector)].map(button => button.textContent).join("|") === "編集テスト|最終章", {}, headings);
    await clickButton("プレビュー");
    assert.equal(previewRequests.length, 1);
    assert.equal(await initialPreview.$(".title-page"), null);
    await clickButton("ソース");
    assert.equal(await page.$eval(source, editor => editor.value), body.replace(wrapped, updatedWrapped));
    await clickButton("最終章");
    await page.waitForFunction(selector => {
        const editor = document.querySelector(selector);
        return editor === document.activeElement && editor.selectionStart === editor.value.indexOf("最終章") && editor.scrollTop > 100;
    }, {}, source);
    await clickButton("ビジュアル");
    await page.waitForFunction(() => [...document.querySelectorAll("img.visual-mermaid-image")]
        .filter(image => image.naturalWidth > 0).length === 2);
    const beforeVisualEdit = visualRequests.length;
    const paragraph = await page.waitForFunction(() => Array.from(document.querySelectorAll(".visual-block"))
        .find(element => element.textContent.includes("本文")));
    await paragraph.evaluate(element => {
        element.querySelector("p").append("を編集");
        element.dispatchEvent(new InputEvent("input", { bubbles: true }));
    });
    await paragraph.dispose();
    await page.waitForFunction(() => document.querySelector(".save-status")?.textContent === "未保存");
    assert.equal(visualRequests.length, beforeVisualEdit);
    await clickButton("ソース");
    const visualEdit = await page.$eval(source, editor => editor.value);
    assert.match(visualEdit, /本文 \*\*太字\*\*を編集/);
    assert.ok(visualEdit.includes(":::warning\n  個別構文を保持\n:::"));
    assert.ok(visualEdit.includes(diagram) && visualEdit.includes(updatedWrapped));
    await clickButton("ビジュアル");
    const editorBlocks = ".visual-editor [data-visual-block]";
    const originalBlockCount = await page.$$eval(editorBlocks, blocks => blocks.length);
    const toolbar = ".visual-toolbar";
    const textParagraph = ".visual-block p";
    const formats = [["太字", "b,strong"], ["斜体", "i,em"], ["取り消し線", "s,strike,del"]];
    assert.deepEqual(await page.$$eval(`${toolbar} button`, buttons => buttons.map(button => button.getAttribute("aria-label"))),
        ["ビジュアル編集を元に戻す", "ビジュアル編集をやり直す", "太字", "斜体", "取り消し線", "箇条書き", "番号付きリスト"]);
    await page.click(textParagraph);
    assert.ok(await page.$$eval(`${toolbar} button`, (buttons, labels) => labels.every(label =>
        buttons.some(button => button.getAttribute("aria-label") === label && button.disabled)), formats.map(([label]) => label)));
    await page.$eval(textParagraph, element => {
        const range = document.createRange();
        range.selectNodeContents(element);
        range.collapse(false);
        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);
    });
    await page.keyboard.down("Control");
    await page.keyboard.press("b");
    await page.keyboard.up("Control");
    await page.keyboard.type(" Plain");
    assert.equal(await page.$eval(textParagraph, element => element.lastChild.nodeValue.endsWith(" Plain")), true);
    await undoVisual();
    /** Reactが本文とカーソル位置の復元を終えるまで待つ。 */
    const waitForParagraphCaret = () => page.waitForFunction(paragraph => {
        const element = document.querySelector(paragraph);
        const selection = window.getSelection();
        const editor = element?.closest('[contenteditable="true"]');
        return element?.firstChild.nodeValue === "本文 " && document.activeElement === editor
            && selection?.isCollapsed && editor.contains(selection.anchorNode);
    }, {}, textParagraph);
    await waitForParagraphCaret();
    for (const [label, selector] of formats) {
        await page.keyboard.press("Home");
        await page.keyboard.down("Shift");
        await page.keyboard.press("ArrowRight");
        await page.keyboard.press("ArrowRight");
        await page.keyboard.up("Shift");
        await clickButton(label);
        await page.waitForFunction((paragraph, css) => document.querySelector(paragraph)?.firstChild.matches?.(css)
            && document.querySelector(paragraph)?.firstChild.textContent === "本文", {}, textParagraph, selector);
        await undoVisual();
        await waitForParagraphCaret();
    }
    await page.keyboard.down("Shift");
    await page.keyboard.press("F10");
    await page.keyboard.up("Shift");
    await page.waitForSelector(".visual-context-menu", { visible: true });
    assert.equal(await page.$eval(".visual-context-menu button", button => button.textContent), "見出しにする");
    assert.equal(await page.$(".visual-add-menu"), null);
    await page.keyboard.press("ArrowDown");
    await page.keyboard.press("ArrowRight");
    await page.waitForSelector(".visual-add-menu", { visible: true });
    assert.deepEqual(await page.$$eval('.visual-add-menu [role="menuitem"]', items => items.map(item => item.textContent)),
        ["空段落", "テーブルDSL", "Mermaid DSL", "図版"]);
    assert.equal(await page.evaluate(() => {
        const main = document.querySelector(".visual-context-menu").getBoundingClientRect();
        const child = document.querySelector(".visual-add-menu").getBoundingClientRect();
        return child.left >= main.right || child.right <= main.left;
    }), true);
    await page.keyboard.press("Escape");
    await page.waitForSelector(".visual-add-menu", { hidden: true });
    await page.keyboard.press("Escape");
    await page.waitForSelector(".visual-context-menu", { hidden: true });
    await waitForParagraphCaret();
    const lastBlock = `${editorBlocks}:last-child`;
    await insertBelow(lastBlock, "空段落");
    await page.waitForFunction(selector => document.activeElement === [...document.querySelectorAll(selector)].at(-1), {}, editorBlocks);
    await page.keyboard.type("Temporary paragraph");
    await page.waitForFunction(() => document.activeElement?.textContent === "Temporary paragraph");
    await page.evaluate(() => {
        const range = document.createRange();
        range.selectNodeContents(document.activeElement);
        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);
    });
    await page.keyboard.press("Backspace");
    await page.waitForFunction(() => !document.activeElement?.textContent.trim());
    await page.keyboard.press("Backspace");
    await page.waitForFunction((selector, size) => document.querySelectorAll(selector).length === size, {}, editorBlocks, originalBlockCount);
    await insertBelow(lastBlock, "空段落");
    await page.waitForFunction(selector => document.activeElement === [...document.querySelectorAll(selector)].at(-1), {}, editorBlocks);
    await page.keyboard.press("Delete");
    await page.waitForFunction((selector, size) => document.querySelectorAll(selector).length === size, {}, editorBlocks, originalBlockCount);
    await clickButton("ソース");
    assert.equal(await page.$eval(source, editor => editor.value), visualEdit);
    await clickButton("ビジュアル");
    const paragraphAnchor = await page.waitForFunction(() => [...document.querySelectorAll(".visual-block p")]
        .find(element => element.textContent === "本文 太字を編集"));
    await insertBelow(paragraphAnchor.asElement(), "空段落");
    await paragraphAnchor.dispose();
    await page.waitForFunction(() => document.activeElement?.classList.contains("visual-block") && !document.activeElement.textContent.trim());
    const neighbors = await page.evaluate(() => ({
        previous: document.activeElement?.previousElementSibling?.textContent.trim(),
        following: document.activeElement?.nextElementSibling?.classList.contains("visual-protected-block"),
    }));
    assert.deepEqual(neighbors, { previous: "本文 太字を編集", following: true });
    await page.keyboard.type("New middle paragraph");
    /** 確認のキャンセルと承認を実際に行い、対象の段落だけが変更されるか調べる。 */
    async function deleteMiddleParagraph(approve) {
        const target = await page.waitForFunction(() => [...document.querySelectorAll(".visual-block")]
            .find(block => block.textContent.trim() === "New middle paragraph"));
        await openBlockMenu(target.asElement());
        await target.dispose();
        const confirmed = new Promise((resolve, reject) => page.once("dialog", dialog => {
            const message = dialog.message();
            (approve ? dialog.accept() : dialog.dismiss()).then(() => resolve(message), reject);
        }));
        await blockAction("このブロックを削除");
        assert.match(await confirmed, /本文から削除しますか/);
        await page.waitForSelector(".visual-context-menu", { hidden: true });
        await page.waitForFunction(shouldExist => [...document.querySelectorAll(".visual-block")]
            .some(block => block.textContent.trim() === "New middle paragraph") === shouldExist, {}, !approve);
    }
    await deleteMiddleParagraph(false);
    await deleteMiddleParagraph(true);
    await page.waitForFunction(() => document.activeElement?.matches(".visual-dsl-content"));
    await undoVisual();
    await page.waitForFunction(() => [...document.querySelectorAll(".visual-block")]
        .some(block => block.textContent.trim() === "New middle paragraph"));
    await clickButton("ソース");
    assert.equal(await page.$eval(source, editor => editor.value), visualEdit.replace(
        "本文 **太字**を編集\n\n:::warning", "本文 **太字**を編集\n\nNew middle paragraph\n\n:::warning",
    ));
    const imagePath = join(root, "test.png");
    await writeFile(imagePath, Buffer.from(png, "base64"));
    await clickButton("ビジュアル");
    await openBlockMenu(".visual-block h1");
    await blockAction("見出しを降格");
    await page.waitForFunction(() => document.querySelector(".visual-block h2")?.textContent === "編集テスト");
    await openBlockMenu(".visual-block h2");
    await blockAction("見出しを昇格");
    await page.waitForSelector(".visual-block h1");
    await insertBelow(".visual-block h1", "テーブルDSL");
    await edit('form[aria-label="挿入する表"] input[name=columns]', "4");
    await clickButton("表を追加");
    await page.waitForFunction(() => document.querySelectorAll('[data-dsl-block="table"] th').length === 4);
    const blankCell = '[data-dsl-block="table"] table tbody td:nth-child(2)';
    assert.ok(await page.$eval(blankCell, cell => cell.offsetWidth >= 80 && cell.offsetHeight >= 40));
    await page.click(blankCell);
    assert.equal(await page.$(".visual-table-actions"), null);
    await page.keyboard.type("Editable cell");
    assert.equal(await page.$eval(blankCell, cell => cell.textContent), "Editable cell");
    const table = '[data-dsl-block="table"]';
    const secondRow = `${table} [data-table-row="2"][data-table-column="2"]`;
    await openBlockMenu(secondRow);
    assert.equal(await page.$eval(".visual-context-menu button", button => button.textContent), "この行の下に行を追加");
    await blockAction("この行の下に行を追加");
    await page.waitForSelector(`${table} [data-table-row="3"][data-table-column="2"]:focus`);
    await openBlockMenu(secondRow);
    await blockAction("この行を削除");
    await page.waitForFunction(selector => document.querySelectorAll(`${selector} tbody tr`).length === 2, {}, table);
    await openBlockMenu(secondRow);
    await blockAction("この列の右に列を追加");
    await page.waitForSelector(`${table} [data-table-row="2"][data-table-column="3"]:focus`);
    await openBlockMenu(`${table} [data-table-row="0"][data-table-column="3"]`);
    assert.equal(await page.$$eval(".visual-context-menu button", items => items.some(item => item.textContent === "この行を削除")), false);
    await blockAction("この列を削除");
    await page.waitForFunction(selector => document.querySelectorAll(`${selector} th`).length === 4, {}, table);
    await insertBelow(blankCell, "Mermaid DSL");
    await page.waitForSelector('details.visual-mermaid-source[open] textarea');
    const mermaidBlock = ".visual-mermaid:not([data-dsl-block])";
    await page.waitForSelector(`${mermaidBlock} img.visual-mermaid-image`);
    await openBlockMenu(`${mermaidBlock} img.visual-mermaid-image`);
    await page.keyboard.press("ArrowRight");
    const sizeFields = '.visual-size-fields';
    await page.waitForSelector(`${sizeFields} input[name=width]:focus`);
    assert.match(await page.$eval(`${sizeFields} label:has(input[name=height])`, label => label.textContent), /最大の高さ/);
    await edit(`${sizeFields} input[name=width]`, "12%");
    await page.keyboard.press("Escape");
    await page.waitForSelector(sizeFields, { hidden: true });
    await page.keyboard.press("ArrowRight");
    await page.waitForSelector(`${sizeFields} input[name=width]:focus`);
    assert.equal(await page.$eval(`${sizeFields} input[name=width]`, field => field.value), "");
    await page.keyboard.press("Escape");
    await page.keyboard.press("Escape");
    await page.waitForSelector(".visual-context-menu", { hidden: true });
    const registered = await request(`${resource}/assets`, "POST", { name: "test.png", base64: png }, 201);
    assert.equal(await page.$('.editor-panel input[type="file"]'), null);
    await insertBelow(".visual-block h1", "図版");
    await page.waitForSelector('button[data-panel="figures"][aria-pressed="true"]');
    await page.click(textParagraph);
    await clickButton("test.pngを本文に挿入");
    const figureBlock = '[data-dsl-block="figure"]:has(img[alt="test.png"])';
    await page.waitForFunction(selector => document.querySelector(`${selector} img`)?.naturalWidth > 0, {}, figureBlock);
    assert.equal(await page.$(".visual-size-options"), null);
    await openBlockMenu(`${figureBlock} img`);
    await page.click('.visual-context-menu [aria-label="サイズを調整"]');
    await page.waitForSelector(`${sizeFields} input[name=width]:focus`);
    assert.equal(await page.evaluate(() => {
        const main = document.querySelector(".visual-context-menu").getBoundingClientRect();
        const formPanel = document.querySelector('.visual-menu-surface[role="dialog"]').getBoundingClientRect();
        return formPanel.left >= main.right || formPanel.right <= main.left;
    }), true);
    await edit(`${sizeFields} input[name=width]`, "invalid");
    await clickButton("サイズを反映");
    await page.waitForSelector(`${sizeFields} [role=alert]`, { visible: true });
    await edit(`${sizeFields} input[name=width]`, "60%");
    await edit(`${sizeFields} input[name=height]`, "72px");
    await clickButton("サイズを反映");
    await page.waitForSelector(sizeFields, { hidden: true });
    await page.waitForFunction(selector => {
        const body = document.querySelector(`${selector} .visual-figure-body`);
        return body?.style.width === "60%" && body.style.getPropertyValue("--visual-figure-height") === "72px";
    }, {}, figureBlock);
    await page.waitForFunction(selector => document.querySelector(`${selector} figcaption`)?.textContent === "図1.1 test.png", {}, figureBlock);
    await openBlockMenu(`${figureBlock} img`);
    await page.click('.visual-context-menu [aria-label="図題を編集"]');
    const captionField = '.visual-caption-fields input[name="caption"]';
    assert.equal(await page.$eval(captionField, field => field.value), "test.png");
    await edit(captionField, "表示例 <入力> & 出力");
    await clickButton("図題を反映");
    await page.waitForFunction(selector => document.querySelector(`${selector} figcaption`)?.textContent === "図1.1 表示例 <入力> & 出力", {}, figureBlock);
    await openBlockMenu(`${figureBlock} img`);
    await page.click('.visual-context-menu [aria-label="図題を編集"]');
    await edit(captionField, "");
    await clickButton("図題を反映");
    await page.waitForFunction(selector => document.activeElement?.matches(selector)
        && !document.activeElement.querySelector("figcaption"), {}, figureBlock);
    await undoVisual();
    await page.waitForFunction(selector => document.querySelector(`${selector} figcaption`)?.textContent === "図1.1 表示例 <入力> & 出力", {}, figureBlock);
    await clickButton("ソース");
    await page.waitForFunction(selector => /assets\/figures\/[a-f0-9-]+\/image\.png/.test(document.querySelector(selector)?.value ?? ""), {}, source);
    const inserted = await page.$eval(source, editor => editor.value);
    assert.match(inserted, /^# 編集テスト/);
    assert.ok(inserted.includes(`:::figure width=60% height=72px\n![test.png](<${registered.path}>)\n\n表示例 &lt;入力&gt; &amp; 出力\n:::\n`));
    assert.ok(inserted.indexOf(registered.path) < inserted.indexOf("Editable cell"));
    assert.match(inserted, /\n:::table\n\| 見出し1/);
    assert.equal(inserted.match(/^```mermaid$/gm)?.length, 3);
    assert.match(inserted, /(?:\|\s*---\s*){4}\|/);
    assert.match(inserted, /\|\s*Editable cell\s*\|/);

    await clickButton("プレビュー");
    await page.waitForFunction(() => document.querySelector(".preview-panel [role=status]")?.textContent.includes("現在の編集内容"));
    assert.equal(await initialPreview.$("img"), null);
    assert.equal(previewRequests.length, 1);
    await clickButton("プレビューを更新");
    await page.waitForFunction(() => document.querySelector(".preview-panel [role=status]")?.textContent === "プレビュー表示中");
    const iframe = await page.waitForSelector(previewSelector);
    const preview = await iframe.contentFrame();
    await preview.waitForFunction(() => document.querySelector("img")?.naturalWidth === 1
        && document.querySelector(".doc-title")?.textContent === "更新した表紙");
    assert.deepEqual(await preview.$eval('figure img[alt="test.png"]', image =>
        [image.style.width, image.style.height, getComputedStyle(image).objectFit, image.closest("figure").querySelector("figcaption").textContent]),
    ["60%", "72px", "contain", "図1.1 表示例 <入力> & 出力"]);
    const pageHeader = await preview.$eval(".document-page-header", header => ({
        text: header.textContent,
        rightColor: getComputedStyle(header.querySelector("span:last-child")).color,
    }));
    assert.match(pageHeader.text, /画面検証.*レビュー中/s);
    assert.equal(pageHeader.rightColor, "rgb(192, 0, 0)");
    assert.equal(previewRequests.length, 2);
    assert.match(previewRequests[1], /assets\/figures\/[a-f0-9-]+\/image\.png/);
    await clickButton("保存");
    await page.waitForFunction(() => document.querySelector(".save-status")?.textContent === "保存済み");
    assert.match((await request(`${resource}/files?path=index.md`)).content, /assets\/figures\/[a-f0-9-]+\/image\.png/);

    await clickButton("出力・Word");
    assert.equal(await page.$('label:has(option[value="exclude"]) select'), null);
    await clickButton("保存してPDFを出力");
    await page.waitForSelector('.job-result a[href*="pdf"]');
    assert.equal(pdfRequests.length, 1);
    assert.equal(Object.hasOwn(pdfRequests[0], "includeRevisionHistory"), false);
    await clickButton("保存してWordを出力");
    await page.waitForSelector('.job-result a[href*="docx"]');
    const imported = await page.$('input[aria-label="Word文書"]');
    await imported.uploadFile(join(root, name, "output", "index.docx"));
    await page.waitForSelector('section[aria-label="Word取り込みの結果"]');
    const beforeWord = await request(`${resource}/files?path=index.md`);
    await clickButton("履歴で比較");
    await page.waitForSelector('.history-panel [aria-label="Markdownの差分"]');
    assert.equal(await page.$eval('button[data-panel="history"]', button => button.getAttribute("aria-pressed")), "true");
    assert.match(await page.$eval(".history-panel .diff", element => element.textContent), /Wordから取り込み/);
    assert.equal(await page.$(".history-panel .diff-same"), null);
    const modePicker = '.history-panel section[aria-label="本文の比較"] select';
    await page.select(modePicker, "full");
    await page.waitForSelector(".history-panel .diff-same");
    await page.select(modePicker, "original");
    await page.waitForSelector(".history-original");
    assert.equal((await request(`${resource}/files?path=index.md`)).revision, beforeWord.revision);
    page.once("dialog", dialog => dialog.accept());
    await clickButton("この版を復元");
    await page.waitForFunction(selector => document.querySelector(selector)?.value.includes("Wordから取り込み"), {}, source);
    const saved = await request(`${resource}/files?path=index.md`);
    assert.notEqual(saved.revision, beforeWord.revision);
    assert.deepEqual((await readdir(join(root, name))).filter(file => file.endsWith(".md")), ["index.md"]);

    const reference = join(root, "source.js");
    await writeFile(reference, "export const double = value => value * 2;\n");
    await clickButton("AIエージェント（GitHub Copilot）支援");
    await page.waitForSelector("#assist-markdown", { visible: true });
    assert.equal(await page.$eval("#assist-images", section => section.hidden), true);
    const sessionSelect = 'select[aria-label="Copilotのセッション"]';
    const modelSelect = 'label:has(> select option[value="vision-test"]) > select';
    await page.waitForFunction((selector, id) => Array.from(document.querySelector(selector)?.options ?? [])
        .some(option => option.value === id), {}, sessionSelect, existingSession.id);
    assert.equal(await page.$eval(sessionSelect, select => select.value), "");
    await page.waitForSelector(modelSelect);
    assert.equal(await page.$eval(modelSelect, select => select.value), "");
    await page.select(modelSelect, "text-test");
    assert.match((await request("/api/v1/sources/inspect", "POST", { path: "apps/server/src/common/api/errors.mjs" })).path,
        /apps[/\\]server[/\\]src[/\\]common[/\\]api[/\\]errors\.mjs$/);
    const runDraft = 'button[form="assist-generate-form"]';
    assert.ok(await page.$eval(".assist-request", request => {
        const run = request.querySelector('button[form="assist-generate-form"]');
        return ['#assist-generate-form', '[aria-label="参照元の登録"]', 'select[name="templateId"]']
            .every(selector => request.querySelector(selector).compareDocumentPosition(run) & Node.DOCUMENT_POSITION_FOLLOWING);
    }));
    const templateSelect = 'select[name="templateId"]';
    await page.waitForFunction(selector => document.querySelector(selector)?.value === "shared-only", {}, templateSelect);
    assert.equal(await page.$eval(templateSelect, select => select.options[0].label), "Shared writing template");
    assert.equal(await page.$("details.writing-guidance"), null);
    await writeFile(join(root, name, "copilot.yaml"), [
        "templates:",
        "  - { id: review-copy, label: Review copy, prompt: Internal copy instructions }",
        "  - id: project-reference",
        "    label: Project reference notes",
        "    prompt: Local prompt for naming functions",
        "    instructionOptionalWithSources: true",
        "",
    ].join("\n"));
    await clickButton("テンプレートを再読み込み");
    await page.waitForFunction(selector => document.querySelector(selector)?.value === "review-copy", {}, templateSelect);
    assert.deepEqual(await page.$eval(templateSelect, select => [...select.options].map(option => option.label)),
        ["Review copy", "Project reference notes"]);
    assert.equal(await page.$eval(".assist-template-prompt", element => element.textContent), "Internal copy instructions");

    await clickButton("ファイル・フォルダを選ぶ");
    await page.waitForSelector('dialog.source-browser[open] button[aria-label="apps を開く"]');
    await page.click('dialog.source-browser button[aria-label="apps を開く"]');
    await page.waitForSelector('dialog.source-browser button[aria-label="server を開く"]');
    await clickButton("このフォルダを選択");
    await page.waitForFunction(() => document.querySelector(".source-candidate code")?.textContent.endsWith("apps"));
    await clickButton("ファイル・フォルダを選ぶ");
    await page.waitForSelector('dialog.source-browser input[aria-label="開くフォルダのパス"]:not(:disabled)');
    await edit('input[aria-label="開くフォルダのパス"]', root);
    await clickButton("開く");
    await page.waitForSelector('dialog.source-browser button[aria-label="source.js を選択"]');
    await page.click('dialog.source-browser button[aria-label="source.js を選択"]');
    await page.waitForFunction(() => document.querySelector(".source-candidate code")?.textContent.endsWith("source.js"));
    await page.select(templateSelect, "project-reference");
    assert.equal(await page.$eval(".assist-template-prompt", element => element.textContent), "Local prompt for naming functions");
    assert.equal(await page.$eval(runDraft, button => button.disabled), true);
    await edit('.source-candidate textarea', "double は画面で利用する計算関数。");
    await clickButton("参照元に追加");
    assert.equal(await page.$eval(runDraft, button => button.disabled), false);
    const instruction = '#assist-markdown textarea[name="instruction"]';
    const proposal = 'section[aria-label="Copilot編集案の結果"]';
    const workingMarkdown = (await page.$eval(source, editor => editor.value)) + "\n本文の添付検証行\n";
    await edit(source, workingMarkdown);
    await edit(instruction, "対象機能の概要を書く。");
    assert.equal(await page.$eval(runDraft, button => button.disabled), true);
    await page.waitForFunction(() => document.querySelector(".assist-submit")?.textContent.includes("保存」を押してから"));
    await request("/api/v1/jobs", "POST", {
        type: "generate", documentId: name, path: saved.path, revision: saved.revision, templateId: "project-reference",
        instruction: "対象機能の概要を書く。", currentMarkdown: workingMarkdown,
    }, 400);
    assert.equal(prompts.length, 0);
    await clickButton("保存");
    await page.waitForFunction(() => document.querySelector(".save-status")?.textContent === "保存済み");
    const selected = "Wordから取り込み";
    await page.$eval(source, (editor, text) => {
        const start = editor.value.indexOf(text);
        editor.focus();
        editor.setSelectionRange(start, start + text.length);
        editor.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
    }, selected);
    assert.equal(await page.$$eval(".editor-panel button", buttons => buttons.some(button => button.textContent.includes("選択箇所をAI"))), false);
    await clickButton("編集案を作成");
    await page.waitForSelector(proposal);
    assert.doesNotMatch(prompts[0], /value \* 2/);
    assert.match(prompts[0], /Project reference notes/);
    assert.match(prompts[0], /Local prompt for naming functions/);
    assert.doesNotMatch(prompts[0], /Shared only text|Internal copy instructions/);
    assert.match(prompts[0], /資料の読み方[\s\S]*double は画面で利用する計算関数/);
    assert.match(prompts[0], /今回の編集依頼:[\s\S]*対象機能の概要を書く/);
    assert.ok(!prompts[0].includes(selected));
    assert.doesNotMatch(prompts[0], /currentMarkdown|本文の添付検証行/);
    assert.equal(documentAttachments[0].length, 2);
    const referenceAttachment = documentAttachments[0][1];
    assert.equal(referenceAttachment.kind, "file");
    assert.equal(referenceAttachment.uri, pathToFileURL(reference).href);
    assert.match(await readFile(new URL(referenceAttachment.uri), "utf8"), /value \* 2/);
    const [fileAttachment] = documentAttachments[0];
    assert.equal(fileAttachment.kind, "file");
    assert.equal(fileAttachment.label, "index.md");
    assert.equal(fileAttachment.uri, pathToFileURL(join(root, name, "index.md")).href);
    assert.equal(await readFile(new URL(fileAttachment.uri), "utf8"), workingMarkdown);
    assert.equal((await request(`${resource}/files?path=index.md`)).content, workingMarkdown);
    await clickButton("履歴で比較");
    await page.waitForSelector(".history-panel .diff");
    assert.match(await page.$eval(".history-panel .diff", element => element.textContent), /生成した仕様書/);
    await clickButton("AIエージェント（GitHub Copilot）支援");
    await page.waitForFunction((selector, id) => document.querySelector(selector)?.value === id, {}, sessionSelect, newSession.id);
    await page.select(sessionSelect, existingSession.id);

    await edit(instruction, "不正文法テスト");
    await clickButton("編集案を作成");
    await page.waitForFunction(() => document.querySelector('section[aria-label="Markdownの文法チェック"]')?.textContent.includes("3行目"));
    assert.equal(await page.$(proposal), null);
    assert.equal((await request(`${resource}/backups`)).backups.filter(version => version.reason === "copilot").length, 1);

    await edit(instruction, "ここに図版を追加して、手順はMermaidで追記して。");
    await clickButton("編集案を作成");
    assert.equal(await page.$eval(sessionSelect, select => select.value), existingSession.id);
    const generated = 'img[alt="提案図版: 受付の流れ"]';
    const candidate = await page.waitForSelector(generated);
    assert.match(await page.$eval(generated, image => image.src), /^data:image\/svg\+xml[;,]/);
    const screenshotBase64 = Buffer.from(await candidate.screenshot({ type: "png" })).toString("base64");
    assert.equal((await request(`${resource}/figures`)).figures.some(figure => figure.kind === "svg"), false);
    await clickButton("図版を編集");
    const dialog = "dialog.figure-editor[open]";
    const shape = `${dialog} g#card rect`;
    await page.waitForSelector(shape, { visible: true });
    await page.click(shape);
    const xField = `${dialog} .figure-editor-coordinate label:first-child input`;
    await page.waitForSelector(xField);
    const originalX = await page.$eval(xField, element => element.valueAsNumber);
    await page.keyboard.press("ArrowRight");
    assert.equal(await page.$eval(xField, element => element.valueAsNumber), originalX + 1);
    await clickButton("元に戻す");
    assert.equal(await page.$eval(xField, element => element.valueAsNumber), originalX);
    const dragShape = await page.$(shape);
    const bounds = await dragShape.boundingBox();
    await page.mouse.move(bounds.x + bounds.width / 2, bounds.y + bounds.height / 2);
    await page.mouse.down();
    await page.mouse.move(bounds.x + bounds.width / 2 + 20, bounds.y + bounds.height / 2, { steps: 6 });
    await page.mouse.up();
    assert.ok(await page.$eval(xField, element => element.valueAsNumber) > originalX);
    await clickButton("編集案の図版に反映");
    await page.waitForSelector(dialog, { hidden: true });
    await clickButton("図版の調整を保存して履歴で比較");
    await page.waitForFunction(() => document.querySelector(".history-panel select")?.selectedOptions[0]?.textContent.includes("図版を調整"));
    assert.equal((await request(`${resource}/figures`)).figures.some(figure => figure.kind === "svg"), false);
    page.once("dialog", dialog => dialog.accept());
    await clickButton("この版を復元");
    await page.waitForFunction(selector => /assets\/figures\/[a-f0-9-]+\/image\.svg/.test(document.querySelector(selector)?.value ?? ""), {}, source);
    const vector = (await request(`${resource}/figures`)).figures.find(figure => figure.kind === "svg");
    const vectorDraft = (await request(`${resource}/figures/${vector.id}`)).figure;
    assert.match(vectorDraft.svg, /<g[^>]*id="card"[^>]*transform="translate\(/);
    const accepted = await page.$eval(source, field => field.value);
    assert.ok(accepted.indexOf("図版の直前") < accepted.indexOf(vector.path) && accepted.indexOf(vector.path) < accepted.indexOf("図版の直後"));
    assert.match(accepted, /```mermaid\nflowchart LR\n    A --> B\n```/);

    await clickButton("AIエージェント（GitHub Copilot）支援");
    await clickButton("図版を作る");
    assert.equal(await page.$eval("#assist-markdown", section => section.hidden), true);
    const existing = await page.$('.local-image-picker input[type="file"]');
    await existing.uploadFile(imagePath);
    await page.waitForSelector('#assist-images img[alt="test.png"]');
    await page.evaluate(base64 => {
        const clipboardData = new DataTransfer();
        const bytes = Uint8Array.from(atob(base64), character => character.charCodeAt(0));
        clipboardData.items.add(new File([bytes], "screen.png", { type: "image/png" }));
        document.querySelector('[aria-label="スクリーンショットを貼り付け"]').dispatchEvent(
            new ClipboardEvent("paste", { bubbles: true, cancelable: true, clipboardData }),
        );
    }, screenshotBase64);
    await page.waitForSelector('#assist-images img[alt="screen.png"]');
    await edit('#assist-images form textarea', "受付カードを囲って、矢印と文字を入れて。");
    assert.equal(await page.$eval('#assist-images button[type="submit"]', button => button.disabled), true);
    await page.select(modelSelect, "vision-test");
    await clickButton("図版作成を依頼");
    await page.waitForSelector('#assist-images [aria-label="図版作成の結果"]');
    assert.equal(await page.$eval(source, field => field.value), accepted);
    assert.equal(await page.$('#assist-images .figure-editor'), null);
    await clickButton("図版タブで確認");
    const raster = (await request(`${resource}/figures`)).figures.find(figure => figure.name === "受付の比較");
    const registeredFigure = (await request(`${resource}/figures/${raster.id}`)).figure;
    const firstScreenshot = registeredFigure.images.find(image => image.name === "screen.png");
    const originalPart = page.waitForResponse(response =>
        response.url().endsWith(`/figures/${raster.id}/parts/${firstScreenshot.id}`));
    await clickButton("受付の比較を編集");
    await page.waitForSelector(dialog, { visible: true });
    assert.equal((await originalPart).status(), 200);
    assert.equal(imageAttachments.length, 2);
    assert.equal(imageAttachments[0].kind, "image");
    assert.equal(imageAttachments[0].mime, "image/png");
    assert.deepEqual(Buffer.from(imageAttachments[0].bytes), Buffer.from(png, "base64"));
    assert.deepEqual(Buffer.from(imageAttachments[1].bytes), Buffer.from(screenshotBase64, "base64"));

    const annotationSelect = `${dialog} .figure-editor-properties select`;
    /** 対象の図版部品を選択欄から選ぶ。 */
    async function selectAnnotation(label) {
        const value = await page.$eval(annotationSelect, (select, text) => [...select.options]
            .find(option => option.label.startsWith(text))?.value, label);
        assert.ok(value, label);
        await page.select(annotationSelect, value);
    }
    const partsDialog = 'dialog.figure-parts-dialog[open]';
    /** 配置済みの画像を、そのサムネイルの選択ボタンから選ぶ。 */
    async function selectImage(label) {
        await clickButton("画像パーツを選ぶ");
        await page.waitForSelector(`${partsDialog} [aria-label="配置済みの画像"] .figure-part-card img`);
        await clickButton(`${label}を編集`);
        await page.waitForSelector(partsDialog, { hidden: true });
    }
    /** 実ブラウザーのポインターで部品のサイズ変更ハンドルを動かす。 */
    async function dragResize(type, dx, dy) {
        const handle = await page.waitForSelector(`${dialog} [data-figure-resize="${type}"]`, { visible: true });
        const rect = await handle.boundingBox();
        const x = rect.x + rect.width / 2;
        const y = rect.y + rect.height / 2;
        await page.mouse.move(x, y);
        await page.mouse.down();
        await page.mouse.move(x + dx, y + dy, { steps: 5 });
        await page.mouse.up();
    }
    await selectAnnotation("枠");
    const widthField = `${dialog} [aria-label="枠の大きさ"] input`;
    const originalWidth = await page.$eval(widthField, element => element.valueAsNumber);
    const originalHeight = await page.$$eval(widthField, elements => elements[1].valueAsNumber);
    await dragResize("box", 15, 10);
    assert.ok(await page.$eval(widthField, element => element.valueAsNumber) > originalWidth);
    await clickButton("元に戻す");
    assert.equal(await page.$eval(widthField, element => element.valueAsNumber), originalWidth);
    await dragResize("box", 15, 10);
    await edit(`${dialog} input[type=color]`, "#206a45");
    /** 数値欄を編集し、フォーカスを外して値を確定する。 */
    async function commitNumber(selector, number) {
        await page.$eval(selector, (field, value) => {
            field.focus();
            field.value = String(value);
            field.blur();
        }, number);
    }
    const strokeField = `${dialog} [aria-label="注釈の色と太さ"] input[type=number]`;
    await commitNumber(strokeField, 7);
    await selectAnnotation("矢印");
    await dragResize("arrow", 16, 8);
    await commitNumber(strokeField, 5);
    await selectAnnotation("受付");
    await commitNumber(strokeField, 30);
    await page.select(`${dialog} .figure-editor-properties label:has(option[value="bold"]) select`, "bold");
    const originalLayerWidth = `${dialog} [aria-label="画像の大きさ"] input[type=number]`;
    await selectImage("screen.png");
    const primaryWidth = await page.$eval(originalLayerWidth, field => field.valueAsNumber);
    await commitNumber(originalLayerWidth, primaryWidth * 0.8);
    await selectImage("確認マーク");
    const generatedPartX = `${dialog} .figure-editor-coordinate label:first-child input`;
    await commitNumber(generatedPartX, 402);
    await clickButton("奥へ");
    await clickButton("変更を保存");
    await page.waitForSelector(dialog, { hidden: true });
    const rasterDraft = (await request(`${resource}/figures/${raster.id}`)).figure;
    const box = rasterDraft.annotations.find(annotation => annotation.type === "box");
    const arrow = rasterDraft.annotations.find(annotation => annotation.type === "arrow");
    const label = rasterDraft.annotations.find(annotation => annotation.type === "label");
    assert.ok(box.width > originalWidth && box.height > originalHeight);
    assert.equal(box.color, "#206a45");
    assert.equal(box.strokeWidth, 7);
    assert.ok(arrow.dx > primaryWidth * 0.27 && arrow.dy > 0);
    assert.equal(arrow.strokeWidth, 5);
    assert.equal(label.text, "受付");
    assert.equal(label.fontSize, 30);
    assert.equal(label.fontWeight, "bold");
    assert.equal(rasterDraft.images.length, 3);
    assert.deepEqual(rasterDraft.images.map(image => image.name), ["screen.png", "確認マーク", "test.png"]);
    const screenshotLayer = rasterDraft.images.find(image => image.name === "screen.png");
    assert.ok(screenshotLayer.width < primaryWidth);
    const addedLayer = rasterDraft.images.find(image => image.name === "test.png");
    const generatedLayer = rasterDraft.images.find(image => image.name === "確認マーク");
    assert.match(generatedLayer.originalPath, /\/layer-[a-f0-9-]+\.svg$/);
    assert.equal(generatedLayer.x, 402);
    assert.match(await readFile(join(root, name, generatedLayer.originalPath), "utf8"), /<circle/);
    assert.deepEqual(await readFile(join(root, name, addedLayer.originalPath)), Buffer.from(png, "base64"));
    assert.deepEqual(await readFile(join(root, name, screenshotLayer.originalPath)), Buffer.from(screenshotBase64, "base64"));
    assert.notDeepEqual(await readFile(join(root, name, raster.path)), Buffer.from(screenshotBase64, "base64"));

    await clickButton("受付の比較を本文に挿入");
    await page.waitForFunction((selector, path) => document.querySelector(selector)?.value.includes(path), {}, source, raster.path);
    const linkedMarkdown = await page.$eval(source, field => field.value);
    await page.waitForSelector('section[aria-label="文書の図版"] .candidate');
    await page.click('button[aria-label="受付の比較を編集"]');
    await page.waitForSelector(`${dialog} image[data-figure-part="image:${screenshotLayer.id}"]`);
    const stored = (await request(`${resource}/parts`)).parts.find(part => part.name === "test.png" && part.figureId !== raster.id);
    assert.ok(stored, "the material from the other figure is reusable");
    await clickButton("画像パーツを選ぶ");
    const catalog = `${partsDialog} [aria-label="文書の画像パーツ"]`;
    await page.waitForFunction((selector, suffix) =>
        Array.from(document.querySelectorAll(`${selector} img`)).some(image =>
            image.getAttribute("src").endsWith(suffix) && image.naturalWidth > 0),
    {}, catalog, `/figures/${stored.figureId}/parts/${stored.id}`);
    await clickButton(`${stored.name}（${stored.figureName}）`);

    const externalImage = join(root, "external-part.png");
    await writeFile(externalImage, Buffer.from(png, "base64"));
    const [chooser] = await Promise.all([page.waitForFileChooser(), clickButton("外部画像を追加")]);
    await chooser.accept([externalImage]);
    await page.waitForSelector(`${partsDialog} [aria-label="外部画像"] img`, { visible: true });
    await clickButton("選択した画像を配置");
    await page.waitForSelector(partsDialog, { hidden: true });
    assert.equal(await page.$$eval(`${dialog} image[data-figure-part]`, images => images.length), 5);
    await clickButton("変更を保存");
    await page.waitForSelector(dialog, { hidden: true });
    const expanded = (await request(`${resource}/figures/${raster.id}`)).figure;
    assert.deepEqual(expanded.images.slice(-2).map(image => image.name), ["test.png", "external-part.png"]);
    assert.equal(expanded.path, raster.path);
    assert.deepEqual(await readFile(join(root, name, expanded.images.at(-1).originalPath)), Buffer.from(png, "base64"));
    await clickButton(`${vector.name}を編集`);
    await page.waitForSelector(shape, { visible: true });
    await page.click(shape);
    await page.waitForSelector(xField);
    await page.$eval(xField, field => { field.focus(); field.value = "45"; field.blur(); });
    await clickButton("変更を保存");
    await page.waitForSelector(dialog, { hidden: true });
    const updated = (await request(`${resource}/figures/${vector.id}`)).figure;
    assert.equal(updated.path, vector.path);
    assert.notEqual(updated.revision, vector.revision);
    assert.equal(await page.$eval(source, field => field.value), linkedMarkdown);
    assert.deepEqual(sessionSelections, [undefined, existingSession.id, existingSession.id, existingSession.id]);
    assert.deepEqual(modelSelections, ["text-test", "text-test", "text-test", "vision-test"]);
    assert.equal(prompts.length, 4);

    const card = `button[aria-label="${name}を開く"]`;
    const savedBeforeClose = (await request(`${resource}/files?path=index.md`)).content;
    assert.notEqual(linkedMarkdown, savedBeforeClose);
    await page.waitForFunction(() => document.querySelector(".save-status")?.textContent === "未保存");
    await page.click(outlineToggle);
    await page.waitForSelector(headings, { hidden: true });

    /** 未保存確認を自動で承認またはキャンセルし、確認が表示されたことを検証する。 */
    async function closeWithConfirmation(accept) {
        let onDialog;
        const confirmation = new Promise((resolve, reject) => {
            onDialog = dialog => {
                const result = { type: dialog.type(), message: dialog.message() };
                (accept ? dialog.accept() : dialog.dismiss()).then(() => resolve(result), reject);
            };
            page.once("dialog", onDialog);
        });

        try {
            await page.click('button[aria-label="文書一覧に戻る"]');
            const result = await Promise.race([confirmation, delay(3000, null, { ref: false })]);
            assert.ok(result, "Closing a folder with unsaved changes must prompt for confirmation");
            assert.equal(result.type, "confirm");
            assert.match(result.message, /未保存/);
        } finally {
            page.off("dialog", onDialog);
        }
    }

    await closeWithConfirmation(false);
    await page.waitForSelector('button[aria-label="文書一覧に戻る"]', { visible: true });
    assert.equal(await page.$eval(source, field => field.value), linkedMarkdown);
    await page.waitForSelector('button.sidebar-reopen', { visible: true });

    await closeWithConfirmation(true);
    await page.waitForSelector(card, { visible: true });
    await edit('.library-search input', '一致しないタイトル');
    await page.waitForSelector(card, { hidden: true });
    await edit('.library-search input', name);
    await page.waitForSelector(card, { visible: true });
    assert.equal(await page.$(".file-tree"), null);
    assert.equal(await page.$(source), null);
    assert.equal(await page.$(previewSelector), null);
    assert.equal(await page.$eval(".header-location", element => element.textContent), "文書ワークスペース");
    assert.equal(await page.$(".editor-panel"), null);
    assert.equal(await page.$(inspector), null);

    await page.click(card);
    await page.waitForSelector('button[aria-label="文書一覧に戻る"]', { visible: true });
    await clickButton("ソース");
    await page.waitForFunction(() => document.querySelector(".save-status")?.textContent === "保存済み");
    assert.equal(await page.$eval(source, field => field.value), savedBeforeClose);
    await page.waitForSelector('button.sidebar-reopen', { visible: true });

    await page.click('button[aria-label="文書一覧に戻る"]');
    await page.waitForSelector(card, { visible: true, timeout: 3000 });
    assert.equal(await page.$(".file-tree"), null);
    assert.deepEqual(pageErrors, []);
});

/** 差分のある保存だけが履歴を作り、確認したバックアップを一件ずつ削除できることを検証する。 */
test("repeated save shortcuts skip clean Markdown and history deletes one version at a time", { skip: !useChrome, timeout: 25000 }, async t => {
    const { base, request } = await fixture(t);
    const id = "history-operations";
    const resource = `/api/v1/documents/${id}`;
    const history = `${resource}/backups`;
    await request("/api/v1/documents", "POST", { name: id }, 201);
    const original = await request(`${resource}/files?path=index.md`);
    const browser = await launchBrowser();
    t.after(() => browser.close());
    const page = await browser.newPage();
    await page.setViewport({ width: 1430, height: 950 });
    page.setDefaultTimeout(8000);
    const saves = [];
    page.on("request", incoming => {
        if (incoming.method() === "PUT" && incoming.url().endsWith(`${resource}/files`)) saves.push(incoming);
    });
    await page.goto(base);
    await page.click(`button[aria-label="${id}を開く"]`);
    const saveButton = ".save-button";
    /** 保存ショートカットを短い間隔で複数回送る。 */
    async function repeatSave() {
        await page.keyboard.down("Control");
        for (let count = 0; count < 4; count++) await page.keyboard.press("s");
        await page.keyboard.up("Control");
    }
    await page.waitForSelector(`${saveButton}:disabled`);
    await repeatSave();
    assert.deepEqual((await request(history)).backups, []);
    assert.equal(saves.length, 0);

    await page.click('.segmented button::-p-text(ソース)');
    const source = "textarea.source-editor";
    await page.waitForSelector(source);
    await page.$eval(source, field => { field.focus(); field.setSelectionRange(field.value.length, field.value.length); });
    await page.keyboard.type("A saved change");
    await page.waitForSelector(`${saveButton}:enabled`);
    await repeatSave();
    await page.waitForFunction(() => document.querySelector(".save-status")?.textContent === "保存済み");
    const saved = await request(`${resource}/files?path=index.md`);
    assert.notEqual(saved.content, original.content);
    await page.waitForSelector(`${saveButton}:disabled`);
    await repeatSave();
    const { backups } = await request(history);
    assert.deepEqual(backups.map(backup => backup.reason), ["save", "initial"]);
    assert.equal(saves.length, 1);

    await page.click('button[data-panel="history"]');
    const versions = ".history-panel select";
    const deleteButton = ".history-panel .history-delete";
    await page.waitForSelector(versions);
    await page.select(versions, backups[1].id);
    page.once("dialog", dialog => dialog.dismiss());
    await page.click(deleteButton);
    assert.deepEqual((await request(history)).backups, backups);

    page.once("dialog", dialog => dialog.accept());
    await page.click(deleteButton);
    await page.waitForFunction((selector, remaining) => {
        const select = document.querySelector(selector);
        return select?.options.length === 1 && select.value === remaining;
    }, {}, versions, backups[0].id);
    assert.deepEqual((await request(history)).backups, [backups[0]]);
    assert.deepEqual(await request(`${resource}/files?path=index.md`), saved);

    page.once("dialog", dialog => dialog.accept());
    await page.click(deleteButton);
    await page.waitForFunction(() => document.querySelector(".history-panel").textContent.includes("履歴はまだありません"));
    assert.deepEqual((await request(history)).backups, []);
    assert.equal(await page.$eval(source, field => field.value), saved.content);
});

/** 空のキャンバスから素材と図形を組み立て、本文に挿入してから再編集する。 */
test("the figure library creates editable figures from an empty canvas", { skip: !useChrome, timeout: 30000 }, async t => {
    const { root, base, request } = await fixture(t);
    const id = "manual-figures";
    const resource = `/api/v1/documents/${id}`;
    await request("/api/v1/documents", "POST", { name: id }, 201);
    const sourceImage = Buffer.from('<svg width="160" height="120" viewBox="0 0 160 120"><rect width="160" height="120" fill="#336699"/></svg>');
    const material = await request(`${resource}/assets`, "POST", { name: "素材.svg", base64: sourceImage.toString("base64") }, 201);
    await request(`${resource}/assets`, "POST", {
        name: "補足.svg", base64: Buffer.from(sourceImage.toString("utf8").replace("#336699", "#933d33")).toString("base64"),
    }, 201);
    const browser = await launchBrowser();
    t.after(() => browser.close());
    const page = await browser.newPage();
    await page.setViewport({ width: 1430, height: 950 });
    page.setDefaultTimeout(10000);
    await page.goto(base);
    await page.click(`button[aria-label="${id}を開く"]`);
    await page.waitForSelector('button[data-panel="figures"]:enabled');
    await page.click('button[data-panel="figures"]');

    const library = 'section[aria-label="文書の図版"]';
    const editor = 'dialog.figure-editor[open]';
    const parts = 'dialog.figure-parts-dialog[open]';
    const panelButton = (container, label) => `${container} button::-p-text(${label})`;
    const create = panelButton(library, "新規作成");
    const save = panelButton(editor, "図版を保存して本文に追加");
    const layers = `${editor} svg image[data-figure-part]`;
    /** サムネイルから指定の素材を選び、まとめてキャンバスに配置する。 */
    async function addMaterials(names) {
        await page.click(panelButton(editor, "画像パーツを選ぶ"));
        for (const name of names) {
            const card = `${parts} button[aria-label="${name}（${name}）"]`;
            await page.waitForSelector(`${card} img`, { visible: true });
            await page.click(card);
            assert.equal(await page.$eval(card, button => button.getAttribute("aria-pressed")), "true");
        }
        await page.click(panelButton(parts, "選択した画像を配置"));
        await page.waitForSelector(parts, { hidden: true });
        return page.waitForSelector(layers, { visible: true });
    }

    await page.waitForSelector(create);
    await page.click(create);
    await page.waitForSelector(`${editor}[aria-label="図版を作成"]`);
    assert.equal(await page.$eval(`${editor} .figure-editor-primary`, button => button.disabled), true);
    await page.type(`${editor} .figure-editor-name input`, "Shapes only");
    await page.click(panelButton(editor, "枠を追加"));
    await page.click(save);
    await page.waitForSelector(editor, { hidden: true });
    const shapes = (await request(`${resource}/figures`)).figures.find(figure => figure.name === "Shapes only");
    const shapeDetail = (await request(`${resource}/figures/${shapes.id}`)).figure;
    assert.equal(shapeDetail.annotations[0].type, "box");
    assert.deepEqual(shapeDetail.images, []);
    assert.equal(shapeDetail.originalPath, undefined);
    await assert.rejects(readFile(join(root, id, "assets", "parts", shapes.id, "original.png")), { code: "ENOENT" });

    await page.click(create);
    await page.type(`${editor} .figure-editor-name input`, "Manual arrangement");
    const selectedNames = ["素材.svg", "補足.svg"];
    await addMaterials(selectedNames);
    assert.equal(await page.$$eval(layers, images => images.length), 2);
    await page.click(panelButton(editor, "元に戻す"));
    await page.waitForSelector(layers, { hidden: true });
    const layer = await addMaterials(selectedNames);
    const beforeOthers = await page.$$eval(layers, images => images.slice(1).map(image => ({
        x: Number(image.getAttribute("x")), y: Number(image.getAttribute("y")),
    })));
    const bounds = await layer.boundingBox();
    const startX = bounds.x + bounds.width / 2;
    const startY = bounds.y + bounds.height / 2;
    await page.mouse.move(startX, startY);
    await page.mouse.down();
    await page.mouse.move(startX + 30, startY + 16, { steps: 6 });
    await page.mouse.up();
    await page.waitForFunction(element => Number(element.getAttribute("x")) > 0 && Number(element.getAttribute("y")) > 0, {}, layer);
    await page.click(panelButton(editor, "矢印を追加"));
    await page.click(save);
    await page.waitForSelector(editor, { hidden: true });
    const manual = (await request(`${resource}/figures`)).figures.find(figure => figure.name === "Manual arrangement");
    const manualDetail = (await request(`${resource}/figures/${manual.id}`)).figure;
    assert.deepEqual(manualDetail.images.map(image => image.name), selectedNames);
    assert.ok(manualDetail.images[0].x > 0 && manualDetail.images[0].y > 0);
    assert.deepEqual(manualDetail.images.slice(1).map(({ x, y }) => ({ x, y })), beforeOthers);
    assert.equal(manualDetail.annotations[0].type, "arrow");
    assert.equal(manualDetail.originalPath, undefined);

    const editShapes = `${library} button[aria-label="Shapes onlyを編集"]`;
    await page.waitForSelector(editShapes);
    await page.click(editShapes);
    await page.waitForSelector(`${editor}[aria-label="図版の編集"]`);
    await addMaterials(["素材.svg"]);
    await page.click(panelButton(editor, "変更を保存"));
    await page.waitForSelector(editor, { hidden: true });
    const updated = (await request(`${resource}/figures/${shapes.id}`)).figure;
    assert.equal(updated.path, shapes.path);
    assert.equal(updated.annotations[0].type, "box");
    assert.equal(updated.images.length, 1);
    assert.notEqual(updated.images[0].originalPath, material.figure.originalPath);
    assert.match(await readFile(join(root, id, updated.images[0].originalPath), "utf8"), /<rect/);

    await page.click(panelButton(".segmented", "ソース"));
    const body = await page.$eval(".source-editor", textarea => textarea.value);
    assert.ok(body.includes(shapes.path) && body.includes(manual.path));
    assert.equal(await page.$('.editor-panel input[type="file"]'), null);
    await page.click('button[data-panel="preview"]');
    await page.click('button[data-panel="figures"]');
    await page.waitForSelector('button[data-panel="figures"][aria-pressed="true"]');
    const imageBeforeRename = await readFile(join(root, id, updated.path));
    await page.click(`${library} button[aria-label="Shapes onlyの名前を変更"]`);
    const nameInput = `${library} form[aria-label="図版の名前を変更"] input`;
    await page.click(nameInput, { clickCount: 3 });
    await page.type(nameInput, "Shape diagram");
    await page.click(panelButton(library, "名前を保存"));
    const insertedByNewName = `${library} button[aria-label="Shape diagramを本文に挿入"]`;
    await page.waitForSelector(insertedByNewName);
    assert.equal(await page.$eval(".source-editor", textarea => textarea.value), body);
    const renamed = (await request(`${resource}/figures/${shapes.id}`)).figure;
    assert.equal(renamed.name, "Shape diagram");
    assert.equal(renamed.path, updated.path);
    assert.notEqual(renamed.revision, updated.revision);
    assert.deepEqual(await readFile(join(root, id, renamed.path)), imageBeforeRename);
    await request(`${resource}/figures/${shapes.id}`, "PUT", { kind: "rename", revision: updated.revision, name: "Stale change" }, 409);
    await page.click(insertedByNewName);
    assert.ok((await page.$eval(".source-editor", textarea => textarea.value)).endsWith(`:::figure\n![Shape diagram](<${shapes.path}>)\n\nShape diagram\n:::\n`));
});

/** 見出し番号を一括操作し、ビジュアルで見える見出しをプレビューとWordに引き継ぐ。 */
test("document heading numbers are kept in preview and exports as edited in the GUI", { skip: !useChrome, timeout: 30000 }, async t => {
    const { base, request } = await fixture(t);
    const id = "heading-numbers";
    const resource = `/api/v1/documents/${id}`;
    await request("/api/v1/documents", "POST", { name: id }, 201);
    const original = await request(`${resource}/files?path=index.md`);
    const markdown = [
        "# 概要", "", "## 1.2.3 リリース履歴", "", "## **接続**", "", "## 8.4. 手書き見出し", "",
        "```text", "## 7.1. コード例", "```", "", "下線の見出し", "------------", "",
    ].join("\r\n");
    await request(`${resource}/files`, "PUT", { ...original, content: markdown });
    const browser = await launchBrowser();
    t.after(() => browser.close());
    const page = await browser.newPage();
    await page.setViewport({ width: 1430, height: 950 });
    page.setDefaultTimeout(8000);
    await page.goto(base);
    await page.click(`button[aria-label="${id}を開く"]`);

    /** 対象欄のうち表示中で有効になっているボタンを押す。 */
    async function clickButton(container, text) {
        const found = await page.waitForFunction((selector, label) => [...document.querySelectorAll(`${selector} button`)]
            .find(button => button.textContent.trim() === label && !button.disabled && button.offsetWidth), {}, container, text);
        await found.asElement().click();
        await found.dispose();
    }

    const heading = ".visual-editor h2:has(strong)";
    const actions = '.heading-number-actions';
    /** 現在の編集欄で、番号変更を一回の操作として取り消す。 */
    async function undo() {
        await page.keyboard.down("Control");
        await page.keyboard.press("z");
        await page.keyboard.up("Control");
    }

    await page.waitForSelector(heading, { visible: true });
    await clickButton(actions, "見出しに番号を付ける");
    await page.waitForFunction(selector => document.querySelector(selector)?.textContent === "1.2. 接続", {}, heading);
    assert.equal(await page.$eval(".visual-editor h1", element => element.textContent), "1. 概要");
    const version = await page.$$eval(".visual-editor h2", elements => elements.map(element => element.textContent));
    assert.ok(version.includes("1.2.3 リリース履歴") && version.includes("8.4. 手書き見出し"));
    await page.click(heading, { button: "right" });
    await clickButton(".visual-context-menu", "本文に戻す");
    await page.waitForFunction(() => {
        const editor = document.activeElement;
        const paragraph = editor?.matches('.visual-block[contenteditable="true"]') ? editor.querySelector("p") : null;
        return paragraph?.textContent === "1.2. 接続" && paragraph.querySelector("strong")?.textContent === "接続";
    });
    await undo();
    await page.waitForFunction(selector => document.querySelector(selector)?.textContent === "1.2. 接続", {}, heading);
    await page.click(".visual-editor h1", { button: "right" });
    await clickButton(".visual-context-menu", "本文に戻す");
    await page.waitForFunction(() => document.activeElement?.matches('.visual-block[contenteditable="true"]')
        && document.activeElement.querySelector("p")?.textContent === "1. 概要");
    await undo();
    await page.waitForFunction(() => document.activeElement?.matches('.visual-block[contenteditable="true"]')
        && document.activeElement.querySelector("h1")?.textContent === "1. 概要");
    await undo();
    await page.waitForFunction(selector => document.querySelector(selector)?.textContent === "接続", {}, heading);
    assert.equal(await page.$eval(".visual-editor h1", element => element.textContent), "概要");

    await clickButton(".segmented", "ソース");
    await clickButton(actions, "見出しに番号を付ける");
    const numbered = markdown.replace("# 概要", "# 1. 概要").replace("## **接続**", "## 1.2. **接続**").replaceAll("\r\n", "\n");
    const removed = markdown.replace("## 8.4. 手書き見出し", "## 手書き見出し").replaceAll("\r\n", "\n");
    const initial = markdown.replaceAll("\r\n", "\n");
    const waitForSource = expected => page.waitForFunction(value => document.querySelector(".source-editor")?.value === value, {}, expected);
    await waitForSource(numbered);
    await clickButton(actions, "見出しの番号を消す");
    await waitForSource(removed);
    await undo();
    await waitForSource(numbered);
    await undo();
    await waitForSource(initial);
    assert.equal(await page.$eval(".save-status", element => element.textContent), "保存済み");

    assert.equal((await request(`${resource}/files?path=index.md`)).content, markdown);
    await page.click('button[data-panel="preview"]');
    await clickButton(".preview-panel", "プレビューを更新");
    await page.waitForFunction(() => document.querySelector('iframe[title="文書プレビュー"]')?.srcdoc.includes('>概要</h1>'));
    await clickButton(".segmented", "ビジュアル");
    await clickButton(actions, "見出しに番号を付ける");
    await page.waitForFunction(() => document.querySelector(".visual-editor h1")?.textContent === "1. 概要");
    await clickButton(".preview-panel", "プレビューを更新");
    await page.waitForFunction(() => document.querySelector('iframe[title="文書プレビュー"]')?.srcdoc.includes('>1. 概要</h1>'));
    const preview = await (await page.waitForSelector('iframe[title="文書プレビュー"]')).contentFrame();
    const visibleHeadings = await page.$$eval(".visual-editor :is(h1,h2,h3)", headings => headings.map(item => item.textContent));
    assert.deepEqual(await preview.$$eval(':is(h1,h2,h3)[id^="toc-"]', headings => headings.map(item => item.textContent)), visibleHeadings);
    await page.click('button[data-panel="output"]');
    await clickButton(".side-content:not([hidden])", "保存してWordを出力");
    await page.waitForSelector('.side-content:not([hidden]) a[download]', { visible: true });
    const output = await page.$eval('.side-content:not([hidden]) a[download]', link => link.href);
    const docx = await JSZip.loadAsync(await (await fetch(output)).arrayBuffer());
    const xml = await docx.file("word/document.xml").async("string");
    assert.match(xml, />1\. 概要</);
    assert.match(xml, />1\.2\.3 リリース履歴</);
    assert.match(xml, />8\.4\. 手書き見出し</);
});

/** DSLの表とMermaidを編集し、構造とサイズの変更を原本単位で取り消せることを検証する。 */
test("visual tables and diagram layout keep their Markdown and support undo", { skip: !useChrome, timeout: 45000 }, async t => {
    const { base, request } = await fixture(t);
    const id = "visual-structures";
    const resource = `/api/v1/documents/${id}`;
    await request("/api/v1/documents", "POST", { name: id }, 201);
    const original = await request(`${resource}/files?path=index.md`);
    const markdown = [
        "# 見出し", "", ":::warning width=80%", "注意する内容", ":::", "",
        ":::table id=rows colRatio=2,1 fontSize=15px", "表の題", "", "| 名前 | 説明 |", "| :--- | ---: |",
        "| A \\| B | 1行目<br>2行目 |", "| 残す | **太字** |", ":::", "",
        "| 左 | 右 |", "| --- | --- |", "| 内容 | 値 |", "",
        ":::pagebreak", ":::", "",
        ":::figure id=diagram width=80% align=left", "```mermaid", "flowchart TD", "    A --> B --> C", "```",
        "流れの題", ":::", "", "```mermaid", "%%fontsize:18px%%", "flowchart LR", "    A --> B", "```", "",
    ].join("\r\n");
    await request(`${resource}/files`, "PUT", { ...original, content: markdown });
    const browser = await launchBrowser();
    t.after(() => browser.close());
    const page = await browser.newPage();
    await page.setViewport({ width: 1430, height: 950 });
    page.setDefaultTimeout(12000);
    const errors = [];
    page.on("pageerror", error => errors.push(error.message));
    await page.goto(base);
    await page.click(`button[aria-label="${id}を開く"]`);

    const dsl = '[data-dsl-block="table"]';
    const normal = '.visual-table-block:not([data-dsl-block])';
    const rows = `${dsl} tbody tr`;
    const data = (row, column) => `${dsl} [data-table-row="${row}"][data-table-column="${column}"]`;
    const button = async (container, label) => {
        const handle = await page.waitForFunction((selector, text) => [...document.querySelectorAll(`${selector} button`)]
            .find(item => item.textContent === text && !item.disabled && item.offsetWidth), {}, container, label);
        await handle.asElement().click();
        await handle.dispose();
    };
    /** 右クリックしたセルの行列メニューを実行する。 */
    const tableAction = async (cell, label) => {
        await page.click(cell, { button: "right" });
        await button(".visual-context-menu", label);
    };
    const counts = async (rowCount, columns) => page.waitForFunction(({ dsl, rows, rowCount, columns }) =>
        document.querySelectorAll(rows).length === rowCount && document.querySelectorAll(`${dsl} th`).length === columns,
    {}, { dsl, rows, rowCount, columns });
    const undo = async () => {
        await page.keyboard.down("Control");
        await page.keyboard.press("z");
        await page.keyboard.up("Control");
    };

    await counts(2, 2);
    await page.waitForFunction(dsl => document.querySelector(`${dsl} caption`)?.textContent.includes("表1.1"), {}, dsl);
    assert.match(await page.$eval(`${dsl} caption`, element => element.textContent), /表の題/);
    assert.equal(await page.$eval(data(1, 0), element => element.textContent), "A | B");
    assert.ok(await page.$(`${data(1, 1)} br`));
    assert.equal(await page.$eval(`${normal} td`, element => element.textContent), "内容");
    assert.equal(await page.$eval('[data-dsl-block="warning"] .visual-dsl-content', element => element.textContent.trim()), "注意する内容");
    assert.ok(await page.$('[data-dsl-block="pagebreak"] [role="separator"]'));

    await tableAction(`${normal} td`, "この列の右に列を追加");
    await page.waitForFunction(selector => document.querySelectorAll(`${selector} th`).length === 3, {}, normal);
    await page.waitForFunction(selector => document.activeElement?.matches(`${selector} td[data-table-column="1"]`), {}, normal);
    await undo();
    await page.waitForFunction(selector => document.querySelectorAll(`${selector} th`).length === 2, {}, normal);

    await tableAction(data(1, 0), "この行の下に行を追加");
    await counts(3, 2);
    await page.waitForFunction(selector => document.activeElement?.matches(selector), {}, data(2, 0));
    await page.keyboard.type("new | cell");
    assert.equal(await page.$eval(data(2, 0), element => element.textContent), "new | cell");
    assert.match(await page.$eval(`${dsl} textarea`, field => field.value), /\| new \\\| cell \|/);
    await undo();
    await page.waitForFunction(selector => document.querySelector(selector)?.textContent === "", {}, data(2, 0));
    await page.waitForFunction(selector => document.activeElement?.matches(selector), {}, data(2, 0));
    await undo();
    await counts(2, 2);
    await tableAction(data(1, 0), "この列の右に列を追加");
    await counts(2, 3);
    assert.equal(await page.$eval(`${dsl} [data-table-row="2"][data-table-column="2"] strong`, element => element.textContent), "太字");
    await tableAction(data(1, 0), "この列を削除");
    await counts(2, 2);
    await page.waitForFunction(selector => document.activeElement?.matches(selector), {}, data(1, 0));
    await undo();
    await counts(2, 3);
    await page.waitForFunction(selector => document.activeElement?.matches(selector), {}, data(1, 0));
    await undo();
    await counts(2, 2);
    await tableAction(data(1, 1), "この行を削除");
    await counts(1, 2);
    await page.waitForFunction(selector => document.activeElement?.matches(selector), {}, data(1, 1));
    await undo();
    await counts(2, 2);
    assert.ok(await page.$(`${data(1, 1)} br`));
    await page.click(`${dsl} details.visual-block-source summary`);
    assert.match(await page.$eval(`${dsl} textarea`, field => field.value), /:::table id=rows colRatio=2,1 fontSize=15px\n表の題\n\n\| 名前 \| 説明 \|\n\| :--- \| ---: \|\n\| A \\\| B \| 1行目<br>2行目 \|/);

    const wrapped = '[data-dsl-block="figure"]';
    const standalone = '.visual-mermaid:not([data-dsl-block])';
    /** 右クリックから図の寸法を入力する。 */
    const size = async (selector, width, height) => {
        await page.click(`${selector} img.visual-mermaid-image`, { button: "right" });
        const resize = '.visual-context-menu [aria-label="サイズを調整"]';
        await page.waitForSelector(resize, { visible: true });
        await page.click(resize);
        await page.waitForSelector('.visual-size-fields input[name="width"]:focus');
        for (const [name, value] of Object.entries({ width, height })) {
            const input = `.visual-size-fields input[name="${name}"]`;
            await page.$eval(input, field => { field.value = ""; });
            await page.type(input, value);
        }
        await button(".visual-size-fields", "サイズを反映");
    };
    await page.waitForSelector(`${wrapped} img.visual-mermaid-image`);
    await page.waitForSelector(`${standalone} img.visual-mermaid-image`);
    await size(wrapped, "56%", "85px");
    await page.waitForFunction(selector => document.querySelector(`${selector} .visual-figure-body`)?.style.width === "56%"
        && document.querySelector(`${selector} img`)?.style.maxHeight === "85px", {}, wrapped);
    assert.match(await page.$eval(`${wrapped} textarea`, field => field.value), /^:::figure id=diagram width=56% align=left height=85px/);
    await page.waitForFunction(selector => document.activeElement?.matches(selector), {}, wrapped);
    await undo();
    await page.waitForFunction(selector => document.querySelector(`${selector} .visual-figure-body`)?.style.width === "80%", {}, wrapped);
    await size(standalone, "70%", "110px");
    await page.waitForFunction(selector => document.querySelector(`${selector} img`)?.style.width === "70%"
        && document.querySelector(`${selector} img`)?.style.maxHeight === "110px", {}, standalone);
    await page.click(`${standalone} details.visual-block-source summary`);
    assert.match(await page.$eval(`${standalone} textarea`, element => element.value), /%%fontsize:18px%%\n%%width:70%%%\n%%height:110px%%\nflowchart/);
    await button(".app-actions", "保存");
    await page.waitForFunction(() => document.querySelector(".save-status")?.textContent === "保存済み");
    const saved = await request(`${resource}/files?path=index.md`);
    assert.equal(saved.content, markdown.replace("%%fontsize:18px%%\r\n", "%%fontsize:18px%%\r\n%%width:70%%%\r\n%%height:110px%%\r\n"));
    await button(".preview-panel", "プレビューを更新");
    await page.waitForFunction(() => document.querySelector('iframe[title="文書プレビュー"]')?.srcdoc.includes('--mermaid-height:110px'));
    const preview = await (await page.waitForSelector('iframe[title="文書プレビュー"]')).contentFrame();
    await preview.waitForSelector('.mermaid-block[style*="110px"] > svg');
    assert.equal(await preview.$eval('.mermaid-block[style*="110px"] > svg', element => getComputedStyle(element).maxHeight), "110px");
    assert.deepEqual(errors, []);
});
