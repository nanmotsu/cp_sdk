/**
 * @file 文書プレビューとビジュアル編集用の表示要素をHTTPで返す。
 */

import { badRequest } from "../../common/api/errors.mjs";
import { readJson, sendJson } from "../../common/api/http.mjs";
import { requireConfig } from "../config/yaml.mjs";
import { previewAssetLink } from "../figures/asset-links.mjs";
import { textInput } from "../shared/input.mjs";
import { renderPreview, renderVisualElements } from "./render.mjs";

/** 描画ルートを登録し、接続が切れたら実行中の描画を中断する。 */
export function previewRoutes(documents) {
    /** 対象文書、設定、画像URLを両方の描画でそろえる。 */
    function route(render, prepareInput) {
        return async (request, response, { id }) => {
            const input = await readJson(request);
            const renderInput = prepareInput(input);
            const folder = await documents.documentRoot(id);
            const sourcePath = await documents.sourcePath(id, input.path);
            const config = requireConfig(await documents.config(id));
            if (response.destroyed) return;
            const controller = new AbortController();
            const abort = () => controller.abort();
            response.once("close", abort);
            try {
                const result = await render({
                    ...renderInput, sourcePath, documentRoot: folder, config, signal: controller.signal,
                    assetUrl: absolute => previewAssetLink(id, folder, absolute),
                });
                return sendJson(response, 200, result);
            } finally {
                response.off("close", abort);
            }
        };
    }

    return [
        ["POST", "/documents/:id/preview", route(renderPreview, ({ content }) => ({ content: textInput(content, "content") }))],
        ["POST", "/documents/:id/visual-elements", route(renderVisualElements, ({ fallbackTitle, diagrams }) => {
            if (!Array.isArray(diagrams)) throw badRequest("diagrams は Mermaid ソースの配列を指定してください。");
            return { fallbackTitle: textInput(fallbackTitle ?? "", "fallbackTitle"),
                diagrams: diagrams.map(source => textInput(source, "diagrams")) };
        })],
    ];
}
