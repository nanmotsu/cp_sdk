/**
 * @file AHPのターンを開始し、応答イベントを集約して必要に応じて中断する。
 */

import { randomUUID } from 'node:crypto';
import { ApiError } from '../api/errors.mjs';
import { disconnected, shortDetail } from './errors.mjs';

const RESPONSE_LIMIT = 300_000;
const TOOL_REQUEST_LIMIT = 8;
const COMMAND_TOOLS = new Set(['execute', 'run_in_terminal', 'runInTerminal', 'powershell', 'bash', 'local_shell']);

/** 既定チャットを検査して依頼を送り、応答の差分をまとめる。承認外のツール要求は拒否する。 */
export async function generateTurn(connection, { session, model, agent, prompt, attachments, imageRequest,
    signal, validateChat, onToolDenied, onText, onToolResult, onToolApprovalNeeded,
    allowedTools = [], manualTools = [] }) {
    const chat = session.defaultChat;
    const actions = connection.actions(chat, signal);
    const turnId = randomUUID();
    const parts = new Map();
    const toolNames = new Map();
    let textLength = 0;
    let reportedText = false;
    let toolRequests = 0;
    let turnStarted = false;
    try {
        const { snapshot } = await connection.request('subscribe', { channel: chat, view: { turns: 1 } }, { signal });
        validateChat(snapshot?.state);
        connection.dispatch(chat, {
            type: 'chat/turnStarted', turnId, startedAt: new Date().toISOString(),
            message: { origin: { kind: 'user' }, text: prompt, ...(model && { model }), ...(agent && { agent }),
                ...(attachments?.length && { attachments }) },
        });
        turnStarted = true;
        for await (const [{ action, rejectionReason }] of actions) {
            if (action?.turnId !== turnId) continue;
            if (rejectionReason) {
                if (action.type === 'chat/turnStarted') {
                    turnStarted = false;
                    if (agent) throw new ApiError(502, 'AHP_CUSTOM_AGENT_REJECTED',
                        `Agent Hostが専用エージェント付きの依頼を受け付けませんでした。VS Codeでエージェントを確認してください。${shortDetail(rejectionReason)}`);
                    if (imageRequest) throw new ApiError(502, 'AHP_IMAGE_ATTACHMENT_REJECTED',
                        `VS CodeのAgent Hostが画像つきの依頼を受け付けませんでした。${shortDetail(rejectionReason)}`);
                    if (attachments?.length) throw new ApiError(502, 'AHP_FILE_ATTACHMENT_REJECTED',
                        `VS CodeのAgent Hostがファイル添付つきの依頼を受け付けませんでした。${shortDetail(rejectionReason)}`);
                }
                throw new ApiError(502, 'AHP_TURN_REJECTED', 'Agent HostでCopilotへの依頼を開始できませんでした。');
            }
            switch (action.type) {
                case 'chat/toolCallStart':
                    toolNames.set(action.toolCallId, action.toolName);
                    if (toolNames.size > TOOL_REQUEST_LIMIT) {
                        throw new ApiError(409, 'AHP_TOOL_REQUEST', 'Copilotのツール実行回数が上限を超えました。');
                    }
                    break;
                case 'chat/responsePart':
                    if (action.part?.kind === 'markdown') {
                        const content = action.part.content ?? '';
                        parts.set(action.part.id, content);
                        textLength += content.length;
                    }
                    break;
                case 'chat/delta': {
                    const content = action.content ?? '';
                    parts.set(action.partId, (parts.get(action.partId) ?? '') + content);
                    textLength += content.length;
                    break;
                }
                case 'chat/toolCallReady':
                    if (allowedTools.includes(toolNames.get(action.toolCallId))) {
                        if (!action.confirmed) {
                            connection.dispatch(chat, { type: 'chat/toolCallConfirmed', turnId, toolCallId: action.toolCallId,
                                approved: true, confirmed: 'user-action' });
                        }
                        break;
                    }
                    if (manualTools.includes(toolNames.get(action.toolCallId))) {
                        if (COMMAND_TOOLS.has(toolNames.get(action.toolCallId)) && action.confirmed && action.confirmed !== 'user-action') {
                            throw new ApiError(409, 'AHP_TOOL_REQUEST', 'Copilotのコマンド実行が自動承認されたため中断しました。');
                        }
                        if (!action.confirmed) onToolApprovalNeeded?.(toolNames.get(action.toolCallId));
                        break;
                    }
                    if (action.confirmed || !action.toolCallId || ++toolRequests > TOOL_REQUEST_LIMIT) {
                        throw new ApiError(409, 'AHP_TOOL_REQUEST', 'Copilotが外部ツールを必要としたため、この生成を中断しました。');
                    }
                    connection.dispatch(chat, { type: 'chat/toolCallConfirmed', turnId, toolCallId: action.toolCallId, approved: false, reason: 'denied' });
                    onToolDenied?.();
                    break;
                case 'chat/toolCallComplete':
                    if (allowedTools.includes(toolNames.get(action.toolCallId)) && action.result?.success) {
                        await onToolResult?.(toolNames.get(action.toolCallId), action.result);
                    }
                    break;
                case 'chat/inputRequested':
                case 'chat/toolCallAuthRequired':
                    throw new ApiError(409, 'AHP_INPUT_REQUIRED', 'Copilotが追加の入力またはログインを求めました。VS CodeのCopilotの状態を確認してください。');
                case 'chat/turnComplete':
                    return [...parts.values()].join('').trim();
                case 'chat/turnCancelled':
                    turnStarted = false;
                    throw new ApiError(409, 'AHP_TURN_CANCELLED', 'Copilotの生成が中断されました。');
                case 'chat/error':
                    throw new ApiError(502, 'AHP_TURN_FAILED', `Copilotの生成に失敗しました。${shortDetail(action.part?.error ?? action.part)}`);
            }
            if (textLength > RESPONSE_LIMIT) throw new ApiError(413, 'AHP_RESPONSE_TOO_LARGE', 'Copilotの応答が文書サイズの上限を超えました。');
            if (textLength > 0 && !reportedText) {
                reportedText = true;
                onText?.();
            }
        }
        throw connection.closeReason ?? disconnected();
    } catch (error) {
        if (turnStarted) {
            try {
                connection.cancelTurn(chat, turnId);
            } catch {
                // A lost connection cannot deliver cancellation. Preserve the original error.
            }
        }
        throw error;
    } finally {
        await actions.return();
    }
}
