/**
 * @file PDFと画像の描画に使うChrome系ブラウザーを選び、Puppeteerで起動する。
 */

import { existsSync } from "node:fs";

const chromeCandidates = [
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
    "/usr/bin/google-chrome",
    "/usr/bin/chromium-browser",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
];

/** 指定された環境変数を優先し、利用できなければ既知のインストール先を調べる。 */
export function findChromeExecutable() {
    const configured = process.env.PUPPETEER_EXECUTABLE_PATH;
    if (configured && existsSync(configured)) return configured;
    return chromeCandidates.find(candidate => existsSync(candidate)) ?? null;
}

/** 検出した実行ファイルを優先してヘッドレスで起動する。検出できない場合はPuppeteerの既定設定に従う。 */
export async function launchBrowser() {
    const { default: puppeteer } = await import("puppeteer");
    const executablePath = findChromeExecutable();
    return puppeteer.launch({
        headless: true,
        ...(executablePath ? { executablePath } : {}),
    });
}
