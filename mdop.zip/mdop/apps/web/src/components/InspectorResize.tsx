/**
 * @file 中央の編集欄と右の操作欄の境界を、ポインターやキーボードで動かせるようにする。
 */

import { useEffect, useRef, useState } from 'react';
import type { KeyboardEvent, PointerEvent, RefObject } from 'react';

/** 実際のペイン幅とCSSの制約から、許容できる右ペインの最小・最大幅を求める。 */
const measure = (editor: HTMLElement, inspector: HTMLElement) => {
  const styles = getComputedStyle(inspector.parentElement!);
  const min = parseFloat(styles.getPropertyValue('--inspector-min-width'));
  const editorMin = parseFloat(styles.getPropertyValue('--editor-min-width'));
  const width = inspector.offsetWidth;
  return { width, min, max: Math.max(min, editor.offsetWidth + width - editorMin) };
};

/** ペイン境界を配置し、アクセス可能な現在値と幅調整の操作を提供する。 */
export default function InspectorResize({ editor, inspector }: {
  editor: RefObject<HTMLElement | null>;
  inspector: RefObject<HTMLElement | null>;
}) {
  const drag = useRef<{ pointerId: number; x: number; width: number } | null>(null);
  const [size, setSize] = useState({ width: 0, min: 0, max: 0 });

  useEffect(() => {
    const left = editor.current;
    const right = inspector.current;
    if (!left || !right) return;
    const observer = new ResizeObserver(() => setSize(measure(left, right)));
    observer.observe(left);
    observer.observe(right);
    return () => observer.disconnect();
  }, [editor, inspector]);

  /** 右ペインの希望幅をCSS変数に設定し、引数省略時は初期幅へ戻す。 */
  function resize(width?: number) {
    const layout = inspector.current?.parentElement;
    if (!layout) return;
    if (width === undefined) layout.style.removeProperty('--inspector-requested-width');
    else layout.style.setProperty('--inspector-requested-width', `${width}px`);
  }

  /** ドラッグ開始時の位置と幅を控え、ポインターを捕捉する。 */
  function start(event: PointerEvent<HTMLDivElement>) {
    if (event.button !== 0 || !inspector.current) return;
    drag.current = { pointerId: event.pointerId, x: event.clientX, width: inspector.current.offsetWidth };
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  /** 開始位置からの横方向の差を右ペインの幅に反映する。 */
  function move(event: PointerEvent<HTMLDivElement>) {
    const active = drag.current;
    if (active?.pointerId === event.pointerId) resize(active.width + active.x - event.clientX);
  }

  /** 矢印キーで幅を調整し、HomeとEndで範囲の端へ移動する。 */
  function keyboard(event: KeyboardEvent<HTMLDivElement>) {
    if (!editor.current || !inspector.current) return;
    const { width, min, max } = measure(editor.current, inspector.current);
    const step = event.shiftKey ? 48 : 16;
    const widths: Record<string, number> = { ArrowLeft: width + step, ArrowRight: width - step, Home: min, End: max };
    const next = Object.hasOwn(widths, event.key) ? widths[event.key] : undefined;
    if (next === undefined) return;
    event.preventDefault();
    resize(next);
  }

  return <div className="inspector-resize" role="separator" aria-orientation="vertical" aria-label="右ペインの幅"
    aria-controls="workspace-inspector" aria-valuenow={size.width} aria-valuemin={size.min} aria-valuemax={size.max}
    tabIndex={0} title="ドラッグまたは矢印キーで右ペインの幅を調整。ダブルクリックで初期幅に戻す"
    onPointerDown={start} onPointerMove={move} onLostPointerCapture={() => { drag.current = null; }}
    onKeyDown={keyboard} onDoubleClick={() => resize()} />;
}
