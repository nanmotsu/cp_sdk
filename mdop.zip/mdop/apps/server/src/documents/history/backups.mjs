/**
 * @file 文書フォルダ全体の版を保管し、比較と復元に使う。
 */

import { createHash, randomUUID } from "node:crypto";
import { constants, createReadStream } from "node:fs";
import { copyFile, mkdir, readdir, readFile, rename, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { badRequest, conflict, notFound } from "../../common/api/errors.mjs";
import { atomicWrite, ensureWorkspaceDirectory, pathParts, statIfPresent, workspacePath } from "../../common/filesystem/paths.mjs";

const historyDir = "backups";
const treeDir = "document";
const sharedName = "shared-config.yaml";
const restoreDir = ".restore";
const backupId = /^[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}$/;
const discardedVersion = /^\.([a-f\d-]+)\.deleted$/;
const reasons = new Set(["initial", "save", "word", "copilot", "copilot-figure", "before-restore"]);

/** 履歴の領域を、通常の画像配信や出力の対象から外す。 */
export function isBackupPath(path) {
    return pathParts(path)[0].toLowerCase() === historyDir;
}

/** 直下の項目を列挙する。履歴自身はコピー・比較・復元から外す。 */
async function entries(folder, skipHistory = false) {
    const names = await readdir(folder);
    return names.filter(name => !skipHistory || name.toLowerCase() !== historyDir).sort();
}

/** 順に通常ファイルとディレクトリをたどる。リンクや特殊ファイルを含む文書は版の作成を止める。 */
async function* walk(folder, skipHistory, parent = "") {
    for (const name of await entries(join(folder, parent), skipHistory && !parent)) {
        const relative = parent ? `${parent}/${name}` : name;
        pathParts(relative);
        const absolute = join(folder, relative);
        const stat = await statIfPresent(absolute);
        if (!stat?.isFile() && !stat?.isDirectory()) {
            throw badRequest(`版に含められないファイルがあります。通常のファイルまたはフォルダを指定してください: ${relative}`);
        }
        yield { relative, absolute, directory: stat.isDirectory() };
        if (stat.isDirectory()) yield* walk(folder, skipHistory, relative);
    }
}

/** 文書内の全項目を、空のフォルダも含めて作業先に複製する。 */
async function copyTree(from, to, { skipHistory = false, signal } = {}) {
    await mkdir(to);
    for await (const entry of walk(from, skipHistory)) {
        signal?.throwIfAborted();
        const target = join(to, entry.relative);
        if (entry.directory) await mkdir(target);
        else await copyFile(entry.absolute, target);
    }
    signal?.throwIfAborted();
}

/** 大きな成果物も一度にメモリに読み込まず、内容から比較用ハッシュを求める。 */
async function digest(file) {
    const hash = createHash("sha256");
    for await (const chunk of createReadStream(file)) hash.update(chunk);
    return hash.digest("hex");
}

/** 設定、画像、本文、成果物を、相対パスから比較できる形にする。 */
async function manifest(folder) {
    const files = new Map();
    for await (const entry of walk(folder, true)) {
        files.set(entry.relative, entry.directory ? "directory" : await digest(entry.absolute));
    }
    return files;
}

/** 保存済みの版を検証し、一覧表示と本文パスの特定に必要な情報を読み込む。 */
async function readMetadata(directory, id) {
    const data = JSON.parse(await readFile(await workspacePath(directory, "metadata.json"), "utf8"));
    if (data.id !== id || !reasons.has(data.reason) || !Number.isFinite(Date.parse(data.createdAt))
        || (data.path !== null && (pathParts(data.path).length !== 1 || data.path.startsWith(".") || !/\.m(?:d|arkdown)$/i.test(data.path)))) {
        throw badRequest("履歴の管理情報を読み込めません。");
    }
    return { id, reason: data.reason, createdAt: data.createdAt, path: data.path,
        ...(typeof data.label === "string" && { label: data.label }),
        ...(Array.isArray(data.warnings) && { warnings: data.warnings.filter(warning => typeof warning === "string") }) };
}

/** 一時フォルダから、履歴に表示できる完成版を公開する。 */
async function publish(history, { path, reason, label, warnings, signal }, build) {
    const id = randomUUID();
    const temp = join(history, `.${id}.tmp`);
    const directory = join(history, id);
    const tree = join(temp, treeDir);
    await mkdir(temp);
    try {
        await build(tree, temp);
        const metadata = { id, reason, label, warnings, path, createdAt: new Date().toISOString() };
        await writeFile(join(temp, "metadata.json"), JSON.stringify(metadata, null, 2) + "\n");
        signal?.throwIfAborted();
        await rename(temp, directory);
        return metadata;
    } finally {
        await rm(temp, { recursive: true, force: true });
    }
}

/** 復元の途中で停止したとき、退避したファイルを使って置き換え前の状態へ戻す。 */
async function rollbackRestore(folder, stage) {
    const phase = join(stage, "phase");
    const current = await statIfPresent(phase) ? await readFile(await workspacePath(stage, "phase"), "utf8") : "";
    if (current === "replace") {
        const next = await workspacePath(stage, "next", { directory: true });
        for (const name of await entries(folder, true)) {
            const destination = join(next, name);
            if (await statIfPresent(destination)) throw conflict(`復元の再開時に同名のファイルが見つかりました: ${name}`);
            await rename(join(folder, name), destination);
        }
        await atomicWrite(phase, "move-old");
    }
    if (current === "move-old" || current === "replace") {
        const previous = await workspacePath(stage, "previous", { directory: true });
        for (const name of await entries(previous)) {
            const destination = join(folder, name);
            if (await statIfPresent(destination)) throw conflict(`退避したファイルと同名のファイルが見つかりました: ${name}`);
            await rename(join(previous, name), destination);
        }
    }
    if (current && !["done", "move-old", "replace"].includes(current)) {
        throw conflict("復元処理の状態を確認できません。");
    }
    await rm(stage, { recursive: true, force: true });
}

/** 文書ストアのロック内で使用する。版管理のファイル操作は文書の保存・図版の更新と直列化される。 */
export function createBackups(documentsRoot) {
    /** 文書別設定がない場合に選ばれる、共通設定のファイルを特定する。 */
    async function sharedConfig(folder) {
        if (await statIfPresent(join(folder, "config.yaml"))) return null;
        return commonConfig();
    }

    /** 現在の共通設定の位置を取得する。 */
    async function commonConfig() {
        const path = await workspacePath(documentsRoot, "config.yaml", { mayBeMissing: true });
        return await statIfPresent(path) ? path : null;
    }

    /** 文書内に履歴がなければ、作成するまで空の一覧として扱う。 */
    async function list(folder) {
        const history = await workspacePath(folder, historyDir, { directory: true, mayBeMissing: true });
        if (!await statIfPresent(history)) return [];
        const found = [];
        for (const entry of await readdir(history, { withFileTypes: true })) {
            if (!entry.isDirectory()) continue;
            if (backupId.test(entry.name)) {
                found.push(await readMetadata(join(history, entry.name), entry.name));
            } else if (backupId.test(discardedVersion.exec(entry.name)?.[1] ?? "")) {
                const pending = await workspacePath(history, entry.name, { directory: true, mayBeMissing: true });
                await clearDiscarded(pending);
            }
        }
        return found.sort((left, right) => right.createdAt.localeCompare(left.createdAt) || right.id.localeCompare(left.id));
    }

    /** UUIDで指定された版の実フォルダを、文書の履歴領域内で検証する。 */
    function backupDirectory(folder, id) {
        if (typeof id !== "string" || !backupId.test(id)) throw notFound("指定の版が見つかりません。");
        return workspacePath(folder, `${historyDir}/${id}`, { directory: true });
    }

    /** 指定された版のスナップショットと、当時の共通設定を取得する。 */
    async function open(folder, id) {
        const directory = await backupDirectory(folder, id);
        const tree = await workspacePath(directory, treeDir, { directory: true });
        const shared = await workspacePath(directory, sharedName, { mayBeMissing: true });
        return { metadata: await readMetadata(directory, id), tree, shared: await statIfPresent(shared) ? shared : null };
    }

    /** 現在のフォルダを複製し、必要に応じて本文や取り込んだ画像を差し替えて版を作る。 */
    async function capture(folder, options, modify) {
        const history = await ensureWorkspaceDirectory(folder, historyDir);
        return publish(history, options, async (tree, directory) => {
            await copyTree(folder, tree, { skipHistory: true, signal: options.signal });
            const shared = await sharedConfig(tree);
            if (shared) await copyFile(shared, join(directory, sharedName));
            await modify?.(tree);
        });
    }

    /** 既存の版を複製して、元の版を維持したまま図版の調整を記録する。 */
    async function fork(folder, source, options, modify) {
        const history = await workspacePath(folder, historyDir, { directory: true });
        return publish(history, options, async (tree, directory) => {
            await copyTree(source.tree, tree, { skipHistory: true });
            if (source.shared) await copyFile(source.shared, join(directory, sharedName));
            await modify(tree);
        });
    }

    /** 履歴から外した版を消去し、消去が中断された場合は次の一覧取得で再試行する。 */
    async function clearDiscarded(directory) {
        await rm(directory, { recursive: true, force: true, maxRetries: 3 }).catch(() => {});
    }

    /** 指定された版を一度に一覧から外し、元の文書に触れずにスナップショットを消去する。 */
    async function discard(folder, id) {
        const version = await backupDirectory(folder, id);
        const pending = await workspacePath(folder, `${historyDir}/.${id}.deleted`, { directory: true, mayBeMissing: true });
        await rename(version, pending);
        await clearDiscarded(pending);
    }

    /** 現在のフォルダ全体を照合するため、ファイルと共通設定のハッシュをまとめる。 */
    async function state(folder) {
        const files = await manifest(folder);
        const shared = await sharedConfig(folder);
        const sharedHash = shared ? await digest(shared) : null;
        const revision = createHash("sha256").update(JSON.stringify([[...files], sharedHash])).digest("hex");
        return { files, sharedHash, revision };
    }

    /** 版から現在の文書に向かうファイル差分と、照合に使うフォルダのリビジョンを返す。 */
    async function compare(folder, version) {
        const current = await state(folder);
        const previous = await manifest(version.tree);
        const paths = [...new Set([...current.files.keys(), ...previous.keys()])].sort();
        const files = paths.flatMap(path => {
            const before = previous.get(path);
            const after = current.files.get(path);
            return before === after ? [] : [{ path, directory: (after ?? before) === "directory",
                change: before === undefined ? "added" : after === undefined ? "removed" : "modified" }];
        });
        const sharedHash = version.shared ? await digest(version.shared) : null;
        return { files, sharedConfigChanged: sharedHash !== current.sharedHash, currentRevision: current.revision };
    }

    /** 未完了の復元が残っていれば、以降の文書操作を始める前に片付ける。 */
    async function recover(folder) {
        const history = join(folder, historyDir);
        if (!(await statIfPresent(history))?.isDirectory()) return;
        const stage = await workspacePath(history, restoreDir, { directory: true, mayBeMissing: true });
        if (await statIfPresent(stage)) await rollbackRestore(folder, stage);
    }

    /** 履歴を残し、原本とすべての付属ファイルを選んだ版に置き換える。 */
    async function restore(folder, version, expectedRevision) {
        const stage = await workspacePath(folder, `${historyDir}/${restoreDir}`, { directory: true, mayBeMissing: true });
        const next = join(stage, "next");
        const previous = join(stage, "previous");
        const phase = join(stage, "phase");
        await mkdir(stage);
        try {
            await copyTree(version.tree, next, { skipHistory: true });
            if (version.shared) {
                const shared = await commonConfig();
                if (!shared || await digest(shared) !== await digest(version.shared)) {
                    await copyFile(version.shared, join(next, "config.yaml"), constants.COPYFILE_EXCL);
                }
            }
            await mkdir(previous);
            if ((await state(folder)).revision !== expectedRevision) {
                throw conflict("復元の準備中に文書が変わりました。差分を更新してから復元してください。");
            }
            await atomicWrite(phase, "move-old");
            for (const name of await entries(folder, true)) await rename(join(folder, name), join(previous, name));
            await atomicWrite(phase, "replace");
            for (const name of await entries(next)) await rename(join(next, name), join(folder, name));
            await atomicWrite(phase, "done");
        } catch (error) {
            await rollbackRestore(folder, stage);
            throw error;
        }
        await rm(stage, { recursive: true, force: true }).catch(() => {});
    }

    return { list, open, capture, fork, discard, state, compare, recover, restore };
}
