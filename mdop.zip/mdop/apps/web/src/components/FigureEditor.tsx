/**
 * @file SVGの部品と、手元画像に重ねる注釈・レイヤーを編集するダイアログ。座標変換、ドラッグ、取り消し、採用データの生成を扱う。
 */

import { useId, useLayoutEffect, useRef, useState } from 'react';
import type { KeyboardEvent, PointerEvent } from 'react';
import { errorMessage, fileBase64 } from '../api';
import type { FigureAnnotation, FigureCompositionInput, FigureImagePlacement, FigureImageUpload } from '../api';
import FigurePartsDialog from './FigurePartsDialog';
import type { FigureImageFile } from './FigurePartsDialog';
import './Figures.css';

/** キャンバス上の配置に、プレビューURLまたは保存待ちの画像を加えた編集用レイヤー。 */
export interface EditorImage extends FigureImagePlacement {
  url?: string;
  upload?: FigureImageUpload;
}

/** エディターを開く時点のSVG、または元画像と注釈・配置の初期値。 */
export type FigureEditorValue =
  | { kind: 'svg'; svg: string }
  | ImageLayout;

/** 採用時に返すSVG、またはラスタ図版を再合成するための注釈と配置。 */
export type FigureEditorResult =
  | { kind: 'svg'; svg: string }
  | { kind: 'screenshot'; annotations: FigureAnnotation[]; composition: FigureCompositionInput };

/** エディターの初期値と、採用・閉じる操作の連携。 */
interface Props {
  title: string;
  onTitleChange?: (title: string) => void;
  documentId?: string;
  value: FigureEditorValue;
  onApply: (value: FigureEditorResult) => void | Promise<void>;
  onClose: () => void;
  applyLabel?: string;
}

/** SVGの描画座標での位置、または二方向の寸法。 */
interface Point { x: number; y: number }
/** 選択リストとキャンバスで共有する部品の識別子と表示名。 */
interface Part { id: string; label: string }
/** SVGの編集対象と、移動前の変換・原点。 */
interface VectorPart extends Part {
  element: SVGGraphicsElement;
  originalTransform: string | null;
  origin: Point;
}
/** 描画中のSVG、図形と画像のレイヤー、選択枠などのDOM参照。 */
interface Scene {
  canvas: SVGSVGElement;
  vectors: VectorPart[];
  layer?: SVGGElement;
  imageLayer?: SVGGElement;
  imageNodes?: Map<string, SVGImageElement>;
  outline: SVGRectElement;
  resizeHandle?: SVGCircleElement;
  originalLabel: string | null;
}
/** キャンバス寸法、画像の配置順、注釈を保持するラスタ図版の作業状態。 */
export type ImageLayout = { kind: 'screenshot'; width: number; height: number; images: EditorImage[]; annotations: FigureAnnotation[] };
/** 新しい図版を組み立て始めるときのキャンバス。 */
export const emptyImageLayout: ImageLayout = { kind: 'screenshot', width: 1000, height: 650, images: [], annotations: [] };
/** SVGの部品座標、またはラスタ図版の配置を保持する編集状態。 */
type Layout =
  | { kind: 'svg'; positions: Record<string, Point> }
  | ImageLayout;

/** ドラッグの開始座標、対象、移動前の状態。操作全体を取り消し1回分にまとめるために使う。 */
interface Drag {
  id: string;
  pointerId: number;
  start: Point;
  origin: Point;
  resize: boolean;
  before: Layout;
}

const namespace = 'http://www.w3.org/2000/svg';
const ink = '#d53343';
const selectionColor = '#266e58';
const maxAnnotations = 300;
const annotationCoordinateLimit = 100000;
const minimumExtent = 0.001;
const maxCanvasSide = 100000;
const maxCanvasPixels = 40_000_000;
const maxImageBytes = 12 * 1024 * 1024;
export const maxImages = 16;
export const maxUploadBytes = 20 * 1024 * 1024;
export const allowedImageTypes = ['image/png', 'image/jpeg', 'image/webp', 'image/gif', 'image/bmp', 'image/svg+xml'];
const primaryImageId = 'original';
const imagePrefix = 'image:';
const drawing = new Set(['rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon', 'path', 'text']);
const safeTags = new Set([
  'svg', 'g', 'title', 'desc', 'tspan', 'stop', 'defs', 'linearGradient', 'radialGradient', 'clipPath', 'marker', ...drawing,
]);
const referenceAttributes = new Set(['fill', 'stroke', 'clip-path', 'marker-start', 'marker-mid', 'marker-end']);
const safeAttributes = new Set((
  'id class data-figure-edit aria-label viewBox preserveAspectRatio x y x1 y1 x2 y2 dx dy cx cy r rx ry fx fy fr ' +
  'width height d points transform gradientUnits gradientTransform spreadMethod offset clipPathUnits markerUnits ' +
  'markerWidth markerHeight refX refY orient fill fill-opacity fill-rule stroke stroke-width stroke-linecap ' +
  'stroke-linejoin stroke-opacity stroke-dasharray stroke-dashoffset stroke-miterlimit opacity text-anchor ' +
  'dominant-baseline alignment-baseline font-family font-size font-weight font-style letter-spacing color stop-color ' +
  'stop-opacity clip-path clip-rule marker-start marker-mid marker-end vector-effect textLength lengthAdjust display visibility'
).split(' '));
const partNames: Record<string, string> = {
  g: 'グループ', rect: '四角形', circle: '円', ellipse: '楕円', line: '線',
  polyline: '折れ線', polygon: '多角形', path: '図形', text: '文字',
  box: '枠', arrow: '矢印', label: '文字',
};
const moveKeys: Record<string, [number, number]> = {
  ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1],
};

/** SVG名前空間で要素を作り、指定された属性を設定する。 */
function element<K extends keyof SVGElementTagNameMap>(name: K, attributes: Record<string, string | number> = {}) {
  const node = document.createElementNS(namespace, name);
  for (const [attribute, value] of Object.entries(attributes)) node.setAttribute(attribute, String(value));
  return node;
}

/** 入力SVGを解析し、エディターで描ける要素と属性を新しいSVGへコピーする。 */
function editableSvg(source: string) {
  const parsed = new DOMParser().parseFromString(source, 'image/svg+xml');
  if (parsed.documentElement.localName !== 'svg' || parsed.documentElement.namespaceURI !== namespace || parsed.doctype) {
    throw new Error('この図版のSVGを開けません。');
  }

  /** 許可された要素・属性でSVGの部分木を組み立て、エディター用のDOMにする。 */
  function copy(node: Element): SVGElement | null {
    if (node.namespaceURI !== namespace || !safeTags.has(node.localName)) return null;
    const target = document.createElementNS(namespace, node.localName);
    for (const attribute of Array.from(node.attributes)) {
      if (attribute.namespaceURI || !safeAttributes.has(attribute.name)) continue;
      const { name, value } = attribute;
      const local = referenceAttributes.has(name) && /^url\(\s*#[A-Za-z_][\w:.-]*\s*\)$/i.test(value);
      if (local || (!/[\\@;{}]/.test(value) && !/(?:url|image-set)\s*\(/i.test(value))) {
        target.setAttribute(name, value);
      }
    }
    for (const child of Array.from(node.childNodes)) {
      if (child.nodeType === Node.TEXT_NODE || child.nodeType === Node.CDATA_SECTION_NODE) {
        target.append(document.createTextNode(child.textContent ?? ''));
      }
      if (child instanceof Element) {
        const safe = copy(child);
        if (safe) target.append(safe);
      }
    }
    return target;
  }

  const svg = copy(parsed.documentElement) as SVGSVGElement;
  if (!svg.hasAttribute('viewBox')) {
    const width = svg.width.baseVal.value;
    const height = svg.height.baseVal.value;
    if (!(width > 0 && height > 0)) throw new Error('図版の大きさを読み取れません。');
    svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
  }
  return svg;
}

/** ラスタ原本のURLがエディターで表示する画像の参照として扱えるかを確認する。 */
function originalImageUrl(path: string) {
  if (/^data:image\/(?:png|jpeg|gif|webp|bmp|svg\+xml);base64,[A-Za-z0-9+/=]+$/i.test(path)) return path;
  const url = new URL(path, window.location.href);
  if (url.protocol === 'blob:' && url.origin === window.location.origin) return url.href;
  if (url.origin === window.location.origin && url.pathname.startsWith('/api/v1/')) return url.href;
  throw new Error('図版の画像素材を読み込めません。');
}

/** 元のSVGまたはラスタ図版からキャンバスと編集用オーバーレイを生成する。 */
function makeScene(value: FigureEditorValue): Scene {
  const canvas = value.kind === 'svg' ? editableSvg(value.svg) : element('svg', {
    width: value.width, height: value.height, viewBox: `0 0 ${value.width} ${value.height}`,
  });
  const outline = element('rect', {
    fill: 'none', stroke: selectionColor, 'stroke-width': 2, 'stroke-dasharray': '5 3',
    'vector-effect': 'non-scaling-stroke', 'pointer-events': 'none', 'data-figure-ui': 'selection', visibility: 'hidden',
  });
  const originalLabel = canvas.getAttribute('aria-label');
  canvas.setAttribute('tabindex', '0');
  canvas.setAttribute('role', 'group');
  canvas.setAttribute('aria-label', '編集する図版');
  if (value.kind === 'svg') {
    canvas.append(outline);
    return { canvas, vectors: [], outline, originalLabel };
  }

  const layer = element('g');
  const imageLayer = element('g');
  const resizeHandle = element('circle', {
    fill: selectionColor, stroke: 'white', 'stroke-width': 2, 'vector-effect': 'non-scaling-stroke',
    'aria-hidden': 'true', visibility: 'hidden',
  });
  canvas.append(imageLayer, layer, outline, resizeHandle);
  return { canvas, vectors: [], layer, imageLayer, imageNodes: new Map(), outline, resizeHandle, originalLabel };
}

/** 対象の図形の境界をキャンバスの座標へ変換する。 */
function figureBounds(canvas: SVGSVGElement, target: SVGGraphicsElement) {
  const canvasMatrix = canvas.getScreenCTM();
  const targetMatrix = target.getScreenCTM();
  if (!canvasMatrix || !targetMatrix) return { x: 0, y: 0, width: 0, height: 0 };
  const box = target.getBBox();
  const matrix = canvasMatrix.inverse().multiply(targetMatrix);
  const corners = [[box.x, box.y], [box.x + box.width, box.y], [box.x, box.y + box.height],
    [box.x + box.width, box.y + box.height]].map(([x, y]) => new DOMPoint(x, y).matrixTransform(matrix));
  if (!corners.every(point => Number.isFinite(point.x) && Number.isFinite(point.y))) {
    return { x: 0, y: 0, width: 0, height: 0 };
  }
  const x = Math.min(...corners.map(point => point.x));
  const y = Math.min(...corners.map(point => point.y));
  return { x, y, width: Math.max(...corners.map(point => point.x)) - x, height: Math.max(...corners.map(point => point.y)) - y };
}

/** 移動できる部品を識別し、元の変換と位置を保存する。 */
function vectorParts(canvas: SVGSVGElement): VectorPart[] {
  /** 階層を巡回して、個別に動かす図形やグループを選ぶ。 */
  function parts(parent: Element): SVGGraphicsElement[] {
    return Array.from(parent.children).flatMap((child): SVGGraphicsElement[] => {
      const name = child.localName;
      if (child.getAttribute('display') === 'none') return [];
      if (drawing.has(name)) return [child as SVGGraphicsElement];
      if (name !== 'g' && name !== 'svg') return [];
      const explicit = child.hasAttribute('data-figure-edit') || child.hasAttribute('aria-label')
        || child.matches('.node, .edgeLabel, .actor, .cluster, .messageText');
      const namedGroup = child.hasAttribute('id') && child.querySelectorAll('g[id]').length === 0;
      if (name === 'g' && (explicit || namedGroup)) return [child as SVGGElement];
      const nested = parts(child);
      return nested.length ? nested : [];
    });
  }
  return parts(canvas).map((node, index) => {
    const id = `vector-${index}`;
    const title = Array.from(node.children).find(child => child.localName === 'title')?.textContent;
    const label = node.getAttribute('aria-label') || title || node.id || `${partNames[node.localName]} ${index + 1}`;
    node.setAttribute('data-figure-part', id);
    const { x, y } = figureBounds(canvas, node);
    return { id, label, element: node, originalTransform: node.getAttribute('transform'), origin: { x, y } };
  });
}

/** 枠・矢印・文字を、選択や描画に使えるSVG要素へ変換する。 */
function rasterPart(annotation: FigureAnnotation) {
  const group = element('g', {
    transform: `translate(${annotation.x} ${annotation.y})`, 'data-figure-part': annotation.id,
  });
  if (annotation.type === 'label') {
    const fontSize = annotation.fontSize ?? 24;
    const label = element('text', {
      x: 0, y: fontSize, 'font-family': 'sans-serif', 'font-size': fontSize,
      'font-weight': annotation.fontWeight ?? 'normal', fill: annotation.color ?? ink,
    });
    label.textContent = annotation.text;
    group.append(label);
    return group;
  }
  const stroke = {
    stroke: annotation.color ?? ink, 'stroke-width': annotation.strokeWidth ?? 3,
    'stroke-linecap': 'round', 'stroke-linejoin': 'round', fill: 'none',
  };
  if (annotation.type === 'box') {
    group.append(element('rect', { ...stroke, width: annotation.width, height: annotation.height }));
  } else {
    const { dx, dy } = annotation;
    const length = Math.hypot(dx, dy);
    const size = Math.min(Math.max(14, (annotation.strokeWidth ?? 3) * 4), length / 3);
    const ux = length ? dx / length : 0;
    const uy = length ? dy / length : 0;
    const baseX = dx - ux * size;
    const baseY = dy - uy * size;
    group.append(element('path', {
      ...stroke,
      d: `M 0 0 L ${dx} ${dy} M ${baseX - uy * size / 2} ${baseY + ux * size / 2} L ${dx} ${dy} L ${baseX + uy * size / 2} ${baseY - ux * size / 2}`,
    }));
  }
  return group;
}

/** サイズハンドルを置くため、枠の寸法または矢印の先端位置を得る。 */
function annotationSize(annotation?: FigureAnnotation) {
  if (annotation?.type === 'box') return { x: annotation.width, y: annotation.height };
  if (annotation?.type === 'arrow') return { x: annotation.dx, y: annotation.dy };
}

/** 必要になった時点でサイズ変更用ハンドルを用意する。 */
function sizeResizeHandle(scene: Scene) {
  const matrix = scene.canvas.getScreenCTM();
  const scale = matrix && Math.hypot(matrix.a, matrix.b);
  if (scale) scene.resizeHandle?.setAttribute('r', String(8 / scale));
}

/** 選択した部品の位置と寸法に合わせてサイズ変更ハンドルを配置する。 */
function placeResizeHandle(scene: Scene, selected: string, point?: Point, size?: Point, kind?: string) {
  const handle = scene.resizeHandle;
  if (!handle) return;
  if (!point || !size || !kind) {
    handle.setAttribute('visibility', 'hidden');
    handle.removeAttribute('data-figure-resize');
    handle.removeAttribute('data-figure-part');
    return;
  }
  handle.setAttribute('cx', String(point.x + size.x));
  handle.setAttribute('cy', String(point.y + size.y));
  handle.setAttribute('data-figure-part', selected);
  handle.setAttribute('data-figure-resize', kind);
  handle.setAttribute('visibility', 'visible');
  sizeResizeHandle(scene);
}

/** 保存済みのURLまたは新規アップロードのデータURLを画像描画に使う。 */
function imageSource(image: EditorImage) {
  if (image.url) return originalImageUrl(image.url);
  if (image.upload) return originalImageUrl(`data:${image.upload.mime};base64,${image.upload.base64}`);
  throw new Error('図版の画像を読み込めません。');
}

/** 選択用の識別子から、対応するラスタ画像レイヤーを探す。 */
function imageFor(layout: ImageLayout, id: string) {
  if (id.startsWith(imagePrefix)) return layout.images.find(image => image.id === id.slice(imagePrefix.length));
}

/** ドラッグ中に使う画像の幅と高さを座標形式へ変換する。 */
function imageSize(image: EditorImage): Point {
  return { x: image.width, y: image.height };
}

/** 配置済み画像を順序どおりにキャンバスへ反映し、選択状態を更新する。 */
function syncImages(scene: Scene, layout: ImageLayout, selected: string) {
  const { imageLayer, imageNodes } = scene;
  if (!imageLayer || !imageNodes) return;
  const active = new Set(layout.images.map(image => image.id));
  for (const [id, node] of imageNodes) {
    if (active.has(id)) continue;
    node.remove();
    imageNodes.delete(id);
  }
  let target: SVGImageElement | undefined;
  for (const [index, image] of layout.images.entries()) {
    let node = imageNodes.get(image.id);
    if (!node) {
      node = element('image', {
        href: imageSource(image), 'data-figure-part': imagePrefix + image.id, preserveAspectRatio: 'none',
      });
      imageNodes.set(image.id, node);
    }
    node.setAttribute('x', String(image.x));
    node.setAttribute('y', String(image.y));
    node.setAttribute('width', String(image.width));
    node.setAttribute('height', String(image.height));
    const current = imageLayer.children[index];
    if (current !== node) imageLayer.insertBefore(node, current ?? null);
    if (imagePrefix + image.id === selected) target = node;
  }
  return target;
}

/** 現在の位置、注釈、画像配置をSVG DOMへ反映し、選択枠を更新する。 */
function applyLayout(scene: Scene, layout: Layout, selected: string) {
  let target: SVGGraphicsElement | undefined;
  if (layout.kind === 'svg') {
    for (const part of scene.vectors) {
      if (part.id === selected) target = part.element;
      const point = layout.positions[part.id];
      const dx = point.x - part.origin.x;
      const dy = point.y - part.origin.y;
      if (!dx && !dy) {
        if (part.originalTransform === null) part.element.removeAttribute('transform');
        else part.element.setAttribute('transform', part.originalTransform);
        continue;
      }
      const parent = part.element.parentElement as SVGGraphicsElement | null;
      const parentMatrix = parent?.getScreenCTM();
      const canvasMatrix = scene.canvas.getScreenCTM();
      const matrix = parentMatrix && canvasMatrix ? parentMatrix.inverse().multiply(canvasMatrix) : new DOMMatrix();
      const x = matrix.a * dx + matrix.c * dy;
      const y = matrix.b * dx + matrix.d * dy;
      if (Number.isFinite(x) && Number.isFinite(y)) {
        part.element.setAttribute('transform', `translate(${round(x)} ${round(y)})${part.originalTransform ? ` ${part.originalTransform}` : ''}`);
      }
    }
  } else {
    scene.canvas.setAttribute('width', String(layout.width));
    scene.canvas.setAttribute('height', String(layout.height));
    scene.canvas.setAttribute('viewBox', `0 0 ${layout.width} ${layout.height}`);
    target = syncImages(scene, layout, selected);
    const nodes = layout.annotations.map(annotation => {
      const node = rasterPart(annotation);
      if (annotation.id === selected) target = node;
      return node;
    });
    scene.layer?.replaceChildren(...nodes);
    const image = imageFor(layout, selected);
    const annotation = layout.annotations.find(item => item.id === selected);
    if (image) placeResizeHandle(scene, selected, image, imageSize(image), 'image');
    else placeResizeHandle(scene, selected, annotation, annotationSize(annotation), annotation?.type);
  }

  scene.outline.setAttribute('visibility', target ? 'visible' : 'hidden');
  if (!target) return;
  const { x, y, width, height } = figureBounds(scene.canvas, target);
  for (const [name, number] of Object.entries({ x: x - 3, y: y - 3, width: width + 6, height: height + 6 })) {
    scene.outline.setAttribute(name, String(number));
  }
}

/** 編集用の選択枠や属性を外し、図版として保存するSVGを返す。 */
function serializeSvg(scene: Scene) {
  const copy = scene.canvas.cloneNode(true) as SVGSVGElement;
  copy.removeAttribute('tabindex');
  copy.removeAttribute('role');
  if (scene.originalLabel === null) copy.removeAttribute('aria-label');
  else copy.setAttribute('aria-label', scene.originalLabel);
  copy.querySelector('[data-figure-ui]')?.remove();
  for (const node of copy.querySelectorAll('[data-figure-part]')) node.removeAttribute('data-figure-part');
  return new XMLSerializer().serializeToString(copy);
}

/** 座標や寸法を小数第3位にそろえて表示・比較する。 */
function round(value: number) {
  return Math.round(value * 1000) / 1000;
}

/** 図版の種類に対応する座標範囲へ制限し、小数の桁をそろえる。 */
function coord(value: number, kind: Layout['kind']) {
  const limit = kind === 'screenshot' ? annotationCoordinateLimit : 10000000;
  return round(Math.max(-limit, Math.min(limit, value)));
}

/** 図形、画像、注釈に対応する現在の位置を取得する。 */
function partPoint(layout: Layout, id: string) {
  if (layout.kind === 'svg') return layout.positions[id];
  return imageFor(layout, id) ?? layout.annotations.find(annotation => annotation.id === id);
}

/** 操作の種類から、移動の基準位置またはリサイズの基準寸法を取得する。 */
function dragPoint(layout: Layout, id: string, resize: boolean) {
  if (!resize) return partPoint(layout, id);
  if (layout.kind === 'screenshot') {
    const image = imageFor(layout, id);
    return image ? imageSize(image) : annotationSize(layout.annotations.find(annotation => annotation.id === id));
  }
}

/** 画像の形式と容量を検査して復号し、追加レイヤーの原寸とアップロードデータを作る。 */
export function loadFigureImage(file: File) {
  const guessedTypes: Record<string, string> = {
    png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp',
    gif: 'image/gif', bmp: 'image/bmp', svg: 'image/svg+xml',
  };
  const mime = guessedTypes[file.name.split('.').at(-1)?.toLowerCase() ?? ''] || file.type;
  if (!allowedImageTypes.includes(mime) || !file.size || file.size > maxImageBytes) {
    throw new Error('PNG・JPEG・WebP・GIF・BMP・SVGのいずれかで、12 MiB以下の画像を選んでください。');
  }
  return fileBase64(file).then(async base64 => {
    const image = new Image();
    const id = crypto.randomUUID();
    const upload = { id, mime, base64 };
    image.src = `data:${mime};base64,${base64}`;
    await image.decode().catch(() => {
      throw new Error('画像を読み込めませんでした。画像形式とサイズを確認してください。');
    });
    if (!image.naturalWidth || !image.naturalHeight || image.naturalWidth * image.naturalHeight > maxCanvasPixels) {
      throw new Error('画像を読み込めませんでした。画像形式とサイズを確認してください。');
    }
    return { id, name: file.name, upload, x: 0, y: 0, width: image.naturalWidth, height: image.naturalHeight };
  });
}

/** 片方の寸法から、全体の画素数上限内に収まるもう片方の最大値を求める。 */
function maxCanvasAxis(otherAxis: number) {
  return Math.min(maxCanvasSide, Math.floor(maxCanvasPixels / otherAxis));
}

/** 既存画像の右または下に追加画像を置く。寸法上限に合わせて縮小する場合がある。 */
export function addImageToCanvas(layout: ImageLayout, image: EditorImage): ImageLayout {
  const gap = Math.max(1, Math.min(20, Math.round(Math.min(layout.width, layout.height) / 24)));
  const right = Math.max(0, ...layout.images.map(item => Math.ceil(item.x + item.width)));
  const bottom = Math.max(0, ...layout.images.map(item => Math.ceil(item.y + item.height)));
  const x = right ? right + gap : 0;
  const y = bottom ? bottom + gap : 0;
  const alongside = Math.min(1, (maxCanvasAxis(layout.height) - x) / image.width, layout.height / image.height);
  const below = Math.min(1, layout.width / image.width, (maxCanvasAxis(layout.width) - y) / image.height);
  const minimumScale = Math.min(1, 24 / Math.min(image.width, image.height));
  const at = alongside >= minimumScale ? { x, y: 0, scale: alongside }
    : below >= minimumScale ? { x: 0, y, scale: below }
      : { x: 0, y: 0, scale: Math.min(1, layout.width / image.width, layout.height / image.height) };
  const width = round(image.width * at.scale);
  const height = round(image.height * at.scale);
  return {
    ...layout,
    width: Math.max(layout.width, Math.ceil(at.x + width)),
    height: Math.max(layout.height, Math.ceil(at.y + height)),
    images: [...layout.images, { ...image, x: at.x, y: at.y, width, height }],
  };
}

/** キャンバスの寸法と画像の配置順、新規素材を保存用データにする。 */
function compositionFor(layout: ImageLayout) {
  const images = layout.images.map(({ upload: _upload, url: _url, ...placement }) => placement);
  const uploads = layout.images.flatMap(image => image.upload ? [image.upload] : []);
  return { width: layout.width, height: layout.height, images, ...(uploads.length && { uploads }) };
}

/** 変更を入力中は保持し、フォーカスを外したときに範囲内の数値として確定する。 */
function NumberField({ label, value, onCommit, min, max, disabled }: {
  label: string; value: number; onCommit: (value: number) => void; min?: number; max?: number; disabled: boolean;
}) {
  return <label className="figure-editor-value">{label}
    <input key={value} type="number" step="any" defaultValue={round(value)} min={min} max={max} disabled={disabled}
      onBlur={(event) => {
        const field = event.currentTarget;
        if (!Number.isFinite(field.valueAsNumber)) { field.value = String(round(value)); return; }
        const next = Math.max(min ?? -Infinity, Math.min(max ?? Infinity, field.valueAsNumber));
        field.value = String(round(next));
        if (round(next) !== round(value)) onCommit(next);
      }}
      onKeyDown={(event) => {
        if (event.key === 'Enter') { event.preventDefault(); event.currentTarget.blur(); }
      }} />
  </label>;
}

/** SVG部品またはラスタ図版の注釈・画像を選択し、位置や表示属性を調整して採用する。 */
export default function FigureEditor({ title, onTitleChange, documentId, value, onApply, onClose, applyLabel = '変更を保存' }: Props) {
  const titleId = useId();
  const original = useRef(value);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const viewportRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<Scene | null>(null);
  const current = useRef<Layout | null>(null);
  const undoStack = useRef<Layout[]>([]);
  const drag = useRef<Drag | null>(null);
  const [layout, setLayout] = useState<Layout | null>(null);
  const [vectorOptions, setVectorOptions] = useState<Part[]>([]);
  const [selected, setSelected] = useState('');
  const [canUndo, setCanUndo] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [showParts, setShowParts] = useState(false);

  useLayoutEffect(() => {
    const dialog = dialogRef.current;
    const viewport = viewportRef.current;
    if (!dialog || !viewport) return;
    dialog.showModal();
    let resizeObserver: ResizeObserver | undefined;
    try {
      const scene = makeScene(original.current);
      viewport.replaceChildren(scene.canvas);
      sceneRef.current = scene;
      if (scene.resizeHandle) {
        resizeObserver = new ResizeObserver(() => sizeResizeHandle(scene));
        resizeObserver.observe(scene.canvas);
      }
      let initial: Layout;
      if (original.current.kind === 'svg') {
        scene.vectors = vectorParts(scene.canvas);
        setVectorOptions(scene.vectors.map(({ id, label }) => ({ id, label })));
        initial = { kind: 'svg', positions: Object.fromEntries(scene.vectors.map(part => [part.id, part.origin])) };
      } else initial = original.current;
      current.current = initial;
      setLayout(initial);
    } catch (exception) {
      setError(errorMessage(exception));
    }
    return () => {
      resizeObserver?.disconnect();
      dialog.close();
      viewport.replaceChildren();
      sceneRef.current = null;
    };
  }, []);

  useLayoutEffect(() => {
    if (layout && sceneRef.current) applyLayout(sceneRef.current, layout, selected);
  }, [layout, selected]);

  const parts = layout?.kind === 'screenshot'
    ? layout.annotations.map((annotation, index) => ({
      id: annotation.id, label: annotation.type === 'label' && annotation.text ? annotation.text : `${partNames[annotation.type]} ${index + 1}`,
    })) : vectorOptions;
  const point = layout && partPoint(layout, selected);
  const canApply = layout?.kind === 'svg' || Boolean(layout?.images.length || layout?.annotations.length);
  const annotation = layout?.kind === 'screenshot' ? layout.annotations.find(item => item.id === selected) : undefined;
  const selectedImage = layout?.kind === 'screenshot' ? imageFor(layout, selected) : undefined;
  const arrowLength = annotation?.type === 'arrow' ? Math.hypot(annotation.dx, annotation.dy) : 0;
  const arrowAngle = annotation?.type === 'arrow' ? Math.atan2(annotation.dy, annotation.dx) * 180 / Math.PI : 0;

  /** 変更前の状態を取り消し履歴へ追加し、保持する件数を制限する。 */
  function remember(before: Layout) {
    undoStack.current.push(before);
    if (undoStack.current.length > 100) undoStack.current.shift();
    setCanUndo(true);
  }

  /** 次の配置を操作用の参照と画面の両方に反映する。 */
  function update(next: Layout) {
    current.current = next;
    setLayout(next);
    setError('');
  }

  /** 最後の編集前の配置を復元し、その時点にない選択を解除する。 */
  function undo() {
    const before = undoStack.current.pop();
    if (!before) return;
    update(before);
    if (!partPoint(before, selected)) setSelected('');
    setCanUndo(undoStack.current.length > 0);
  }

  /** 選択された部品の位置を、SVG・画像・注釈それぞれの保存形式で更新する。 */
  function move(id: string, point: Point, rememberChange = true) {
    const before = current.current;
    if (!before) return;
    const previous = partPoint(before, id);
    const x = coord(point.x, before.kind);
    const y = coord(point.y, before.kind);
    if (!previous || (round(previous.x) === x && round(previous.y) === y)) return;
    if (rememberChange) remember(before);
    const next: Layout = before.kind === 'svg'
      ? { kind: 'svg', positions: { ...before.positions, [id]: { x, y } } }
      : id.startsWith(imagePrefix)
        ? { ...before, images: before.images.map(image => imagePrefix + image.id === id ? { ...image, x, y } : image) }
        : { ...before, annotations: before.annotations.map(item => item.id === id ? { ...item, x, y } : item) };
    update(next);
  }

  /** 画像は縦横比を保ち、枠は幅と高さ、矢印は終点との差を更新する。 */
  function resizePart(id: string, point: Point, rememberChange = true) {
    const before = current.current;
    if (before?.kind !== 'screenshot') return;
    const image = imageFor(before, id);
    if (image) {
      const origin = imageFor(drag.current?.before.kind === 'screenshot' ? drag.current.before : before, id) ?? image;
      const ratio = (origin.width * point.x + origin.height * point.y) / (origin.width ** 2 + origin.height ** 2);
      scaleImage(image, ratio, origin, rememberChange);
      return;
    }
    const item = before.annotations.find(annotation => annotation.id === id);
    const x = coord(point.x, 'screenshot');
    const y = coord(point.y, 'screenshot');
    if (item?.type === 'box') {
      const width = Math.max(minimumExtent, x);
      const height = Math.max(minimumExtent, y);
      if (item.width !== width || item.height !== height) editAnnotation({ ...item, width, height }, rememberChange);
    } else if (item?.type === 'arrow' && (item.dx !== x || item.dy !== y)) {
      editAnnotation({ ...item, dx: x, dy: y }, rememberChange);
    }
  }

  /** フォームの長さと角度を、矢印の始点から終点までの差分に変換する。 */
  function resizeArrow(length: number, angle: number) {
    const radians = (angle % 360) * Math.PI / 180;
    const x = Math.cos(radians);
    const y = Math.sin(radians);
    const limitedLength = Math.min(length, annotationCoordinateLimit / Math.max(Math.abs(x), Math.abs(y)));
    resizePart(selected, { x: limitedLength * x, y: limitedLength * y });
  }

  /** 縦横比を保って画像の表示サイズを変え、座標の制限内に収める。 */
  function scaleImage(image: EditorImage, scale: number, reference = image, rememberChange = true) {
    const before = current.current;
    if (before?.kind !== 'screenshot') return;
    const ratio = Math.max(minimumExtent / Math.min(reference.width, reference.height),
      Math.min(annotationCoordinateLimit / Math.max(reference.width, reference.height), scale));
    const width = round(reference.width * ratio);
    const height = round(reference.height * ratio);
    if (width === image.width && height === image.height) return;
    if (rememberChange) remember(before);
    update({ ...before, images: before.images.map(item => item.id === image.id ? { ...item, width, height } : item) });
  }

  /** 画面上のポインター位置を、画面変換行列の逆変換でキャンバス座標にする。 */
  function canvasPoint(event: PointerEvent<HTMLDivElement>) {
    const canvas = sceneRef.current?.canvas;
    const matrix = canvas?.getScreenCTM();
    const point = matrix && new DOMPoint(event.clientX, event.clientY).matrixTransform(matrix.inverse());
    return point && Number.isFinite(point.x) && Number.isFinite(point.y) ? point : null;
  }

  /** 指された部品を選び、操作開始時の座標と配置を控える。 */
  function startDrag(event: PointerEvent<HTMLDivElement>) {
    if (busy || event.button !== 0 || drag.current) return;
    const canvas = sceneRef.current?.canvas;
    if (!canvas || !(event.target instanceof Element) || !canvas.contains(event.target)) return;
    const target = event.target.closest('[data-figure-part]');
    const id = target?.getAttribute('data-figure-part') ?? '';
    const resize = Boolean(target?.hasAttribute('data-figure-resize'));
    const before = current.current;
    const start = canvasPoint(event);
    const origin = before && dragPoint(before, id, resize);
    setSelected(id);
    canvas.focus({ preventScroll: true });
    if (!origin || !start || !before) return;
    event.preventDefault();
    drag.current = { id, pointerId: event.pointerId, start, origin, resize, before };
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  /** 開始地点からの移動量を適用する。ドラッグ中の各フレームは個別の履歴に保存しない。 */
  function dragPart(event: PointerEvent<HTMLDivElement>) {
    const active = drag.current;
    if (!active || event.pointerId !== active.pointerId) return;
    const point = canvasPoint(event);
    if (!point) return;
    const next = { x: active.origin.x + point.x - active.start.x, y: active.origin.y + point.y - active.start.y };
    if (active.resize) resizePart(active.id, next, false);
    else move(active.id, next, false);
  }

  /** ドラッグが変化を生んだ場合は一度だけ履歴に登録する。中断時は開始前の状態へ戻す。 */
  function finishDrag(event: PointerEvent<HTMLDivElement>, cancel: boolean) {
    const active = drag.current;
    if (!active || event.pointerId !== active.pointerId) return;
    drag.current = null;
    if (cancel) {
      update(active.before);
      return;
    }
    const point = current.current && dragPoint(current.current, active.id, active.resize);
    if (point && (round(point.x) !== round(active.origin.x) || round(point.y) !== round(active.origin.y))) {
      remember(active.before);
    }
  }

  /** フォーム入力を妨げない範囲で、矢印キーの移動と取り消しを処理する。 */
  function keyboard(event: KeyboardEvent<HTMLDialogElement>) {
    if (busy || drag.current || (event.target instanceof Element && event.target.closest('input, textarea, select'))) return;
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z' && !event.shiftKey) {
      event.preventDefault();
      undo();
      return;
    }
    const units = moveKeys[event.key];
    if (!units || !point || event.ctrlKey || event.metaKey || event.altKey) return;
    event.preventDefault();
    const step = event.shiftKey ? 10 : 1;
    move(selected, { x: point.x + units[0] * step, y: point.y + units[1] * step });
  }

  /** キャンバスに合わせた位置とサイズに、枠・矢印・文字の初期値を作る。 */
  function addAnnotation(type: FigureAnnotation['type']) {
    const before = current.current;
    if (before?.kind !== 'screenshot' || before.annotations.length >= maxAnnotations) return;
    const id = crypto.randomUUID();
    const span = Math.min(before.width, before.height);
    const common = { id, x: round(before.width * 0.24), y: round(before.height * 0.28) };
    const newAnnotation: FigureAnnotation = type === 'box'
      ? { ...common, type: 'box', width: round(span * 0.34), height: round(span * 0.18) }
      : type === 'arrow'
        ? { ...common, type: 'arrow', dx: round(span * 0.3), dy: round(span * 0.17) }
        : { ...common, type: 'label', text: '注釈' };
    remember(before);
    update({ ...before, annotations: [...before.annotations, newAnnotation] });
    setSelected(id);
  }

  /** IDに対応する注釈の表示属性や寸法を更新する。 */
  function editAnnotation(next: FigureAnnotation, rememberChange = true) {
    const before = current.current;
    if (before?.kind !== 'screenshot') return;
    if (rememberChange) remember(before);
    update({ ...before, annotations: before.annotations.map(item => item.id === next.id ? next : item) });
  }

  /** ラスタ編集で選択された画像レイヤーまたは注釈を取り除く。 */
  function removePart() {
    const before = current.current;
    if (before?.kind !== 'screenshot' || !selected) return;
    remember(before);
    const image = imageFor(before, selected);
    update(image ? { ...before, images: before.images.filter(item => item.id !== image.id) }
      : { ...before, annotations: before.annotations.filter(item => item.id !== selected) });
    setSelected('');
  }

  /** 縦横いずれかのキャンバス寸法を、画素数と辺の上限内で変更する。 */
  function changeCanvas(axis: 'width' | 'height', value: number) {
    const before = current.current;
    if (before?.kind !== 'screenshot') return;
    const extent = Math.max(1, Math.min(maxCanvasAxis(axis === 'width' ? before.height : before.width), Math.round(value)));
    if (extent === before[axis]) return;
    remember(before);
    update({ ...before, [axis]: extent });
  }

  /** 選んだ画像を一段ずつ手前または奥へ移動する。 */
  function moveImageLayer(image: EditorImage, step: -1 | 1) {
    const before = current.current;
    if (before?.kind !== 'screenshot') return;
    const index = before.images.findIndex(item => item.id === image.id);
    const destination = index + step;
    if (index < 0 || destination < 0 || destination >= before.images.length) return;
    const images = [...before.images];
    [images[index], images[destination]] = [images[destination], images[index]];
    remember(before);
    update({ ...before, images });
  }

  /** 選んだ画像を読み込み、すべてがそろってから一度の編集として配置する。 */
  async function addImages(files: FigureImageFile[]) {
    const before = current.current;
    if (busy || before?.kind !== 'screenshot' || !files.length) return;
    const images = await Promise.all(files.map(async ({ file, name }) => {
      const image = await loadFigureImage(file);
      return name ? { ...image, name } : image;
    }));
    const next = images.reduce(addImageToCanvas, before);
    remember(before);
    update(next);
    setSelected(imagePrefix + images.at(-1)!.id);
  }

  /** 保存待ちの画像容量を差し引き、素材を追加できるバイト数を返す。 */
  function availableUploadBytes(images: EditorImage[]) {
    return images.reduce((remaining, image) => {
      const base64 = image.upload?.base64;
      if (!base64) return remaining;
      const padding = base64.endsWith('==') ? 2 : base64.endsWith('=') ? 1 : 0;
      return remaining - (base64.length * 3 / 4 - padding);
    }, maxUploadBytes);
  }

  /** 現在の状態を保存用データにし、候補または図版一覧へ渡す。失敗時は編集画面に理由を残す。 */
  async function apply() {
    const scene = sceneRef.current;
    const ready = current.current;
    if (!scene || !ready || !canApply || busy || drag.current) return;
    setBusy(true);
    setError('');
    try {
      applyLayout(scene, ready, selected);
      await onApply(ready.kind === 'svg'
        ? { kind: 'svg', svg: serializeSvg(scene) }
        : { kind: 'screenshot', annotations: ready.annotations, composition: compositionFor(ready) });
    } catch (exception) {
      setError(errorMessage(exception));
    } finally {
      setBusy(false);
    }
  }

  const full = layout?.kind === 'screenshot' && layout.annotations.length >= maxAnnotations;
  const heading = onTitleChange ? '図版を作成' : '図版の編集';
  return <dialog ref={dialogRef} className="figure-editor" aria-label={heading}
    aria-describedby={onTitleChange ? undefined : titleId} onKeyDown={keyboard}
    onCancel={(event) => { event.preventDefault(); if (!busy) onClose(); }}>
    <div className="figure-editor-shell">
      <header className="figure-editor-heading">
        <div><h2>{heading}</h2>{!onTitleChange && <p id={titleId}>{title}</p>}</div>
        <button type="button" onClick={undo} disabled={!canUndo || busy}>元に戻す</button>
      </header>
      {onTitleChange && <label className="figure-editor-value figure-editor-name">図版の名前
        <input value={title} maxLength={120} disabled={busy} placeholder="図版" onChange={event => onTitleChange(event.target.value)} />
      </label>}
      {layout?.kind === 'screenshot' && <div className="figure-editor-toolbar" role="group" aria-label="図版に部品を追加">
        {documentId && <button type="button" aria-haspopup="dialog" disabled={busy} onClick={() => setShowParts(true)}>画像パーツを選ぶ</button>}
        <button type="button" disabled={busy || full} onClick={() => addAnnotation('box')}>枠を追加</button>
        <button type="button" disabled={busy || full} onClick={() => addAnnotation('arrow')}>矢印を追加</button>
        <button type="button" disabled={busy || full} onClick={() => addAnnotation('label')}>文字を追加</button>
      </div>}
      <div className="figure-editor-body">
        <div className="figure-editor-viewport" ref={viewportRef}
          onPointerDown={startDrag} onPointerMove={dragPart} onPointerUp={(event) => finishDrag(event, false)}
          onPointerCancel={(event) => finishDrag(event, true)} onLostPointerCapture={(event) => finishDrag(event, true)} />
        <aside className="figure-editor-properties" aria-label="選んだ部品の設定">
          <label className="figure-editor-value">図形・注釈
            <select value={selectedImage ? '' : selected} onChange={(event) => setSelected(event.target.value)} disabled={!parts.length || busy}>
              <option value="">未選択</option>
              {parts.map(part => <option key={part.id} value={part.id}>{part.label}</option>)}
            </select>
          </label>
          {point && <div className="figure-editor-coordinate">
            <NumberField key={`${selected}-x`} label="X座標" value={point.x} onCommit={(x) => move(selected, { ...point, x })} disabled={busy} />
            <NumberField key={`${selected}-y`} label="Y座標" value={point.y} onCommit={(y) => move(selected, { ...point, y })} disabled={busy} />
          </div>}
          {selectedImage && layout?.kind === 'screenshot' && <><div className="figure-editor-coordinate" role="group" aria-label="画像の大きさ">
            <NumberField key={`${selected}-width`} label="画像の幅" value={selectedImage.width} min={minimumExtent}
              max={annotationCoordinateLimit} onCommit={(width) => scaleImage(selectedImage, width / selectedImage.width)} disabled={busy} />
            <NumberField key={`${selected}-height`} label="画像の高さ" value={selectedImage.height} min={minimumExtent}
              max={annotationCoordinateLimit} onCommit={(height) => scaleImage(selectedImage, height / selectedImage.height)} disabled={busy} />
          </div><div className="form-actions" role="group" aria-label="画像の重なり順">
            <button type="button" disabled={busy || layout.images[0]?.id === selectedImage.id}
              onClick={() => moveImageLayer(selectedImage, -1)}>奥へ</button>
            <button type="button" disabled={busy || layout.images.at(-1)?.id === selectedImage.id}
              onClick={() => moveImageLayer(selectedImage, 1)}>手前へ</button>
          </div></>}
          {annotation?.type === 'box' && <div className="figure-editor-coordinate" role="group" aria-label="枠の大きさ">
            <NumberField key={`${selected}-width`} label="幅" value={annotation.width} min={minimumExtent} max={annotationCoordinateLimit}
              onCommit={(width) => editAnnotation({ ...annotation, width: round(width) })} disabled={busy} />
            <NumberField key={`${selected}-height`} label="高さ" value={annotation.height} min={minimumExtent} max={annotationCoordinateLimit}
              onCommit={(height) => editAnnotation({ ...annotation, height: round(height) })} disabled={busy} />
          </div>}
          {annotation?.type === 'arrow' && <div className="figure-editor-coordinate" role="group" aria-label="矢印の大きさと向き">
            <NumberField key={`${selected}-length`} label="長さ" value={arrowLength} min={0} max={annotationCoordinateLimit * Math.SQRT2}
              onCommit={(length) => resizeArrow(length, arrowAngle)} disabled={busy} />
            <NumberField key={`${selected}-angle`} label="角度（度）" value={arrowAngle}
              onCommit={(angle) => resizeArrow(arrowLength, angle)} disabled={busy} />
          </div>}
          {annotation && <div className="figure-editor-coordinate" role="group" aria-label="注釈の色と太さ">
            <label className="figure-editor-value">{partNames[annotation.type]}の色
              <input type="color" value={annotation.color ?? ink} disabled={busy}
                onChange={(event) => editAnnotation({ ...annotation, color: event.target.value })} />
            </label>
            {annotation.type !== 'label' && <NumberField key={`${selected}-stroke-width`} label="線の太さ" value={annotation.strokeWidth ?? 3}
              min={minimumExtent} max={100} onCommit={(strokeWidth) => editAnnotation({ ...annotation, strokeWidth: round(strokeWidth) })}
              disabled={busy} />}
            {annotation.type === 'label' && <NumberField key={`${selected}-font-size`} label="文字サイズ" value={annotation.fontSize ?? 24}
              min={minimumExtent} max={512} onCommit={(fontSize) => editAnnotation({ ...annotation, fontSize: round(fontSize) })}
              disabled={busy} />}
          </div>}
          {annotation?.type === 'label' && <><label className="figure-editor-value">文字の太さ
            <select value={annotation.fontWeight ?? 'normal'} disabled={busy} onChange={(event) => {
              const fontWeight = event.target.value === 'bold' ? 'bold' : 'normal';
              editAnnotation({ ...annotation, fontWeight });
            }}>
              <option value="normal">標準</option><option value="bold">太字</option>
            </select>
          </label><label className="figure-editor-value">注釈の文字
            <input key={`${annotation.id}:${annotation.text}`} type="text" maxLength={1000} defaultValue={annotation.text} disabled={busy}
              onBlur={(event) => {
                const text = event.target.value.trim();
                if (text && text !== annotation.text) editAnnotation({ ...annotation, text });
                event.target.value = text || annotation.text;
              }}
              onKeyDown={(event) => { if (event.key === 'Enter') event.currentTarget.blur(); }} />
          </label></>}
          {(annotation || selectedImage) && <button type="button" disabled={busy} onClick={removePart}>
            {selectedImage ? '画像を削除' : '注釈を削除'}
          </button>}
          <p className="figure-editor-hint">
            {annotation?.type === 'box' && <>右下のハンドルで枠の大きさを変えます。<br /></>}
            {annotation?.type === 'arrow' && <>先端のハンドルで矢印の長さと向きを変えます。<br /></>}
            {selectedImage && <>右下のハンドルで画像を拡大・縮小します。<br /></>}
            部品はドラッグで移動できます。矢印キーで1、Shift＋矢印で10ずつ移動できます。
          </p>
          {layout?.kind === 'screenshot' && <div className="figure-editor-coordinate figure-editor-canvas-size" role="group" aria-label="キャンバスサイズ">
            <NumberField label="キャンバス幅" value={layout.width} min={1} max={maxCanvasAxis(layout.height)}
              onCommit={(width) => changeCanvas('width', width)} disabled={busy} />
            <NumberField label="キャンバス高さ" value={layout.height} min={1} max={maxCanvasAxis(layout.width)}
              onCommit={(height) => changeCanvas('height', height)} disabled={busy} />
          </div>}
        </aside>
      </div>
      {error && <p className="figure-editor-error" role="alert">{error}</p>}
      <footer className="figure-editor-actions">
        <button type="button" disabled={busy} onClick={onClose}>キャンセル</button>
        <button type="button" className="figure-editor-primary" disabled={!canApply || busy} onClick={() => void apply()}>
          {busy ? '反映中…' : applyLabel}
        </button>
      </footer>
    </div>
    {showParts && documentId && layout?.kind === 'screenshot' &&
      <FigurePartsDialog documentId={documentId} selected={selected} remaining={maxImages - layout.images.length}
        uploadLimit={availableUploadBytes(layout.images)}
        placed={layout.images.map((image, index) => ({
          id: imagePrefix + image.id,
          name: image.name || (image.id === primaryImageId ? '元の画像' : `画像 ${index + 1}`),
          url: imageSource(image),
        }))} accept={allowedImageTypes.join(',')} onSelect={setSelected} onAdd={addImages} onClose={() => setShowParts(false)} />}
  </dialog>;
}
