/**
 * @file Markdownに埋め込んだ独自ブロックを検出し、有効なDSL定義に従って画像・表・注意欄などのHTMLに変換する。
 */

/**
 * ブロック定義は dsl-definition.mjs の組み込み定義または文書YAMLから受け取る。
 * 各定義は、本文、区切り、図、表のいずれかの描画方式を選ぶ。
 *
 * :::type
 * ...content...
 * :::
 * を HTML に変換する。content 部分は parseFn（例: marked.parse）で再帰処理する。
 */
import { resolve } from "path";
import { layoutLength, parseColumnWidths, readMermaidLayout, splitFigureSource } from "../../../../../packages/markdown/layout.mjs";
import { resolveDslBlockKind } from "./dsl-definition.mjs";
import { scanDocumentSyntax } from "./markdown-syntax.mjs";

/**
 * ドキュメントを [markdown|dsl] セグメントに分割する
 * 開きタグの後ろに属性を記述可能: :::figure width=80%
 * @param {string} src
 * @returns {{ kind: 'md'|'dsl', text?: string, type?: string, attrs?: Record<string,string>, content?: string }[]}
 */
function splitSegments(src) {
    const segments = [];
    let last = 0;
    let block;
    let depth = 0;
    for (const entry of scanDocumentSyntax(src)) {
        if (entry.kind === "dsl-open") {
            if (!block) {
                block = entry;
            }
            depth++;
            continue;
        }
        if (!block || entry.kind !== "dsl-close" || --depth !== 0) continue;
        if (block.start > last) {
            segments.push({ kind: 'md', text: src.slice(last, block.start) });
        }
        last = entry.end;
        segments.push({
            kind: 'dsl', type: block.name, attrs: block.attributes,
            content: src.slice(block.end, entry.start),
        });
        block = undefined;
    }
    if (last < src.length) {
        segments.push({ kind: 'md', text: src.slice(last) });
    }
    return segments;
}

/**
 * DSLブロックを、定義が選んだ描画方式に沿ってHTMLに変換する。
 * @param {string} type
 * @param {Record<string,string>} attrs  開きタグ属性（例: { width: '80%' }）
 * @param {string} content
 * @param {function(string): string} parseFn
 * @param {{ assetsBaseAbs?: string|null }} ctx  アセットルートコンテキスト
 */
function buildBlock(type, attrs, content, parseFn, ctx = {}) {
    const blockMap = new Map((ctx.dslConfig?.blocks || []).map(b => [b.name, b]));
    const block = blockMap.get(type);
    // 未知のブロックはそのまま div 変換（フォールバック）
    if (!block) return `<div class="${type}">\n${parseFn(content.trimEnd())}</div>`;

    const trimmed = content.trimEnd();
    const kind = resolveDslBlockKind(block);

    // selfClosing: :::pagebreak:::
    if (kind === "separator") {
        return `<${block.element} class="${block.class}"></${block.element}>`;
    }

    // captionPosition="bottom": figure（画像 + 下キャプション）
    if (kind === "figure") {
        // width / height: 属性指定 -> スキーマ defaults -> 未指定
        const defaults = block.defaults ?? {};
        const width = attrs.width ?? defaults.width ?? null;
        const height = attrs.height ?? defaults.height ?? null;
        const sizeStyle = buildImageSizeStyle(width, height);

        // align: left / center / right（省略時は CSS クラスのデフォルト = center）
        const align = attrs.align ?? null;
        const idAttr = attrs.id ? ` id="${attrs.id}"` : '';

        const { body: bodyMd, caption } = splitFigureSource(trimmed);
        const hasImage = /^!\[/.test((bodyMd || "").trim());
        const codeFenceMatch = (bodyMd || "").trim().match(/^(?:`{3,}|~{3,})[ \t]*([^\s]*)/);
        const codeLang = (codeFenceMatch?.[1] || "").toLowerCase();
        const isNonMermaidCodeFigure = !!codeFenceMatch && codeLang !== "mermaid";
        const figureClass = isNonMermaidCodeFigure ? `${block.class} code-figure` : block.class;
        const mermaidHeight = codeLang === "mermaid" ? layoutLength(height) : undefined;
        const bodyStyle = buildFigureBodyStyle(hasImage ? null : width, codeLang === "mermaid" || hasImage ? null : height, align);
        const effectiveBody = mermaidHeight ? bodyMd.replace(/^\s*(?:`{3,}|~{3,})[ \t]*mermaid[^\r\n]*\r?\n/i,
            opening => readMermaidLayout(bodyMd.slice(opening.length)).height ? opening : `${opening}%%height:${mermaidHeight}%%\n`) : bodyMd;
        let bodyHtml = parseFn(effectiveBody).trim();

        if (hasImage) {
            // marked.parse が出力する <img> に style 属性を注入
            bodyHtml = bodyHtml.replace(/<img(\s)/gi, `<img style="${sizeStyle}"$1`);

            // 相対パスは assetsBaseAbs 起点で file:/// に解決
            const assetsBaseAbs = ctx.assetsBaseAbs ?? null;
            if (assetsBaseAbs) {
                bodyHtml = bodyHtml.replace(/(<img\b[^>]*?\bsrc=")([^"]+)(")/gi, (_, pre, src, post) => {
                    if (/^(https?:|file:|data:)/i.test(src)) return pre + src + post;
                    const clean = src.replace(/^\.\//, "");
                    const abs = resolve(assetsBaseAbs, clean).replace(/\\/g, "/");
                    return `${pre}file:///${abs}${post}`;
                });
            }
        }

        const alignStyle = align ? ` style="text-align:${align}"` : '';
        const bodyWrapper = bodyStyle
            ? `<div class="figure-body" style="${bodyStyle}">${bodyHtml}</div>`
            : bodyHtml;
        return [
            `<${block.element} class="${figureClass}"${idAttr}${alignStyle}>`,
            bodyWrapper,
            caption ? `<figcaption>${caption}</figcaption>` : '',
            `</${block.element}>`,
        ].filter(Boolean).join('\n');
    }

    // captionPosition="top": table（上キャプション + 表）
    if (kind === "table") {
        const idAttr = attrs.id ? ` id="${attrs.id}"` : '';
        const lines = trimmed.split('\n');
        // 先頭行が | で始まる場合はキャプションなし（表の本体として扱う）
        const firstIsTableRow = /^\|/.test(lines[0]?.trim() ?? '');
        const caption = firstIsTableRow ? '' : (lines[0]?.trim() ?? '');
        const bodyMd = firstIsTableRow ? trimmed : lines.slice(1).join('\n');
        const colWidths = parseColumnWidths(attrs.colRatio);

        let tableHtml = parseFn(bodyMd).trim();
        if (attrs.fontSize) {
            tableHtml = appendStyleToFirstTable(tableHtml, `font-size:${attrs.fontSize}`);
        }
        if (colWidths.length > 0) {
            tableHtml = injectColgroupToFirstTable(tableHtml, colWidths);
        }
        if (caption) {
            tableHtml = tableHtml.replace(/<table\b[^>]*>/i, opening => (
                `${opening}<caption class="table-caption">${caption}</caption>`
            ));
        }

        return [
            `<${block.element} class="${block.class}"${idAttr}>`,
            tableHtml,
            `</${block.element}>`,
        ].filter(Boolean).join('\n');
    }

    // デフォルト通常ブロック。attrs.width でインライン幅指定可能。
    const inlineStyle = attrs.width ? ` style="max-width:${attrs.width}"` : '';
    return `<${block.element} class="${block.class}"${inlineStyle}>\n${parseFn(trimmed)}</${block.element}>`;
}

/**
 * width / height 値から img 用の style 文字列を組み立てる。
 * max-width:100% は常に付与して画面幅オーバーを防ぐ。
 */
function buildImageSizeStyle(width, height) {
    const parts = ['max-width:100%'];
    if (width) parts.push(`width:${width}`);
    const boxHeight = layoutLength(height);
    if (boxHeight) parts.push(`height:${boxHeight}`, 'object-fit:contain');
    return parts.join(';');
}

/**
 * 図本体（画像/コード/Mermaid 共通）へ適用するサイズ指定スタイルを組み立てる。
 */
function buildFigureBodyStyle(width, height, align) {
    const parts = [];
    if (width) parts.push(`width:${width}`);
    if (height && height !== 'auto') {
        parts.push(`max-height:${height}`);
    }
    if (parts.length > 0) {
        const a = String(align || '').toLowerCase();
        if (a === 'left') {
            parts.push('margin:0 auto 0 0');
        } else if (a === 'right') {
            parts.push('margin:0 0 0 auto');
        } else {
            parts.push('margin:0 auto');
        }
    }
    return parts.join(';');
}

/**
 * 先頭の <table> タグへ style を追記する。
 */
function appendStyleToFirstTable(tableHtml, styleChunk) {
    if (!styleChunk) return tableHtml;
    return tableHtml.replace(/<table\b([^>]*)>/i, (match, attrs) => {
        if (/\sstyle="/i.test(attrs)) {
            return `<table${attrs.replace(/\sstyle="([^"]*)"/i, (_m, s) => ` style="${s}; ${styleChunk}"`)}>`;
        }
        return `<table${attrs} style="${styleChunk}">`;
    });
}

/**
 * 先頭の <table> タグ直後へ colgroup を挿入する。
 * colgroup を付与する場合は table-layout: fixed も同時に設定し、
 * 列幅比率がセル内容に引っ張られないようにする。
 */
function injectColgroupToFirstTable(tableHtml, widths) {
    if (!Array.isArray(widths) || widths.length === 0) return tableHtml;
    const colgroup = `<colgroup>${widths.map(w => `<col style="width:${w}">`).join('')}</colgroup>`;
    return tableHtml.replace(/<table\b([^>]*)>/i, (_, attrs) => {
        // class="col-fixed" を付与（既存 class があれば追記）
        let newAttrs = /\bclass="/i.test(attrs)
            ? attrs.replace(/\bclass="([^"]*)"/i, 'class="$1 col-fixed"')
            : attrs + ' class="col-fixed"';
        // table-layout: fixed を style に追記（既存 style があれば追記）
        newAttrs = /\bstyle="/i.test(newAttrs)
            ? newAttrs.replace(/\bstyle="([^"]*)"/i, 'style="$1; table-layout: fixed"')
            : newAttrs + ' style="table-layout: fixed"';
        return `<table${newAttrs}>${colgroup}`;
    });
}

/**
 * :::hide ... ::: ブロックをソースから除去する（ネスト対応）。
 *
 * 行単位でネスト深度を追跡するため、内部に他の ::: ブロックが
 * あっても正しく除去される。
 *
 * @param {string} src
 * @returns {string}
 */
function stripHideBlocks(src) {
    const lines = src.split(/\r?\n/);
    const out = [];
    let depth = 0;
    for (const line of lines) {
        if (depth === 0) {
            if (/^:::hide(?:\s|$)/.test(line)) {
                depth = 1; // hide ブロック開始。この行は出力しない
            } else {
                out.push(line);
            }
        } else {
            // hide ブロック内はすべて出力しない
            if (/^:::\w/.test(line)) {
                depth++; // 任意のネスト開きタグ
            } else if (/^:::(?!\w)/.test(line)) {
                depth--; // 閉じタグ
            }
        }
    }
    return out.join('\n');
}

/**
 * Markdown ソースに含まれる独自DSLブロックを HTML に変換する
 *
 * @param {string} markdown
 * @param {function(string): string} parseFn  - marked.parse などの Markdown→HTML 関数
 * @param {{ assetsBaseAbs?: string|null }} ctx  アセットルートコンテキスト
 * @returns {string} HTML
 */
export function transformDSL(markdown, parseFn, ctx = {}) {
    const segments = splitSegments(stripHideBlocks(markdown));
    return segments
        .map(seg => {
            if (seg.kind === 'md') return parseFn(seg.text);
            return buildBlock(seg.type, seg.attrs, seg.content, parseFn, ctx);
        })
        .join('\n');
}

