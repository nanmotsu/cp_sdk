/**
 * @file ブラウザーのルートにReactのアプリを描画し、全体のスタイルを読み込む。
 */

import { createRoot } from 'react-dom/client';
import App from './App';
import './styles.css';

createRoot(document.getElementById('root')!).render(<App />);
