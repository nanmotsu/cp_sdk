/**
 * @file GUIの文書プレビューと、ビジュアル編集用の表紙・図・書式を描画する。
 */

import { basename, dirname, extname } from "node:path";
import { resolveDslBlockKind } from "../shared/dsl-definition.mjs";
import { prepareMarkup } from "../shared/markup.mjs";
import { renderMermaidFigures } from "../shared/mermaid.mjs";
import { generateConfigCSS, resolveAssetsBaseAbs } from "../shared/render-common.mjs";
import { coverMarkup, htmlDocument, renderDocument } from "../shared/rendering.mjs";
import { resolveRenderingSettings, structureCss } from "../shared/settings.mjs";
import { layoutLength } from "../../../../../packages/markdown/layout.mjs";
import { headingNumberLevels } from "../../../../../packages/markdown/headings.mjs";

const visualStyleKeys = new Set([
    "background", "background-color", "border", "border-left", "border-radius", "color", "font-size", "font-style",
    "font-weight", "line-height", "margin", "max-width", "padding", "text-align", "text-decoration",
]);

/** 有効なDSLを、編集中のDOMに適用できる表示情報に絞って返す。 */
function visualLayout(dsl, heading) {
    const blocks = dsl.blocks.map(block => {
        const styles = Object.entries(block.styles ?? {}).filter(([key, value]) => visualStyleKeys.has(key)
            && typeof value === "string" && !/[;{}\\@]|\b(?:url|image-set)\s*\(/i.test(value));
        return {
            name: block.name,
            label: typeof block.snippet?.description === "string" && block.snippet.description.trim() ? block.snippet.description : block.name,
            kind: resolveDslBlockKind(block),
            styles: Object.fromEntries(styles.map(([key, value]) => [key.replace(/-([a-z])/g, (_, letter) => letter.toUpperCase()), value])),
            defaults: { width: layoutLength(block.defaults?.width), height: layoutLength(block.defaults?.height) },
        };
    });
    const levels = headingNumberLevels(heading.levels);
    return {
        blocks,
        headingLevels: heading.numbering ? levels : [],
        figurePrefix: dsl.blocks.find(block => block.name === "figure")?.captionPrefix || "図",
        tablePrefix: dsl.blocks.find(block => block.name === "table")?.captionPrefix || "表",
    };
}

/** ビジュアル編集用の表紙、DSLの表示設定、入力順のMermaid描画結果を返す。 */
export async function renderVisualElements({ fallbackTitle, diagrams, sourcePath, documentRoot, config, assetUrl, signal }) {
    signal?.throwIfAborted();
    const { page, style, dsl } = resolveRenderingSettings(config);
    const warnings = [];
    const title = config.title || fallbackTitle || basename(sourcePath, extname(sourcePath));
    const cover = coverMarkup(config, title);
    let visualCover = null;
    if (cover) {
        const sourceDir = dirname(sourcePath);
        const bodyHtml = await prepareMarkup(cover, {
            assetsBase: resolveAssetsBaseAbs(config, sourceDir), sourceDir, documentRoot, assetUrl, warnings,
        });
        const css = [
            generateConfigCSS({ styleConfig: style, dslConfig: dsl, pageCfg: page }),
            structureCss,
            `html, body { margin: 0; padding: 0; }
            .title-page { min-height: 100vh; padding: 24px; overflow-wrap: anywhere; }
            .title-page .cover-image { max-height: min(var(--cover-max-height), 245px); object-fit: contain; }`,
        ].join("\n");
        visualCover = { html: htmlDocument({ title, css, bodyHtml }), hasImage: Boolean(config.cover) };
    }
    const figures = await renderMermaidFigures(diagrams, { fontSize: style.typography.fontSize.body, signal }).catch(() => {
        signal?.throwIfAborted();
        return diagrams.map(() => ({ error: "Mermaidを描画できませんでした。ChromeまたはChromiumを確認してください。" }));
    });
    return { cover: visualCover, diagrams: figures, layout: visualLayout(dsl, style.heading), warnings };
}

/** 編集中の本文を右側のプレビューで表示するHTMLと警告へ変換する。 */
export async function renderPreview(input) {
    const { html, warnings } = await renderDocument(input, "preview");
    return { html, warnings };
}
