/**
 * @file 変換や生成を行うジョブを開始し、終了まで状態を読み取るReactフック。
 */

import { useEffect, useRef, useState } from 'react';
import { api, ApiError, errorMessage } from './api';
import type { Job, JobPayload } from './api';

/** 1つの操作欄でジョブの受付・実行・結果・中断を管理する。 */
export function useJob<T>() {
  const [job, setJob] = useState<Job<T> | null>(null);
  const [error, setError] = useState('');
  const [posting, setPosting] = useState(false);
  const [canceling, setCanceling] = useState(false);
  const active = useRef(false);
  const jobId = job?.status === 'queued' || job?.status === 'running' ? job.id : undefined;

  useEffect(() => {
    if (!jobId) return;
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout>;

    /** 現在のジョブだけを定期取得する。完了・履歴からの消失・画面離脱でポーリングを終える。 */
    async function poll() {
      try {
        const { job: current } = await api.job<T>(jobId!, controller.signal);
        if (controller.signal.aborted) return;
        setError('');
        setJob((previous) => previous?.id === current.id && ['queued', 'running'].includes(previous.status)
          ? current : previous);
        if (current.status !== 'queued' && current.status !== 'running') return;
      } catch (exception) {
        if (controller.signal.aborted) return;
        if (exception instanceof ApiError && exception.status === 404) {
          setJob(null);
          setError(errorMessage(exception));
          return;
        }
        setError(errorMessage(exception));
      }
      timer = setTimeout(poll, 600);
    }

    timer = setTimeout(poll, 300);
    return () => {
      controller.abort();
      clearTimeout(timer);
    };
  }, [jobId]);

  /** 同じ操作欄からの重複受付を抑えながら、新規ジョブを登録する。 */
  async function start(payload: JobPayload) {
    if (active.current || jobId) return;
    active.current = true;
    setError('');
    setPosting(true);
    setJob(null);
    try {
      const result = await api.startJob<T>(payload);
      setJob(result.job);
    } catch (exception) {
      setError(errorMessage(exception));
    } finally {
      active.current = false;
      setPosting(false);
    }
  }

  /** 実行中または待機中のジョブへ中断を要求し、サーバーが返した状態を反映する。 */
  async function cancel() {
    if (!jobId || canceling) return;
    setCanceling(true);
    try {
      const result = await api.cancelJob<T>(jobId);
      setJob(result.job);
    } catch (exception) {
      setError(errorMessage(exception));
    } finally {
      setCanceling(false);
    }
  }

  return { job, error, posting, canceling, busy: posting || Boolean(jobId), start, cancel };
}

/** 進捗表示や各操作欄が使うフックの状態・操作型。 */
export type JobState<T> = ReturnType<typeof useJob<T>>;
