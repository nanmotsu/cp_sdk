import { useEffect, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { errorMessage } from '../../api';
import type { DocumentInfo } from '../../api';
import { useJob } from '../../useJob';
import { JobFeedback } from '../Feedback';
import SourceBrowseDialog from '../SourceBrowseDialog';
import { traceApi } from './api';
import type { CreateInput, RunResult, Summary } from './api';
import './traceability.css';

function dateLabel(value?: string) {
  if (!value || Number.isNaN(Date.parse(value))) return '更新日不明';
  return new Intl.DateTimeFormat('ja-JP', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value));
}

function SourceField({ label, value, onChange, documents, disabled }: {
  label: string; value: string; onChange: (value: string) => void; documents: DocumentInfo[]; disabled: boolean;
}) {
  const [browse, setBrowse] = useState(false);
  return <fieldset className="trace-source-field" disabled={disabled}>
    <legend>{label}</legend>
    <label>アプリ内の文書<select value="" onChange={event => onChange(event.target.value)}>
      <option value="">文書から選択</option>
      {documents.flatMap(doc => doc.files.map(file => <option key={doc.id + '/' + file.path}
        value={'documents/' + doc.id + '/' + file.path}>{doc.name} / {file.path}</option>))}
    </select></label>
    <label>ファイル・フォルダのパスまたはURI<input required value={value} onChange={event => onChange(event.target.value)}
      placeholder="C:\\projects\\要件.xlsx または file:///…" /></label>
    <button type="button" onClick={() => setBrowse(true)}>ファイル・フォルダを選ぶ</button>
    {browse && <SourceBrowseDialog onClose={() => setBrowse(false)} onChoose={path => { onChange(path); setBrowse(false); }} />}
  </fieldset>;
}

export default function TraceabilityLibrary({ documents, onOpen }: { documents: DocumentInfo[]; onOpen: (id: string) => void }) {
  const [entries, setEntries] = useState<Summary[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState('');
  const [sourceUri, setSourceUri] = useState('');
  const [targetUri, setTargetUri] = useState('');
  const [granularity, setGranularity] = useState('');
  const request = useRef<CreateInput | undefined>(undefined);
  const handled = useRef('');
  const task = useJob<RunResult>();
  useEffect(() => {
    let active = true;
    traceApi.list().then(result => { if (active) setEntries(result.traceabilities); })
      .catch(exception => { if (active) setError(errorMessage(exception)); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);
  useEffect(() => {
    if (task.job?.status === 'succeeded' && task.job.result?.id && handled.current !== task.job.id) {
      handled.current = task.job.id;
      onOpen(task.job.result.id);
    }
  }, [task.job, onOpen]);

  async function create(event: FormEvent) {
    event.preventDefault();
    if (task.busy || !window.confirm(`「${name.trim()}」を新規作成し、資料同士の関係を調査しますか？`)) return;
    const values = { name: name.trim(), sourceUri: sourceUri.trim(), targetUri: targetUri.trim(), granularity: granularity.trim() };
    if (!request.current || Object.entries(values).some(([key, value]) => request.current?.[key as keyof CreateInput] !== value)) {
      request.current = { requestId: crypto.randomUUID(), ...values };
    }
    await task.start({ type: 'traceability-create', ...request.current });
  }

  const filtered = entries.filter(entry => entry.name.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()));
  return <section className="trace-library" aria-label="トレーサビリティ一覧">
    <div className="library-heading"><h2>トレーサビリティ</h2>
      <label className="library-search">タイトルで検索<input type="search" value={query} onChange={event => setQuery(event.target.value)} placeholder="関係のタイトルを入力" /></label>
    </div>
    {error && <p className="error" role="alert">{error}</p>}
    {loading ? <p role="status">読み込み中…</p> : <div className="trace-card-grid">
      {filtered.map(entry => <button key={entry.id} className="trace-card" onClick={() => onOpen(entry.id)} disabled={task.busy}>
        <strong>{entry.name}</strong><span className="trace-card-path">{entry.sourceUri}</span><span aria-hidden="true">↓</span><span className="trace-card-path">{entry.targetUri}</span>
        <span>最終更新日 {dateLabel(entry.updatedAt)}</span>
        <small>{entry.id.slice(0, 8)}</small>
      </button>)}
      <button className="trace-card trace-new" type="button" onClick={() => { setCreating(true); request.current = undefined; }} disabled={task.busy}>
        <span aria-hidden="true">＋</span>新規トレーサビリティ
      </button>
    </div>}
    {creating && <form className="trace-create" onSubmit={create} aria-label="新規トレーサビリティ">
      <div className="subsection-head"><h3>新規トレーサビリティ</h3><button type="button" disabled={task.busy} onClick={() => setCreating(false)}>閉じる</button></div>
      <label>タイトル<input required value={name} maxLength={255} onChange={event => setName(event.target.value)} disabled={task.busy} /></label>
      <div className="trace-source-grid">
        <SourceField label="元ドキュメント" value={sourceUri} onChange={setSourceUri} documents={documents} disabled={task.busy} />
        <SourceField label="先ドキュメント" value={targetUri} onChange={setTargetUri} documents={documents} disabled={task.busy} />
      </div>
      <label>項目を抜き出す粒度<textarea required value={granularity} onChange={event => setGranularity(event.target.value)} disabled={task.busy}
        rows={3} placeholder="例：利用者ができる操作ごとに要件を分ける。先は各操作を実現する仕様・処理単位で抜き出す。" /></label>
      <div className="form-actions"><button className="primary" type="submit" disabled={task.busy || !name.trim() || !sourceUri.trim() || !targetUri.trim() || !granularity.trim()}>
        関係を調査して作成
      </button></div>
      <JobFeedback state={task} />
    </form>}
  </section>;
}
