/**
 * @file 文書機能が利用する生成エージェントの契約。接続先ごとの形式はアダプターが引き受ける。
 */

/**
 * @typedef {"edit-document" | "compose-figure" | `traceability-${"generate" | "revise" | "check"}-${"related" | "source" | "target" | "map"}`} AgentPurpose
 * @typedef {{ line: number, character: number }} FilePosition 0始まりの行・文字位置。
 * @typedef {{ start: FilePosition, end: FilePosition }} FileRange
 * @typedef {{ kind: "file", uri: string, label: string, role: "document" | "directory", range?: FileRange }} FileAttachment
 * @typedef {{ kind: "image", mime: string, label: string, bytes: Uint8Array }} ImageAttachment
 * @typedef {{ mime: string, bytes: Buffer }} GeneratedImage Copilotの画像生成ツールが返した画像。
 * @typedef {{ id: string, title: string, modifiedAt?: string }} AgentSession
 * @typedef {{ id: string, name: string, supportsVision?: boolean }} AgentModel
 * @typedef {{ available: boolean, message: string, protocolVersion?: string, models?: AgentModel[] }} AgentStatus
 */

/**
 * 生成を始めるたびに、その時点の依頼と添付を指定する。セッションIDは再利用先の識別子として扱う。
 * @typedef {object} AgentRequest
 * @property {AgentPurpose} purpose 実行する文書機能。
 * @property {string} prompt 今回の依頼と必要な文脈。
 * @property {Array<FileAttachment | ImageAttachment>} [attachments] 今回参照できるファイルと画像。
 * @property {string} [sessionId] 再利用するセッションの識別子。
 * @property {string} [sessionTitle] 新規セッションの名前。
 * @property {string} [modelId] 利用者が選んだモデルの識別子。
 * @property {AbortSignal} [signal] 実行の中断。
 * @property {(message: string) => void} [onProgress] 利用者向けの進捗通知。
 */

/**
 * テストでは同じ契約を実装した模擬応答を注入できる。
 * @typedef {object} Agent
 * @property {() => Promise<AgentStatus>} status 接続と利用可能モデルを確認する。
 * @property {(options?: { signal?: AbortSignal }) => Promise<AgentSession[]>} listSessions 作業場所のセッションを一覧する。
 * @property {(request: AgentRequest) => Promise<{ text: string, session?: AgentSession, generatedImages?: GeneratedImage[] }>} complete 今回の依頼を実行する。
 */
