import { createHash, randomUUID } from 'node:crypto';
import { copyFile, mkdir, readFile, readdir, rename, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { badRequest, conflict } from '../common/api/errors.mjs';
import { atomicWrite, pathParts, statIfPresent, workspacePath } from '../common/filesystem/paths.mjs';

const versionPattern = /^[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}$/;
const hash = value => createHash('sha256').update(value).digest('hex');

async function names(folder) {
  return (await readdir(folder)).filter(name => name.toLowerCase() !== 'backups').sort();
}

async function* walk(folder, prefix = '') {
  const entries = prefix ? (await readdir(join(folder, prefix))).sort() : await names(folder);
  for (const name of entries) {
    const path = prefix ? prefix + '/' + name : name;
    pathParts(path);
    const info = await statIfPresent(join(folder, path));
    if (!info?.isFile() && !info?.isDirectory()) throw badRequest('全体履歴に含められない項目です: ' + path);
    const absolute = await workspacePath(folder, path, { directory: info.isDirectory() });
    yield { path, absolute, directory: info.isDirectory() };
    if (info.isDirectory()) yield* walk(folder, path);
  }
}

/** 空フォルダを含め、通常の関係データ全体を複製する。 */
export async function copyRelation(from, to) {
  await mkdir(to);
  for await (const entry of walk(from)) {
    const dest = join(to, entry.path);
    if (entry.directory) await mkdir(dest);
    else await copyFile(entry.absolute, dest);
  }
}

export async function relationManifest(folder) {
  const files = {};
  for await (const entry of walk(folder)) files[entry.path] = entry.directory ? 'directory' : hash(await readFile(entry.absolute));
  return files;
}

export async function relationRevision(folder) {
  return hash(JSON.stringify(await relationManifest(folder)));
}

/** state の JSON を差し替えた全体版を履歴として公開する。 */
export async function captureRelation(folder, state, metadata, id = randomUUID()) {
  const history = join(folder, 'backups');
  await mkdir(history, { recursive: true });
  const temp = join(history, '.' + id);
  await mkdir(temp);
  try {
    await copyRelation(folder, join(temp, 'tree'));
    for (const [name, value] of Object.entries(state)) {
      pathParts(name);
      await writeFile(join(temp, 'tree', name), value);
    }
    await writeFile(join(temp, 'metadata.json'), JSON.stringify({
      format: 2, ...metadata, id, createdAt: new Date().toISOString(),
    }, null, 2) + '\n');
    await rename(temp, join(history, id));
    return id;
  } finally {
    await rm(temp, { recursive: true, force: true });
  }
}

export async function openRelationVersion(folder, id) {
  if (typeof id !== 'string' || !versionPattern.test(id)) throw badRequest('版 ID が不正です。');
  const base = await workspacePath(folder, 'backups/' + id, { directory: true });
  const metadata = JSON.parse(await readFile(await workspacePath(base, 'metadata.json'), 'utf8'));
  if (metadata.id !== id || metadata.format !== 2) throw badRequest('履歴の形式を確認してください。');
  const tree = await workspacePath(base, 'tree', { directory: true });
  return { metadata, tree };
}

export async function relationHistory(folder) {
  const base = join(folder, 'backups');
  if (!await statIfPresent(base)) return [];
  const result = [];
  for (const name of await readdir(base)) {
    if (versionPattern.test(name)) result.push((await openRelationVersion(folder, name)).metadata);
  }
  return result.sort((a, b) => b.createdAt.localeCompare(a.createdAt) || b.id.localeCompare(a.id));
}

/** 置換途中の停止から、実行前の関係へ戻す。 */
export async function recoverRelation(folder) {
  const stage = join(folder, 'backups', '.transaction');
  if (!await statIfPresent(stage)) return;
  const phasePath = join(stage, 'phase');
  const phase = await statIfPresent(phasePath) ? await readFile(phasePath, 'utf8') : '';
  if (phase === 'replace') {
    for (const name of await names(folder)) await rename(join(folder, name), join(stage, 'next', name));
    await atomicWrite(phasePath, 'move-old');
  }
  if (phase === 'replace' || phase === 'move-old') {
    for (const name of await readdir(join(stage, 'previous'))) {
      if (await statIfPresent(join(folder, name))) throw conflict('復旧対象と現行の項目が重複しています: ' + name);
      await rename(join(stage, 'previous', name), join(folder, name));
    }
  }
  if (phase && !['done', 'replace', 'move-old'].includes(phase)) throw conflict('保存処理の状態を読み取れません。');
  await rm(stage, { recursive: true, force: true });
}

/** 履歴を維持してデータ全体を置換し、中断時は次回アクセスでロールバックする。 */
export async function replaceRelation(folder, sourceTree, expectedRevision) {
  const stage = join(folder, 'backups', '.transaction');
  await mkdir(stage);
  try {
    await copyRelation(sourceTree, join(stage, 'next'));
    await mkdir(join(stage, 'previous'));
    if (await relationRevision(folder) !== expectedRevision) throw conflict('処理中に関係が更新されました。再読み込みしてください。');
    await atomicWrite(join(stage, 'phase'), 'move-old');
    for (const name of await names(folder)) await rename(join(folder, name), join(stage, 'previous', name));
    await atomicWrite(join(stage, 'phase'), 'replace');
    for (const name of await readdir(join(stage, 'next'))) await rename(join(stage, 'next', name), join(folder, name));
    await atomicWrite(join(stage, 'phase'), 'done');
  } catch (error) {
    await recoverRelation(folder);
    throw error;
  }
  await rm(stage, { recursive: true, force: true });
}

/** 保存内容の差をファイル、項目 ID、列ごとに返す。 */
export async function relationDiff(beforeFolder, afterFolder) {
  const before = await relationManifest(beforeFolder);
  const after = await relationManifest(afterFolder);
  const files = [...new Set([...Object.keys(before), ...Object.keys(after)])].sort().flatMap(path =>
    before[path] === after[path] ? [] : [{ path, change: before[path] === undefined ? 'added' : after[path] === undefined ? 'removed' : 'modified' }]);
  const rows = [];
  for (const file of ['source-items.json', 'target-items.json', 'mappings.json']) {
    const a = JSON.parse(await readFile(join(beforeFolder, file), 'utf8'));
    const b = JSON.parse(await readFile(join(afterFolder, file), 'utf8'));
    const left = a.items ?? a.rows;
    const right = b.items ?? b.rows;
    const old = new Map(left.map(row => [row.id, row]));
    const next = new Map(right.map(row => [row.id, row]));
    for (const id of new Set([...old.keys(), ...next.keys()])) {
      const x = old.get(id), y = next.get(id);
      if (!x || !y) rows.push({ file, id, change: x ? 'removed' : 'added', before: x ?? null, after: y ?? null });
      else {
        const cells = [...new Set([...Object.keys(x), ...Object.keys(y)])].flatMap(column =>
          JSON.stringify(x[column]) === JSON.stringify(y[column]) ? [] : [{ column, before: x[column] ?? null, after: y[column] ?? null }]);
        if (cells.length) rows.push({ file, id, change: 'modified', cells });
      }
    }
    const common = new Set([...old.keys()].filter(id => next.has(id)));
    const l = left.filter(row => common.has(row.id)).map(row => row.id);
    const r = right.filter(row => common.has(row.id)).map(row => row.id);
    if (JSON.stringify(l) !== JSON.stringify(r)) rows.push({ file, change: 'reordered', before: l, after: r });
  }
  return { files, rows };
}
