/**
 * @file プレビュー、PDF、Wordで共用するHTMLと前付けを組み立てる。
 */

import { basename, dirname, extname } from "node:path";
import { Marked } from "marked";
import { transformDSL } from "./dsl.mjs";
import {
    applyCaptionNumbersToHtml,
    applyOrderedListStyleClasses,
    buildPreviewHeader,
    buildTitlePage,
    generateConfigCSS,
    generateOrderedListStyleCSS,
    resolveAssetsBaseAbs,
    resolveDslBodyWithWarnings,
} from "./render-common.mjs";
import { buildRevisionHistoryPage, buildTOC, linkHeadings } from "./layout.mjs";
import { escapeHtml, prepareMarkup } from "./markup.mjs";
import { renderMermaidBlocks } from "./mermaid.mjs";
import { resolveRenderingSettings, structureCss } from "./settings.mjs";


const marked = new Marked({ gfm: true, breaks: false });
/** GFMの設定を共有してMarkdownをHTMLへ変換する。 */
const parseMarkdown = source => marked.parse(source);
const htmlPolicy = "default-src 'none'; img-src data: 'self'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'";
/** 設定と文書タイトルから表紙を作る。改訂履歴に合わせてタイトルを補う場合がある。 */
export function coverMarkup(config, title) {
    const history = config.revisionHistory;
    const inferTitle = Array.isArray(history) && history.length > 0;
    return buildTitlePage({
        ...config,
        title: escapeHtml(config.title || (inferTitle && !config.cover ? title : "")),
        subtitle: escapeHtml(config.subtitle),
        cover: escapeHtml(config.cover),
    });
}

/** 描画用の本文とCSSを、表示制限を含む独立したHTMLにまとめる。 */
export function htmlDocument({ title, css, bodyHtml, bodyClass = "" }) {
    const html = `<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="Content-Security-Policy" content="${htmlPolicy}">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(title)}</title>
  <style>${css.replace(/<\/style/gi, "\\3c /style")}</style>
</head>
<body${bodyClass}>${bodyHtml}</body>
</html>`;
    return html;
}

/** Markdownから図表と画像を解決し、出力先に合わせて前付けとCSSを組み立てる。 */
export async function renderDocument({ content, sourcePath, documentRoot, config = {}, assetUrl, signal, includeRevisionHistory }, output) {
    signal?.throwIfAborted();
    const word = output === "docx";
    const settings = resolveRenderingSettings(config);
    const { page, style, dsl } = settings;
    const { markdown, warnings } = resolveDslBodyWithWarnings(content.replace(/^\uFEFF/, ""), style, dsl);
    const sourceDir = dirname(sourcePath);
    const assetsBase = resolveAssetsBaseAbs(config, sourceDir);
    const markupOptions = { assetsBase, sourceDir, documentRoot, assetUrl, warnings };
    const listStyle = config.orderedListStyle;
    let bodyHtml = transformDSL(markdown, parseMarkdown, { dslConfig: dsl });
    bodyHtml = applyCaptionNumbersToHtml(bodyHtml, style.heading, dsl);
    bodyHtml = applyOrderedListStyleClasses(bodyHtml, listStyle);
    bodyHtml = await prepareMarkup(bodyHtml, markupOptions);
    const { html: withAnchors, headings } = linkHeadings(bodyHtml);
    bodyHtml = withAnchors;
    const title = config.title || headings.find(heading => heading.level === 1)?.title || basename(sourcePath, extname(sourcePath));
    const revisionHistory = buildRevisionHistoryPage(config, output, output === "pdf" ? includeRevisionHistory : undefined);
    if (!word) {
        const headingPage = coverMarkup(config, title);
        const contents = buildTOC(headings, config, parseMarkdown, page);
        const decoration = [headingPage, revisionHistory, contents].join("\n");
        bodyHtml = `${await prepareMarkup(decoration, markupOptions)}\n${bodyHtml}`;
    } else if (revisionHistory) {
        bodyHtml = `${await prepareMarkup(revisionHistory, markupOptions)}\n${bodyHtml}`;
    }
    bodyHtml = await renderMermaidBlocks(bodyHtml, {
        warnings, fontSize: style.typography.fontSize.body, raster: word, signal,
    });
    signal?.throwIfAborted();
    if (word) return { title, page, bodyHtml, warnings };

    const css = [
        generateConfigCSS({ styleConfig: style, dslConfig: dsl, pageCfg: page }),
        structureCss,
        generateOrderedListStyleCSS(listStyle),
    ].join("\n");
    const bodyClass = page.paragraphIndent ? ' class="indent-body"' : "";
    const header = output === "preview" ? await buildPreviewHeader(page, markupOptions) : "";
    const html = htmlDocument({ title, css, bodyHtml: header + bodyHtml, bodyClass });
    return { html, page, warnings, markupOptions };
}
