import { createHash } from 'node:crypto';

export function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === 'object') return Object.fromEntries(Object.keys(value).sort().map(key => [key, canonical(value[key])]));
  return value;
}

export function businessHash(value) {
  return createHash('sha256').update(JSON.stringify(canonical(value))).digest('hex');
}

/** 項目表の業務内容だけで④の確認通知を決める。 */
export function reviewStatus(current, saved, basis, inputVersion) {
  return Object.fromEntries(['source', 'target'].map(side => {
    const currentHash = businessHash(current[side]);
    if (!inputVersion && current.mappings.rows.length === 0) {
      return [side, { status: 'not-created', message: '判定未作成', currentHash }];
    }
    const record = saved?.[side];
    const baselineHash = record?.hash ?? (basis ? businessHash(basis[side]) : undefined);
    const baselineVersion = record?.version ?? (basis ? inputVersion : undefined);
    const status = baselineHash ? baselineHash !== currentHash ? 'changed' : record ? 'confirmed' : 'unconfirmed'
      : inputVersion || record ? 'unavailable' : 'unconfirmed';
    const label = side === 'source' ? '元項目表' : '先項目表';
    const message = status === 'changed' ? (record ? label + 'が変更されました。判定に影響する可能性があります。' : '判定後に' + label + 'が変更されました。')
      : status === 'unavailable' ? '比較元の版を読み込めません。' : status === 'confirmed' ? '確認済み' : baselineHash ? '未確認' : '未確認（比較元なし）';
    return [side, { status, message, currentHash, baselineHash, baselineVersion, confirmedAt: record?.confirmedAt }];
  }));
}
