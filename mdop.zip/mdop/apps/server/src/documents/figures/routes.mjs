/**
 * @file 図版・画像素材・文書付属ファイルをHTTPで管理・配信する。
 */

import { readJson, sendFile, sendJson } from "../../common/api/http.mjs";
import { assetHeaders } from "./asset-links.mjs";

/** 図版と資産のルートを登録する。 */
export function figureRoutes(documents, figures, uploads) {
    return [
        ["GET", "/documents/:id/parts", async (_request, response, { id }) =>
            sendJson(response, 200, { parts: await documents.access(id, () => figures.listParts(id)) })],
        ["GET", "/documents/:id/figures", async (_request, response, { id }) =>
            sendJson(response, 200, { figures: await documents.access(id, () => figures.list(id)) })],
        ["POST", "/documents/:id/figures", async (request, response, { id }) => {
            const input = await readJson(request, uploads);
            return sendJson(response, 201, { figure: await documents.access(id, () => figures.create(id, input)) });
        }],
        ["POST", "/documents/:id/figures/prepare-svg", async (request, response, { id }) => {
            await documents.documentRoot(id);
            const { svg } = await readJson(request);
            return sendJson(response, 200, { svg: figures.prepareSvg(svg) });
        }],
        ["GET", "/documents/:id/figures/:figureId", async (_request, response, { id, figureId }) =>
            sendJson(response, 200, { figure: await documents.access(id, () => figures.get(id, figureId)) })],
        ["PUT", "/documents/:id/figures/:figureId", async (request, response, { id, figureId }) => {
            const input = await readJson(request, uploads);
            return sendJson(response, 200, { figure: await documents.access(id, () => figures.update(id, figureId, input)) });
        }],
        [["GET", "HEAD"], "/documents/:id/figures/:figureId/parts/:partId", async (request, response, { id, figureId, partId }) => {
            const asset = await documents.access(id, () => figures.part(id, figureId, partId));
            return sendFile(request, response, asset.absolute, asset.type, assetHeaders(asset));
        }],
        [["GET", "HEAD"], "/documents/:id/assets", async (request, response, { id }, url) => {
            const asset = await documents.asset(id, url.searchParams.get("path"));
            return sendFile(request, response, asset.absolute, asset.type, assetHeaders(asset));
        }],
        ["POST", "/documents/:id/assets", async (request, response, { id }) => {
            const { name, base64 } = await readJson(request, uploads);
            const mime = documents.imageMime(name);
            const figure = await documents.access(id, () => figures.importImage(id, { name, mime, base64 }));
            return sendJson(response, 201, { path: figure.path, figure });
        }],
    ];
}
