/**
 * @file 過去のMarkdownと作業中のMarkdownを、追加・削除・共通の行に分ける。
 */

/** 色と行番号の表示に使う、比較結果の1行。 */
export type DiffLine = { kind: 'same' | 'removed' | 'added'; text: string; before?: number; after?: number };

/** 片側に1回だけ出る共通行を、前後の順序が変わらない範囲で比較の目印にする。 */
function anchors(before: string[], after: string[]) {
  const positions = (lines: string[]) => {
    const map = new Map<string, number>();
    lines.forEach((line, i) => map.set(line, map.has(line) ? -1 : i));
    return map;
  };
  const oldPositions = positions(before);
  const nextPositions = positions(after);
  const matches: { old: number; next: number; previous?: number }[] = [];
  const tails: number[] = [];
  before.forEach((line, old) => {
    const next = nextPositions.get(line);
    if (oldPositions.get(line) !== old || next === undefined || next < 0) return;
    let start = 0;
    let end = tails.length;
    while (start < end) {
      const middle = Math.floor((start + end) / 2);
      if (matches[tails[middle]].next < next) start = middle + 1;
      else end = middle;
    }
    const previous = tails[start - 1];
    tails[start] = matches.push({ old, next, previous }) - 1;
  });
  const result: { old: number; next: number }[] = [];
  for (let index = tails.at(-1); index !== undefined; index = matches[index].previous) result.push(matches[index]);
  return result.reverse();
}

/** Myersの行差分を使い、変更の少ない長文も行数の積に比例する処理を避ける。 */
function matchLines(before: string[], after: string[]) {
  const steps: Int32Array[] = [];
  let budget = 1_500_000;
  for (let depth = 0; depth <= Math.min(512, before.length + after.length); depth++) {
    const previous = steps.at(-1);
    const positions = new Int32Array(depth + 1);
    steps.push(positions);
    for (let index = 0; index <= depth; index++) {
      const diagonal = 2 * index - depth;
      let old = !previous ? 0 : descends(previous, index, depth) ? previous[index] : previous[index - 1] + 1;
      let next = old - diagonal;
      while (old < before.length && next < after.length && before[old] === after[next]) {
        if (--budget < 0) return undefined;
        old++;
        next++;
      }
      positions[index] = old;
      if (old === before.length && next === after.length) return commonLines(steps, old, next);
    }
  }
  return undefined;
}

/** 同じ対角線に達する二つの経路のうち、より先に進める経路を選ぶ。 */
function descends(previous: Int32Array, index: number, depth: number) {
  return index === 0 || (index < depth && previous[index - 1] < previous[index]);
}

/** 差分探索の経路を逆順にたどり、対応する共通行を求める。 */
function commonLines(steps: Int32Array[], old: number, next: number) {
  const matches: { old: number; next: number }[] = [];
  for (let depth = steps.length - 1; depth > 0; depth--) {
    const diagonal = old - next;
    const index = (diagonal + depth) / 2;
    const previous = steps[depth - 1];
    const down = descends(previous, index, depth);
    const oldStart = previous[down ? index : index - 1];
    const nextStart = oldStart - diagonal - (down ? 1 : -1);
    while (old > oldStart && next > nextStart) matches.push({ old: --old, next: --next });
    old = oldStart;
    next = nextStart;
  }
  while (old > 0 && next > 0) matches.push({ old: --old, next: --next });
  return matches.reverse();
}

/** 過去の版を基準にし、改行コードを正規化して行単位で比較する。 */
export function compareMarkdown(before: string, after: string): DiffLine[] {
  const split = (text: string) => text ? text.replace(/(?:\r\n|\r|\n)$/, '').split(/\r\n|\r|\n/) : [];
  const old = split(before);
  const next = split(after);
  const lines: DiffLine[] = [];
  /** 共通行で区切り、間の範囲を過去側・現在側の順で出す。 */
  function append(startOld: number, endOld: number, startNext: number, endNext: number, canPartition: boolean) {
    let a = startOld;
    let b = startNext;
    if (a === endOld || b === endNext) {
      for (; a < endOld; a++) lines.push({ kind: 'removed', text: old[a], before: a + 1 });
      for (; b < endNext; b++) lines.push({ kind: 'added', text: next[b], after: b + 1 });
      return;
    }
    const oldSlice = old.slice(a, endOld);
    const nextSlice = next.slice(b, endNext);
    const common = Math.abs(oldSlice.length - nextSlice.length) <= 512 ? matchLines(oldSlice, nextSlice) : undefined;
    const points = common ?? (canPartition ? anchors(oldSlice, nextSlice) : []);
    for (const point of [...points, { old: oldSlice.length, next: nextSlice.length }]) {
      const i = startOld + point.old;
      const j = startNext + point.next;
      if (!common && (i > a || j > b) && points.length) append(a, i, b, j, false);
      else {
        for (; a < i; a++) lines.push({ kind: 'removed', text: old[a], before: a + 1 });
        for (; b < j; b++) lines.push({ kind: 'added', text: next[b], after: b + 1 });
      }
      if (i < endOld) lines.push({ kind: 'same', text: old[i], before: i + 1, after: j + 1 });
      a = i + 1;
      b = j + 1;
    }
  }
  append(0, old.length, 0, next.length, true);
  return lines;
}
