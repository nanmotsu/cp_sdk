/**
 * @file ブラウザーなしで、描画設定の既定値・文書設定の優先順位・図表参照を検証する。
 */

import assert from "node:assert/strict";
import { parseConfig } from "../apps/server/src/documents/config/yaml.mjs";
import { DEFAULT_DSL, resolveDslBlockKind } from "../apps/server/src/documents/shared/dsl-definition.mjs";
import {
    DEFAULT_PAGE,
    DEFAULT_STYLE,
    resolveEffectivePageConfig,
    resolveEffectiveStyleConfig,
    resolveRenderingSettings,
} from "../apps/server/src/documents/shared/settings.mjs";
import { resolveDslBodyWithWarnings } from "../apps/server/src/documents/shared/render-common.mjs";

const page = resolveEffectivePageConfig({
    margin: { top: "20mm" },
    headerFooter: {
        enabled: true,
        footer: { center: "<span class='pageNumber'></span>" },
    },
}, {
    ...DEFAULT_PAGE,
    headerFooter: {
        enabled: false,
        fontSize: "9px",
        header: { left: "Document" },
        footer: { right: "Example" },
    },
});
assert.equal(page.margin.top, "20mm");
assert.equal(page.margin.left, DEFAULT_PAGE.margin.left);
assert.equal(page.headerFooter.enabled, true);
assert.equal(page.headerFooter.header.left, "Document");
assert.equal(page.headerFooter.footer.center, "<span class='pageNumber'></span>");
assert.equal(page.headerFooter.footer.right, "Example");

const style = resolveEffectiveStyleConfig({ headingNumbering: false }, DEFAULT_STYLE);
assert.equal(style.heading.numbering, false);
assert.equal(DEFAULT_STYLE.heading.numbering, true);

const { config, diagnostics } = parseConfig("typography:\n  fontSize:\n    body: 18px\ndsl:\n  blocks:\n    - {name: note, element: aside, class: note}\n");
assert.deepEqual(diagnostics, []);
const settings = resolveRenderingSettings(config);
assert.deepEqual(settings.style.typography.fontSize, { ...DEFAULT_STYLE.typography.fontSize, body: "18px" });
assert.deepEqual(settings.dsl.blocks.map(block => block.name), ["note"]);
assert.equal(resolveDslBlockKind(settings.dsl.blocks[0]), "text");
assert.deepEqual(DEFAULT_DSL.blocks.slice(-3).map(resolveDslBlockKind), ["separator", "figure", "table"]);

const canonicalSettings = parseConfig("headingNumbering: false\nheading: {levels: [h1]}\norderedListStyle: {level1: decimal, level2: paren-upper-alpha}\n");
assert.deepEqual(canonicalSettings.diagnostics, []);
assert.deepEqual(resolveRenderingSettings(canonicalSettings.config).style.heading, { numbering: false, levels: ["h1"] });
for (const [source, key] of [
    ["toc: 1", "toc"],
    ["headerFooter: {enabled: 'yes'}", "headerFooter.enabled"],
    ["heading: {numbering: true}", "heading.numbering"],
    ["revisionHistoryPage: false", "revisionHistoryPage"],
    ["numberedListStyle: {level1: decimal}", "numberedListStyle"],
    ["orderedListStyle: {top: decimal}", "orderedListStyle.top"],
    ["orderedListStyle: {level2: '(A)'}", "orderedListStyle.level2"],
    ["htmlOutputDir: output", "htmlOutputDir"],
]) {
    const parsed = parseConfig(source);
    assert.equal(parsed.config, null);
    assert.ok(parsed.diagnostics.some(message => message.includes(key)), source);
}

const resolved = resolveDslBodyWithWarnings(
    "# Section\n\nSee {{ref:fig-a}} and {{ref:missing}}.\n\n:::figure id=fig-a\nCaption\n:::\n",
    DEFAULT_STYLE,
    DEFAULT_DSL,
);
assert.match(resolved.markdown, /図1\.1/);
assert.deepEqual(resolved.warnings, ["未解決参照: missing"]);

assert.throws(
    () => resolveDslBodyWithWarnings(
        ":::figure id=duplicate\nOne\n:::\n\n:::figure id=duplicate\nTwo\n:::\n",
        DEFAULT_STYLE,
        DEFAULT_DSL,
    ),
    /参照IDが重複しています/,
);

console.log("unit tests passed");
