/**
 * @file 図版の画像素材を検証し、生成案を図版ストア用の配置データへ変換する。
 */

import { badRequest } from "../../common/api/errors.mjs";
import { figureFormats } from "../figures/formats.mjs";
import { FIGURE_LAYER_LIMIT, FIGURE_RASTER_LIMIT } from "../figures/store.mjs";
import { ASSET_LIMIT, decodeBase64, textInput } from "../shared/input.mjs";

/** AIに渡すローカル素材の識別子と画像の合計サイズを確認する。 */
export function figureMaterials(input) {
    if (!Array.isArray(input) || input.length > FIGURE_LAYER_LIMIT) throw badRequest(`図版の素材は${FIGURE_LAYER_LIMIT}枚以内で指定してください。`);
    const ids = new Set();
    let totalBytes = 0;
    return input.map(item => {
        const { id, mime, base64 } = item ?? {};
        const name = textInput(item?.name, "name", 512).trim();
        if (!name || typeof id !== "string" || !/^[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}$/.test(id)
            || ids.has(id) || !Object.hasOwn(figureFormats, mime)) throw badRequest("図版の画像素材を確認してください。");
        ids.add(id);
        const original = decodeBase64(base64, FIGURE_RASTER_LIMIT);
        totalBytes += original.length;
        if (totalBytes > ASSET_LIMIT) throw badRequest("図版の画像素材は合計20 MiBまでです。");
        return { id, name, mime, original };
    });
}

/** 検証済みのAI図版案を、送信用画像を介さず元の素材から組み立てる。 */
export function figureFromDraft(draft, materials) {
    const sources = new Map([...materials, ...(draft.generatedMaterials ?? [])].map(image => [image.id, image]));
    const images = [];
    const uploads = [];
    for (const { sourceId, svg, ...placement } of draft.images) {
        const source = svg === undefined ? sources.get(sourceId) : { mime: "image/svg+xml", original: Buffer.from(svg) };
        images.push(placement);
        uploads.push({ id: placement.id, mime: source.mime, base64: source.original.toString("base64") });
    }
    return { kind: "raster", name: draft.name, annotations: draft.annotations,
        composition: { width: draft.width, height: draft.height, images, uploads } };
}
