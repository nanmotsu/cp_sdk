/**
 * @file 保存した版の比較、復元、個別削除を行う。
 */

import { useEffect, useMemo, useRef, useState } from 'react';
import { api, errorMessage } from '../api';
import type { BackupDetail, BackupReason, BackupSummary } from '../api';
import { compareMarkdown } from '../editor/lineDiff';
import { hasUnsavedChanges, useWorkspace } from '../workspace';
import type { OpenFile } from '../workspace';
import { Warnings } from './Feedback';

const reasons: Record<BackupReason, string> = {
  initial: '履歴開始時の原本',
  save: '保存',
  word: 'Word取り込み',
  copilot: 'Copilot編集案',
  'copilot-figure': 'Copilot編集案（図版を調整）',
  'before-restore': '復元前の退避',
};
const dateFormat = new Intl.DateTimeFormat('ja-JP', { dateStyle: 'short', timeStyle: 'medium' });
const changeLabels = { added: '追加', removed: '削除', modified: '変更' };
const linesPerPage = 500;

/** 一覧と削除の確認に、版の日時と作成理由を表示する。 */
function backupLabel(backup: BackupSummary) {
  const label = backup.label ? `（${backup.label}）` : '';
  return `${dateFormat.format(new Date(backup.createdAt))}　${reasons[backup.reason]}${label}`;
}

/** 追加・削除の符号と色を使い、行数が多い場合は順次表示する。 */
function HistoryDiff({ before, after }: { before: string; after: string }) {
  const [mode, setMode] = useState<'diff' | 'full' | 'original'>('diff');
  const [limit, setLimit] = useState(linesPerPage);
  const lines = useMemo(() => compareMarkdown(before, after), [before, after]);
  const visible = useMemo(() => mode === 'full' ? lines : lines.filter(line => line.kind !== 'same'), [mode, lines]);
  return <section className="stack" aria-label="本文の比較">
    <label>本文の表示
      <select value={mode} onChange={event => {
        setMode(event.target.value as typeof mode);
        setLimit(linesPerPage);
      }}>
        <option value="diff">差分のみ</option>
        <option value="full">全文と差分</option>
        <option value="original">選んだ版の本文</option>
      </select>
    </label>
    {mode === 'original' ? <pre className="diff history-original" tabIndex={0} aria-label="選んだ版のMarkdown">{before}</pre>
      : visible.length ? <>
        <p className="history-legend"><span className="diff-removed">− 選んだ版の行</span>
          <span className="diff-added">＋ 現在の行</span></p>
        <div className="diff" tabIndex={0} aria-label="Markdownの差分">
          {visible.slice(0, limit).map(({ kind, text, before: old, after: next }) => <div
            key={`${kind}-${old ?? next}`} className={`diff-${kind}`}>
            <span className="history-line-number" aria-hidden="true">{old ?? next}</span>
            <span className="diff-marker" aria-hidden="true">{kind === 'added' ? '+' : kind === 'removed' ? '−' : ' '}</span>{text || ' '}
          </div>)}
        </div>
        {visible.length > limit && <button type="button" onClick={() => setLimit(value => value + linesPerPage)}>
          次の行を表示（残り {visible.length - limit} 行）
        </button>}
      </> : <p className="muted">{before === after ? '本文の差分はありません。' : '改行コードまたは末尾の改行が異なります。'}</p>}
  </section>;
}

/** 一覧と比較を切り替え、復元前に比較した文書と作業本文を確かめる。 */
export default function HistoryPanel({ documentId: id, file, selectedId, onSelect, version, disabled, onRestore }: {
  documentId: string;
  file: OpenFile | null;
  selectedId: string;
  onSelect: (id: string) => void;
  version: string;
  disabled: boolean;
  onRestore: (detail: BackupDetail) => Promise<void>;
}) {
  const [backups, setBackups] = useState<BackupSummary[] | null>(null);
  const [listError, setListError] = useState('');
  const [comparison, setComparison] = useState<{ detail: BackupDetail; content: string } | null>(null);
  const [compareError, setCompareError] = useState('');
  const [deleteError, setDeleteError] = useState('');
  const [deleting, setDeleting] = useState(false);
  const deleteRequest = useRef<AbortController | null>(null);
  const [refresh, setRefresh] = useState(0);
  const selected = backups?.find(backup => backup.id === selectedId) ?? backups?.[0];
  const backupId = selected?.id;
  const detail = comparison?.detail.backup.id === backupId ? comparison?.detail : undefined;
  const externalEdit = !!(detail && file && detail.current?.revision !== file.revision);
  const edited = !!(detail && file && !externalEdit && file.content !== comparison?.content);
  const dirty = hasUnsavedChanges(file);
  const changedFiles = detail?.files.filter(change => detail.file?.path !== detail.current?.path || change.path !== detail.file?.path) ?? [];
  const difference = detail && ((detail.file?.content ?? '') !== comparison?.content || detail.files.length > 0 || detail.sharedConfigChanged);
  const blocked = disabled || deleting;

  useEffect(() => () => deleteRequest.current?.abort(), [id]);

  useEffect(() => {
    const controller = new AbortController();
    setListError('');
    api.backups(id, controller.signal).then(result => {
      if (!controller.signal.aborted) setBackups(result.backups);
    }).catch(error => {
      if (!controller.signal.aborted) setListError(errorMessage(error));
    });
    return () => controller.abort();
  }, [id, refresh, version]);

  useEffect(() => {
    setComparison(null);
    setCompareError('');
    if (!backupId) return;
    const controller = new AbortController();
    api.backup(id, backupId, controller.signal).then(result => {
      if (controller.signal.aborted) return;
      const editor = useWorkspace.getState().file;
      const current = editor?.documentId === id && editor.revision === result.current?.revision ? editor.content : result.current?.content ?? '';
      setComparison({ detail: result, content: current });
    }).catch(error => {
      if (!controller.signal.aborted) setCompareError(errorMessage(error));
    });
    return () => controller.abort();
  }, [id, backupId, refresh, version]);

  /** 確認した版だけを削除し、残りの履歴から次の比較対象を選ぶ。 */
  async function deleteSelected() {
    if (!selected || blocked || deleteRequest.current) return;
    if (!window.confirm(`${backupLabel(selected)}\n\nこのバックアップを削除しますか？ 削除した版は復元できません。`)) return;
    const controller = new AbortController();
    deleteRequest.current = controller;
    setDeleting(true);
    setDeleteError('');
    try {
      const { deletedId } = await api.deleteBackup(id, selected.id, controller.signal);
      if (controller.signal.aborted) return;
      setBackups(current => current?.filter(backup => backup.id !== deletedId) ?? []);
      onSelect('');
      setRefresh(value => value + 1);
    } catch (error) {
      if (!controller.signal.aborted) setDeleteError(errorMessage(error));
    } finally {
      if (!controller.signal.aborted) {
        deleteRequest.current = null;
        setDeleting(false);
      }
    }
  }

  return <div className="form-panel stack history-panel">
    <div className="subsection-head">
      <h3>文書の履歴</h3>
      <button type="button" disabled={blocked} onClick={() => {
        setDeleteError('');
        setRefresh(value => value + 1);
      }}>履歴と差分を更新</button>
    </div>
    {listError && <p className="error" role="alert">{listError}</p>}
    {!backups && !listError && <p className="muted" role="status">履歴を読み込んでいます…</p>}
    {backups?.length === 0 && <p className="muted">履歴はまだありません。保存、Word取り込み、Copilot編集案の作成で追加されます。</p>}
    {selected && <>
      <label>比較する版
        <select value={selected.id} onChange={event => {
          setDeleteError('');
          onSelect(event.target.value);
        }} disabled={blocked}>
          {backups?.map(backup => <option key={backup.id} value={backup.id}>{backupLabel(backup)}</option>)}
        </select>
      </label>
      <div className="form-actions">
        <button className="history-delete" type="button" disabled={blocked}
          onClick={() => void deleteSelected()}>{deleting ? '削除中…' : 'この版を削除'}</button>
      </div>
    </>}
    {deleteError && <p className="error" role="alert">{deleteError}</p>}
    {selected && !detail && !compareError && <p className="muted" role="status">選んだ版と比較しています…</p>}
    {compareError && <p className="error" role="alert">{compareError}</p>}
    {detail && comparison && <>
      <Warnings warnings={detail.backup.warnings} />
      {externalEdit && <p className="muted">{dirty
        ? 'ディスクと編集中の本文が両方変更されています。編集中の内容を確認してから文書を開き直してください。'
        : 'ディスク上の最新の状態と比較しています。'}</p>}
      {edited && <p className="muted" role="status">比較後に本文が変わりました。「履歴と差分を更新」で比較し直せます。</p>}
      {detail.file || detail.current ? <HistoryDiff key={`${backupId}/${refresh}/${version}`}
        before={detail.file?.content ?? ''} after={comparison.content} />
        : <p className="muted">比較できる原本Markdownがありません。</p>}
      <section className="stack" aria-label="フォルダ内の変更">
        <h4>設定・画像・出力などの差分</h4>
        {changedFiles.length ? <ul className="history-files">
          {changedFiles.map(({ path, change, directory }) => <li key={path} data-change={change}>
            <span>{changeLabels[change]}</span> <code>{path}{directory ? '/' : ''}</code>
          </li>)}
        </ul> : <p className="muted">変更された付属ファイルはありません。</p>}
        {detail.sharedConfigChanged && <p className="muted">共通設定の適用状態または内容が異なります。</p>}
      </section>
      <div className="form-actions">
        <button className="primary" type="button" disabled={blocked || !difference || edited || (externalEdit && dirty)}
          onClick={() => void onRestore(detail)}>この版を復元</button>
      </div>
      <p className="muted">{dirty ? '復元前の編集中の内容も、履歴に退避します。'
        : '復元すると、本文と付属ファイルが選んだ版の状態になります。'}</p>
    </>}
  </div>;
}
