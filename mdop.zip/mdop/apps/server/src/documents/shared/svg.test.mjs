/**
 * @file 編集可能なSVGの構造と、描画寸法の上限を検証する。
 */

import assert from "node:assert/strict";
import test from "node:test";
import { normalizeFigureSvg } from "./svg.mjs";

/** 複数ルート、外部への参照、描画できる要素がないSVGを保存対象から除くことを検証する。 */
test("generated SVG rejects multiple roots, external definitions and no drawable content", () => {
    assert.throws(() => normalizeFigureSvg("<svg><rect /></svg><svg />"), /最上位/);
    assert.throws(() => normalizeFigureSvg("<svg><!DOCTYPE svg></svg>"), /外部定義/);
    assert.throws(() => normalizeFigureSvg("<svg><script>1</script></svg>"), /図形や文字/);
    assert.throws(() => normalizeFigureSvg(" ".repeat(256 * 1024 + 1)), /256 KiB/);
});

/** 大きいSVGの論理座標を維持して、実寸を上限内に収める。 */
test("generated SVG preserves the viewBox and limits dimensions", () => {
    const source = '<svg viewBox="0 0 3200 1600"><rect width="3200" height="1600"/></svg>';
    const svg = normalizeFigureSvg(source);
    assert.match(svg, /viewBox="0 0 3200 1600"/);
    assert.match(svg, /^<svg[^>]*width="1600" height="800"/);
});
