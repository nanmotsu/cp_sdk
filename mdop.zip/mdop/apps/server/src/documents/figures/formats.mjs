/**
 * @file 図版の素材として使う画像形式と、ブラウザーに渡すバイト列の検証。
 */

import { normalizeFigureSvg } from "../shared/svg.mjs";

/** 保存時の拡張子をメディア種別から決める。 */
export const figureFormats = {
    "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp",
    "image/gif": "gif", "image/bmp": "bmp", "image/svg+xml": "svg",
};

/** 図版素材を確認する。SVGは外部参照を除いた編集用の形式に整える。 */
export function validateFigureMaterial(bytes, mime) {
    if (mime === "image/svg+xml") return Buffer.from(normalizeFigureSvg(bytes.toString("utf8")));
    const valid = mime === "image/png" ? bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))
        : mime === "image/jpeg" ? bytes.subarray(0, 3).equals(Buffer.from([255, 216, 255]))
        : mime === "image/webp" ? bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP"
        : mime === "image/gif" ? /^GIF8[79]a$/.test(bytes.toString("ascii", 0, 6))
        : mime === "image/bmp" && bytes.toString("ascii", 0, 2) === "BM";
    if (!valid) throw new Error("画像の内容と形式が一致しません。");
    return bytes;
}
