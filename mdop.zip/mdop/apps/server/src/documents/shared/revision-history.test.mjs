/**
 * @file 改訂履歴の設定検証と、出力先ごとに掲載内容が切り替わることを検証する。
 */

import assert from "node:assert/strict";
import { resolve } from "node:path";
import test from "node:test";
import JSZip from "jszip";
import { parseConfig } from "../config/yaml.mjs";
import { renderDocx, renderPdf } from "../export/render.mjs";
import { renderPreview, renderVisualElements } from "../preview/render.mjs";
import { buildRevisionHistoryPage } from "./layout.mjs";

const documentRoot = resolve(".");
const input = {
    documentRoot,
    sourcePath: resolve(documentRoot, "index.md"),
    content: "# Document title\n\nDocument body.\n",
};
const history = [{ version: "1.0", description: "Saved change history" }];

/** 出力先ごとの表示設定と個別出力の指定が有効に働くことを検証する。 */
test("revision visibility accepts output overrides and validates each configured field", () => {
    const { config, diagnostics } = parseConfig(`revisionHistoryVisibility:
  preview: true
  pdf: false
revisionHistory:
  - version: "1.0"
    description: Saved change history
`);
    assert.deepEqual(diagnostics, []);
    assert.deepEqual(config.revisionHistoryVisibility, { preview: true, pdf: false });
    assert.deepEqual(config.revisionHistory, history);
    assert.match(buildRevisionHistoryPage(config), /Saved change history/);
    assert.equal(buildRevisionHistoryPage(config, "pdf"), "");
    assert.match(buildRevisionHistoryPage(config, "docx"), /Saved change history/);
    assert.match(buildRevisionHistoryPage(config, "pdf", true), /Saved change history/);
    assert.equal(buildRevisionHistoryPage({ revisionHistory: history }, "pdf", false), "");
    assert.equal(buildRevisionHistoryPage({}, "pdf", true), "");

    const invalid = parseConfig('revisionHistoryVisibility: {html: true, pdf: 0, preview: "yes"}\n');
    assert.equal(invalid.config, null);
    assert.match(invalid.diagnostics.join("\n"), /revisionHistoryVisibility\.html/);
    assert.match(invalid.diagnostics.join("\n"), /revisionHistoryVisibility\.pdf/);
    assert.match(invalid.diagnostics.join("\n"), /revisionHistoryVisibility\.preview/);
    assert.equal(parseConfig("revisionHistoryVisibility: false\n").config, null);
});

/** プレビューとWordが掲載設定を別々に参照し、表紙の扱いに影響しないことを検証する。 */
test("the preview and Word choose history separately while the cover stays consistent", async () => {
    const config = { revisionHistory: history, revisionHistoryVisibility: { preview: false, docx: true } };
    const preview = await renderPreview({ ...input, config });
    assert.match(preview.html, /<p class="doc-title">Document title<\/p>/);
    assert.doesNotMatch(preview.html, /Saved change history/);
    const visual = await renderVisualElements({ ...input, fallbackTitle: "Document title", diagrams: [], config });
    assert.match(visual.cover.html, /<p class="doc-title">Document title<\/p>/);

    const docx = await renderDocx({ ...input, config });
    const docxWithHistory = await JSZip.loadAsync(docx.buffer);
    assert.match(await docxWithHistory.file("word/document.xml").async("string"), /Saved change history/);
    const withoutHistory = await renderDocx({ ...input, config: {
        ...config, revisionHistoryVisibility: { preview: true, docx: false },
    } });
    const docxWithoutHistory = await JSZip.loadAsync(withoutHistory.buffer);
    assert.doesNotMatch(await docxWithoutHistory.file("word/document.xml").async("string"), /Saved change history/);
});

/** 指定された1回のPDF出力だけ、文書で設定した履歴の掲載を上書きできることを検証する。 */
test("a one-off PDF choice overrides the configured revision history page", {
    skip: process.env.MD_OPERATOR_TEST_CHROME !== "1",
}, async () => {
    const config = { titlePage: false, toc: false, revisionHistory: history, revisionHistoryVisibility: { pdf: false } };
    const excluded = await renderPdf({ ...input, config });
    const included = await renderPdf({ ...input, config, includeRevisionHistory: true });
    const pageCount = buffer => [...buffer.toString("latin1").matchAll(/\/Type\s*\/Page\b/g)].length;
    assert.equal(pageCount(excluded.buffer), 1);
    assert.equal(pageCount(included.buffer), 2);
});
