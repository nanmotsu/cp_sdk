/**
 * @file ローカルHTTPの入口で要求元と入力を確認し、応答形式を統一する。
 */

import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import { pipeline } from "node:stream/promises";
import { ApiError, badRequest } from "./errors.mjs";

const localhost = /^(?:127\.0\.0\.1|localhost|\[::1\])(?::\d{1,5})?$/i;

/** Hostを確認し、書き込みなどの要求ではブラウザーが送る取得元情報も検証する。 */
export function checkLocalRequest(request) {
    if (!localhost.test(request.headers.host ?? "")) throw new ApiError(403, "LOCAL_HOST_REQUIRED", "ローカルのURLからアクセスしてください。");
    if (request.method === "GET" || request.method === "HEAD") return;
    const origin = request.headers.origin;
    if (request.headers["sec-fetch-site"] === "cross-site" || (origin && !/^https?:\/\//i.test(origin))) {
        throw new ApiError(403, "LOCAL_ORIGIN_REQUIRED", "ローカルの画面から操作してください。");
    }
    if (origin && !localhost.test(origin.replace(/^https?:\/\//i, ""))) {
        throw new ApiError(403, "LOCAL_ORIGIN_REQUIRED", "ローカルの画面から操作してください。");
    }
}

/** Content-Typeとサイズを確認してリクエスト本文を読み、JSONオブジェクトを返す。 */
export async function readJson(request, { limit = 12 * 1024 * 1024 } = {}) {
    if (!/^application\/json(?:\s*;|$)/i.test(request.headers["content-type"] ?? "")) {
        throw new ApiError(415, "JSON_REQUIRED", "Content-Type: application/json を指定してください。");
    }
    const tooLarge = new ApiError(413, "PAYLOAD_TOO_LARGE", "リクエストのサイズが上限を超えています。");
    if (Number(request.headers["content-length"]) > limit) {
        request.resume();
        throw tooLarge;
    }
    const chunks = [];
    let size = 0;
    for await (const chunk of request.iterator({ destroyOnReturn: false })) {
        size += chunk.length;
        if (size > limit) {
            request.resume();
            throw tooLarge;
        }
        chunks.push(chunk);
    }
    let data;
    try {
        data = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    } catch {
        throw badRequest("JSONの内容を確認してください。");
    }
    if (!data || typeof data !== "object" || Array.isArray(data)) throw badRequest("JSONオブジェクトを指定してください。");
    return data;
}

/** JSONをUTF-8で返す。ローカルの編集中データがキャッシュに残らないようにする。 */
export function sendJson(response, status, value) {
    const content = JSON.stringify(value);
    response.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
    response.end(content);
}

/** 例外を共通のエラー応答に変換する。想定外の内部例外はログと利用者向けの応答を分ける。 */
export function sendError(response, error) {
    const upstreamStatus = error.statusCode;
    const exposed = error instanceof ApiError || (Number.isInteger(upstreamStatus) && upstreamStatus >= 400 && upstreamStatus <= 599);
    const status = exposed ? (error.status ?? upstreamStatus) : error.code === "ENOENT" ? 404 : 500;
    if (status === 500 && !exposed) console.error(error);
    sendJson(response, status, {
        error: {
            code: exposed ? (error.code ?? "INTEGRATION_ERROR") : status === 404 ? "NOT_FOUND" : "INTERNAL_ERROR",
            message: exposed ? error.message : status === 404 ? "ファイルが見つかりません。" : "サーバーで処理できませんでした。",
            ...(exposed && error.details !== undefined ? { details: error.details } : {}),
        },
    });
}

/** 指定された種別でファイルを送信する。HEADではヘッダーだけを返す。 */
export async function sendFile(request, response, path, type, extraHeaders = {}) {
    const { size } = await stat(path);
    response.writeHead(200, {
        "Content-Type": type,
        "Content-Length": size,
        "Cache-Control": "no-store",
        "X-Content-Type-Options": "nosniff",
        ...extraHeaders,
    });
    if (request.method === "HEAD") return response.end();
    await pipeline(createReadStream(path), response);
}
