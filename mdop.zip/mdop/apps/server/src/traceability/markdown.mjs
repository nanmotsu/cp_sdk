const cell = value => String(value ?? '').replace(/\|/g, '\\|').replace(/\r?\n/g, '<br>');

/** 画面と同じ行・件数・確認通知を Markdown に出力する。 */
export function traceabilityMarkdown(detail) {
  const { config, source, target, matrix, review } = detail;
  const lines = ['# ' + config.name, '', '元資料 ' + config.sourceUri, '', '先資料 ' + config.targetUri, '',
    '粒度 ' + config.granularity, '', '関係性調査 ' + (config.assessment?.status ?? '記録なし'), '', config.assessment?.reason ?? '',
    '', '保存版 ' + (detail.version ?? detail.revision), '',
    '元項目 ' + matrix.total + '件、' + Object.entries(matrix.counts).map(([key, count]) => key + ' ' + count + '件').join('、'), '',
    ...Object.entries(review).map(([side, state]) => (side === 'source' ? '元項目表 ' : '先項目表 ') + state.message), '',
    '| 元 ID | 元項目 | 元の位置 | 先項目・位置 | 対応度 | 対応詳細 | 特記事項 |',
    '| --- | --- | --- | --- | --- | --- | --- |'];
  for (const row of matrix.rows) {
    const references = row.targets.map(item => item.missing ? item.id + '（参照先なし）' : item.id + ' ' + item.content + '（' + item.location + '）' + (item.notes ? ' ' + item.notes : '')).join('\n');
    lines.push('| ' + [row.source.id, row.source.content, row.source.location, references, row.mapping?.degree ?? '判定未作成',
      row.mapping?.detail, [row.source.notes, row.mapping?.notes].filter(Boolean).join('\n')].map(cell).join(' | ') + ' |');
  }
  if (matrix.orphans.length) {
    lines.push('', '## 元項目なし', '', '| 判定 ID | 元 ID | 先 ID | 対応度 | 詳細 |', '| --- | --- | --- | --- | --- |');
    for (const row of matrix.orphans) lines.push('| ' + [row.id, row.sourceId, row.targetIds.join(', '), row.degree, row.detail].map(cell).join(' | ') + ' |');
  }
  for (const [label, table] of [['元資料', source], ['先資料', target]]) {
    lines.push('', '## ' + label + 'の読取範囲', '', ...table.scope.read.map(value => '- 読取済み ' + value),
      ...table.scope.unread.map(value => '- 未読 ' + value));
  }
  return lines.join('\n') + '\n';
}
