export const FIGURES_DIRECTORY: string;
export const FIGURE_PARTS_DIRECTORY: string;
export const figureIdPattern: RegExp;
export function isFigureImagePath(path: string): boolean;
