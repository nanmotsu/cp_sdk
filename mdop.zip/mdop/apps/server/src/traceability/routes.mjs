import { readJson, sendJson } from '../common/api/http.mjs';
import { ApiError, badRequest } from '../common/api/errors.mjs';

function exposed(error) {
  if (error.status) return error;
  if (error.code === 'ENOENT') return new ApiError(404, 'TRACEABILITY_NOT_FOUND', 'トレーサビリティまたは履歴が見つかりません。');
  return new ApiError(/競合|変わり|一致|進行中/.test(error.message) ? 409 : 400, 'TRACEABILITY_INPUT', error.message);
}
const handle = fn => async (...args) => {
  try { return await fn(...args); } catch (error) { throw exposed(error); }
};

export function traceabilityRoutes(store) {
  return [
    ['GET', '/traceabilities', handle(async (_request, response) => sendJson(response, 200, { traceabilities: await store.list() }))],
    ['GET', '/traceabilities/:id', handle(async (_request, response, { id }) => sendJson(response, 200, { traceability: await store.get(id) }))],
    ['PUT', '/traceabilities/:id', handle(async (request, response, { id }) =>
      sendJson(response, 200, { traceability: await store.save(id, await readJson(request)) }))],
    ['POST', '/traceabilities/:id/review', handle(async (request, response, { id }) =>
      sendJson(response, 200, { traceability: await store.confirm(id, await readJson(request)) }))],
    ['GET', '/traceabilities/:id/history', handle(async (_request, response, { id }) =>
      sendJson(response, 200, { history: await store.history(id) }))],
    ['GET', '/traceabilities/:id/history/:version', handle(async (_request, response, { id, version }) =>
      sendJson(response, 200, { traceability: await store.get(id, version) }))],
    ['GET', '/traceabilities/:id/diff', handle(async (_request, response, { id }, url) =>
      sendJson(response, 200, { diff: await store.diff(id, url.searchParams.get('from') || undefined, url.searchParams.get('to') || undefined) }))],
    ['POST', '/traceabilities/:id/restore', handle(async (request, response, { id }) => {
      const { version, revision } = await readJson(request);
      return sendJson(response, 200, { traceability: await store.restore(id, version, { revision }) });
    })],
    ['GET', '/traceabilities/:id/markdown', handle(async (_request, response, { id }, url) => {
      const body = await store.markdown(id, url.searchParams.get('version') || undefined);
      response.writeHead(200, { 'Content-Type': 'text/markdown; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
      response.end(body);
    })],
  ];
}

export function traceabilityJobs(store, jobs, assistance) {
  function checkInput(input) {
    if (typeof input.instruction === 'string' && input.instruction.length > 32_000) throw badRequest('依頼内容は32,000文字以内にしてください。');
    if (input.throughEnd && input.mode !== 'generate') throw badRequest('ここから最後までは新規生成で選んでください。');
    if (input.sessionId !== undefined) throw badRequest('セッションはツールが関係ごとに選択します。');
  }
  return {
    'traceability-create': input => {
      checkInput(input);
      return jobs.add(input.type, options => assistance.create(input, options));
    },
    'traceability-run': async input => {
      checkInput(input);
      await store.get(input.traceabilityId);
      return jobs.add(input.type, options => assistance.run(input.traceabilityId, input, options));
    },
  };
}
