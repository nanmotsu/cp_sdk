/**
 * @file 文書フォルダ内のパス検証と、ファイルを途中の状態にせず置き換える共通処理。
 */

import { randomUUID } from "node:crypto";
import { lstat, mkdir, rename, rm, writeFile } from "node:fs/promises";
import { basename, dirname, join } from "node:path";
import { badRequest, notFound } from "../api/errors.mjs";

const reservedWindowsName = /^(?:con|prn|aux|nul|com[1-9¹²³]|lpt[1-9¹²³])(?:\.|$)/i;

/** スラッシュ区切りの相対パスを分解する。移動要素、空要素、Windowsの予約名は400として拒否する。 */
export function pathParts(value) {
    if (typeof value !== "string" || value.length > 1024 || value.includes("\\")) {
        throw badRequest("相対パスを / 区切りで指定してください。");
    }
    const parts = value.split("/");
    if (parts.some(part => !part || part === "." || part === ".." || part.length > 255
        || /[\x00-\x1f<>:"|?*]/.test(part) || /[. ]$/.test(part) || reservedWindowsName.test(part))) {
        throw badRequest(`使用できない相対パスです: ${value}`);
    }
    return parts;
}

/** リンクをたどらずにファイル情報を取得する。不在の場合は null を返す。 */
export async function statIfPresent(path) {
    try {
        return await lstat(path);
    } catch (error) {
        if (error.code !== "ENOENT") throw error;
        return null;
    }
}

/** 基準フォルダから各階層を順に検査し、通常ファイルまたはディレクトリのパスを返す。作成前は mayBeMissing で未作成の末尾を許容できる。 */
export async function workspacePath(root, value, { mayBeMissing = false, directory = false } = {}) {
    const parts = pathParts(value);
    let path = root;
    for (const [index, part] of parts.entries()) {
        path = join(path, part);
        const entry = await statIfPresent(path);
        const last = index === parts.length - 1;
        if (!entry) {
            if (mayBeMissing) return join(path, ...parts.slice(index + 1));
            throw notFound(`見つかりません: ${value}`);
        }
        if (entry.isSymbolicLink() || (!(last && !directory) && !entry.isDirectory())
            || (last && !directory && !entry.isFile())) {
            throw badRequest(`文書内の通常の${directory ? "フォルダ" : "ファイル"}を指定してください: ${value}`);
        }
    }
    return path;
}

/** 文書内の指定先を必要に応じて作成し、作成後にパスの種類を再検査する。 */
export async function ensureWorkspaceDirectory(root, value) {
    const path = await workspacePath(root, value, { mayBeMissing: true, directory: true });
    await mkdir(path, { recursive: true });
    return workspacePath(root, value, { directory: true });
}

/** 同じディレクトリの一時ファイルに全量を書いてから、移動で公開する。公開前に中断を確認し、一時ファイルは結果にかかわらず除去する。 */
export async function atomicWrite(path, data, { signal } = {}) {
    const temp = join(dirname(path), `.${randomUUID()}-${basename(path).slice(0, 32)}.tmp`);
    try {
        await writeFile(temp, data, { flag: "wx" });
        signal?.throwIfAborted();
        await rename(temp, path);
    } finally {
        await rm(temp, { force: true });
    }
}
