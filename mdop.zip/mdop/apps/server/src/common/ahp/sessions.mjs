/**
 * @file AHPのセッション設定、一覧、作成、既定チャットの準備を扱う。
 */

import { ApiError } from '../api/errors.mjs';
import { ROOT } from './client.mjs';
import { disconnected, shortDetail } from './errors.mjs';

/** Agent Hostで利用可能なセッション設定を問い合わせる。 */
export function resolveSessionConfig(connection, provider, workingDirectory, config, signal) {
    return connection.request('resolveSessionConfig', { channel: ROOT, provider, workingDirectory, config }, { signal });
}

/** 開いた接続のプロトコルに合う作業場所のフィールドでセッションを作る。 */
export function createSession(connection, id, { workingDirectory, protocolVersion, ...options }, signal) {
    const workspace = protocolVersion.startsWith('0.') ? { workingDirectory } : { workingDirectories: [workingDirectory] };
    return connection.request('createSession', { channel: id, ...options, ...workspace }, { signal, timeout: 30_000 });
}

/** プロトコルの各形式から主な作業場所を取り出す。 */
export function primaryDirectory(state) {
    return state?.workingDirectories?.[0] ?? state?.workingDirectory;
}

/** 新しいセッションに表示名を付ける。 */
export function titleSession(connection, id, title) {
    connection.dispatch(id, { type: 'session/titleChanged', title });
}

/** セッション一覧をページごとに取得し、同じカーソルが繰り返された場合は止める。 */
export async function* listSessions(connection, signal) {
    const cursors = new Set();
    let cursor;
    do {
        const result = await connection.request('listSessions', { channel: ROOT, limit: 50, ...(cursor && { cursor }) }, { signal });
        yield* (result?.items ?? []);
        cursor = result?.nextCursor;
        if (cursor && cursors.has(cursor)) throw new ApiError(502, 'AHP_SESSION_LIST', 'Agent Hostからセッション一覧を最後まで取得できませんでした。');
        cursors.add(cursor);
    } while (cursor);
}

/** 既定チャットと、指定されたカスタムエージェントが利用可能になるまで待つ。 */
export async function readySession(connection, session, signal, selectCustomization) {
    const actions = connection.actions(session, signal);
    const readState = async () => (await connection.request('subscribe', { channel: session }, { signal }))?.snapshot?.state;
    const check = (state) => {
        if (state?.lifecycle === 'failed') throw new ApiError(502, 'AHP_SESSION_FAILED', `Copilotセッションを開始できませんでした。${shortDetail(state.creationError)}`);
        // VS Code can publish a provisional chat before it starts the Copilot runtime on the first turn.
        if (!state?.defaultChat) return undefined;
        const customizations = state.customizations?.flatMap(item => item.enabled === false ? [] : item.children ?? [item]) ?? [];
        const customization = customizations.find(item => item.type === 'agent' && item.enabled !== false && !item.disableUserInvocation
            && selectCustomization(item.uri));
        return customization && { session: state, agent: { uri: customization.uri } };
    };
    try {
        let state = check(await readState());
        if (state) return state;
        for await (const [{ action }] of actions) {
            if (action?.type === 'session/creationFailed') {
                throw new ApiError(502, 'AHP_SESSION_FAILED', `Copilotセッションを開始できませんでした。${shortDetail(action.error)}`);
            }
            if (['session/ready', 'session/defaultChatChanged', 'session/chatAdded', 'session/customizationsChanged'].includes(action?.type)) {
                state = check(await readState());
                if (state) return state;
            }
        }
        throw connection.closeReason ?? disconnected();
    } finally {
        await actions.return();
    }
}
