/**
 * @file ページ・書式の組み込み値と、文書設定を適用する順序。
 * 文書YAMLのキーは config/schema.mjs、DSLは shared/dsl-definition.mjs。
 * 書式をCSSへ反映する処理は core/render_common.mjs、構造と印刷用のCSSは core/styles.css。
 */

import { readFileSync } from "node:fs";
import { DEFAULT_DSL } from "./dsl-definition.mjs";

/** 用紙・余白・段落と目次に使う組み込み値。 */
export const DEFAULT_PAGE = {
    paper: "A4",
    orientation: "portrait",
    margin: {
        top: "10mm",
        right: "10mm",
        bottom: "15mm",
        left: "15mm"
    },
    paragraphIndent: true,
    tocDepth: 3
};

/** CSSとWordへの変換で使う、文字・色・間隔・採番・表紙の組み込み値。 */
export const DEFAULT_STYLE = {
    typography: {
        fontFamily: "'Noto Sans JP', 'Hiragino Sans', 'Yu Gothic', 'Meiryo', sans-serif",
        fontSize: {
            title: "36px",
            h1: "28px",
            h2: "24px",
            h3: "20px",
            h4: "18px",
            body: "16px",
            small: "13px"
        },
        lineHeightBody: 1.3,
        lineHeightHeading: 1.3,
        fontWeight: {
            heading: "700",
            body: "400"
        }
    },
    colors: {
        text: "#333333",
        heading: "#111111",
        headingBorder: "#2c3e50",
        subtle: "#555555",
        link: "#0066cc",
        code: "#c7254e",
        codeBg: "#f9f2f4",
        preBg: "#f6f8fa"
    },
    heading: {
        numbering: true,
        levels: [
            "h1",
            "h2",
            "h3"
        ]
    },
    spacing: {
        paragraphGap: "0.75em",
        headingTop: "2em",
        headingBottom: "0.5em",
        tocPadding: "0.1em 0",
        tocItemPadding: "0 0"
    },
    titlePage: {
        titleSize: "36px",
        subtitleSize: "18px",
        coverMaxHeight: "360px"
    }
};

/** プレビューと印刷で共通の、文書の構造を決めるCSS。 */
export const structureCss = readFileSync(new URL("./styles.css", import.meta.url), "utf8");

/** 文書指定のDSLはブロックの定義全体を採用し、省略時は組み込みの定義を選ぶ。 */
export function resolveRenderingDsl(config = {}) {
    return config.dsl ?? DEFAULT_DSL;
}

/** 用紙、向き、余白、ヘッダー等に文書指定と組み込み値を反映する。 */
export function resolveEffectivePageConfig(meta, basePageConfig) {
    const baseHeaderFooter = basePageConfig.headerFooter ?? {};
    const metaHeaderFooter = meta?.headerFooter ?? {};
    const normalizedMargin = {
        top: meta?.margin?.top ?? basePageConfig.margin?.top,
        right: meta?.margin?.right ?? basePageConfig.margin?.right,
        bottom: meta?.margin?.bottom ?? basePageConfig.margin?.bottom,
        left: meta?.margin?.left ?? basePageConfig.margin?.left,
    };

    return {
        ...basePageConfig,
        paper: meta?.paper ?? basePageConfig.paper,
        orientation: meta?.orientation ?? basePageConfig.orientation,
        margin: normalizedMargin,
        tocDepth: meta?.tocDepth ?? basePageConfig.tocDepth,
        paragraphIndent: meta?.paragraphIndent ?? basePageConfig.paragraphIndent,
        headerFooter: {
            ...baseHeaderFooter,
            ...metaHeaderFooter,
            header: { ...(baseHeaderFooter.header ?? {}), ...(metaHeaderFooter.header ?? {}) },
            footer: { ...(baseHeaderFooter.footer ?? {}), ...(metaHeaderFooter.footer ?? {}) },
        },
    };
}

/** 表紙、図表の章別採番、文字と余白に使う最終のスタイル定義を組み立てる。 */
export function resolveEffectiveStyleConfig(meta, baseStyleConfig) {
    return {
        ...baseStyleConfig,
        heading: {
            ...baseStyleConfig.heading,
            numbering: meta?.headingNumbering ?? baseStyleConfig.heading.numbering,
        },
    };
}

/** 文書設定に組み込みのページ・スタイル・DSLの既定値を反映する。 */
export function resolveRenderingSettings(config) {
    return {
        page: resolveEffectivePageConfig(config, DEFAULT_PAGE),
        style: resolveEffectiveStyleConfig(config, {
            ...DEFAULT_STYLE,
            typography: {
                ...DEFAULT_STYLE.typography,
                ...config.typography,
                fontSize: { ...DEFAULT_STYLE.typography.fontSize, ...config.typography?.fontSize },
                fontWeight: { ...DEFAULT_STYLE.typography.fontWeight, ...config.typography?.fontWeight },
            },
            heading: { ...DEFAULT_STYLE.heading, ...config.heading },
            colors: { ...DEFAULT_STYLE.colors, ...config.colors },
            spacing: { ...DEFAULT_STYLE.spacing, ...config.spacing },
            titlePage: { ...DEFAULT_STYLE.titlePage, ...config.titlePageStyle },
        }),
        dsl: resolveRenderingDsl(config),
    };
}
