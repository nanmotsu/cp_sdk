/**
 * @file 改訂履歴と目次の前付けを組み立て、目次のリンク先になる見出しIDを付ける。
 */

import { escapeHtml, textFromMarkup } from "./markup.mjs";

/** 出力形式ごとの掲載設定を確認し、YAMLの改訂履歴を表のHTMLへ変換する。 */
export function buildRevisionHistoryPage(config, output = "preview", includeRevisionHistory) {
    const rows = config.revisionHistory;
    const visible = includeRevisionHistory ?? config.revisionHistoryVisibility?.[output];
    if (visible === false || !Array.isArray(rows) || rows.length === 0) return "";
    const hasAuthor = rows.some(row => String(row.author ?? "").trim());
    // 末尾の改行を除去してから \n を <br> に変換 (YAML の | ブロックスカラー対応)
    const cell = v => escapeHtml(v).replace(/\n+$/, "").replace(/\n/g, "<br>");
    const rowsHtml = rows.map(r => [
        `        <tr>`,
        `            <td>${cell(r.version)}</td>`,
        `            <td>${cell(r.date)}</td>`,
        ...(hasAuthor ? [`            <td>${cell(r.author)}</td>`] : []),
        `            <td>${cell(r.description)}</td>`,
        `        </tr>`,
    ].join("\n")).join("\n");
    return [
        '<section class="revision-history">',
        '  <p class="revision-history-title">改訂履歴</p>',
        '  <table>',
        '    <thead>',
        '      <tr>',
        '        <th class="col-version">版</th>',
        '        <th class="col-date">日付</th>',
        ...(hasAuthor ? ['        <th class="col-author">作成者</th>'] : []),
        '        <th class="col-description">改訂内容</th>',
        '      </tr>',
        '    </thead>',
        '    <tbody>',
        rowsHtml,
        '    </tbody>',
        '  </table>',
        '</section>',
    ].join("\n");
}

/** 原本の見出し文字を自動目次用に取得し、見出しにリンク先を付ける。 */
export function linkHeadings(bodyHtml) {
    const headings = [];
    const html = bodyHtml.replace(/<h([1-3])\b([^>]*)>([\s\S]*?)<\/h\1>/gi, (_, level, attributes, content) => {
        const index = headings.length + 1;
        const explicit = attributes.match(/\sid="([^"]+)"/);
        const id = explicit ? textFromMarkup(explicit[1]) : `toc-${index}`;
        headings.push({ level: Number(level), title: textFromMarkup(content).trim(), id });
        return `<h${level}${attributes}${explicit ? "" : ` id="${id}"`}>${content}</h${level}>`;
    });
    return { html, headings };
}

/**
 * 見出しリストからリンク付き目次 HTML を生成する。
 * - 既存見出しから自動生成
 * - meta.tocManual がある場合は手入力目次を優先
 * - meta.toc === false の場合は目次を出力しない
 * - tocDepth: 目次に含める最大見出しレベル (1-3)
 *   優先順: 文書設定 > アプリ既定値 (デフォルト)
 */
export function buildTOC(headings, meta, parseFn, pageConfig) {
    if (meta.toc === false) return "";

    const manualRaw = meta.tocManual ?? null;
    const hasManualTOC = (typeof manualRaw === "string" && manualRaw.trim() !== "")
        || (Array.isArray(manualRaw) && manualRaw.length > 0);
    if (hasManualTOC) {
        const manualMd = Array.isArray(manualRaw)
            ? manualRaw.map(v => String(v ?? "")).join("\n")
            : String(manualRaw);
        const manualHtml = parseFn(manualMd).trim();
        return [
            '<nav class="toc toc-manual">',
            '  <p class="toc-title">目次</p>',
            '  <div class="toc-manual-body">',
            manualHtml,
            '  </div>',
            '</nav>',
        ].join("\n");
    }

    // tocDepth: 文書設定 > アプリ既定値
    const rawDepth = meta.tocDepth ?? pageConfig.tocDepth ?? 3;
    const tocDepth = Math.max(1, Math.min(3, parseInt(rawDepth) || 3));

    const filteredHeadings = headings.filter(h => h.level <= tocDepth);
    if (filteredHeadings.length === 0) return "";

    const minLevel = Math.min(...filteredHeadings.map(h => h.level));
    const items = filteredHeadings.map(({ level, title, id }) => {
        const indent = (level - minLevel) * 1.5;
        return `    <li class="toc-level-${level}" style="padding-left:${indent}em"><a href="#${escapeHtml(id)}">${escapeHtml(title)}</a></li>`;
    });
    return [
        '<nav class="toc">',
        '  <p class="toc-title">目次</p>',
        '  <ul>',
        ...items,
        '  </ul>',
        '</nav>',
    ].join("\n");
}

