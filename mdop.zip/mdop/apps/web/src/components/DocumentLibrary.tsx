/** @file 文書のトップ画面。タイトル検索、更新日、作成と選択をまとめる。 */
import { useMemo, useState } from 'react';
import type { FormEvent } from 'react';
import { api, errorMessage } from '../api';
import type { DocumentInfo } from '../api';
import './DocumentLibrary.css';

interface Props {
  documents: DocumentInfo[];
  loading: boolean;
  opening: boolean;
  onOpen: (document: DocumentInfo) => void;
  onCreated: (document: DocumentInfo) => Promise<void>;
  onError: (message: string) => void;
}

function updatedLabel(value?: string) {
  if (!value) return '更新日不明';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '更新日不明' : new Intl.DateTimeFormat('ja-JP', {
    year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit',
  }).format(date);
}

export default function DocumentLibrary({ documents, loading, opening, onOpen, onCreated, onError }: Props) {
  const [query, setQuery] = useState('');
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState('');
  const [working, setWorking] = useState(false);
  const filtered = useMemo(() => documents.filter(document => document.name.toLocaleLowerCase('ja-JP')
    .includes(query.trim().toLocaleLowerCase('ja-JP'))), [documents, query]);

  async function create(event: FormEvent) {
    event.preventDefault();
    const title = name.trim();
    if (!title || working || !window.confirm(`「${title}」を新規作成しますか？`)) return;
    setWorking(true);
    try {
      const { document } = await api.createDocument(title);
      await onCreated(document);
      setCreating(false);
      setName('');
      setQuery('');
    } catch (error) {
      onError(errorMessage(error));
    } finally {
      setWorking(false);
    }
  }

  return <main className="document-library" aria-label="すべての文書">
    <div className="library-heading">
      <div>
        <p className="library-eyebrow">DOCUMENTS</p>
        <h2>すべての文書</h2>
        <p>文書を選ぶと編集画面が開きます。</p>
      </div>
      <label className="library-search">
        <span>タイトルで検索</span>
        <input type="search" value={query} onChange={event => setQuery(event.target.value)} placeholder="文書のタイトルを入力" />
      </label>
    </div>
    {loading ? <p className="library-empty">文書を読み込んでいます…</p> : <>
      {filtered.length === 0 && <p className="library-empty">{query ? '一致する文書がありません。' : 'まだ文書がありません。'}</p>}
      <div className="library-grid">
        {filtered.map(document => <button key={document.id} type="button" className="document-card"
          disabled={opening || working} onClick={() => onOpen(document)} aria-label={`${document.name}を開く`}>
          <span className="document-cover" aria-hidden="true">
            <span className="document-cover-mark">MD OPERATOR</span>
            <strong>{document.name}</strong>
            <span className="document-cover-rule" />
            <span className="document-cover-footer">DOCUMENT</span>
          </span>
          <span className="document-card-info">
            <strong>{document.name}</strong>
            <span>最終更新日 {updatedLabel(document.updatedAt)}</span>
          </span>
        </button>)}
        <div className="new-document-slot">
          {!creating ? <button type="button" className="new-document-card" disabled={opening || working}
            onClick={() => setCreating(true)} aria-label="新規文書を作成">
            <span className="new-document-plus" aria-hidden="true">＋</span><span>新規文書</span>
          </button> : <form className="new-document-form" onSubmit={create}>
            <label htmlFor="new-document-name">新規文書のタイトル</label>
            <input id="new-document-name" autoFocus value={name} onChange={event => setName(event.target.value)} required maxLength={512}
              placeholder="タイトルを入力" />
            <div className="new-document-actions">
              <button type="button" onClick={() => setCreating(false)} disabled={working}>キャンセル</button>
              <button type="submit" disabled={working || opening || !name.trim()}>作成</button>
            </div>
          </form>}
        </div>
      </div>
    </>}
  </main>;
}
