/**
 * @file 型情報を参照できないHTML変換ライブラリについて、GUIで使う範囲の型を宣言する。
 */

declare module 'turndown' {
  /** HTMLからMarkdownに戻すためにGUIで使う変換器の型。 */
  export default class TurndownService {
    /** 変換器に既定の見出しやコードブロックの書式を渡す。 */
    constructor(options?: Record<string, unknown>);
    /** HTML文字列または要素をMarkdownへ変換する。 */
    turndown(input: HTMLElement | string): string;
    /** 変換器に追加の変換規則を登録する。 */
    use(plugin: (service: TurndownService) => void): TurndownService;
  }
}

declare module 'turndown-plugin-gfm' {
  import type TurndownService from 'turndown';

  /** TurndownにGFMの表や書式の変換規則を追加するプラグイン。 */
  export function gfm(service: TurndownService): void;
}
