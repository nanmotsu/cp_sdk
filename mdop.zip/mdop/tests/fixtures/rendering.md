# 利用者管理仕様書

このサンプルでは、Markdown原本、図表、Mermaid、PDF・Word出力を試せます。

## 利用者登録

1. 管理者が利用者の情報を入力します。
2. システムが入力を検証し、登録結果を表示します。

:::warning
入力エラーがある場合は、登録せず該当する項目を表示します。
:::

登録の流れを {{ref:registration}} に、管理項目を {{ref:account-fields}} に示します。

:::figure id=registration width=70%
```mermaid
flowchart LR
    A["入力"] --> B["検証"]
    B --> C["結果表示"]
```
利用者登録の処理
:::

:::table id=account-fields
利用者の管理項目

| 項目 | 必須 | 説明 |
| --- | --- | --- |
| 利用者ID | はい | 利用者を識別する値 |
| 表示名 | はい | アプリに表示する名前 |
:::

## 出力形式

編集の内容はこのMarkdownに保存します。PDFとWordは同じ文書フォルダの `output/` に作成されます。
