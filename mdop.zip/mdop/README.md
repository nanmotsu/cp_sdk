# MD Operator

Markdownをブラウザで編集し、PDFやWordに出力するローカルアプリです。

## 起動

Node.js 22.12以上が必要です。プロジェクトのルートで次を実行します。

```powershell
npm ci
npm run build
npm start
```

ブラウザで [http://127.0.0.1:3355/](http://127.0.0.1:3355/) を開きます。セットアップ済みなら `npm start` で起動できます。停止するにはターミナルで `Ctrl+C` を押します。

PDF出力やMermaidの描画にはChromeまたはChromiumを使います。実行ファイルの場所は `PUPPETEER_EXECUTABLE_PATH` で指定できます。

## 基本操作

1. 左の **文書** 一覧からサンプルを開きます。新規文書は **＋** を押し、フォルダ名を入力して **作成** を押します。
2. 中央の **ビジュアル** または **ソース** で編集し、上部の **保存** を押します。原本は `documents/<文書>/` にあります。
3. 右の **プレビューを更新** で見た目を確認します。PDF・Wordは **出力・Word** から出力でき、既定では文書フォルダ内の `output/` に保存されます。

## サンプル文書

サンプルはアプリ左側の文書一覧から開けます。

- 画面操作、設定、出力方法は [外部仕様書](documents/0_sample_外部仕様書/index.md)
- システム構成、API、データの保存方法は [内部仕様書](documents/0_sample_内部仕様書/index.md)
- VS Codeとの接続、AIによる本文編集や図版作成は [GitHub Copilot支援ガイド](documents/0_sample_GitHub_Copilot支援/index.md)
