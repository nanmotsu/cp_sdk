/**
 * @file 文書フォルダの版を保存・比較し、安全に復元する。
 */

import { badRequest, conflict } from "../../common/api/errors.mjs";
import { atomicWrite, statIfPresent, workspacePath } from "../../common/filesystem/paths.mjs";
import { loadDocumentConfig } from "../config/yaml.mjs";
import { documentSummary, markdownFiles, readOriginal } from "../markdown/store.mjs";
import { MARKDOWN_LIMIT, textInput } from "../shared/input.mjs";

/** 原本の消失や重複があっても、付属ファイルを比較して過去の版から復元できるようにする。 */
async function readHistoryFile(folder, files) {
    if (files.length !== 1) return null;
    const absolute = await workspacePath(folder, files[0].path);
    if ((await statIfPresent(absolute))?.size > MARKDOWN_LIMIT) return null;
    return readOriginal(folder, files[0].path);
}

/** 生成案の保存、履歴の比較と復元を同じ文書ロックで行う。 */
export function createHistoryStore({ root, backups, access, checkRestoreVersion, markRestored }) {
    /** WordやCopilotの結果を、原本への変更を確定する前に、本文と必要な付属ファイルごと保管する。 */
    function archiveProposal(id, original, expectedRestore, options, build) {
        return access(id, async folder => {
            options.signal.throwIfAborted();
            checkRestoreVersion(id, expectedRestore);
            const current = await readOriginal(folder, original.path);
            if (current.revision !== original.revision) {
                throw conflict("処理中に原本Markdownが更新されました。現在の文書でやり直してください。", { revision: current.revision });
            }
            if (options.configRevision !== undefined && (await loadDocumentConfig(root, folder)).revision !== options.configRevision) {
                throw conflict("編集案の作成中に設定が更新されました。現在の設定でやり直してください。");
            }
            const backup = await backups.capture(folder, { ...options, path: original.path }, async tree => {
                const markdown = textInput(await build(tree), "Markdown");
                await atomicWrite(await workspacePath(tree, original.path), markdown, { signal: options.signal });
            });
            if (options.signal.aborted) await backups.discard(folder, backup.id);
            options.signal.throwIfAborted();
            return backup;
        });
    }

    /** Copilotの履歴をコピーし、調整した図版で別の版を作る。 */
    function forkCopilotBackup(id, backupId, editFigures) {
        return access(id, async folder => {
            const source = await backups.open(folder, backupId);
            if (!["copilot", "copilot-figure"].includes(source.metadata.reason)) {
                throw badRequest("Copilotの編集案から作られた版を指定してください。");
            }
            const original = await readOriginal(source.tree, source.metadata.path);
            return backups.fork(folder, source, { path: original.path, reason: "copilot-figure", warnings: source.metadata.warnings },
                tree => editFigures(tree, original.content));
        });
    }

    /** 履歴の本文と、現在のフォルダとの比較結果を一緒に取得する。 */
    function backupDetail(id, backupId) {
        return access(id, async folder => {
            const version = await backups.open(folder, backupId);
            const file = await readHistoryFile(version.tree, await markdownFiles(version.tree));
            const current = await readHistoryFile(folder, await markdownFiles(folder));
            return { backup: version.metadata, file, current, ...await backups.compare(folder, version) };
        });
    }

    /** 比較した時点から変化がないことを確認し、現在の作業を退避してから復元する。 */
    function restoreBackup(id, backupId, { currentRevision, currentMarkdown, revision: editorRevision }) {
        if (typeof currentRevision !== "string" || !/^[a-f\d]{64}$/.test(currentRevision)) {
            throw badRequest("履歴の比較結果を取得してから復元してください。");
        }
        if (currentMarkdown !== undefined) textInput(currentMarkdown, "currentMarkdown");
        return access(id, async folder => {
            const version = await backups.open(folder, backupId);
            const targetFiles = await markdownFiles(version.tree);
            const file = await readHistoryFile(version.tree, targetFiles);
            const current = await readHistoryFile(folder, await markdownFiles(folder));
            if ((await backups.state(folder)).revision !== currentRevision
                || (currentMarkdown !== undefined && (!current || editorRevision !== current.revision))) {
                throw conflict("比較後に文書が変わりました。差分を更新してから復元してください。");
            }
            await backups.capture(folder, { path: current?.path ?? null, reason: "before-restore" }, async tree => {
                if (current && currentMarkdown !== undefined && currentMarkdown !== current.content) {
                    await atomicWrite(await workspacePath(tree, current.path), currentMarkdown);
                }
            });
            await backups.restore(folder, version, currentRevision);
            markRestored(id);
            return { file, document: documentSummary(id, targetFiles) };
        });
    }

    return {
        archiveProposal, forkCopilotBackup, backupDetail, restoreBackup,
        listBackups: id => access(id, backups.list),
        deleteBackup: (id, backupId) => access(id, folder => backups.discard(folder, backupId)),
    };
}
