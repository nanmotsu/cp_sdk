
**AIエージェントとは、LLM（大規模言語モデル）をAIハーネスによって制御し、状況に応じて推論・ツール実行・結果確認を繰り返しながら、自律的に目的の達成を目指すシステムである。**


# GitHub Copilotのエージェントハーネス進化史

**対象：** VS Code / GitHub Copilot CLI / Copilot SDK / Agent Host / AHP / Claude Code・Claude Agent SDK  
**整理日：** 2026年11月16日  
**目的：** 用語の関係、設計の変遷、Claudeとの先後関係、エージェントループの実行責務を、公式資料の根拠に基づいて説明する。

> **読み方**：本文では、公式資料に明示された内容を**【確認事項】**、複数の資料を合わせて考えた説明を**【解釈】**、断定できない部分を**【未確認】**と表記する。出典の `[S1]` などは末尾の「一次資料・参考資料」に対応する。

---

## 1. 用語定義

| 用語 | 定義 | この資料での区別 |
|---|---|---|
| **LLM / Model** | テキストやツール呼び出しを生成する推論モデル | ループの実行プロセスそのものではない |
| **Agent** | LLMにツールや作業環境を与え、目的の達成を試みるソフトウェアシステム | モデル単体と区別する |
| **Agent Loop** | モデル呼び出し→ツール要求の取得→ツール実行→結果をモデルへ返す、という反復処理 | 本稿の中心となる「ループ」 |
| **Agent Harness** | コンテキスト、モデル、ツール、権限、Agent Loopなどを統合するエージェント実行機構 | VS Code公式ではRuntimeとしての側面も含んで説明する [S1][S2] |
| **Runtime** | Harnessを実際に動かす実行時の実装・プロセス | Copilot標準構成ではCopilot CLIがループを主導 [S3] |
| **SDK** | Harness / Runtimeを別のプログラムから利用するためのAPI・ライブラリ | APIがループ全体を隠蔽できても、SDK内でループが回るとは限らない |
| **CLI** | コマンドラインから使うアプリケーション。Copilotの場合はSDKの接続先Runtimeとしても動く | 画面操作用CLIとエージェント実行エンジンの役割を兼ねうる |
| **Agent Host** | Harnessを実行・管理し、クライアント側に見えるセッションを所有する独立プロセス | Agent Loopを独自に再実装する層ではない [S1][S2] |
| **Adapter** | HarnessごとのAPI・イベント・権限をAgent Hostの共通セッションモデルへ変換する接続層 | SDKを無加工で何でも差し替えられるわけではない |
| **AHP (Agent Host Protocol)** | Agent Hostとクライアント間の通信、セッション状態、同期を定める公開プロトコル | エージェントの推論方法を規格化するものではない [S1] |
| **Client** | VS Code、Agentsウィンドウ、ブラウザ、独自AHPクライアントなど | セッションを表示・操作する側 |
| **Extension Host** | VS Code拡張機能を動かすプロセス | 旧Local Harnessの実行寿命がVS Codeウィンドウに結び付いていた要因 |
| **Session** | 会話履歴や作業状態を保持する単位 | Runtime内部のセッションとHostがクライアント向けに管理する状態を区別する |
| **MCP** | エージェントが外部ツール・情報源と連携するプロトコル | AHPとは目的が異なる。MCPは主にツール連携、AHPはHost・Client間のセッション連携 |

### 用語の包含関係に関する注意

**Harness = Runtime = SDK = Host、ではない。** ただし「Harness」と「Runtime」は文脈により重なって使われる。概念を単純な親子の包含関係だけで表すより、**Harness＝エージェントとして動く仕組み、Runtime＝その実行時実装、SDK＝その呼び出し窓口、Agent Host＝実行とセッションの管理境界、AHP＝クライアントとの通信規約**と役割で区別する方が誤解が少ない。[S1][S2][S3]

---

## 2. 結論（先に要点）

1. **Claudeがエージェントループ自体を発明したわけではない。** 少なくとも2022年のReAct論文に、推論と行動を交互に行うエージェントの基本構造が示されている。[S12]
2. **ハーネスのSDK化ではClaudeがCopilotより早かった。** Anthropicは2025年5月22日にClaude Code SDKを発表し、GitHubは2026年1月14日にCopilot SDKの技術プレビューを発表した。初公開で約8か月の差がある。[S5][S7]
3. **旧VS Code Local HarnessはExtension Hostに強く結び付いていた。** 各ウィンドウがエージェントの実行基盤を持ち、ウィンドウを閉じるとRuntimeも停止する構造だった。[S1]
4. **Copilot SDKはAgent Loopそのものを実行する主体ではない。** 標準構成ではSDKはCopilot CLIにJSON-RPCで接続し、CLIがツール使用ループを主導する。[S3]
5. **Agent HostもAgent Loopの司令塔ではない。** セッションの所有・同期、Harnessの接続、ツール中継などを担い、各Harnessは独自のAgent Loopを保持する。[S1][S2]
6. **Agent HostとAHPは、SDK共通化とは別の「長時間セッション・複数画面・リモート接続」の問題にも対応した。** 公式発表はこの二つの要求の合流を設計変更の背景として説明している。[S1]
7. **ClaudeにもHostに似た仕組み・発想はあった。** Claude Code on the web（2025年10月）やClaude Managed Agents（2026年4月）はUIと実行環境を分離し、セッションを管理する。しかし、Microsoft AHPと同じ「異なるHarnessを公開共通プロトコルで扱うHost」の提供とは目的が異なる。[S9][S10]

---

## 3. 公開情報で追う歴史

| 時期 | 主体 | 出来事 | 意味 | 根拠 |
|---|---|---|---|---|
| **2022/10/06** | 研究 | ReAct論文公開 | 推論と行動・ツール利用を交互に行う基礎形 | [S12] |
| **2025/05/22** | Anthropic | Claude Code SDKを発表 | Claude Codeのエージェント実装を他アプリでも利用可能に | [S5] |
| **2025/09/25** | GitHub | Copilot CLI公開プレビュー | VS Codeから独立したターミナル型エージェントを提供 | [S6] |
| **2025/09/29** | Anthropic | Claude Agent SDKの位置づけを公表 | コーディング以外にも使えるHarnessの再利用を強調 | [S8] |
| **2025/10/20** | Anthropic | Claude Code on the web | クラウド実行・複数タスク・ブラウザからの操作 | [S9] |
| **2025年後半** | VS Code | Local Agent Chatのバックグラウンド継続 | チャットを閉じても動作可能。ただしウィンドウとの結び付きは残る | [S1] |
| **2026/01/14** | GitHub | Copilot SDK技術プレビュー | Copilot CLIをSDK経由でプログラムから利用 | [S7] |
| **2026/02/04** | VS Code | 1.109でClaude Agent SDK統合を公開 | Copilot以外の公式HarnessをVS Codeから使用 | [S13] |
| **2026/02** | Anthropic | Claude Code Remote Control | 動作中のローカルセッションを別端末から操作 | [S14] |
| **2026/04/08** | Anthropic | Claude Managed Agents発表 | Harnessと実行環境・権限・長時間Sessionをマネージド提供 | [S10] |
| **2026/06/02** | GitHub | Copilot SDK一般提供（GA） | 共通Runtimeへアクセスする安定APIを提供 | [S11] |
| **2026/08/26** | VS Code | Agent Host設計を公式解説 | 独立Host、AHP、複数HarnessのAdapter構成を説明 | [S1] |
| **2026/10/28** | VS Code | AHP 1.0を発表 | Hostとクライアントの接続を公開プロトコルで標準化 | [S4] |
| **2026/11/11** | VS Code | 1.146で旧Local Harnessを非推奨化 | Copilot Harnessが標準。旧方式は2027年2月廃止予定 | [S15] |

**重要：** 上表は*一般公開された情報の時系列*であり、各社の社内検討・実装開始の順番を証明するものではない。特に「Claudeの設計がMicrosoftの発想の直接の原因」という因果関係は確認できない。

### 3.1 旧VS Code Local Harnessが抱えていた問題

従来の概念図：

```text
VS CodeウィンドウA
  └─ Extension Host
       └─ Copilot Chat拡張
            └─ Local Harness / Agent Loop

VS CodeウィンドウB
  └─ Extension Host
       └─ 別のLocal Harness / Agent Loop
```

- ウィンドウごとにエージェント実行基盤をロードする。
- ウィンドウに実行寿命が結び付く。
- 複数画面から同一の実行中セッションを操作しにくい。
- Copilot CLIなどとのHarness実装の共通化も進める必要があった。

これらはMicrosoftの設計記事に直接記されている。【確認事項】[S1]

### 3.2 SDK化は何を解決したか

CLI側のHarness/Runtimeを、VS Codeなどの外部プログラムでも使えるようにする。

```text
CLIアプリ ──────┐
               ├── 共通のCopilot Runtime / Agent Loop
外部アプリ ─ SDK ┘
```

これによりエージェントの基本動作を共通化しやすくなった。【確認事項】[S1][S11] ただし、**SDKを導入するだけでは、別のVS Codeウィンドウやブラウザ間で「同じ実行中セッション」を所有・同期する問題は自動解決しない。**【解釈】

### 3.3 Agent HostとAHPは何を解決したか

Microsoftは次の要求を統合したと説明している。[S1]

1. VS Codeのウィンドウをまたいでセッションを継続する。
2. Copilot SDKを採用し、複数Copilot製品のHarness動作を揃える。
3. Copilot・Claudeなど異なるHarnessを、共通のセッションUIで扱う。
4. 複数クライアントから同一セッションに接続し、状態を同期する。

そのため、**Runtimeの共通化（SDK）と、セッション管理の共通化（Agent Host + AHP）は別の責務**である。

---

## 4. 現在の構成と実行フロー

### 4.1 Agent Hostを使う構成（概念図）

```mermaid
flowchart TB
  A[VS Code Chat] -->|AHP| H[Agent Host]
  B[Agentsウィンドウ] -->|AHP| H
  C[独自AHPクライアント] -->|AHP| H
  H --> CA[Copilot Adapter]
  H --> CL[Claude Adapter]
  H --> CX[Codex統合アダプター等]
  CA --> SDK[Copilot SDK]
  SDK -->|JSON-RPC| CLI[Copilot CLI Runtime]
  CLI --> LOOP[Copilot Agent Loop]
  CL --> CASDK[Claude Agent SDK]
  CASDK --> CLOOP[Claude Harness / Loop]
```

> 図は責務を理解するための**概念図**。各部品が必ず異なるOSプロセスであることを示していない。ClaudeやCodexの具体的なプロセス境界は統合方式・バージョンによって異なる。[S1][S2]

Agent HostはHarnessを実行・管理し、各HarnessのAdapterがその固有イベントをAHPのセッションモデルに変換する。AHPはSession、Chat、Terminal、Changesetなどの状態をクライアントへ公開し、スナップショットと順序付き更新によって同期する。【確認事項】[S1]

### 4.2 Copilot SDKを直接使う構成

```mermaid
flowchart LR
  APP[自作Node.jsアプリ] --> SDK[Copilot SDK]
  SDK -->|JSON-RPC| CLI[Copilot CLI]
  CLI <-->|モデル呼び出し| LLM[LLM]
  CLI -->|ツール実行| TOOL[ローカルツール等]
  TOOL -->|結果| CLI
  CLI -->|イベント| SDK
  SDK --> APP
```

**Agent HostなしでもAgent Loopは成立する。** 自作アプリがSDKからプロンプトを送ると、Copilot CLIがモデルへの再問い合わせとツール使用の反復を進める。【確認事項】[S3]

### 4.3 エージェントループ本体（Copilot CLI）

```mermaid
flowchart TD
  P[ユーザーのプロンプト] --> M[CLIがLLMを呼び出す]
  M --> Q{ツール呼び出し要求があるか}
  Q -->|ある| T[CLIがツールを実行・結果収集]
  T --> M
  Q -->|ない| F[最終応答]
  F --> I[session.idle]
```

公式の責務分担：[S3]

- **アプリ**：最初のプロンプトを送る。
- **SDK**：プロンプトとイベントを送受信する。標準構成ではAgent Loopを制御しない。
- **Copilot CLI**：モデルへの反復呼び出しとツール実行結果のフィードバックを担当する。
- **LLM**：ツール呼び出しを要求するか、最終応答を出すかを決める。
- **Agent Host**：必要な場合にセッションを管理し、Client由来のツールなどを中継する。Loopの反復を毎回指揮するわけではない。

### 4.4 「SDKはループをすべて覆うのか」への答え

**呼び出し側のAPIという意味では「覆う」、実行主体という意味では「覆わない」。**

Copilot SDKの公開ドキュメントはSDKを**transport layer**、Copilot CLIを**orchestrator**と説明している。従って次の整理が正確である。[S3]

| 問い | 答え |
|---|---|
| SDK APIだけでAgent Loopを利用できるか | **はい**。CLI等のRuntimeをSDKが利用できる構成なら、Hostは必須でない |
| SDKライブラリ自身がループ処理を回しているか | **標準のCopilot構成ではいいえ**。CLIがループの主体 |
| Agent HostとSDKを組み合わせて一つのAgent Loopを構築するか | **いいえ**。Hostは主にセッションとクライアント接続を管理する |
| Hostがループに一切影響しないか | **いいえ**。ツール中継、権限、キャンセル、クライアント依存機能が処理に影響する場合はある |
| CopilotとClaudeは同じAgent Loopを共有するか | **いいえ**。各Harnessは独自のループと能力を維持する [S1] |

### 4.5 VS Code拡張機能のツールを呼ぶ場合

```text
Copilot Runtime
    ↓  ツール実行要求
Copilot SDK / Adapter
    ↓
Agent Host
    ↓  クライアントが提供したツールを中継
VS Code Extension Host（拡張機能）
    ↑  実行結果
Agent Host → Adapter / SDK → Copilot Runtime
    ↓
LLMへの次の問い合わせ（Runtime側のループ継続）
```

Agent Hostはループを*実行*しないが、ループが必要とする機能を*仲介*する場合がある。VS Code側の拡張機能が提供するツールは、そのクライアントが接続されている必要がある。【確認事項】[S1][S2]

---

## 5. Claudeはどこで先行したか

### 5.1 SDKについては明確に先行

- Claude Code SDK発表：**2025年5月22日**。[S5]
- Copilot SDK技術プレビュー：**2026年1月14日**。[S7]
- **初公開日で約8か月Claudeが先行**。

Anthropicは2025年9月に、Claude CodeのHarnessをプログラミング以外のエージェントにも再利用する考え方を説明した。【確認事項】[S8]

ただし「早くSDK化した」ことは「性能が常に高い」「他社が真似したことが証明できる」を意味しない。

### 5.2 ClaudeにはAgent Host相当の発想がなかったのか

**なかったとは言えない。** 先行する例がある。

| Claudeの仕組み | 公開時期 | Hostと似ている点 | Agent Host/AHPと異なる点 |
|---|---|---|---|
| **Claude Code on the web** | 2025/10 | UIから独立したクラウド上でセッションを実行・管理 | Claude専用のクラウド実行が中心 [S9] |
| **Claude Code Remote Control** | 2026/02 | 実行中のローカルClaude Codeを別端末から操作 | ローカルClaude Codeプロセスは存続が必要。汎用異種Harness Hostではない [S14] |
| **Claude Managed Agents** | 2026/04 | Harness、状態・権限・長時間セッションを管理 | Anthropic管理のAgent実行サービスが中心 [S10] |
| **Microsoft Agent Host + AHP** | 2026年に公開説明 | 独立したHostが複数クライアントとHarnessを管理 | 異種Harnessを共通セッションモデルで扱う公開プロトコルが特徴 [S1][S4] |

**【解釈】** Claudeは「自社Harnessを様々な環境から使えるようにする」方向で進み、Microsoftは「異なるHarnessを同じHostとクライアントで管理する」方向を明確に打ち出した、と整理できる。

**【未確認】** Anthropic社内にMicrosoft AHP相当の汎用Host構想が存在しなかったこと、あるいはMicrosoftがClaudeを直接模倣したことを証明する一次資料は確認できない。公開製品が同じ問題を別の境界で解いている、という範囲にとどめるべきである。

---

## 6. Agent HostとAHPがSDKとは別に必要な理由

### 解決する問題が異なる

| 課題 | SDK / 各Harness | Agent Host / AHP |
|---|---|---|
| モデル呼び出し・ループ | **主担当：Runtime** | 共通化しない |
| 独自ツール・コンテキスト | Harness固有 | 必要に応じて中継・表示 |
| セッション内部の会話状態 | SDK / Runtime固有のモデルを持つ | UI向けの共通状態・セッション所有 |
| VS Codeとブラウザの同時表示 | SDKだけで自動保証されない | **中心的な責務** |
| 実行中セッションへの再接続 | Runtimeのセッション復帰機能に依存 | スナップショットと更新イベントで同期 |
| Claude・Copilotなどの共存 | 各社SDKは別物 | Adapterで共通の見え方に変換 |
| ツール承認・中止・Clientツール | 各Harnessの実装を利用 | 共通UIからの操作・中継も担当 |

### AHPで標準化しているもの／していないもの

- **標準化する**：HostとClientの接続、セッション・チャットなどの共通状態、順序付き更新通知、同期・再接続、対応機能の交渉。
- **標準化しない**：モデル内部の思考方法、各HarnessのAgent Loop、コンテキスト管理アルゴリズム、全SDKのAPIそのもの。

AHPはMicrosoftのLSP（Language Server Protocol）、DAP（Debug Adapter Protocol）の経験に基づく設計であると公式に説明されている。[S4]

### ライフサイクルに関する注意

Agent Hostへ移行しても、ローカルのエージェントがPCの電源断やHostプロセス終了を越えて自動で動き続けるわけではない。2026年8月のVS Code公式記事は、**ローカルAgent HostはVS Codeが管理するため、ローカルセッションの継続にはVS Codeが起動している必要がある**と注意している。一方、リモートHostは接続元UIが切れても、実行先マシンとHostが稼働していれば継続できる。[S1][S2]

---

## 7. 仮説の検証結果

| 仮説 | 評価 | 判断 |
|---|---|---|
| ClaudeがAgent Loopを発明した | **否** | ReActなど先行研究がある [S12] |
| ClaudeがSDK化で先行した | **確認** | 2025/05/22 vs 2026/01/14 [S5][S7] |
| VS Code旧Local Harnessはウィンドウ依存だった | **確認** | VS Code公式が設計上の制約を明記 [S1] |
| SDK化によりCopilot CLIのRuntimeを再利用するようになった | **確認** | Copilot SDKとCLIの関係が公式に明記 [S3][S11] |
| Agent HostはSDKと一緒にAgent Loopを作る | **否** | Agent Loopは各HarnessのRuntimeが持つ [S1][S3] |
| Agent Hostはセッション管理・UI分離を共通化する | **確認** | Agent HostとAHPの主要目的 [S1][S2] |
| ClaudeにもHost的な仕組みがあった | **確認** | Cloud Sessions、Remote Control、Managed Agents [S9][S10][S14] |
| MicrosoftはClaude SDKの直接的な後追いでHostを作った | **未確認** | 公開時系列から直接的な因果関係は断定できない |
| AHP経由なら任意SDKを差すだけで動く | **否** | HarnessごとのAdapterが必要 [S1] |
| 異種Harnessに切り替えてもセッション内部状態が完全に引き継がれる | **保証なし** | 会話・文脈のhandoffとRuntime内部状態の完全互換は別問題 [S16] |
| 共通SDK化でVS CodeとCLIが完全に同じ動作になる | **保証なし** | 共通基盤で差は縮まるが、ツール・権限・設定・環境は異なり得る [S1][S11] |

---

## 8. AHPクライアント開発における選択

**AHPを使うべきケース**

- VS Code Agent Hostが持つセッションを別アプリから表示・操作したい。
- Copilot / Claude / Codexなどを共通のセッション操作で扱いたい。
- 複数クライアント間で進捗・承認・キャンセル・変更内容を同期したい。

**Copilot SDKを直接使うべきケース**

- 自作アプリ・自動化パイプラインがCopilotエンジンを直接利用する。
- SDKのセッション・ツール・イベントをアプリ自身で設計・制御する。
- VS Code Agent Hostのセッション一覧との共有を必須にしない。

**混同してはいけない点**：SDK側で独立に作成したセッションは、Host経由で管理されるセッションと自動的に同一になるわけではない。また、「同一セッション」という言葉は、AHPの共通表示状態なのか、Harness内部の会話状態なのか、ワークスペースや作業ディレクトリなのかを区別して使うべきである。

---

## 9. 説明資料にそのまま使える要約

> GitHub Copilotの進化は、二つの設計課題が合流した結果と捉えられる。第一は、VS Code固有のLocal Harnessから、Copilot CLIを中心とした共通エージェントRuntimeへ実装を寄せ、SDK経由で再利用すること。第二は、エージェントをVS Codeのウィンドウ寿命から切り離し、長時間セッションを複数画面・リモート環境から管理することである。
>
> そのため、Copilot SDKはエージェントRuntimeへのプログラム上の入口、Agent HostはHarnessとセッションを管理する独立プロセス、AHPはHostとクライアントを結ぶ共通プロトコル、という責務分離が採用された。
>
> ClaudeはSDK化で約8か月先行し、クラウド実行やリモート操作でも関連する仕組みを早期に提供した。一方、Microsoftの特徴は、Copilot・Claudeなどの異なるHarnessを、それぞれのAgent Loopを保ったまま共通のHost・セッションUIへ統合した点にある。
>
> **SDKとAgent Hostが協力して一つのAgent Loopを構成しているのではない。ループはHarnessのRuntimeが実行し、SDKはこれを利用するAPI、Agent Hostはセッション・クライアントとの接続境界を提供する。**

---

## 10. 一次資料・参考資料

以下は原則として、開発元の公式資料・公式ドキュメント・オリジナルの研究論文。資料上の番号はこの節に対応する。

- **[S1]** VS Code Blog, *Introducing the Agent Host for persistent, portable agent sessions* (2026-08-26) — https://code.visualstudio.com/blogs/2026/08/26/agent-host-architecture
- **[S2]** VS Code, *Agent Host architecture*（2026-11時点） — https://code.visualstudio.com/docs/agents/concepts/agent-host
- **[S3]** GitHub, *The agent loop*（Copilot SDK公式ドキュメント） — https://docs.github.com/en/copilot/how-tos/copilot-sdk/features/agent-loop
- **[S4]** VS Code Blog, *VS Code Wrapped: GitHub Universe 2026* (2026-10-28) — https://code.visualstudio.com/blogs/2026/10/28/vscode-wrapped
- **[S5]** Anthropic, *Introducing Claude 4* (2025-05-22; Claude Code SDK発表を含む) — https://www.anthropic.com/news/claude-4
- **[S6]** GitHub Changelog, *GitHub Copilot CLI is now in public preview* (2025-09-25) — https://github.blog/changelog/2025-09-25-github-copilot-cli-is-now-in-public-preview/
- **[S7]** GitHub Changelog, *Copilot SDK in technical preview* (2026-01-14) — https://github.blog/changelog/2026-01-14-copilot-sdk-in-technical-preview/
- **[S8]** Anthropic, *Building agents with the Claude Agent SDK* (2025-09-29) — https://claude.com/resources/articles/building-agents-with-the-claude-agent-sdk
- **[S9]** Anthropic, *Claude Code on the web* (2025-10-20) — https://claude.com/resources/articles/claude-code-on-the-web
- **[S10]** Anthropic, *Claude Managed Agents* (2026-04-08) — https://claude.com/blog/claude-managed-agents
- **[S11]** GitHub Changelog, *Copilot SDK is now generally available* (2026-06-02) — https://github.blog/changelog/2026-06-02-copilot-sdk-is-now-generally-available/
- **[S12]** Yao et al., *ReAct: Synergizing Reasoning and Acting in Language Models* (2022-10-06) — https://arxiv.org/abs/2210.03629
- **[S13]** VS Code 1.109 Release Notes (2026-02-04; Claude Agent Preview) — https://code.visualstudio.com/updates/v1_109
- **[S14]** Anthropic, *Claude Code Remote Control*（公式ドキュメント） — https://code.claude.com/docs/en/remote-control
- **[S15]** VS Code 1.146 Release Notes (2026-11-11) — https://code.visualstudio.com/updates/v1_146
- **[S16]** VS Code, *Choose an agent harness*（handoffとHarnessの違い） — https://code.visualstudio.com/docs/agents/run/agent-harnesses

---

*本資料は2026年11月16日時点で確認できる公開情報に基づく。内部実装や製品仕様は更新され得る。*
