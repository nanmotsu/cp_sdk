/**
 * @file レンダリング前のHTMLを整形し、本文や表紙が参照する画像を出力用に解決する。
 */

import { readFile, realpath, stat } from "node:fs/promises";
import { extname, isAbsolute, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { parseDocument } from "htmlparser2";
import serialize from "dom-serializer";
import { isFigureImagePath } from "../../../../../packages/markdown/figure-paths.mjs";
import { figureImageFile } from "../figures/media.mjs";

const imageTypes = new Map([[".png", "image/png"], [".svg", "image/svg+xml"]]);

const allowedTags = new Set((
    "a abbr address article aside b blockquote br caption code col colgroup dd del details div dl dt em figcaption " +
    "figure footer h1 h2 h3 h4 h5 h6 header hr i img kbd li main mark nav ol p pre s samp " +
    "section small span strong sub summary sup table tbody td th thead tfoot tr u ul var"
).split(" "));
const plainAttributes = new Set([
    "align", "alt", "class", "colspan", "height", "id", "lang", "open",
    "reversed", "rowspan", "scope", "start", "style", "title", "width",
]);
const maxImageSize = 12 * 1024 * 1024;
const maxEmbeddedSize = 48 * 1024 * 1024;

/** 文字列のHTML上で特別な意味を持つ文字をエスケープする。 */
export function escapeHtml(value) {
    return String(value ?? "")
        .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

/** HTMLから見出しやリンクで使う表示テキストを取り出す。 */
export function textFromMarkup(html) {
    const textFromNodes = nodes => nodes.map(node => node.type === "text" ? node.data
        : node.children ? textFromNodes(node.children) : "").join("");
    return textFromNodes(parseDocument(html).children);
}

/** 対象パスが指定されたルートの配下にあるかを確認する。 */
function isWithin(root, path) {
    const local = relative(root, path);
    return local === "" || (!isAbsolute(local) && local !== ".." && !local.startsWith(`..${sep}`));
}

/** 画像の参照値を、基準ディレクトリからのローカルパスへ解決する。 */
function localImagePath(src, basedir) {
    if (/^file:/i.test(src)) return fileURLToPath(src);
    if (/^(?:[a-z][\w+.-]*:|[/\\])/i.test(src)) return null;
    return resolve(basedir, decodeURIComponent(src));
}

/** 画像リンクを、文書ルート基準の保管パスに変換する。 */
function relativeImagePath(src, base, root) {
    const path = localImagePath(src, base);
    return path && isWithin(root, path) ? relative(root, path).split(sep).join("/") : "";
}

/** HTMLを構文木にし、危険な要素と属性を取り除いて画像を配信URLかデータURLに置き換える。 */
export async function prepareMarkup(html, { assetsBase, sourceDir = assetsBase, documentRoot, assetUrl, warnings }) {
    const root = await realpath(documentRoot);
    const imageCache = new Map();
    let embeddedBytes = 0;

    /** 画像の参照と配置場所を確認し、用途に合うURLを返す。解決できない参照は警告にする。 */
    async function imageSource(src) {
        if (!src) return undefined;
        try {
            const sourcePath = relativeImagePath(src, sourceDir, root);
            const path = isFigureImagePath(sourcePath) || sourceDir === assetsBase
                ? sourcePath : relativeImagePath(src, assetsBase, root);
            const actual = await figureImageFile(root, path);
            const mime = imageTypes.get(extname(actual));
            const info = await stat(actual);
            if (!info.isFile() || info.size > maxImageSize) throw new Error("画像が大きいか、ファイルではありません");
            if (assetUrl) {
                const url = assetUrl(actual);
                if (typeof url === "string" && url.startsWith("/api/v1/")) return url;
            }
            if (embeddedBytes + info.size > maxEmbeddedSize) throw new Error("画像の合計サイズが上限を超えています");
            embeddedBytes += info.size;
            const buffer = await readFile(actual);
            return `data:${mime};base64,${buffer.toString("base64")}`;
        } catch (error) {
            const label = src.startsWith("data:") ? "埋め込み画像" : src.slice(0, 160);
            warnings.push(`画像を読み込めません: ${label} (${error.code === "ENOENT" ? "ファイルなし" : error.message})`);
            return undefined;
        }
    }

    /** HTMLの子要素を巡回して表示用に整え、必要な画像を解決する。 */
    async function clean(nodes) {
        const kept = [];
        for (const node of nodes) {
            if (node.type === "text") {
                kept.push(node);
                continue;
            }
            if (node.name === "input" && node.attribs?.type === "checkbox" && Object.hasOwn(node.attribs, "disabled")) {
                kept.push({ type: "text", data: Object.hasOwn(node.attribs, "checked") ? "☑" : "☐" });
                continue;
            }
            if (node.type !== "tag" || !allowedTags.has(node.name)) continue;
            const attrs = node.attribs;
            const source = attrs.src;
            for (const [key, value] of Object.entries(attrs)) {
                if (key === "href" && node.name === "a" && /^(?:#|https?:\/\/|mailto:)/i.test(value)) continue;
                if (key === "style" && /url\s*\(|image-set\s*\(|[{}\\@]/i.test(value)) delete attrs[key];
                if (!plainAttributes.has(key)) delete attrs[key];
            }
            if (node.name === "img") {
                if (!imageCache.has(source)) imageCache.set(source, await imageSource(source));
                const url = imageCache.get(source);
                if (url) attrs.src = url;
            }
            node.children = await clean(node.children);
            kept.push(node);
        }
        return kept;
    }

    return serialize(await clean(parseDocument(html).children), { encodeEntities: "utf8" });
}
