/**
 * @file ローカルHTTP APIの要求・応答をGUIと共有するTypeScript契約。経路とJSONの制約は同じディレクトリのOpenAPIを参照する。
 */

/** 文書一覧に表示するID、原本候補と、原本が複数ある場合の診断。 */
export interface DocumentInfo {
  id: string;
  name: string;
  files: { path: string }[];
  conflict?: string;
}

/** ファイルの相対パス、本文と、保存時の同時編集検出に使うリビジョン。 */
export interface MarkdownFile {
  path: string;
  content: string;
  /** 取得したファイル内容のハッシュ。保存前にディスク上の値と照合する。 */
  revision: string;
}

/** 版を作った操作。復元前の退避には編集中の本文も含められる。 */
export type BackupReason = 'initial' | 'save' | 'word' | 'copilot' | 'copilot-figure' | 'before-restore';

/** 履歴一覧で表示する版の識別子、日時、原本パスと補足情報。 */
export interface BackupSummary {
  id: string;
  reason: BackupReason;
  createdAt: string;
  path: string | null;
  label?: string;
  warnings?: string[];
}

/** 過去の版を基準にした、今の文書フォルダの差分。 */
export interface BackupDetail {
  backup: BackupSummary;
  file: MarkdownFile | null;
  current: MarkdownFile | null;
  /** 比較した時点のフォルダ全体のハッシュ。 */
  currentRevision: string;
  files: { path: string; directory: boolean; change: 'added' | 'removed' | 'modified' }[];
  sharedConfigChanged: boolean;
}

/** 比較した状態と、復元前の版に含める編集中の本文。 */
export interface BackupRestoreInput {
  currentRevision: string;
  currentMarkdown?: string;
  revision?: string;
}

/** 復元した原本と、文書ツリーを更新する情報。原本がない場合は file が null になる。 */
export interface BackupRestoreResult {
  file: MarkdownFile | null;
  document: DocumentInfo;
}

/** 有効なYAMLの出所、原文、解析結果とリビジョン。無効時は解析済み設定が null になる。 */
export interface ConfigInfo {
  /** 文書フォルダ内のYAMLと、共通YAMLのどちらを選んだか。 */
  source: 'document' | 'shared';
  path: string;
  yaml: string;
  revision: string;
  config: Record<string, unknown> | null;
  diagnostics?: string[];
}

/** 文書設定のフォームが部分更新できる基本項目。送信しないキーは変更対象に含めない。 */
export interface BasicSettingsPatch {
  title?: string;
  subtitle?: string;
  titlePage?: boolean;
  paper?: string;
  orientation?: 'portrait' | 'landscape';
  toc?: boolean;
  tocDepth?: number;
  revisionHistoryVisibility?: { preview?: boolean; pdf?: boolean; docx?: boolean };
  headerFooter?: { enabled?: boolean; header?: { right?: string } };
}

/** 右側のプレビューへ表示するHTMLと描画時の警告。 */
export interface PreviewResult {
  html: string;
  warnings: string[];
}

/** ビジュアル編集で扱うMermaidの個別結果。サイズ情報付きSVGまたはエラー。 */
export type VisualDiagram = { svg: string; width: string | null; maxHeight: string | null } | { error: string };

/** 有効なDSLのうち、ビジュアル編集に必要な表示種別とスタイル。 */
export interface VisualDslDefinition {
  name: string;
  label: string;
  kind: 'text' | 'table' | 'figure' | 'separator';
  styles: Record<string, string>;
  defaults: { width?: string; height?: string };
}

/** 図表とDSLを、右のプレビューの設定に合わせて表示する情報。 */
export interface VisualLayout {
  blocks: VisualDslDefinition[];
  headingLevels: number[];
  figurePrefix: string;
  tablePrefix: string;
}

/** ビジュアル編集に表示する表紙と入力順のMermaid結果。 */
export interface VisualElements {
  cover: { html: string; hasImage: boolean } | null;
  diagrams: VisualDiagram[];
  layout: VisualLayout;
  warnings: string[];
}

/** 表紙タイトルを補う候補と、描画するMermaidソース。 */
export interface VisualElementsInput {
  fallbackTitle: string;
  diagrams: string[];
}

/** 生成したPDF・Wordの相対パス、ダウンロードURLと警告。 */
export interface ExportResult {
  path: string;
  url: string;
  warnings: string[];
}

/** DOCXから作った本文案、取り込み時の原本リビジョン、警告と履歴の版。 */
export interface WordImportResult extends MarkdownFile {
  backup: BackupSummary;
  warnings: string[];
}

/** AI依頼で選択できるテンプレートと、読み取り専用で表示するプロンプト。 */
export interface CopilotTemplateOption {
  id: string;
  label: string;
  prompt: string;
  instructionOptionalWithSources: boolean;
}

/** 現在の文書で使えるテンプレートと読込元。 */
export interface CopilotTemplateList {
  source: 'shared' | 'document';
  path: string;
  templates: CopilotTemplateOption[];
  diagnostics: string[];
}

/** 外部連携の接続状況、モデル候補、作業場所。 */
export interface IntegrationStatus {
  copilot: { available: boolean; message: string; protocolVersion?: string; models?: CopilotModel[] };
  workspace?: string;
}

/** Agent Hostが公開するモデルの選択情報。既知の場合は画像入力の可否を含む。 */
export interface CopilotModel {
  id: string;
  name: string;
  supportsVision?: boolean;
}

/** VS Codeで再開できるチャットのIDと、選択画面に使う情報。 */
export interface CopilotSession {
  id: string;
  title: string;
  modifiedAt?: string;
}

/** 対象の作業ディレクトリと、そこで使えるCopilotセッションの一覧。 */
export interface CopilotSessions {
  workspace: string;
  sessions: CopilotSession[];
}

/** 利用者が登録した資料と、フォルダ内のファイル・読み方。 */
export interface SourceRequest {
  path: string;
  /** フォルダ全体を1件のAHPディレクトリ添付として渡す。省略時はfilesで指定したファイルを渡す。 */
  scope?: 'directory';
  files?: string[];
  readingNote?: string;
}

/** 登録前に確認した資料の種類と候補、読み取りに関する警告。 */
export interface SourceInfo extends SourceRequest {
  kind: 'project' | 'file' | 'excel';
  warnings: string[];
}

/** 参照元ダイアログで表示できるフォルダの項目、親パス、件数制限の有無。 */
export interface SourceFolderContents {
  path: string;
  parent: string | null;
  entries: { name: string; path: string; kind: 'folder' | 'file' }[];
  truncated: boolean;
}

/** Copilot本文案、利用した出典、診断と、採用候補の図版。 */
export interface GenerationResult {
  markdown: string;
  sources: { path: string; range?: string; sheet?: string }[];
  warnings: string[];
  diagnostics?: GenerationDiagnostic[];
  session?: CopilotSession;
  figures?: DraftFigure[];
  /** 文法チェックを通過し、図版まで保存した版。 */
  backup?: BackupSummary;
}

/** 本文案に含まれるSVG候補と、履歴への保存時に実パスへ置換する仮参照。 */
export interface DraftFigure {
  id: string;
  name: string;
  svg: string;
  /** 本文案に埋め込まれ、図版保存後の相対パスへ置き換わる文字列。 */
  placeholder: string;
}

/** 編集案を採用する前の文法診断。可能な場合は本文内の行番号を含む。 */
export interface GenerationDiagnostic {
  severity: 'error' | 'warning';
  code: string;
  message: string;
  line?: number;
}

/** ラスタ図版の枠・矢印・文字。座標と外観に加え、種類ごとの寸法や文字情報を持つ。 */
export type FigureAnnotation = { id: string; x: number; y: number; color?: string } & (
  | { type: 'box'; width: number; height: number; strokeWidth?: number }
  | { type: 'arrow'; dx: number; dy: number; strokeWidth?: number }
  | { type: 'label'; text: string; fontSize?: number; fontWeight?: 'normal' | 'bold' }
);

/** キャンバスに置く画像の識別子、ピクセル位置と表示寸法。 */
export interface FigureImagePlacement {
  id: string;
  name?: string;
  x: number;
  y: number;
  width: number;
  height: number;
}

/** 保存済みの画像原本を指すパス付きの配置。 */
export interface FigureImage extends FigureImagePlacement {
  originalPath: string;
}

/** 文書の素材一覧に載せる画像。図版IDと素材IDで配信先を指定する。 */
export interface FigurePart {
  id: string;
  name: string;
  fileName: string;
  figureId: string;
  figureName: string;
}

/** 新しいレイヤーIDに対応するメディア種別とBase64の原本。 */
export interface FigureImageUpload {
  id: string;
  mime: string;
  base64: string;
}

/** ラスタ図版のキャンバス寸法、配置順のレイヤーと追加する画像。 */
export interface FigureCompositionInput {
  width: number;
  height: number;
  images: FigureImagePlacement[];
  uploads?: FigureImageUpload[];
}

/** 専用エージェントの応答を検証し、登録した図版。 */
export interface FigureGenerationResult {
  figure: FigureSummary;
  session?: CopilotSession;
}

/** 図版作成ジョブに渡す手元の画像素材。 */
export type FigureMaterialInput = FigureImageUpload & { name: string };

/** 図版一覧で表示する名前・種類、本文用の固定パスとリビジョン。 */
export interface FigureSummary {
  id: string;
  name: string;
  kind: 'svg' | 'raster';
  /** 原本Markdownから参照する固定の画像パス。 */
  path: string;
  revision: string;
}

/** SVG本体、またはラスタの原本・サイズ・画像レイヤー・注釈を含む編集用データ。 */
export type FigureDetail = FigureSummary & (
  | { kind: 'svg'; svg: string; mermaidSource?: string }
  | { kind: 'raster'; originalPath?: string; width: number; height: number; annotations: FigureAnnotation[]; images: FigureImage[] }
);

/** 図版を新規作成するためのSVG、またはラスタ原本と注釈・配置。 */
export type FigureCreateInput = { name: string } & (
  | { kind: 'svg'; svg: string; mermaidSource?: string; id?: string }
  | { kind: 'raster'; mime: string; base64: string; annotations?: FigureAnnotation[]; composition?: FigureCompositionInput }
  | { kind: 'raster'; mime?: never; base64?: never; annotations?: FigureAnnotation[]; composition: FigureCompositionInput }
);

/** 取得時のリビジョンで競合を確認し、既存の図版の編集内容を更新する要求。 */
export type FigureUpdateInput = { revision: string } & (
  | { kind: 'rename'; name: string }
  | { kind: 'svg'; svg: string }
  | { kind: 'raster'; annotations: FigureAnnotation[]; composition?: FigureCompositionInput }
);

/** HTTPまたはジョブが返す機械判定用のコード、表示メッセージ、任意の詳細。 */
export interface ResponseError {
  code: string;
  message: string;
  details?: unknown;
}

/** 変換・生成処理の進行状態と、完了した結果または失敗理由。 */
export interface Job<T> {
  id: string;
  type: JobPayload['type'];
  status: 'queued' | 'running' | 'succeeded' | 'failed' | 'canceled';
  progress?: string;
  /** 成功した場合に、種別に対応する結果を格納する。 */
  result?: T;
  error?: ResponseError | string;
}

/** 変換・生成の各種別で受付時に必要な入力。type で種別ごとの項目を判別する。 */
export type JobPayload = { documentId: string } & (
  | { type: 'pdf'; path: string; revision: string; includeRevisionHistory?: boolean }
  | { type: 'docx'; path: string; revision: string }
  | { type: 'docx-import'; path: string; revision: string; name: string; base64: string }
  | { type: 'generate'; path?: string; revision?: string; templateId: string; instruction: string; sources: SourceRequest[]; sessionId?: string; modelId?: string }
  | { type: 'compose-figure'; images: FigureMaterialInput[]; instruction: string; sessionId?: string; modelId?: string }
);
