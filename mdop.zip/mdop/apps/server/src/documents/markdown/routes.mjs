/**
 * @file 文書一覧と原本Markdownの読み書きをHTTPで提供する。
 */

import { readJson, sendJson } from "../../common/api/http.mjs";

/** 文書と原本のルートを登録する。 */
export function markdownRoutes(documents) {
    return [
        ["GET", "/documents", async (_request, response) => sendJson(response, 200, { documents: await documents.list() })],
        ["POST", "/documents", async (request, response) => {
            const { name } = await readJson(request);
            return sendJson(response, 201, { document: await documents.create(name) });
        }],
        ["GET", "/documents/:id/files", async (_request, response, { id }, url) =>
            sendJson(response, 200, await documents.read(id, url.searchParams.get("path")))],
        ["POST", "/documents/:id/files", async (request, response, { id }) => {
            const { path, content } = await readJson(request);
            return sendJson(response, 201, await documents.createFile(id, path, content));
        }],
        ["PUT", "/documents/:id/files", async (request, response, { id }) => {
            const { path, content, revision } = await readJson(request);
            return sendJson(response, 200, await documents.save(id, path, content, revision));
        }],
    ];
}
