/**
 * @file AI編集案のDSL、図表参照、Mermaidの診断を、行番号を含めて検証する。
 */

import assert from "node:assert/strict";
import test from "node:test";
import { resolveRenderingDsl } from "./settings.mjs";
import { validateGeneratedMarkdown } from "./validate-markdown.mjs";

/** 有効なカスタムDSLを認め、コード例に含まれる記法を診断しないことを検証する。 */
test("generated Markdown accepts effective DSL and ignores literal syntax", async () => {
    const dsl = resolveRenderingDsl({ dsl: { blocks: [{ name: "note", element: "div", class: "note" }] } });
    const markdown = [
        "# 概要",
        "",
        ":::note",
        "補足",
        ":::",
        "",
        "`{{ref:inline}}` と <!-- {{ref:comment}} -->",
        "本文 <!--",
        ":::unknown",
        "{{ref:comment}}",
        ":::",
        "-->",
        "",
        "````markdown",
        ":::unknown",
        "{{ref:example}}",
        "```mermaid",
        "this is only an example",
        "```",
        ":::",
        "````",
    ].join("\r\n");
    const diagnostics = await validateGeneratedMarkdown(markdown, {
        dsl, renderMermaid: async () => assert.fail("literal Mermaid example"),
    });
    assert.deepEqual(diagnostics, []);
});

/** 本文内の記法、参照、設定情報の誤りが、修正すべき行に対応することを検証する。 */
test("generated Markdown reports format and references on source lines", async () => {
    const source = [
        "---",
        "title: 表紙",
        "---",
        "",
        "## 仕様変更履歴",
        ":::figure id=shared",
        "図",
        ":::",
        ":::table id=shared",
        "| A |",
        "| --- |",
        ":::",
        "正しい図表 {{ref:shared}}、未定義 [[ref:missing]]",
        ":::revision-history",
        "履歴",
        ":::",
        ":::warning",
        "閉じ忘れ",
    ].join("\n");
    const diagnostics = await validateGeneratedMarkdown(source);
    assert.deepEqual(diagnostics.map(({ code, line }) => [code, line]), [
        ["FRONTMATTER", 1], ["DUPLICATE_REFERENCE_ID", 9], ["UNRESOLVED_REFERENCE", 13],
        ["UNKNOWN_DSL", 14], ["UNCLOSED_DSL", 17],
    ]);
    assert.ok(diagnostics.every(finding => finding.severity === "error"));
});

/** 描画に失敗したMermaidを、コードフェンスの開始行で報告することを検証する。 */
test("generated Markdown validates Mermaid source and points to its opening fence", async () => {
    const source = [
        "# テスト",
        ":::figure height=120px",
        "```mermaid",
        "flowchart LR",
        "  A --> B",
        "```",
        ":::",
        "",
        "~~~mermaid",
        "invalid source",
        "~~~",
    ].join("\n");
    const seen = [];
    const diagnostics = await validateGeneratedMarkdown(source, {
        renderMermaid: async code => {
            seen.push(code);
            if (code.includes("invalid")) throw new Error("parse error");
        },
    });
    assert.equal(seen.length, 2);
    assert.match(seen[0], /%%height:120px%%[\s\S]*A --> B/);
    assert.match(seen[1], /invalid source/);
    assert.deepEqual(diagnostics, [{
        severity: "error", code: "INVALID_MERMAID", message: "Mermaidの図を描画できません: parse error", line: 9,
    }]);
});

/** 図表の宣言が参照より後にある場合も、IDを解決できることを検証する。 */
test("generated Markdown resolves forward figure references", async () => {
    const markdown = "詳しくは {{ref:login-flow}} を参照します。\n\n:::figure id=login-flow\n図の説明\n:::\n";
    assert.deepEqual(await validateGeneratedMarkdown(markdown), []);
});
