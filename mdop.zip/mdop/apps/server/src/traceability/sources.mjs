/** 根拠資料の URI と、Office 資料の位置を保った読み取り用本文を用意する。 */
import { lstat, readFile, readdir, realpath } from 'node:fs/promises';
import { basename, extname, isAbsolute, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import JSZip from 'jszip';
import mammoth from 'mammoth';
import { parseDocument } from 'htmlparser2';
import { ApiError } from '../common/api/errors.mjs';

const excluded = new Set(['.git', '.runs', 'backups', 'node_modules', 'dist', 'build', 'coverage', '.aws', '.ssh']);
const fileLimit = 500;
const textLimit = 250_000;
const bytesLimit = 16 * 1024 * 1024;
const textExtensions = new Set('.md .markdown .txt .csv .tsv .json .yaml .yml .xml .html .css .js .mjs .ts .tsx .jsx .py .cs .java .kt .go .rs .c .h .cpp .sql .sh .ps1 .toml'.split(' '));

function children(node, name) {
  return (node.children ?? []).filter(child => child.name === name);
}
function descendants(node, name) {
  return (node.children ?? []).flatMap(child => [...(child.name === name ? [child] : []), ...descendants(child, name)]);
}
function text(node) {
  return node.type === 'text' ? node.data : (node.children ?? []).map(text).join('');
}
function xml(value) {
  return parseDocument(value, { xmlMode: true, decodeEntities: true });
}

export function sourcePath(uri, root) {
  if (typeof uri !== 'string' || !uri.trim() || uri.includes('\0')) throw new ApiError(400, 'INVALID_SOURCE', '元・先の資料を指定してください。');
  const value = uri.trim();
  if (value.startsWith('file:')) {
    try { return fileURLToPath(value); } catch { throw new ApiError(400, 'INVALID_SOURCE', 'ローカルのファイル URI を指定してください。'); }
  }
  if (/^[a-z][\w+.-]*:/i.test(value) && !/^[a-z]:[\\/]/i.test(value)) throw new ApiError(400, 'INVALID_SOURCE', 'ローカルの資料を指定してください。');
  return isAbsolute(value) ? value : resolve(root, value);
}

export async function normalizeSource(uri, root) {
  const path = sourcePath(uri, root);
  const info = await lstat(path).catch(error => { throw new ApiError(400, 'SOURCE_NOT_FOUND', '指定した資料を開けません。', { reason: error.code }); });
  if (info.isSymbolicLink() || (!info.isFile() && !info.isDirectory())) throw new ApiError(400, 'INVALID_SOURCE', '通常のファイルまたはフォルダを指定してください。');
  return pathToFileURL(await realpath(path)).href;
}

async function officeText(path, extension, buffer) {
  if (extension === '.docx') {
    const result = await mammoth.convertToHtml({ buffer });
    const document = parseDocument(result.value);
    const blocks = (node) => (node.children ?? []).flatMap(child =>
      /^(p|h[1-6])$/.test(child.name ?? '') ? [child] : blocks(child));
    const paragraphs = blocks(document).map((node, index) => `${node.name === 'p' ? '段落' : '見出し'}${index + 1}: ${text(node)}`);
    const tables = descendants(document, 'table').map((table, index) => descendants(table, 'tr').map((row, rowIndex) =>
      `表${index + 1} 行${rowIndex + 1}: ${children(row, 'td').map((cell, column) => `列${column + 1}=${text(cell)}`).join(' | ')}`).join('\n'));
    return { body: [...paragraphs, ...tables].join('\n'), unread: result.messages.map(item => `${path}: ${item.message}`) };
  }
  const zip = await JSZip.loadAsync(buffer);
  const read = async name => {
    const file = zip.file(name);
    if (!file) throw new Error(`Excel の ${name} を読み取れません。`);
    if (file._data?.uncompressedSize > bytesLimit) throw new Error('Excel の展開サイズが上限を超えています。');
    return file.async('string');
  };
  const strings = zip.file('xl/sharedStrings.xml')
    ? descendants(xml(await read('xl/sharedStrings.xml')), 'si').map(text) : [];
  const book = xml(await read('xl/workbook.xml'));
  const relationships = descendants(xml(await read('xl/_rels/workbook.xml.rels')), 'Relationship');
  const parts = [];
  const unread = [];
  for (const sheet of descendants(book, 'sheet')) {
    const name = sheet.attribs.name;
    const relation = relationships.find(item => item.attribs.Id === sheet.attribs['r:id']);
    try {
      let target = relation?.attribs.Target;
      if (!target || target.includes('..')) throw new Error('シートの位置を解決できません。');
      target = target.startsWith('/') ? target.slice(1) : 'xl/' + target;
      const rows = descendants(xml(await read(target)), 'row').map(row => children(row, 'c').map(cell => {
        const value = children(cell, 'v')[0];
        const data = cell.attribs.t === 's' ? strings[Number(value && text(value))] : value ? text(value) : text(cell);
        return `${cell.attribs.r}=${data ?? ''}`;
      }).join(' | '));
      parts.push(`シート「${name}」\n${rows.join('\n')}`);
    } catch (error) { unread.push(`${path} シート「${name}」: ${error.message}`); }
  }
  return { body: parts.join('\n\n'), unread };
}

/** 元 URI を添付し、展開できた資料には位置付き本文を添える。 */
export async function prepareTraceabilitySources(uris, root, signal) {
  const attachments = [];
  const read = [];
  const unread = [];
  const parts = [];
  let count = 0;
  let length = 0;
  async function visit(path) {
    signal?.throwIfAborted();
    if (++count > fileLimit || length >= textLimit) { unread.push(`${path}: 資料の列挙・本文量の上限`); return; }
    try {
      const info = await lstat(path);
      if (info.isSymbolicLink()) { unread.push(`${path}: リンクは読み取り対象外`); return; }
      if (info.isDirectory()) {
        for (const entry of await readdir(path, { withFileTypes: true })) {
          if (entry.isDirectory() && (excluded.has(entry.name.toLowerCase()) || entry.name.toLowerCase() === 'traceabilities')) continue;
          if (entry.name.startsWith('.env')) continue;
          await visit(join(path, entry.name));
          if (count > fileLimit || length >= textLimit) { unread.push(`${path}: 残りの項目は列挙・本文量の上限で未読`); break; }
        }
        return;
      }
      const extension = extname(path).toLowerCase();
      if (info.size > bytesLimit) { unread.push(`${path}: 16 MiB を超える資料`); return; }
      if (!textExtensions.has(extension) && !['.xlsx', '.docx'].includes(extension)) { unread.push(`${path}: 本文の変換対象外。元 URI を参照`); return; }
      const buffer = await readFile(path);
      const converted = ['.xlsx', '.docx'].includes(extension)
        ? await officeText(path, extension, buffer) : { body: buffer.toString('utf8'), unread: [] };
      const body = converted.body.slice(0, Math.max(0, textLimit - length));
      if (body.length < converted.body.length) unread.push(`${path}: 本文が上限で打ち切られた`);
      length += body.length;
      read.push(pathToFileURL(path).href);
      unread.push(...converted.unread);
      parts.push(`資料 ${pathToFileURL(path).href}\n${body}`);
    } catch (error) {
      signal?.throwIfAborted();
      unread.push(`${path}: ${error.message}`);
    }
  }
  for (const uri of [...new Set(uris)]) {
    const path = sourcePath(uri, root);
    const normalized = pathToFileURL(path).href;
    const info = await lstat(path).catch(() => null);
    attachments.push({ kind: 'file', uri: normalized, label: basename(path), role: info?.isDirectory() ? 'directory' : 'document' });
    await visit(path);
  }
  return { attachments, body: parts.join('\n\n'), scope: { read, unread } };
}
