/**
 * @file ブラウザーに渡す文書資産のURLと、配信時のHTTPヘッダーを組み立てる。
 */

import { isAbsolute, relative, sep } from "node:path";

/** 文書IDと相対パスをエンコードし、資産配信用のAPI URLを作る。 */
export function assetLink(id, path) {
    return `/api/v1/documents/${encodeURIComponent(id)}/assets?path=${encodeURIComponent(path)}`;
}

/** ファイルが文書ルートの内側にあるときだけプレビュー用の資産URLを返す。 */
export function previewAssetLink(id, folder, absolute) {
    if (typeof absolute !== "string" || !isAbsolute(absolute)) return undefined;
    const inside = relative(folder, absolute);
    if (!inside || inside === ".." || inside.startsWith(`..${sep}`) || isAbsolute(inside)) return undefined;
    return assetLink(id, inside.split(sep).join("/"));
}

/** SVGのブラウザー表示と、変換成果物のダウンロードに必要な応答ヘッダーを返す。 */
export function assetHeaders(asset) {
    if (asset.type === "image/svg+xml") {
        return { "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox" };
    }
    if (asset.type.startsWith("image/")) return {};
    return { "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(asset.name).replace(/['()*]/g, char => `%${char.charCodeAt(0).toString(16)}`)}` };
}
