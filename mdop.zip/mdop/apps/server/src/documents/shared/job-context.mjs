/**
 * @file 文書ジョブの受付で、リビジョンと出力条件を確認する。
 */

import { badRequest, conflict } from "../../common/api/errors.mjs";

/** 改訂履歴の個別指定を受け付けるのはPDFジョブだけとする。 */
export function assertRevisionHistoryOption({ type, includeRevisionHistory }) {
    if (includeRevisionHistory !== undefined && (type !== "pdf" || typeof includeRevisionHistory !== "boolean")) {
        throw badRequest("includeRevisionHistory はPDF出力で true または false を指定してください。");
    }
}

/** ジョブ要求に原本リビジョンが指定されている場合は、読み取った原本と比較する。 */
function assertRevision(input, original) {
    if (input.revision !== undefined && input.revision !== original.revision) {
        throw conflict("保存後に原本Markdownが更新されました。最新の内容を読み込んでください。", { revision: original.revision });
    }
}

/** ジョブを登録する前に、対象文書・原本のリビジョン・復元状態を取得する。 */
export async function readJobDocument(documents, input) {
    const id = input.documentId;
    const expectedRestore = documents.restoreVersion(id);
    const folder = await documents.documentRoot(id);
    const original = await documents.read(id, input.path);
    assertRevision(input, original);
    return { id, expectedRestore, folder, original };
}
