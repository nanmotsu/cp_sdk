import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import test from 'node:test';
import JSZip from 'jszip';
import { createTraceabilityStore, resolveTraceabilityFolder } from '../apps/server/src/traceability/store.mjs';
import { createTraceabilityAssistance } from '../apps/server/src/traceability/assistance.mjs';
import { prepareTraceabilitySources } from '../apps/server/src/traceability/sources.mjs';

test('関係ごとのセッションを再利用し、重複・失効した対応を置き換える', async t => {
  const root = await mkdtemp(join(tmpdir(), 'mdop-traceability-session-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await writeFile(join(root, 'requirements.md'), '# 要件\n登録と取消');
  await writeFile(join(root, 'spec.md'), '# 仕様\n登録処理');
  const calls = [];
  const live = new Set();
  const agent = {
    async listSessions() { return [...live].map(id => ({ id })); },
    async complete(input) {
      calls.push(input);
      const sessionId = input.sessionId ?? 'ahp-session:/' + randomUUID();
      live.add(sessionId);
      const context = JSON.parse(input.prompt.split('\n\n')[1]);
      const value = context.operation === 'related'
        ? { status: '関連あり', reason: '同じ製品' }
        : { items: [{ id: 'S1', content: '登録', location: '要件1' }], scope: { read: ['要件1'], unread: [] } };
      return { text: context.mode === 'check' ? '検査結果 S1 は整合' : JSON.stringify({ ...context, candidate: value }), session: { id: sessionId } };
    },
  };
  const store = createTraceabilityStore(root);
  const assistance = createTraceabilityAssistance({ root, store, agent });
  const selection = { name: '同名', sourceUri: 'requirements.md', targetUri: 'spec.md', granularity: '要件ごと' };
  const A = await assistance.create({ ...selection, requestId: randomUUID() }, {});
  const B = await assistance.create({ ...selection, requestId: randomUUID() }, {});
  const bindingA = await store.getSession(A.id);
  const bindingB = await store.getSession(B.id);
  assert.notEqual(bindingA.sessionId, bindingB.sessionId);
  await assistance.run(A.id, { stage: 'source', mode: 'generate', revision: (await store.get(A.id)).revision }, {});
  assert.equal(calls.at(-1).sessionId, bindingA.sessionId);
  assert.match(calls.at(-1).prompt, /登録と取消/);
  assert.equal(calls.at(-1).attachments[0].uri, pathToFileURL(join(root, 'requirements.md')).href);
  // 再起動後のアプリでも、他の関係が同じセッションを指す場合には新しく作る。
  await store.setSession(B.id, { relationId: B.id, sessionId: bindingA.sessionId });
  const restarted = createTraceabilityAssistance({ root, store, agent });
  const configBeforeCheck = await readFile(join(await resolveTraceabilityFolder(root, A.id), 'traceability.json'), 'utf8');
  const check = await restarted.run(A.id, { stage: 'source', mode: 'check', revision: (await store.get(A.id)).revision }, {});
  assert.equal(calls.at(-1).sessionId, undefined);
  assert.equal(await readFile(join(await resolveTraceabilityFolder(root, A.id), 'traceability.json'), 'utf8'), configBeforeCheck);
  live.delete(check.session.id);
  await restarted.run(A.id, { stage: 'source', mode: 'check', revision: (await store.get(A.id)).revision }, {});
  assert.equal(calls.at(-1).sessionId, undefined);
  assert.deepEqual((await store.get(B.id)).source.items, []);
});

test('Excel はシートとセル、Word は見出しと表の位置を本文に残す', async t => {
  const root = await mkdtemp(join(tmpdir(), 'mdop-traceability-office-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const workbook = new JSZip();
  workbook.file('xl/workbook.xml', '<workbook><sheets><sheet name="登録" r:id="r1"/><sheet name="取消" r:id="r2"/></sheets></workbook>');
  workbook.file('xl/_rels/workbook.xml.rels', '<Relationships><Relationship Id="r1" Target="worksheets/sheet1.xml"/><Relationship Id="r2" Target="worksheets/missing.xml"/></Relationships>');
  workbook.file('xl/sharedStrings.xml', '<sst><si><t>ユーザー登録</t></si></sst>');
  workbook.file('xl/worksheets/sheet1.xml', '<worksheet><sheetData><row><c r="A1" t="s"><v>0</v></c><c r="B1" t="inlineStr"><is><t>確認</t></is></c></row></sheetData></worksheet>');
  await writeFile(join(root, 'requirements.xlsx'), await workbook.generateAsync({ type: 'nodebuffer' }));
  const docx = new JSZip();
  docx.file('[Content_Types].xml', '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>');
  docx.file('_rels/.rels', '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>');
  docx.file('word/document.xml', '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:t>登録仕様</w:t></w:r></w:p><w:tbl><w:tr><w:tc><w:p><w:r><w:t>登録可能</w:t></w:r></w:p></w:tc></w:tr></w:tbl></w:body></w:document>');
  await writeFile(join(root, 'spec.docx'), await docx.generateAsync({ type: 'nodebuffer' }));
  await mkdir(join(root, 'backups'));
  await writeFile(join(root, 'backups', 'old.md'), '過去の誤った要件');
  const result = await prepareTraceabilitySources([root], root);
  assert.match(result.body, /シート「登録」/);
  assert.match(result.body, /A1=ユーザー登録/);
  assert.match(result.body, /B1=確認/);
  assert.ok(result.scope.unread.some(item => item.includes('取消')));
  assert.match(result.body, /登録仕様/);
  assert.match(result.body, /表1 行1: 列1=登録可能/);
  assert.doesNotMatch(result.body, /過去の誤った要件/);
});

test('途中失敗は完了段階を保持し、再開時には固定表を再生成しない', async t => {
  const root = await mkdtemp(join(tmpdir(), 'mdop-traceability-pipeline-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  await writeFile(join(root, 'a.md'), '# 元\n登録');
  await writeFile(join(root, 'b.md'), '# 先\n登録する');
  let fail = true;
  const operations = [];
  const agent = {
    async listSessions() { return []; },
    async complete(input) {
      const ctx = JSON.parse(input.prompt.split('\n\n')[1]);
      operations.push(ctx.operation);
      if (ctx.operation === 'target' && fail) throw new Error('試験用タイムアウト');
      const candidate = ctx.operation === 'related' ? { status: '関連あり', reason: '登録' }
        : ctx.operation === 'map' ? [{ id: 'M1', sourceId: 'S1', targetIds: ['T1'], degree: '全', detail: '登録処理' }]
        : { items: [{ id: ctx.operation === 'source' ? 'S1' : 'T1', content: '登録', location: '第1節' }], scope: { read: ['第1節'], unread: [] } };
      return { text: JSON.stringify({ ...ctx, candidate }) };
    },
  };
  const store = createTraceabilityStore(root);
  const assistance = createTraceabilityAssistance({ root, store, agent });
  const created = await assistance.create({ requestId: randomUUID(), name: '登録', sourceUri: 'a.md', targetUri: 'b.md', granularity: '要件' }, {});
  let group;
  await assert.rejects(assistance.run(created.id, { stage: 'source', mode: 'generate', throughEnd: true, revision: (await store.get(created.id)).revision }, {}), error => {
    assert.match(error.message, /タイムアウト/);
    assert.equal(error.details.completedStages[0].stage, 'source');
    group = error.details.groupId;
    return true;
  });
  const partial = await store.get(created.id);
  assert.equal(partial.source.items[0].id, 'S1');
  assert.equal(partial.target.items.length, 0);
  assert.ok((await store.history(created.id)).filter(item => item.groupId === group).length >= 3);
  await store.save(created.id, { revision: partial.revision, fixedFiles: ['source-items.json'] });
  fail = false;
  operations.length = 0;
  await assistance.run(created.id, { stage: 'source', mode: 'generate', throughEnd: true, revision: (await store.get(created.id)).revision }, {});
  assert.deepEqual(operations, ['target', 'map']);
  assert.equal((await store.get(created.id)).mappings.rows[0].degree, '全');
});
