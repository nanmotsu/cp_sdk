/**
 * @file 文書別・共通のYAMLファイルを選び、容量制限を適用して読み込む。
 */

import { readFile } from "node:fs/promises";
import yaml from "js-yaml";
import { statIfPresent, workspacePath } from "../../common/filesystem/paths.mjs";

export const CONFIG_LIMIT = 256 * 1024;

/** 文書別ファイルが置かれていれば、そのファイル全体を使う。 */
export async function readDocumentYaml(documentsRoot, documentRoot, name) {
    const localPath = await workspacePath(documentRoot, name, { mayBeMissing: true });
    const localStat = await statIfPresent(localPath);
    const source = localStat ? "document" : "shared";
    const path = localStat ? name : `documents/${name}`;
    const selected = localStat ? localPath : await workspacePath(documentsRoot, name, { mayBeMissing: true });
    const stat = localStat ?? await statIfPresent(selected);
    if (stat?.size > CONFIG_LIMIT) {
        return { source, path, yaml: "", state: "overflow", signature: `${stat.size}:${stat.mtimeMs}`,
            diagnostics: [`${name} の上限は 256 KiB です。`] };
    }
    try {
        const yaml = await readFile(selected, "utf8");
        return { source, path, yaml, state: "read", signature: yaml, diagnostics: [] };
    } catch (error) {
        if (error.code !== "ENOENT") throw error;
        return { source, path, yaml: "", state: "missing", signature: "", diagnostics: [`${path} がありません。`] };
    }
}

/** YAMLを読み込み、設定として扱える大きさと階層に収まることを確認する。 */
export function loadYaml(source) {
    const config = yaml.load(source, { schema: yaml.JSON_SCHEMA });
    const visiting = new Set();
    let size = 0;
    /** ノード数・深さ・循環参照と、設定オブジェクトで許可しないキーを検査する。 */
    function validateTree(value, depth) {
        if (++size > 10000 || depth > 32 || visiting.has(value)) {
            throw new Error("設定の階層、項目数、またはYAMLエイリアスを確認してください。");
        }
        if (value === null || typeof value !== "object") return;
        visiting.add(value);
        for (const [key, child] of Object.entries(value)) {
            if (["__proto__", "constructor", "prototype"].includes(key)) throw new Error(`使用できない設定キーです: ${key}`);
            validateTree(child, depth + 1);
        }
        visiting.delete(value);
    }
    validateTree(config, 0);
    return config;
}
