/**
 * @file Markdownの編集案から、本文に挿入する編集可能なSVG図版を取り出す。
 */

import { randomUUID } from "node:crypto";
import { scanDocumentSyntax } from "../shared/markdown-syntax.mjs";
import { normalizeFigureSvg } from "../shared/svg.mjs";

const language = "md-operator-figure";
const figureLimit = 12;

// A figure fence occupies the position of the eventual Markdown image. Ordinary
// Mermaid fences and examples nested inside other code fences remain Markdown.
/** 図版用のコードフェンスを検査し、有効なSVGを仮参照へ置換する。不正な図版には本文上の位置付き診断を返す。 */
export function extractDraftFigures(markdown) {
    const diagnostics = [];
    const figures = [];
    const chunks = [];
    let offset = 0;
    let removedLines = 0;
    let opening;

    for (const entry of scanDocumentSyntax(markdown)) {
        if (entry.kind === "fence-open" && entry.language === language) opening = entry;
        if (entry.kind !== "fence-close" || !opening) continue;

        try {
            if (figures.length >= figureLimit) throw new Error(`一度に提案できる図版は${figureLimit}点までです。`);
            const title = markdown.slice(opening.start, opening.end)
                .trim().replace(/^(`{3,}|~{3,})[ \t]*md-operator-figure\b/i, "").trim();
            const name = Array.from(title).slice(0, 120).join("") || `図版 ${figures.length + 1}`;
            const svg = normalizeFigureSvg(markdown.slice(opening.end, entry.start));
            const id = randomUUID();
            const placeholder = `./__md_operator_figures__/${id}.svg`;
            const alt = name.replace(/[\\[\]]/g, "\\$&");
            const indent = /^ {0,3}/.exec(markdown.slice(opening.start))[0];
            const lineEnding = /(?:\r?\n)$/.exec(markdown.slice(entry.start, entry.end))?.[0] ?? "";
            chunks.push(markdown.slice(offset, opening.start), `${indent}![${alt}](${placeholder})${lineEnding}`);
            offset = entry.end;
            removedLines += entry.line - opening.line;
            figures.push({ id, name, svg, placeholder });
        } catch (error) {
            diagnostics.push({ severity: "error", code: "INVALID_DRAFT_FIGURE", line: opening.line - removedLines,
                message: `編集可能な図版を作成できませんでした。 ${error.message}` });
        }
        opening = undefined;
    }

    if (opening) {
        diagnostics.push({ severity: "error", code: "UNCLOSED_DRAFT_FIGURE", line: opening.line - removedLines,
            message: "編集可能な図版のコードフェンスを閉じてください。" });
    }
    chunks.push(markdown.slice(offset));
    return { markdown: chunks.join(""), figures, diagnostics };
}
