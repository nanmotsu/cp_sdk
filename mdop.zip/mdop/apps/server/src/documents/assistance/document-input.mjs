/**
 * @file 生成エージェントが参照する保存済み原本のファイル添付を用意する。
 */

import { pathToFileURL } from 'node:url';
import { badRequest } from '../../common/api/errors.mjs';
import { workspacePath } from '../../common/filesystem/paths.mjs';

/** 保存済みの原本を、文書全体の読み取り範囲付きで添付する。 */
export async function prepareDocumentInput(folder, { path, content: markdown }, signal) {
    if (markdown.length > 120_000) throw badRequest('原本のMarkdownは120000文字以内で指定してください。');
    signal?.throwIfAborted();
    const file = await workspacePath(folder, path);
    const lines = markdown.split(/\r\n|\r|\n/);
    const range = { start: { line: 0, character: 0 }, end: { line: lines.length - 1, character: lines.at(-1).length } };
    return {
        attachments: [{ kind: 'file', uri: pathToFileURL(file).href, label: path, role: 'document', ...(markdown && { range }) }],
        hasText: Boolean(markdown.trim()),
    };
}
